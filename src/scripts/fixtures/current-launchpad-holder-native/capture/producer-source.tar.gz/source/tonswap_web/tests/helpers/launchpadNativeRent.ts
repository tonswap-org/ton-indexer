import { expect } from 'vitest';
import type { launchpadNativeWorld } from './launchpadNativeWire';
export async function launchpadNativeRent(f:Awaited<ReturnType<typeof launchpadNativeWorld>>){
 const core=await import('../../../tonswap_tolk/node_modules/@ton/core');
   const freeze=async(account:Awaited<ReturnType<typeof f.chain.getContract>>)=>{
    const saved=account.account;if(!saved.account||saved.account.storage.state.type!=='active')throw Error('active holder');const init=saved.account.storage.state.state;
    // Every boundary remains native: protect other accounts, charge rent at a
    // temporary config18 rate, and later restore with the exact retained init.
    for(const raw of new Set(f.captured.map(t=>t.account))){if(raw===account.address.toRawString()||raw===f.admin.address.toRawString())continue;const to=core.Address.parse(raw);if((await f.chain.getContract(to)).accountState?.type==='active')await f.admin.send({to,value:core.toNano('100'),body:core.Cell.EMPTY});}
    const oldConfig=f.chain.config,at=Math.max(f.chain.now!+1,saved.account.storageStats.lastPaid+1),elapsed=BigInt(at-saved.account.storageStats.lastPaid),rate=saved.account.storageStats.used.bits+500n*saved.account.storageStats.used.cells,factor=(saved.account.storage.balance.coins+core.toNano('.15'))*65536n/(rate*elapsed)+1n;
    const cfg=core.Dictionary.loadDirect(core.Dictionary.Keys.Int(32),core.Dictionary.Values.Cell(),oldConfig.beginParse()),storage=core.Dictionary.empty(core.Dictionary.Keys.Uint(32),{serialize(_v:number,b:import('../../../tonswap_tolk/node_modules/@ton/core').Builder){b.storeUint(0xcc,8).storeUint(0,32).storeUint(factor,64).storeUint(500n*factor,64).storeUint(1,64).storeUint(500,64);},parse(){return 0;}}).set(0,0);cfg.set(18,core.beginCell().storeDictDirect(storage).endCell());f.chain.setConfig(core.beginCell().storeDictDirect(cfg).endCell());f.chain.now=at;
    try{await f.admin.send({to:account.address,value:0n,body:core.Cell.EMPTY});}finally{f.chain.setConfig(oldConfig);}expect(account.accountState?.type).toBe('frozen');return init;
   };
   const restore=async(account:Awaited<ReturnType<typeof f.chain.getContract>>,init:Awaited<ReturnType<typeof freeze>>)=>{await f.admin.send({to:account.address,init,value:core.toNano('1000'),body:core.Cell.EMPTY});expect(account.accountState?.type).toBe('active');};
 return{freeze,restore};
}
