import { expect,it } from 'vitest';
import { mkdirSync,writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { describeWire } from '../helpers/contractSandbox';
import { launchpadNativeWorld } from '../helpers/launchpadNativeWire';
import { launchpadNativeRent } from '../helpers/launchpadNativeRent';
import { nativeLaunchpadProof } from '../helpers/launchpadEvidence';
import { prepareLaunchControl,prepareLaunchTransfer } from '../../services/launchpadContracts';
import { verifyCurrentT3Transaction } from '../../services/t3CurrentEvidence';

describeWire('current Launchpad holder loss evidence',()=>{
 for(const scenario of ['notification','lost-bounce'] as const)it.each(['default','x6'] as const)(`${scenario} retains exact original and current holder recovery state (%s)`,async config=>{
  const f=await launchpadNativeWorld(config,0,true,true);try{
   const core=await import('../../../tonswap_tolk/node_modules/@ton/core'),{ManualRouter,sentTo}=await import('../../../tonswap_tolk/tests/helpers/ManualRouter');
   const {freeze,restore}=await launchpadNativeRent(f);
   await f.arm();f.chain.now=f.terms.startTime;
   let start:number,proof:ReturnType<typeof nativeLaunchpadProof>;
   const holder=await f.chain.getContract(f.sale.address),wallet=await f.chain.getContract((await f.sale.getJettonSlots()).get(0)!.wallet!);
   if(scenario==='notification'){
    const plan=await prepareLaunchTransfer({owner:f.buyerAddress,target:f.saleAddress,kind:'contribute',amount:7_000_000_000n,minTokens:1n,queryId:70n},f.options),saved=await freeze(holder);start=f.captured.length;await f.send(plan,f.other);proof=nativeLaunchpadProof(f,plan,'contribute',start,f.buyerAddress,70n);expect(proof.result.status).toBe('pending');await restore(holder,saved);
    expect((await f.sale.getEntry(f.other.address)).paid).toBe(0n);
   }else{
    await f.send(await prepareLaunchTransfer({owner:f.buyerAddress,target:f.saleAddress,kind:'contribute',amount:2_000_000_000n,minTokens:1n,queryId:71n},f.options),f.other);f.chain.now=f.terms.endTime;
    await f.send(await prepareLaunchControl({owner:f.buyerAddress,target:f.saleAddress,kind:'finalize',queryId:72n},f.options),f.other);
    const plan=await prepareLaunchControl({owner:f.buyerAddress,target:f.saleAddress,kind:'claim',queryId:73n},f.options),router=new ManualRouter(f.chain);start=f.captured.length;
    const body=f.other.createTransfer({sendMode:core.SendMode.PAY_GAS_SEPARATELY+core.SendMode.IGNORE_ERRORS,messages:[core.internal({to:f.sale.address,value:plan.value,body:core.Cell.fromBase64(plan.body.toBoc().toString('base64'))})]}),ownerTx=await(await f.chain.getContract(f.other.address)).receiveMessage(core.external({to:f.other.address,body}),{now:f.chain.now});router.enqueue(...ownerTx.outMessages.values().filter(m=>m.info.type==='internal'));
    await router.drain(m=>sentTo(m,wallet.address)&&m.body.bits.length>=32&&m.body.beginParse().preloadUint(32)===0x0f8a7ea5);
    const ws=await freeze(wallet),hs=await freeze(holder);await router.deliver(router.pending.findIndex(m=>sentTo(m,wallet.address)));await router.deliver(router.pending.findIndex(m=>sentTo(m,holder.address)));await router.drain();proof=nativeLaunchpadProof(f,plan,'claim',start,f.buyerAddress,73n,true);expect(proof.result.status).toBe('accepted');await restore(wallet,ws);await restore(holder,hs);
    expect((await f.sale.getEntry(f.other.address)).paid).toBe(0n);expect(await f.sale.getOwed(0,f.other.address)).toBe(0n);
   }
   const txs=f.captured.slice(start),decoded=txs.map(verifyCurrentT3Transaction),source=decoded.find(t=>t.account===wallet.address.toRawString()&&t.tx.inMessage?.body.bits.length!>=32&&t.tx.inMessage?.body.beginParse().preloadUint(32)===(scenario==='notification'?0x5433444c:0x0f8a7ea5)),target=decoded.find(t=>t.account===holder.address.toRawString()&&!t.succeeded&&(scenario==='notification'?t.tx.inMessage?.body.beginParse().preloadUint(32)===0x7362d09c:t.tx.inMessage?.info.type==='internal'&&t.tx.inMessage.info.bounced));
   expect(source).toBeTruthy();expect(target).toBeTruthy();expect((await f.sale.getRecovery())!.pending).toBe(0n);
   if(process.env.TONSWAP_LAUNCHPAD_HOLDER_CAPTURE_DIR){const dir=join(process.env.TONSWAP_LAUNCHPAD_HOLDER_CAPTURE_DIR,`${scenario}-${config}`);mkdirSync(dir,{recursive:true});writeFileSync(join(dir,'original.json'),JSON.stringify({schema:'tonswap-launchpad-holder-native-capture-v1',request:proof.p,result:proof.result,scenario,boundaries:{holder:holder.address.toRawString(),wallet:wallet.address.toRawString(),sourceLt:source!.tx.lt.toString(),sourceHash:source!.hash,targetLt:target!.tx.lt.toString(),targetHash:target!.hash},transactions:txs},null,2),{flag:'wx'});await f.exportNative(dir);}
  }finally{await f.close();}
 },90000);
});
