import { Address, Message } from '@ton/core';
import { Blockchain, SmartContractTransaction } from '@ton/sandbox';

function pair(message: Message): string {
    if (message.info.type !== 'internal') throw new Error('Manual router accepts internal messages only');
    return `${message.info.src.toRawString()}:${message.info.dest.toRawString()}`;
}

/** Executes one transaction at a time while preserving order for every sender/destination pair. */
export class ManualRouter {
    private queue: Message[] = [];
    readonly transactions: SmartContractTransaction[] = [];
    constructor(readonly blockchain: Blockchain) {}
    get pending(): readonly Message[] { return [...this.queue]; }
    enqueue(...messages: Message[]): void {
        for (const message of messages) pair(message);
        this.queue.push(...messages);
    }
    async deliver(index = 0): Promise<SmartContractTransaction> {
        const message = this.queue[index];
        if (!message) throw new Error('No queued message at index');
        const key = pair(message);
        if (this.queue.slice(0, index).some((earlier) => pair(earlier) === key)) throw new Error('Delivery would violate same-pair order');
        this.queue.splice(index, 1);
        if (message.info.type !== 'internal') throw new Error('Expected internal message');
        const tx = await (await this.blockchain.getContract(message.info.dest)).receiveMessage(message, { now: this.blockchain.now });
        this.transactions.push(tx);
        this.enqueue(...tx.outMessages.values().filter((out) => out.info.type === 'internal'));
        return tx;
    }
    async drain(hold: (message: Message) => boolean = () => false, limit = 1000): Promise<void> {
        for (let n = 0; n < limit; n++) {
            const index = this.queue.findIndex((message, i) => !hold(message)
                && !this.queue.slice(0, i).some((earlier) => pair(earlier) === pair(message)));
            if (index < 0) return;
            await this.deliver(index);
        }
        throw new Error('Manual routing transaction limit exceeded');
    }
}

export function sentTo(message: Message, address: Address): boolean {
    return message.info.type === 'internal' && message.info.dest.equals(address);
}
