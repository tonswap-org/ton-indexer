import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { Address, Cell, serializeTuple } from '@ton/core';
import { readLaunchpadState, type LaunchpadBinding } from '../../services/launchpadContracts';
import type { FreshChainRead } from '../../services/spotContracts';
import type { LaunchpadEvidenceRequest, LaunchpadProofBinding } from '../../services/launchpadOperationSettlement';
const sources={empty:JSON.parse(gunzipSync(readFileSync(new URL('../fixtures/fresh-launchpad/holder-empty-collector.json.gz',import.meta.url))).toString()),recovery:JSON.parse(gunzipSync(readFileSync(new URL('../fixtures/fresh-launchpad/holder-recovery-collector.json.gz',import.meta.url))).toString())};
function restore(v:any,strings:string[]):any{if(v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===1&&Object.hasOwn(v,'originalString')){const text=strings[v.originalString];if(typeof text!=='string')throw Error('Missing retained original');return text;}return Array.isArray(v)?v.map(a=>restore(a,strings)):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,a])=>[k,restore(a,strings)])):v;}
const key=(c:any)=>c.kind==='account'?`account:${c.address}`:`${c.address}:${c.method}:${serializeTuple((c.args??[]).map((a:any)=>a.type==='int'?{type:'int',value:BigInt(a.value)}:{type:a.type,cell:typeof a.cell==='string'?Cell.fromBase64(a.cell):a.cell})).hash().toString('hex')}`;
export async function launchpadHolderFixture(index=0,kind:'empty'|'recovery'='recovery'){
 const external=kind==='recovery'&&process.env.TONSWAP_LAUNCHPAD_HOLDER_COLLECTOR;
 const data=external?JSON.parse(readFileSync(external,'utf8')):sources[kind],c=external?data.cases[index]:restore(data.cases[index],data.strings),world=external?JSON.parse(readFileSync(c.completePath,'utf8')):restore(data.worlds[c.world],data.strings),observed=new Map(world.calls.map((call:any,i:number)=>[key(call),world.results[i]]));
 const read:FreshChainRead=async(calls,options)=>{options?.signal?.throwIfAborted();return{source:'indexer',head:world.head,receivedAt:world.head.utime*1000,results:calls.map(call=>{const r:any=observed.get(key(call));if(!r)throw Error(`Missing retained read ${key(call)}`);return call.kind==='getter'?structuredClone(r):{kind:'account',state:r.state==='uninit'?'uninitialized':r.state,balance:BigInt(r.balance),code:r.code?Cell.fromBase64(r.code):null,data:r.data?Cell.fromBase64(r.data):null,lastTx:r.lastTx};})};};
 const b=world.bindings,binding:LaunchpadBinding={...b,templateHashes:b.templates,...Object.fromEntries(['factory','governance','feeSink','dlmmFactory','t3Root'].map(k=>[k,Address.parse(b[k])]))};
 const state=await readLaunchpadState(null,{binding,read});const proof:LaunchpadProofBinding={state,proofCodeHash:c.manifest.templates.T3RecoveryProof,v21WalletHash:c.manifest.templates.JettonV21Wallet,stablecoinWalletHash:c.manifest.vendor.stablecoin.wallet.codeHash};
 return{c,world,read,binding:proof,request:c.request as LaunchpadEvidenceRequest,head:world.head};
}
