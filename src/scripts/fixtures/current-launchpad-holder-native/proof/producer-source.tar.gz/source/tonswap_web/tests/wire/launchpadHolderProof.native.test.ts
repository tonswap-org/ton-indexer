import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { Address, beginCell, Cell, Dictionary, contractAddress, loadTransaction, loadShardAccount } from '@ton/core';
import { expect, it, vi } from 'vitest';
import { describeWire, contractCode, runtimeCell, webCell, sandboxRpc } from '../helpers/contractSandbox';
import { launchpadHolderFixture } from '../helpers/currentLaunchpadHolder';
import { proofBlock, proofMasterchain } from '../../../ton-indexer/src/scripts/support/fakeLiteEngine';
import { SparseT3Tree } from '../../../ton-indexer/src/ledger/currentT3Receipts';
import { currentJettonConfigPrices } from '../../../ton-indexer/src/data/configPrices';
import { t3ProofConfigToCell, t3ProofData } from '../../services/t3Contracts';
import { readT3ProofStage, isT3ProofStepApplied } from '../../services/t3ProofSession';
import { prepareLaunchpadHolderProofStep, revalidateLaunchpadHolderProofStep, type LaunchpadHolderProofSession } from '../../services/launchpadHolderProofSession';
import { decodeLaunchChild, readLaunchpadRecoveryState } from '../../services/launchpadContracts';
import { decodeLaunchpadHolderRecoveries } from '../../services/launchpadHolderRecoveryEvidence';
const mocks=vi.hoisted(()=>({request:vi.fn(),prices:vi.fn()}));
vi.mock('../../services/indexer',()=>({indexerRequest:mocks.request}));
vi.mock('../../services/jettonConfigPrices',()=>({readJettonQuotePrices:mocks.prices}));
describeWire('native Launchpad holder proof sessions on unchanged originals',()=>{
 it.each([0,1,2,3])('verifies both source and target, funds certificate and consumes receipt (%s)',async index=>{
  const f=await launchpadHolderFixture(index),c=f.c,candidate=c.response.candidates[0],config=c.name.endsWith('x6')?'x6':'default';
  const {createNativeTransactionExecutor}=await import('../../../tonswap_tolk/tests/helpers/nativeTransactionExecutor'),{Blockchain,internal,TreasuryContract}=await import('../../../tonswap_tolk/node_modules/@ton/sandbox'),core=await import('../../../tonswap_tolk/node_modules/@ton/core'),indexerCore=await import('../../../ton-indexer/node_modules/@ton/core'),{FEE_CONFIGS}=await import('../../../tonswap_tolk/tests/fixtures/feeConfigs');
  const executor=await createNativeTransactionExecutor({nativeGetters:true}),originals:any[]=[];
  const proxy={...executor,runTransaction:async(args:Parameters<typeof executor.runTransaction>[0])=>{const result=await executor.runTransaction(args);if(result.result.success){const tx=loadTransaction(Cell.fromBase64(result.result.transaction).beginParse());originals.push({account:`0:${tx.address.toString(16).padStart(64,'0')}`,transactionBoc:result.result.transaction,beforeShardAccountBoc:args.shardAccount,afterShardAccountBoc:result.result.shardAccount});}return result;}};
  try{
   const holder=c.response.holders.find((h:any)=>h.address===candidate.holder),shards=[holder.shardAccountBoc,holder.wallet.shardAccountBoc].map((v:string)=>Cell.fromBase64(v));
   const dict=Dictionary.empty(Dictionary.Keys.BigUint(256),{serialize(v:Cell,b:ReturnType<typeof beginCell>){b.storeUint(0,5).storeCoins(0).storeBit(false).storeSlice(v.beginParse());},parse(s:any){return s.asCell();}});
   for(const shard of shards){const account=loadShardAccount(shard.beginParse()).account!.addr;dict.set(BigInt('0x'+account.hash.toString('hex')),shard);}
   const shard=proofBlock(70,f.head.utime,0,{accounts:indexerCore.Cell.fromBase64(beginCell().storeDict(dict).storeUint(0,5).storeCoins(0).storeBit(false).endCell().toBoc().toString('base64'))}),master=proofMasterchain(f.head.seqno+1,f.head.utime,shard);
   const head={workchain:-1,shard:master.id.shard,seqno:f.head.seqno+1,utime:f.head.utime,rootHashHex:master.id.rootHash.toString('hex'),fileHashHex:master.id.fileHash.toString('hex')};
   const anchor=(address:string)=>{const original=shards.find(s=>loadShardAccount(s.beginParse()).account!.addr.toRawString()===address)!;return{account:address,head,shardBlock:{workchain:0,shard:shard.id.shard,seqno:70,rootHashHex:shard.id.rootHash.toString('hex'),fileHashHex:shard.id.fileHash.toString('hex')},masterchainProofBoc:master.proof.toString('base64'),accountProofBoc:shard.proof.toString('base64'),accountBoc:original.refs[0].toBoc().toString('base64'),shardAccountBoc:original.toBoc().toString('base64')};};
   const recovery=structuredClone(c.response);recovery.asOf={masterchainSeqno:head.seqno,unixTime:head.utime,blockRootHash:head.rootHashHex};f.binding.state.head=head;
   const decoded=decodeLaunchpadHolderRecoveries(recovery,c.request,f.binding,head.utime*1000);expect(decoded.status).toBe('ready');if(decoded.status!=='ready')throw Error('Missing native holder candidate');
   const{recordBoc,proofBoc,status,head:_,sourceBeforeAccountBoc,sourceAfterAccountBoc,...fixed}=decoded.candidates[0],point=(hash:string,lt:string)=>({hash:BigInt('0x'+hash),lt:BigInt(lt),anchor:BigInt('0x'+head.rootHashHex)});
   const cfg=t3ProofConfigToCell({nonce:1n,controller:Address.parse(fixed.holder),hub:Address.parse(fixed.holder),master:f.binding.state.binding.t3Root,request:Cell.fromBase64(fixed.requestBoc),sourceWallet:Address.parse(fixed.wallet),targetWallet:Address.parse(fixed.target),queryId:BigInt(fixed.wire),amount:BigInt(fixed.amountRaw),walletCodeHash:BigInt('0x'+f.binding.state.binding.t3WalletHash),source:point(fixed.sourceHash,fixed.sourceLt),target:point(fixed.targetHash,fixed.targetLt)});
   const proofCode=await contractCode('T3RecoveryProof'),data=await runtimeCell(t3ProofData(cfg)),proofAddress=core.contractAddress(0,{code:proofCode,data}),session:LaunchpadHolderProofSession={version:1,original:c.request,candidate:fixed,nonce:'0'.repeat(63)+'1',anchor:head,configBoc:cfg.toBoc().toString('base64'),address:proofAddress.toRawString()};
   const chain=await Blockchain.create({executor:proxy,config:FEE_CONFIGS[config]});chain.now=head.utime;const nativeMaster={...master.id,shard:BigInt(master.id.shard)};chain.prevBlocks={lastMcBlocks:[nativeMaster],prevKeyBlock:nativeMaster,lastMcBlocks100:[]};
   const holderAddress=core.Address.parse(fixed.holder);await chain.setShardAccount(holderAddress,core.loadShardAccount((await runtimeCell(holder.shardAccountBoc)).beginParse()));
   const rpc=sandboxRpc(chain),read:any=async(calls:any[])=>({source:'rpc',head,receivedAt:0,results:await Promise.all(calls.map(async call=>{if(call.kind==='getter'){const g=await rpc.runGetMethod(call.address,call.method,call.args);return{kind:'getter',exitCode:g.exit_code,stack:g.stack};}const a=await rpc.getAddressInformation(call.address);return{kind:'account',state:a.state,balance:BigInt(a.balance),code:a.code?Cell.fromBase64(a.code):null,data:a.data?Cell.fromBase64(a.data):null,lastTx:null};}))});
   vi.spyOn(Date,'now').mockReturnValue(head.utime*1000);const convert=(v:any):any=>typeof v==='string'?BigInt(v):Object.fromEntries(Object.entries(v).map(([k,n])=>[k,convert(n)]));mocks.prices.mockResolvedValue({head,prices:convert(currentJettonConfigPrices(chain.config.toBoc().toString('base64'),head.utime))});
   let stage=readT3ProofStage(webCell(data),cfg),deployed=false;const records=new Map(f.world.completeTransactions.map((r:any)=>[Cell.fromBase64(r.transactionBoc).hash().toString('hex'),r.transactionBoc]));
   const prepare=async()=>{const transactionBocs:string[]=[],isTarget=stage.phase>=3&&stage.phase<=5;
    if(stage.phase===2||stage.phase===5){let hash=BigInt(stage.cursor.hash).toString(16).padStart(64,'0');for(let j=0;j<4;j++){const raw=records.get(hash) as string;expect(raw).toBeTruthy();transactionBocs.push(raw);const t=loadTransaction(Cell.fromBase64(raw).beginParse());if(String(t.lt)===(isTarget?fixed.targetLt:fixed.sourceLt))break;hash=t.prevTransactionHash.toString(16).padStart(64,'0');}}
    const sessionShardAccountBoc=deployed?core.beginCell().store(core.storeShardAccount((await chain.getContract(proofAddress)).account)).endCell().toBoc().toString('base64'):null;
    mocks.request.mockResolvedValue({schema:'tonswap-launchpad-holder-proof-session-v1',releaseId:c.request.releaseId,manifestHash:c.request.manifestHash,asOf:head,recovery,anchor:head,address:session.address,configBoc:session.configBoc,source:anchor(fixed.wallet),target:isTarget?anchor(fixed.target):null,history:null,sessionShardAccountBoc,transactionBocs});
    const p=await prepareLaunchpadHolderProofStep(c.request,fixed.key,session,{read,binding:f.binding});expect(p.status,`native phase ${stage.phase}`).toBe('ready');if(p.status!=='ready')throw Error('Missing native plan');return p;
   };
   const steps:number[]=[];for(let i=0;i<48&&stage.phase!==7;i++){const p=await prepare(),old=stage;steps.push(p.plan.step);await revalidateLaunchpadHolderProofStep(c.request,fixed.key,session,p.plan,{read,binding:f.binding});
    const result=await chain.sendMessage(internal({from:core.Address.parse(c.request.owner),to:proofAddress,value:p.plan.value,bounce:p.plan.bounce,...(p.plan.init?{stateInit:{code:proofCode,data}}:{}),body:await runtimeCell(p.plan.body)})),own=result.transactions.find(t=>t.inMessage?.info.type==='internal'&&t.inMessage.info.dest.equals(proofAddress))!;
    expect(own.description.type==='generic'&&own.description.computePhase.type==='vm'?own.description.computePhase.exitCode:own.description).toBe(0);
    stage=readT3ProofStage(webCell(((await chain.getContract(proofAddress)).accountState as any).state.data),cfg);deployed=true;expect(stage).toEqual(p.plan.nextStage);expect(isT3ProofStepApplied(p.plan,{head,deployed,stage})).toBe(true);expect(isT3ProofStepApplied(p.plan,{head,deployed,stage:old})).toBe(false);
   }
   expect(stage.phase).toBe(7);expect(stage.evidence).toBe(fixed.kind==='notification'?1:2);expect(steps).toContain(fixed.kind==='notification'?16:17);expect(steps.at(-1)).toBe(24);
   const p=await prepare();expect(p.plan.step).toBe(30);const certificate=await chain.sendMessage(internal({from:core.Address.parse(c.request.owner),to:proofAddress,value:p.plan.value,bounce:true,body:await runtimeCell(p.plan.body)}));
   const received=certificate.transactions.find(t=>t.inMessage?.info.type==='internal'&&t.inMessage.info.dest.equals(holderAddress)&&t.inMessage.body.beginParse().preloadUint(32)===(fixed.kind==='notification'?0x54334e43:0x54334643))!;expect(received.description.type==='generic'&&received.description.aborted).toBe(false);
   const log=received.outMessages.values().find(m=>m.info.type==='external-out'&&m.body.beginParse().preloadUint(32)===0x4a524543)!;expect(log).toBeTruthy();const record=webCell(log.body.refs[0]),tree=new SparseT3Tree();tree.set(BigInt(fixed.sourceLt),indexerCore.Cell.fromBase64(record.toBoc().toString('base64')));const proof=webCell(await runtimeCell(tree.proof(BigInt(fixed.sourceLt)).toBoc().toString('base64')));
   const current=await chain.getContract(holderAddress);const holderState=()=>readLaunchpadRecoveryState(decodeLaunchChild(webCell((current.accountState as any).state.data)).recovery.get(0)!);expect(holderState().pending).toBe(BigInt(fixed.amountRaw));
   recovery.holders.find((h:any)=>h.address===fixed.holder).shardAccountBoc=core.beginCell().store(core.storeShardAccount(current.account)).endCell().toBoc().toString('base64');recovery.candidates[0].recordBoc=record.toBoc().toString('base64');recovery.candidates[0].proofBoc=proof.toBoc().toString('base64');
   const ready=decodeLaunchpadHolderRecoveries(recovery,c.request,f.binding,head.utime*1000);expect(ready.status==='ready'&&ready.candidates[0].status).toBe('claim-receipt');
   const g=await rpc.runGetMethod(fixed.holder,'get_min_recovery_claim',[{type:'cell',cell:record}]);expect(g.exit_code).toBe(0);const value=BigInt(g.stack[0][1] as string),claim=beginCell().storeUint(0x4a52434d,32).storeRef(record).storeRef(proof).endCell();
   // Continue the captured treasury's original history. The JRCM intent must
   // itself be an original external-owner transaction, not an injected message.
   const ownerOriginal=[...f.world.completeTransactions].reverse().find((row:any)=>row.account===c.request.owner);expect(ownerOriginal).toBeTruthy();
   const ownerShard=core.loadShardAccount((await runtimeCell(ownerOriginal.afterShardAccountBoc)).beginParse());
   expect(ownerShard.account?.storage.state.type).toBe('active');
   if(ownerShard.account?.storage.state.type!=='active'||!ownerShard.account.storage.state.state.data)throw Error('Original treasury state required');
   const ownerState=ownerShard.account.storage.state.state,treasury=TreasuryContract.create(0,ownerState.data.beginParse().loadUintBig(256));
   expect(treasury.address.toRawString()).toBe(c.request.owner);expect(ownerState.code?.equals(TreasuryContract.code)).toBe(true);
   await chain.setShardAccount(treasury.address,ownerShard);
   const claimStart=originals.length;
   const claimed=await chain.sendMessage(core.external({to:treasury.address,body:treasury.createTransfer({sendMode:core.SendMode.PAY_GAS_SEPARATELY,messages:[core.internal({to:holderAddress,value,bounce:true,body:await runtimeCell(claim)})]})}));expect(claimed.transactions.find(t=>t.inMessage?.info.type==='internal'&&t.inMessage.info.dest.equals(holderAddress))!.description.type).toBe('generic');expect(holderState().pending).toBe(0n);
   const owed=await rpc.runGetMethod(fixed.holder,'get_owed',[{type:'int',value:0n},{type:'slice',cell:beginCell().storeAddress(Address.parse(c.request.owner)).endCell()}]);expect(owed.exit_code).toBe(0);expect(BigInt(owed.stack[0][1] as string)).toBe(BigInt(fixed.amountRaw));
   expect(isT3ProofStepApplied(p.plan,{head,deployed,stage})).toBe(false);
   if(process.env.TONSWAP_HOLDER_PROOF_OUTPUT){const dir=process.env.TONSWAP_HOLDER_PROOF_OUTPUT;mkdirSync(dir,{recursive:true});writeFileSync(join(dir,`${c.name}.json`),JSON.stringify({schema:'tonswap-native-holder-proof-v1',qualification:'Original native source/target histories and native verifier/receiver/claim execution. Synthetic masterchain wrappers; no consensus or deployment authority.',sourceSha256:c.completeSha256,session,steps,certificatePlan:{bodyBoc:p.plan.body.toBoc().toString('base64'),valueNano:String(p.plan.value)},receiptBoc:record.toBoc().toString('base64'),proofBoc:proof.toBoc().toString('base64'),owner:c.request.owner,claimDispatch:originals[claimStart],transactions:originals},null,2)+'\n',{flag:'wx'});}
  }finally{vi.restoreAllMocks();await executor.close();}
 },90000);
});
