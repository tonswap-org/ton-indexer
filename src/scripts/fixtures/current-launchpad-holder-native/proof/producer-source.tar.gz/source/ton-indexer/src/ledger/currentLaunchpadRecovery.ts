import { Address, beginCell, Cell, Dictionary } from '@ton/core';
import { readHolderReceipt, readHolderRecoveryState } from '../runtime/launchpadHolderRecoveryEvidence';
import { t3PathRoot } from './currentT3Wire';
import { decodeLaunchLp, type decodeLaunchChild } from './currentLaunchpadState';
import { need, raw, tokenTransfer, type CurrentLaunchpadTransaction } from './currentLaunchpadProof';
type Child = ReturnType<typeof decodeLaunchChild>;
const hash = (cell: Cell) => BigInt('0x' + cell.hash().toString('hex'));
const pair = (a: bigint, b: bigint) => hash(beginCell().storeUint(3, 8).storeUint(a, 256).storeUint(b, 256).endCell());
function books(child: Child) {
  return Dictionary.loadDirect(Dictionary.Keys.Uint(8), { serialize() { throw Error('Read only'); }, parse(s) {
    const total = s.loadCoins(), count = s.loadUint(16), entries = s.loadDict(Dictionary.Keys.Address(), Dictionary.Values.BigVarUint(4)), archive = s.loadMaybeRef(); s.endParse();
    return { total, count, entries, archive };
  } }, child.owed);
}
function archived(cell: Cell | null | undefined) {
  need(cell && !cell.isExotic); const s = cell.beginParse(), count = s.loadUintBig(65), root = s.loadUintBig(256), total = s.loadCoins();
  const frontier = s.loadDict(Dictionary.Keys.Uint(8), Dictionary.Values.BigUint(256)); s.endParse(); return { count, root, total, frontier };
}
/** A successful original CLMA consumes one exact committed owed leaf. Receipt
 * retirement is separate from the emitted token transfer's eventual delivery. */
export function verifyLaunchpadArchiveClaim(body: Cell, holder: string, before: Child, after: Child) {
  need(before.identity.role === 0 && after.identity.role === 0 && !body.isExotic);
  const s = body.beginParse(); need(s.loadUint(32) === 0x434c4d41); s.loadUintBig(64);
  const slot = s.loadUint(8), id = s.loadUintBig(64), owner = s.loadAddress(), amount = s.loadCoins(); let proof: Cell | null = s.loadRef(); s.endParse();
  need(slot <= 1 && amount > 0n);
  const left = books(before).get(slot), right = books(after).get(slot); need(left && right);
  const a = archived(left.archive), z = archived(right.archive); need(id < a.count && z.count === a.count && z.total === a.total - amount && right.total === left.total - amount);
  let old = hash(beginCell().storeUint(1, 8).storeAddress(Address.parse(holder)).storeUint(slot, 8).storeUint(id, 64).storeAddress(owner).storeUint(amount, 120).endCell());
  let next = hash(beginCell().storeUint(2, 8).storeAddress(Address.parse(holder)).storeUint(slot, 8).storeUint(id, 64).endCell());
  for (let level = 0; level < 64; level++) {
    need(proof && !proof.isExotic); const p = proof.beginParse(), sibling = p.loadUintBig(256); proof = p.loadMaybeRef(); p.endParse(); need((proof === null) === (level === 63));
    if ((id >> BigInt(level)) & 1n) { old = pair(sibling, old); next = pair(sibling, next); } else { old = pair(old, sibling); next = pair(next, sibling); }
  }
  need(old === a.root && next === z.root);
  return { beneficiary: raw(owner)!, amountRaw: String(amount), slot };
}
/** JRCM restores an already proven holder receipt to native accounting. It
 * neither creates a wallet credit nor reclassifies its original income source. */
export function verifyLaunchpadHolderClaim(tx: CurrentLaunchpadTransaction, before: Child, after: Child) {
  const s = tx.tx.inMessage!.body.beginParse(); need(s.loadUint(32) === 0x4a52434d);
  const receipt = s.loadRef(), proof = s.loadRef(); s.endParse(); const r = readHolderReceipt(receipt); need(!r.claimed && before.identity.role < 2);
  const left = tx.before.account?.storage.state, right = tx.after.account?.storage.state;
  need(left?.type === 'active' && right?.type === 'active' && left.state.data && right.state.data);
  const a = readHolderRecoveryState(left.state.data), z = readHolderRecoveryState(right.state.data); need(a && z && a.initialized && z.initialized && a.lastKey === z.lastKey && a.pending - z.pending === r.amount);
  const claimed = beginCell().storeUint(r.key, 64).storeRef(beginCell().storeBit(r.incoming).storeUint(r.slot, 8).storeCoins(r.amount).storeBit(true).storeRef(r.body)).endCell();
  need(t3PathRoot(r.key, receipt, proof) === a.root && t3PathRoot(r.key, claimed, proof) === z.root);
  let beneficiary: string, queryId: bigint;
  if (r.incoming) {
    const p = r.body.beginParse(); need(p.loadUint(32) === 0x7362d09c); queryId = p.loadUintBig(64); need(p.loadCoins() === r.amount); beneficiary = raw(p.loadAddress())!;
    // A wrapped swap refund may change its beneficial owner. Such a receipt
    // remains unresolved until the original swap origin is authenticated.
    const payload = p.loadBit() ? p.loadRef() : beginCell().storeSlice(p).endCell();
    if (payload.bits.length >= 32) need(payload.beginParse().preloadUint(32) !== 0x53575233);
  } else { const request = tokenTransfer(r.body); need(request.amount === r.amount); beneficiary = request.owner; queryId = request.queryId; }
  if (before.identity.role === 0) {
    const leftOwed = books(before).get(r.slot)?.entries.get(Address.parse(beneficiary)) ?? 0n;
    const rightOwed = books(after).get(r.slot)?.entries.get(Address.parse(beneficiary)) ?? 0n;
    need(rightOwed - leftOwed === r.amount);
  } else {
    const l = decodeLaunchLp(before), q = decodeLaunchLp(after), counts = l.unlockAt === 0 || tx.tx.now < l.unlockAt;
    const restore = r.incoming || beneficiary === raw(l.pool);
    need(q.t3Bal - l.t3Bal === (counts && restore ? r.amount : 0n));
    beneficiary = tx.account;
  }
  return { beneficiary, queryId: String(queryId), amountRaw: String(r.amount), slot: r.slot };
}
