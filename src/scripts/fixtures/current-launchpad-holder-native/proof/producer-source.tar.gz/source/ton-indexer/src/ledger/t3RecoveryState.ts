import { Address, Cell, Dictionary, beginCell } from "@ton/core";
import { referralAddress, readT3ReferralState } from "./t3Wire";
import { readCurrentJettonWalletStorage } from "./jettonWalletState";
const end = (s: ReturnType<Cell["beginParse"]>) => {
  if (s.remainingBits || s.remainingRefs)
    throw Error("Trailing T3 recovery storage");
};
const hex = (n: bigint | undefined) =>
  n === undefined ? null : n.toString(16).padStart(64, "0");
export const t3ReceiptKey = (
  domain: number,
  root: string,
  party: string,
  id: string,
) =>
  beginCell()
    .storeUint(domain, 32)
    .storeAddress(Address.parse(root))
    .storeAddress(Address.parse(party))
    .storeUint(BigInt(id), 64)
    .endCell()
    .hash();
export function readT3RecoveryRoot(
  boc: string,
  root: string,
  wallet: string,
  hub: string,
  queryId: string,
  wireId: string,
) {
  const cell = Cell.fromBase64(boc),
    s = cell.beginParse();
  if (s.loadUint(32) !== 0x4a545253 || s.remainingBits || s.remainingRefs !== 4)
    throw Error("T3 root storage");
  const registry = s.loadRef().beginParse(),
    data = s.loadRef().beginParse();
  registry.loadMaybeAddress();
  const enabled = registry.loadUint(8),
    withdrawalsOnly = registry.loadUint(8);
  registry.loadRef();
  end(registry);
  if (enabled > 1 || withdrawalsOnly > 1) throw Error("T3 root flags");
  const totalSupplyRaw = data.loadCoins().toString();
  data.loadMaybeAddress();
  const walletCode = data.loadRef();
  data.loadRef();
  const emitter = data.loadMaybeAddress()?.toRawString() ?? null;
  end(data);
  const r = s.loadRef().beginParse(),
    receipts = r.loadDict(
      Dictionary.Keys.BigUint(256),
      Dictionary.Values.BigUint(256),
    );
  end(r);
  s.loadRef();
  end(s);
  const get = (domain: number, party: string, id: string) =>
    receipts.get(
      BigInt("0x" + t3ReceiptKey(domain, root, party, id).toString("hex")),
    );
  return {
    walletCode,
    summary: {
      enabled,
      withdrawalsOnly,
      totalSupplyRaw,
      emitter,
      walletCodeHash: walletCode.hash().toString("hex"),
      receiptHash: hex(get(0x4a425354, wallet, queryId)),
      pendingHash: hex(get(0x54334250, wallet, queryId)),
      negativeHash: hex(get(0x5433424e, wallet, queryId)),
      acceptedHash: hex(get(0x54334241, wallet, queryId)),
      wireWalletHash: hex(get(0x54334257, hub, wireId)),
      wireQueryId: get(0x54334251, hub, wireId)?.toString() ?? null,
      wireIntentHash: hex(get(0x54334249, hub, wireId)),
      wireAmountRaw: get(0x5433424d, hub, wireId)?.toString() ?? null,
      dataHash: cell.hash().toString("hex"),
    },
  };
}
export function readT3RecoveryWallet(boc: string) {
  const cell = Cell.fromBase64(boc), storage = readCurrentJettonWalletStorage(cell);
  const owner = storage.owner.toRawString(), root = storage.root.toRawString(),
    destination = storage.feeDelegate?.toRawString() ?? null,
    balanceRaw = storage.balance.toString(), lockedFeesRaw = storage.lockedFees.toString(),
    borrowedFeesRaw = storage.borrowedFees.toString(), opcode = storage.lastBounceOpcode,
    transferQueryId = storage.lastBounceQueryId.toString(), transferAmountRaw = storage.lastBounceAmount.toString();
  // Current jetton_wallet.tolk settlement_status: the root-cell tuple is
  // separate from the burn journal below. NONE may retain a finalized tuple.
  const transferStatus: 0 | 1 | 2 | 3 = destination === null
    ? 0
    : opcode === 0x4a534954
      ? 1
      : opcode === 0x4a535543
        ? 2
        : opcode === 0x4a544246
          ? 3
          : 0;
  const j = storage.burnJournal.beginParse(), mint = storage.mintJournal.beginParse();
  const readMint = (value: ReturnType<Cell["beginParse"]>) => {
    const status = value.loadUint(8), wireId = value.loadUintBig(64), queryId = value.loadUintBig(64), amount = value.loadCoins(), requestHash = value.loadUintBig(256);
    end(value);
    if (status !== 0 && status !== 2 || status === 0 && (wireId !== 0n || queryId !== 0n || amount !== 0n || requestHash !== 0n)) throw Error("T3 wallet mint journal");
    return {status, wireId, queryId, amount, requestHash};
  };
  readMint(mint);
  const mintReceipts = Dictionary.loadDirect(Dictionary.Keys.BigUint(64), {serialize: () => {throw Error("Read-only mint receipt");}, parse: readMint}, storage.mintReceipts);
  for (const [wireId, receipt] of mintReceipts) if (receipt.status !== 2 || receipt.wireId !== wireId || receipt.amount <= 0n) throw Error("T3 wallet mint receipt");
  Dictionary.loadDirect(Dictionary.Keys.BigUint(256), Dictionary.Values.Cell(), storage.referralNotifications);
  const status = j.loadUint(8),
    queryId = j.loadUintBig(64).toString(),
    amountRaw = j.loadCoins().toString(),
    requestHash = hex(j.loadUintBig(256))!,
    response = j.loadMaybeAddress()?.toRawString() ?? null;
  end(j);
  if (status > 5) throw Error("T3 wallet status");
  return {
    balanceRaw,
    owner,
    root,
    lockedFeesRaw,
    borrowedFeesRaw,
    transfer: {
      status: transferStatus,
      queryId: transferQueryId,
      amountRaw: transferAmountRaw,
      destination,
      opcode,
    },
    journal: { status, queryId, amountRaw, requestHash, response },
    dataHash: cell.hash().toString("hex"),
  };
}
export function readT3RecoveryHub(boc: string, owner: string, queryId: string) {
  const cell = Cell.fromBase64(boc),
    s = cell.beginParse();
  if (s.loadUint(32) !== 0x54335354 || s.remainingBits || s.remainingRefs !== 1)
    throw Error("T3 hub storage");
  const data = s.loadRef().beginParse();
  data.skip(40);
  for (let i = 0; i < 4; i++) data.loadCoins();
  data.loadRef();
  data.loadRef();
  data.skip(208);
  data.loadRef();
  data.loadMaybeAddress();
  const root = data.loadAddress().toRawString(),
    enabled = data.loadUint(8),
    b = data.loadRef().beginParse();
  end(data);
  if (enabled > 1) throw Error("T3 hub enabled");
  b.loadMaybeAddress();
  b.skip(64);
  b.loadCoins();
  b.skip(64);
  b.loadRef();
  const p = b.loadRef().beginParse();
  const referral = readT3ReferralState(b.loadRef());
  if (referral.t3Root !== null && referral.t3Root !== root) throw Error("T3 referral root mismatch");
  end(b);
  p.loadUintBig(64);
  const entries = p.loadDict(
      Dictionary.Keys.BigUint(256),
      Dictionary.Values.Cell(),
    ),
    identities = p.loadDict(
      Dictionary.Keys.BigUint(64),
      Dictionary.Values.BigUint(256),
    ),
    payoutBusiness = p.loadDict(
      Dictionary.Keys.BigUint(256),
      Dictionary.Values.Cell(),
    );
  p.loadDict(Dictionary.Keys.BigUint(256), Dictionary.Values.Cell());
  end(p);
  const key = BigInt("0x" + beginCell().storeUint(0x54335049, 32)
    .storeUint(1, 8).storeAddress(Address.parse(owner))
    .storeUint(BigInt(queryId), 64).endCell().hash().toString("hex")),
    entry = entries.get(key);
  if (!entry)
    return {
      root,
      enabled,
      proof: null,
      dataHash: cell.hash().toString("hex"),
    };
  const v = entry.beginParse();
  const storedQueryId = v.loadUintBig(64), wireId = v.loadUintBig(64),
    amountRaw = v.loadCoins(), payoutId = v.loadUintBig(64),
    consumed = v.loadUint(8), intentCell = v.loadRef(),
    reservation = v.loadRef().beginParse();
  end(v);
  const intentHash = reservation.loadUintBig(256);
  for (let i = 0; i < 3; i++) reservation.loadCoins();
  const continuation = reservation.loadRef().beginParse(); end(reservation);
  for (let i = 0; i < 4; i++) continuation.loadCoins();
  continuation.loadUint(8);
  const referralEconomics = continuation.loadRef().beginParse(); end(continuation);
  for (let i = 0; i < 5; i++) referralEconomics.loadCoins();
  referralEconomics.loadUint(32); referralEconomics.loadRef(); end(referralEconomics);
  let recipient: string | null = null, slippage: number | null = null,
    mode: number | null = null, outputToken: number | null = null,
    referrer: string | null = null;
  if (consumed === 0) {
    const intent = intentCell.beginParse();
    if (intent.loadAddress().toRawString() !== owner) throw Error("T3 proof owner");
    recipient = intent.loadAddress().toRawString();
    slippage = intent.loadUint(16); mode = intent.loadUint(8);
    outputToken = intent.loadUint(8); referrer = referralAddress(intent.loadRef());
    end(intent);
  } else if (consumed === 1) {
    end(intentCell.beginParse());
  }
  const identityCell = payoutBusiness.get(key);
  if (!identityCell) throw Error("T3 proof payout business identity");
  const identity = identityCell.beginParse();
  const identityPayoutId = identity.loadUintBig(64),
    identityHash = identity.loadUintBig(256);
  identity.loadDict(Dictionary.Keys.BigUint(256), Dictionary.Values.Cell()); end(identity);
  const proof = {
    queryId, wireId: wireId.toString(), owner, recipient,
    amountRaw: amountRaw.toString(), slippage, mode, outputToken,
    payoutId: payoutId.toString(), consumed, referrer,
    intentHash: hex(intentHash)!,
  };
  if (
    proof.consumed > 1 ||
    proof.payoutId === "0" ||
    proof.wireId === "0" ||
    intentHash === 0n ||
    (consumed === 0 && storedQueryId !== BigInt(queryId)) ||
    (consumed === 1 && storedQueryId !== 0n) ||
    identities.get(payoutId) !== key ||
    identityPayoutId !== payoutId || identityHash !== intentHash
  )
    throw Error("T3 proof identity");
  return { root, enabled, proof, dataHash: cell.hash().toString("hex") };
}
