import { validateReleaseManifest } from './releaseManifestCodec.mjs';
import type { ReleaseManifestV1, Role } from './releaseManifestCodec.mjs';
import { deriveT3RedemptionBinding, type T3RedemptionBinding } from './services/t3RedemptionBinding';

export { ROLES, stableJson, manifestHash, validateReleaseManifest } from './releaseManifestCodec.mjs';
export type { ReleaseManifestV1, Role, ManifestTemplate } from './releaseManifestCodec.mjs';

/** The web's camelCase address keys of deployed roles. */
export const WEB_ROLE_KEYS = {
  governance: 'Governance', treasury: 'Treasury', usdtRoot: 'USDT', usdcRoot: 'USDC', kusdRoot: 'KUSD',
  feeRouter: 'FeeRouter', gasVault: 'GasVault', swapCoordinator: 'SwapCoordinator', spotOrderFactory: 'SpotOrderFactory',
  riskVault: 'RiskVault', t3Hub: 'T3Hub', tsMinter: 'TSMinter', dlmmFactory: 'DlmmPoolFactory',
  perpsEngine: 'PerpsEngine', coverManager: 'ParisianPolicyManager', coverVault: 'CoverVault', coverUpkeep: 'CoverAutomationUpkeep',
  referralRegistry: 'ReferralRegistry', emissionsSplitter: 'EmissionsSplitter',
  buybackExecutor: 'BuybackExecutor', optionFactory: 'OptionFactory', optionSeriesManager: 'OptionSeriesManager',
  optionVault: 'OptionVault', saleFactory: 'SaleFactory', genesisDistributor: 'GenesisDistributor',
  merkleClaim: 'MerkleClaim', remint: 'Remint', testnetFaucet: 'TestnetFaucet',
} as const satisfies Record<string, Role>;
export type WebAddressKey = keyof typeof WEB_ROLE_KEYS | 'dlmmPool';
export type WebAddresses = Record<WebAddressKey, string>;

/** TESTNET_ADDRESSES: every key, '' where the release has no such contract (or no release is installed). */
export function webAddresses(m: ReleaseManifestV1 | null): WebAddresses {
  const out = Object.fromEntries(Object.entries(WEB_ROLE_KEYS).map(([k, r]) => [k, m?.contracts[r]?.address ?? ''])) as WebAddresses;
  out.dlmmPool = m?.spotMarkets[0]?.pool ?? '';
  return out;
}

export type ReleaseSpotMarket = { key: string; address: string; baseSymbol: string; quoteSymbol: string };
export type ReleasePerpsMarket = { marketId: number; assetSymbol: string; quoteSymbol: string; engine?: string; pool: string;
  poolCodeHash: string; tokenRoot: string; candleMarketKey: string };
export type ReleaseOptionsMarket = { seriesId: string; assetSymbol: string; quoteSymbol: string; optionAddress: string };

// Live bindings: set once by installReleaseManifest, before main.ts imports the application. Everything else is derived
// from TONSWAP_RELEASE by its consumer.
export let TONSWAP_RELEASE: ReleaseManifestV1 | null = null;
export let TONSWAP_RELEASE_MARKETS: { spot: ReleaseSpotMarket[]; perps: ReleasePerpsMarket[]; options: ReleaseOptionsMarket[] } =
  { spot: [], perps: [], options: [] };
/** Immutable release identities; custody wallets are learned from authenticated chain state. */
export let TONSWAP_T3_REDEMPTION: T3RedemptionBinding | undefined;

const freezeJson = (value: unknown): void => {
  if (!value || typeof value !== 'object') return;
  for (const child of Object.values(value)) freezeJson(child);
  Object.freeze(value);
};

export function installReleaseManifest(input: unknown, expectedNetwork?: ReleaseManifestV1['network']): ReleaseManifestV1 {
  const v = validateReleaseManifest(input, expectedNetwork);
  if (v.ok === false) throw new Error(`release-manifest.json is invalid: ${v.errors.join(', ')}`);
  // Own an immutable JSON snapshot: a caller cannot change addresses or identity after constants are evaluated.
  const snapshot: unknown = JSON.parse(JSON.stringify(v.m));
  const cloned = validateReleaseManifest(snapshot, expectedNetwork);
  if (cloned.ok === false) throw new Error(`release-manifest.json is invalid: ${cloned.errors.join(', ')}`);
  const m = cloned.m;
  if (TONSWAP_RELEASE) {
    if (TONSWAP_RELEASE.manifestHash !== m.manifestHash) throw new Error('A different release is already installed. Reload the application.');
    return TONSWAP_RELEASE;
  }
  const c = m.contracts;
  const redemption = deriveT3RedemptionBinding(m);
  const root = (symbol: string) => m.tokens.find(t => t.symbol === symbol)!.root;
  const markets: typeof TONSWAP_RELEASE_MARKETS = {
    spot: m.spotMarkets.map(s => ({ key: `spot:${s.symbol}-T3`, address: s.pool, baseSymbol: s.symbol, quoteSymbol: 'T3' })),
    perps: m.perpsMarkets.map(p => ({ marketId: p.marketId, assetSymbol: p.symbol, quoteSymbol: 'T3', engine: c.PerpsEngine?.address,
      pool: p.pool, poolCodeHash: m.templates.DlmmPool, tokenRoot: root(p.symbol), candleMarketKey: `perps-oracle:${p.marketId}` })),
    options: m.options.filter(o => o.option).map(o => ({ seriesId: o.seriesId!, assetSymbol: o.symbol, quoteSymbol: 'T3', optionAddress: o.option! })),
  };
  freezeJson(m);
  freezeJson(redemption);
  freezeJson(markets);
  // All validation and derivation finish before publishing any of the three bindings.
  TONSWAP_RELEASE = m;
  TONSWAP_T3_REDEMPTION = redemption;
  TONSWAP_RELEASE_MARKETS = markets;
  return m;
}
