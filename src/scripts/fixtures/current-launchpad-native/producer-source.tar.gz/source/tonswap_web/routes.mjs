// The route manifest: the ONE place where application routes are defined.
//
// Everything that needs to know about a route derives from this file and never keeps a copy:
// viewRoutes.ts (parse/build), the shell (navigation, titles, up-navigation), the static IPFS
// entrypoints (scripts/ipfs/materialize_static_routes.mjs) and the release UI authorization
// allow-list (scripts/autotest/release_tonconnect_authorization.mjs). It is plain ESM so build
// scripts can import it without a TypeScript toolchain; routes.d.mts carries the types.
//
// Safety: this module validates itself at import. A malformed manifest throws before any
// consumer can run, so the release authorization policy (which imports it) fails closed.

/** Parameter kinds. `token` values are checked against the token registry by the app; the
 * manifest only records the kind so consumers know how to read, write and enumerate a value. */
export const PARAM_KINDS = Object.freeze(['token', 'poolToken', 'market', 'sale', 'inviter']);

export const VIEW_IDS = Object.freeze(['wallet', 'earn', 'swap', 'leverage', 'options', 'sccp', 'launchpad', 'settings']);

/** Opened for `/` and for paths no route names. */
export const DEFAULT_ROUTE_ID = 'swap';

/** Token symbols that get a static `/swap/:from/:to` entrypoint on IPFS gateways. */
export const STATIC_SWAP_SYMBOLS = Object.freeze(['gram', 't3', 'usdt', 'usdc', 'kusd', 'ts']);

// Fields:
//   id            stable identifier; also the key of the route title in the shell catalog
//   path          pattern; `:name` segments are parameters declared in `params`
//   view          the top-level destination the route belongs to
//   titleKey      catalog key of the page title and of the up-navigation label. Scheme:
//                 `shell.route.<id with dots removed and each later segment capitalised>`, so
//                 `settings.notifications` -> `shell.route.settingsNotifications`. The shell catalog is a
//                 nested tree where a key is a message or a branch, never both, so every title is a leaf
//                 directly under `route` and no key may be a dot-prefix of another. Variants of one
//                 screen (`swap.pair`, `leverage.market`, `earn.rewardsToken`, `ref`) share its key.
//                 assertManifest enforces the single-leaf grammar, which rules out prefix collisions.
//   parent        route id that "up" navigates to, or null
//   navGroup      'primary' (tab bar and sidebar) | 'trade' (modes inside Swap) | 'secondary' (sidebar and Settings) | null
//   tabBarView    the primary destination that stays current while this route is shown
//   releaseSigning  whether the release UI authorization may approve wallet transactions raised on this
//                 route (the allow-list). A route that raises transactions but is false is blocked.
//   namespaces    screen-specific message catalogs to preload (the always-loaded base is not listed)
//   params        { name: kind } for every `:name` in the path; names are RouteState fields
//   tab           Earn tab shown while this route is open
//   static        parameterised routes only: true when entrypoints are materialized for IPFS
//   feature       the route exists only when this product feature is enabled
//   opens         an entry link that opens another route (parse only, never built)
const DEFINITIONS = [
  {
    id: 'swap', path: '/swap', view: 'swap', titleKey: 'shell.route.swap', parent: null, navGroup: 'primary',
    releaseSigning: true, namespaces: ['swap', 'swapOrders', 'market', 'review']
  },
  {
    id: 'wallet', path: '/wallet', view: 'wallet', titleKey: 'shell.route.wallet', parent: null,
    navGroup: 'primary', releaseSigning: true, namespaces: ['wallet', 'transfer', 'review']
  },
  {
    id: 'earn.pools', path: '/earn', view: 'earn', titleKey: 'shell.route.earnPools', parent: null,
    navGroup: 'primary', releaseSigning: true, namespaces: ['earn', 'pools', 'review'], tab: 'pools'
  },
  {
    id: 'earn.add', path: '/earn/add/t3/:liquidityToken', view: 'earn', titleKey: 'shell.route.earnAdd',
    parent: 'earn.pools', navGroup: null, releaseSigning: true, namespaces: ['earn', 'addLiquidity', 'review'],
    params: { liquidityToken: 'poolToken' }, tab: 'pools'
  },
  {
    id: 'earn.rewards', path: '/earn/rewards', view: 'earn', titleKey: 'shell.route.earnRewards', parent: null,
    navGroup: null, releaseSigning: true, namespaces: ['earn', 'farming', 'review'], tab: 'rewards'
  },
  {
    id: 'earn.rewardsToken', path: '/earn/rewards/t3/:liquidityToken', view: 'earn',
    titleKey: 'shell.route.earnRewards', parent: 'earn.rewards', navGroup: null, releaseSigning: true,
    namespaces: ['earn', 'farming', 'review'], params: { liquidityToken: 'poolToken' }, tab: 'rewards'
  },
  {
    id: 'earn.getT3', path: '/earn/get-t3', view: 'earn', titleKey: 'shell.route.earnGetT3', parent: null,
    navGroup: null, releaseSigning: true, namespaces: ['earn', 'getT3', 'review'], tab: 'get-t3'
  },
  {
    id: 'earn.protection', path: '/earn/protection', view: 'earn', titleKey: 'shell.route.earnProtection',
    parent: null, navGroup: null, releaseSigning: true, namespaces: ['earn', 'protection', 'review'],
    tab: 'protection'
  },
  {
    id: 'earn.vote', path: '/earn/vote', view: 'earn', titleKey: 'shell.route.earnVote', parent: null,
    navGroup: null, releaseSigning: true, namespaces: ['earn', 'vote', 'review'], tab: 'vote'
  },
  {
    id: 'swap.pair', path: '/swap/:swapFrom/:swapTo', view: 'swap', titleKey: 'shell.route.swap', parent: null,
    navGroup: null, releaseSigning: true, namespaces: ['swap', 'swapOrders', 'market', 'review'],
    params: { swapFrom: 'token', swapTo: 'token' }, static: true
  },
  {
    id: 'leverage', path: '/leverage', view: 'leverage', titleKey: 'shell.route.leverage', parent: null,
    navGroup: 'trade', tabBarView: 'swap', releaseSigning: true, namespaces: ['leverage', 'market', 'review']
  },
  {
    id: 'leverage.market', path: '/leverage/:leverageMarketId', view: 'leverage',
    titleKey: 'shell.route.leverage', parent: 'leverage', navGroup: null, tabBarView: 'swap', releaseSigning: true,
    namespaces: ['leverage', 'market', 'review'], params: { leverageMarketId: 'market' }, static: true
  },
  {
    id: 'options', path: '/options', view: 'options', titleKey: 'shell.route.options', parent: null,
    navGroup: 'trade', tabBarView: 'swap', releaseSigning: true,
    namespaces: ['options', 'optionsWriter', 'market', 'review']
  },
  {
    id: 'sccp', path: '/sccp', view: 'sccp', titleKey: 'shell.route.sccp', parent: null,
    navGroup: 'secondary', tabBarView: 'settings', releaseSigning: false, namespaces: ['sccp']
  },
  {
    id: 'launchpad', path: '/launchpad', view: 'launchpad', titleKey: 'shell.route.launchpad', parent: null,
    navGroup: 'primary', releaseSigning: true, namespaces: ['launch', 'launchSales']
  },
  {
    id: 'launchpad.create', path: '/launchpad/create', view: 'launchpad', titleKey: 'shell.route.launchpadCreate',
    parent: 'launchpad', navGroup: null, releaseSigning: true, namespaces: ['launch', 'launchCreate', 'review']
  },
  {
    id: 'launchpad.sale', path: '/launchpad/:launchpadId', view: 'launchpad',
    titleKey: 'shell.route.launchpadSale', parent: 'launchpad', navGroup: null, releaseSigning: true,
    namespaces: ['launch', 'launchSales', 'review'], params: { launchpadId: 'sale' }
  },
  {
    id: 'launchpad.manage', path: '/launchpad/:launchpadId/manage', view: 'launchpad',
    titleKey: 'shell.route.launchpadManage', parent: 'launchpad.sale', navGroup: null, releaseSigning: true,
    namespaces: ['launch', 'launchCreate', 'review'], params: { launchpadId: 'sale' }
  },
  {
    id: 'settings', path: '/settings', view: 'settings', titleKey: 'shell.route.settings', parent: null,
    navGroup: 'primary', releaseSigning: false, namespaces: ['settings', 'appearance']
  },
  {
    id: 'settings.notifications', path: '/settings/notifications', view: 'settings',
    titleKey: 'shell.route.settingsNotifications', parent: 'settings', navGroup: null, releaseSigning: false,
    namespaces: ['settings', 'notifications']
  },
  {
    id: 'settings.rewards', path: '/settings/rewards', view: 'settings', titleKey: 'shell.route.settingsRewards',
    parent: 'settings', navGroup: null, releaseSigning: false, namespaces: ['settings', 'referral', 'review']
  },
  {
    id: 'settings.reports', path: '/settings/reports', view: 'settings', titleKey: 'shell.route.settingsReports',
    parent: 'settings', navGroup: null, releaseSigning: false, namespaces: ['settings'], feature: 'taxReports'
  },
  {
    id: 'settings.network', path: '/settings/network', view: 'settings', titleKey: 'shell.route.settingsNetwork',
    parent: 'settings', navGroup: null, releaseSigning: false, namespaces: ['settings']
  },
  {
    id: 'settings.protocol', path: '/settings/protocol', view: 'settings', titleKey: 'shell.route.settingsProtocol',
    parent: 'settings', navGroup: null, releaseSigning: true, namespaces: ['settings', 'protocolAdmin', 'vote', 'review']
  },
  {
    id: 'settings.status', path: '/settings/status', view: 'settings', titleKey: 'shell.route.settingsStatus',
    parent: 'settings', navGroup: null, releaseSigning: false, namespaces: ['settings', 'protocolAdmin']
  },
  {
    id: 'ref', path: '/ref/:inviter', view: 'swap', titleKey: 'shell.route.swap', parent: null, navGroup: null,
    releaseSigning: false, namespaces: ['swap', 'swapOrders', 'market', 'review'], params: { inviter: 'inviter' },
    opens: 'swap'
  }
];

const segmentsOf = (path) => path.split('/').filter(Boolean);
const isParameter = (segment) => segment.startsWith(':');

const deepFreeze = (value) => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze(child);
  }
  return value;
};

/** Path before the first parameter segment, e.g. `/earn/add/t3/:token` -> `/earn/add/t3`. */
const staticPrefixOf = (path) => {
  const literal = [];
  for (const segment of segmentsOf(path)) {
    if (isParameter(segment)) break;
    literal.push(segment);
  }
  return literal.length > 0 ? `/${literal.join('/')}` : '';
};

/** True when `location` is exactly `prefix` or continues it with a path, query or fragment. */
export const isUnderRoutePrefix = (location, prefix) => {
  if (typeof location !== 'string' || typeof prefix !== 'string' || !prefix.startsWith('/')) return false;
  return (
    location === prefix ||
    location.startsWith(`${prefix}/`) ||
    location.startsWith(`${prefix}?`) ||
    location.startsWith(`${prefix}#`)
  );
};

/** Same grammar as KEY_PATTERN in i18n/message.ts (a test keeps the two in step). */
const TITLE_KEY_PATTERN = /^shell\.route\.[a-z][A-Za-z0-9]*$/;

const assertManifest = (routes) => {
  const titleKeys = new Set(routes.map((route) => route.titleKey));
  for (const key of titleKeys) {
    if (!TITLE_KEY_PATTERN.test(key)) throw new Error(`Route title key ${String(key)} must be shell.route.<lowerCamelName>.`);
  }
  const ids = new Set();
  const paths = new Set();
  for (const route of routes) {
    if (ids.has(route.id)) throw new Error(`Route manifest repeats id ${route.id}.`);
    if (paths.has(route.path)) throw new Error(`Route manifest repeats path ${route.path}.`);
    ids.add(route.id);
    paths.add(route.path);
    if (!route.path.startsWith('/') || route.path.length > 1 && route.path.endsWith('/')) {
      throw new Error(`Route ${route.id} has a malformed path.`);
    }
    if (!VIEW_IDS.includes(route.view)) throw new Error(`Route ${route.id} names an unknown view.`);
    if (!VIEW_IDS.includes(route.tabBarView)) throw new Error(`Route ${route.id} names an unknown tab bar view.`);
    if (![null, 'primary', 'trade', 'secondary'].includes(route.navGroup)) throw new Error(`Route ${route.id} has an unknown navGroup.`);
    if (typeof route.releaseSigning !== 'boolean') throw new Error(`Route ${route.id} must declare whether release signing may originate on it.`);
    const declared = Object.keys(route.params ?? {}).sort();
    const inPath = segmentsOf(route.path).filter(isParameter).map((segment) => segment.slice(1)).sort();
    if (declared.join() !== inPath.join()) throw new Error(`Route ${route.id} parameters do not match its path.`);
    for (const kind of Object.values(route.params ?? {})) {
      if (!PARAM_KINDS.includes(kind)) throw new Error(`Route ${route.id} uses unknown parameter kind ${kind}.`);
    }
    if (route.static && declared.length === 0) throw new Error(`Route ${route.id} has no parameters to enumerate.`);
    if (route.namespaces.length === 0 || new Set(route.namespaces).size !== route.namespaces.length) {
      throw new Error(`Route ${route.id} has an invalid namespace list.`);
    }
  }
  const byId = new Map(routes.map((route) => [route.id, route]));
  for (const route of routes) {
    for (const link of [route.parent, route.opens]) {
      if (link !== null && link !== undefined && !byId.has(link)) throw new Error(`Route ${route.id} links to unknown route ${link}.`);
    }
    const seen = new Set([route.id]);
    for (let up = route.parent; up; up = byId.get(up).parent) {
      if (seen.has(up)) throw new Error(`Route ${route.id} has a parent cycle.`);
      seen.add(up);
    }
    if (route.opens && (byId.get(route.opens).opens || Object.keys(byId.get(route.opens).params ?? {}).length > 0)) {
      throw new Error(`Route ${route.id} must open a parameter-free route.`);
    }
  }
  for (const view of VIEW_IDS) {
    const landings = routes.filter((route) => route.view === view && segmentsOf(route.path).length === 1 && !route.params);
    if (landings.length !== 1) throw new Error(`View ${view} needs exactly one landing route.`);
  }
};

export const ROUTES = deepFreeze(
  DEFINITIONS.map((definition) => ({ tabBarView: definition.view, ...definition }))
);
assertManifest(ROUTES);

const routesById = new Map(ROUTES.map((route) => [route.id, route]));

export const routeById = (id) => {
  const route = routesById.get(id);
  if (!route) throw new Error(`Unknown route ${String(id)}.`);
  return route;
};

/** The one route that opens a view: `/<view>` with no parameters. */
export const landingRoute = (view) => {
  const landing = ROUTES.find((route) => route.view === view && segmentsOf(route.path).length === 1 && !route.params);
  if (!landing) throw new Error(`Unknown view ${String(view)}.`);
  return landing;
};

/** The parameter-free route at `/<segment>` (for example `/earn`), or null. */
export const routeAtRoot = (segment) => ROUTES.find((route) => route.path === `/${segment}`) ?? null;

/** Earn tab ids in display order, derived from the parameter-free Earn routes. */
export const EARN_TAB_IDS = Object.freeze(ROUTES.filter((route) => route.tab && !route.params).map((route) => route.tab));

/** First path segments of every route (`/earn`, `/ref`...): how hash routing recognises an app route. */
export const ROUTE_ROOTS = Object.freeze(new Set(ROUTES.map((route) => `/${segmentsOf(route.path)[0]}`)));

/** Whether the route exists in this build. `features` is `{ taxReports: boolean }`. */
export const isRouteAvailable = (route, features = {}) => !route.feature || features[route.feature] === true;

/** Routes shown in navigation for a group, in display order. */
export const navRoutes = (group, features = {}) =>
  ROUTES.filter((route) => route.navGroup === group && isRouteAvailable(route, features));

const compiled = ROUTES.map((route) => ({
  route,
  segments: segmentsOf(route.path),
  literals: segmentsOf(route.path).filter((segment) => !isParameter(segment)).length
})).sort((a, b) => b.literals - a.literals);

const decodeSegment = (segment) => {
  try {
    return decodeURIComponent(segment);
  } catch {
    return undefined;
  }
};

/**
 * Finds the route a normalized path (no base, query or fragment) names. Literal segments win
 * over parameters (`/launchpad/create` is never a sale id). Returns `{ route, params }` where
 * every param is the decoded segment, or undefined when it is not valid percent-encoding; the
 * caller validates values by kind. Returns null when no available route matches.
 */
export const matchRoute = (path, features = {}) => {
  const segments = segmentsOf(path);
  for (const { route, segments: pattern } of compiled) {
    if (pattern.length !== segments.length || !isRouteAvailable(route, features)) continue;
    const params = {};
    const matches = pattern.every((part, index) => {
      if (!isParameter(part)) return part === segments[index];
      params[part.slice(1)] = decodeSegment(segments[index]);
      return true;
    });
    if (matches) return { route, params };
  }
  return null;
};

/** Fills a route's path. Returns null unless every parameter has a non-empty value. */
export const fillRoutePath = (id, params = {}) => {
  const route = routeById(id);
  const parts = [];
  for (const segment of segmentsOf(route.path)) {
    if (!isParameter(segment)) {
      parts.push(segment);
      continue;
    }
    const value = params[segment.slice(1)];
    if (value === undefined || value === null || String(value) === '') return null;
    parts.push(encodeURIComponent(String(value)));
  }
  return `/${parts.join('/')}`;
};

/**
 * The location prefix under which wallet transactions are authorized for a route (for example
 * `/earn` for `earn.pools`). Fail-closed: an unknown route, a route that may not transact, a
 * route that starts with a parameter, or a prefix that also covers a route that may not transact
 * throws, so a stale or widened allow-list can never silently authorize more than the manifest.
 */
export const transactionRoutePrefix = (id) => {
  const route = routeById(id);
  if (!route.releaseSigning) throw new Error(`Route ${id} is not in the release signing scope.`);
  const prefix = staticPrefixOf(route.path);
  if (!prefix) throw new Error(`Route ${id} has no fixed path prefix.`);
  const exposed = ROUTES.filter((other) => isUnderRoutePrefix(other.path, prefix) && !other.releaseSigning);
  if (exposed.length > 0) {
    throw new Error(`Prefix ${prefix} would also cover ${exposed.map((other) => other.id).join(', ')}.`);
  }
  return prefix;
};

/** Leverage market ids that may become static entrypoints: positive uint32, no duplicates. */
export const assertLeverageMarketIds = (ids) => {
  if (!Array.isArray(ids)) throw new Error('Leverage routes require a list of market ids.');
  if (ids.some((id) => !Number.isSafeInteger(id) || id <= 0 || id > 0xffffffff) || new Set(ids).size !== ids.length) {
    throw new Error('Invalid leverage route market identity.');
  }
  return ids;
};

/**
 * Every static SPA entrypoint path for IPFS gateways, sorted. Parameter-free routes are always
 * included; parameterised routes only when marked `static`, expanded with the supplied symbols
 * (pairs of distinct tokens) and market ids. Entry links (`/ref/:inviter`) are never static.
 */
export const staticRoutePaths = ({ features = {}, swapSymbols = STATIC_SWAP_SYMBOLS, leverageMarketIds = [] } = {}) => {
  const marketIds = assertLeverageMarketIds(leverageMarketIds);
  const paths = new Set();
  for (const route of ROUTES) {
    if (route.opens || !isRouteAvailable(route, features)) continue;
    const names = Object.keys(route.params ?? {});
    if (names.length === 0) {
      paths.add(route.path);
      continue;
    }
    if (!route.static) continue;
    let combinations = [{}];
    for (const name of names) {
      const kind = route.params[name];
      const candidates = kind === 'token' ? swapSymbols : kind === 'market' ? marketIds : null;
      if (!candidates) throw new Error(`Route ${route.id} cannot enumerate ${kind} parameters.`);
      combinations = combinations.flatMap((partial) =>
        candidates
          .filter((value) => kind !== 'token' || !Object.values(partial).includes(value))
          .map((value) => ({ ...partial, [name]: value }))
      );
    }
    for (const params of combinations) paths.add(fillRoutePath(route.id, params));
  }
  return [...paths].sort();
};
