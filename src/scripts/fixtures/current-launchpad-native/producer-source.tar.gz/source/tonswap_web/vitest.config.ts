import { defineConfig } from 'vitest/config';
import vue from '@vitejs/plugin-vue';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { resolveReleaseViteCacheDir } from './releaseViteCache';

const configDir = fileURLToPath(new URL('.', import.meta.url));
const cacheDir = resolveReleaseViteCacheDir(
  process.env.TONSWAP_RELEASE_VITE_CACHE_DIR,
  path.join(configDir, 'tmp_autotest', 'vitest-cache')
);

// plugin-vue makes a component an ordinary import, so a test renders the real SFC (renderToString,
// or a mount in a browser) instead of compiling its source text by hand.
export default defineConfig({
  plugins: [vue()],
  resolve: { alias: { 'vitest-environment-mounted-components': path.join(configDir, 'tests/helpers/mountedComponent.ts') } },
  cacheDir,
  test: {
    cache: false,
    setupFiles: ['tests/setup/release.ts'],
    fileParallelism: false,
    include: ['tests/**/*.test.ts'],
    exclude: ['e2e/**', 'node_modules/**', 'dist/**']
  }
});
