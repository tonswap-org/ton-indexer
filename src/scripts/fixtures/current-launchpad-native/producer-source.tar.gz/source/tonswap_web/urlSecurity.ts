export const normalizeHostname = (hostname: string | null | undefined) => {
  const normalized = hostname?.trim().toLowerCase().replace(/\.$/, '') ?? '';
  return normalized === '[::1]' ? '::1' : normalized;
};

export const isToncenterHostname = (hostname: string | null | undefined) => {
  const normalized = normalizeHostname(hostname);
  return normalized === 'toncenter.com' || normalized.endsWith('.toncenter.com');
};

export const isLoopbackHostname = (hostname: string | null | undefined) => {
  const normalized = normalizeHostname(hostname);
  return normalized === 'localhost' || normalized === '127.0.0.1' || normalized === '0.0.0.0' || normalized === '::1';
};

export const parseUrl = (value: string, base?: string) => {
  try {
    return base ? new URL(value, base) : new URL(value);
  } catch (_err) {
    return null;
  }
};

export const isHttpsUrl = (value: string, base?: string) => parseUrl(value, base)?.protocol === 'https:';
