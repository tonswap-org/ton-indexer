import type { Token } from './types';
import { EARN_TAB_IDS } from './routes.mjs';
import { parseUrl } from './urlSecurity';
import { TONSWAP_RELEASE, TONSWAP_RELEASE_MARKETS, webAddresses } from './releaseManifest';

export const NATIVE_ASSET_SYMBOL = 'GRAM';
export const NATIVE_ASSET_NAME = 'Gram';

// main.ts installs release-manifest.json before this module is first evaluated; tests and scripts that install none
// see no deployment.
const release = TONSWAP_RELEASE;

export type SupportedNetwork = 'mainnet' | 'testnet';
export const TONSWAP_NETWORK: SupportedNetwork = release?.network === 'ton:mainnet' ? 'mainnet' : 'testnet';
export const LOCAL_DIRECT_GOVERNANCE = release?.network === 'ton:localnet';

const processEnv: Record<string, string | undefined> = typeof process !== 'undefined' && process.env ? process.env : {};
const runtimeEnv: Record<string, string | undefined> = {
  ...((import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env ?? {}),
  ...processEnv
};

export const TESTNET_CONFIG = {
  network: TONSWAP_NETWORK,
  toncenterEndpoint: release?.services.tonRpc ?? '',
  toncenterApiKey: runtimeEnv.VITE_TONCENTER_API_KEY?.trim() || '',
  indexerEndpoint: release?.services.indexer ?? ''
} as const;

/** Deployed addresses by web key: a projection of the release through WEB_ROLE_KEYS. */
export const TESTNET_ADDRESSES = webAddresses(release);
export { TONSWAP_RELEASE, TONSWAP_RELEASE_MARKETS };

const CORE_TOKEN_SYMBOLS = ['T3', 'TS', 'USDT', 'USDC', 'KUSD'];
const decimals = (symbol: string) => release?.tokens.find(token => token.symbol === symbol)?.decimals ?? 9;

/**
 * Where new testers can get free test GRAM. Optional release configuration: set
 * VITE_TESTNET_GRAM_FAUCET_URL to an https URL (no credentials in it). The value is empty when it
 * is unset, not an https URL, or the network is not testnet, and callers must then hide the
 * faucet step instead of rendering a dead link.
 */
const resolveTestnetGramFaucetUrl = (): string => {
  const raw = runtimeEnv.VITE_TESTNET_GRAM_FAUCET_URL?.trim();
  if (!raw || TONSWAP_NETWORK !== 'testnet') return '';
  const url = parseUrl(raw);
  return url?.protocol === 'https:' && !url.username && !url.password ? url.href : '';
};
export const TESTNET_GRAM_FAUCET_URL = resolveTestnetGramFaucetUrl();

export const TS_DECIMALS = 9;
export const DEFAULT_SWAP_TOKENS = {
  pay: 'T3',
  receive: TONSWAP_RELEASE_MARKETS.spot[0]?.baseSymbol ?? 'KUSD'
} as const;

export const TESTNET_TOKENS: Token[] = [
  {
    id: 'ton',
    symbol: NATIVE_ASSET_SYMBOL,
    name: NATIVE_ASSET_NAME,
    kind: 'native',
    decimals: 9,
    balance: null,
    balanceUsd: null,
    price: null,
    change24h: null,
    iconColor: 'bg-sky-500'
  },
  {
    id: 't3',
    symbol: 'T3',
    name: 'T3 USD',
    kind: 'jetton',
    decimals: 9,
    address: TESTNET_ADDRESSES.t3Hub,
    balance: null,
    balanceUsd: null,
    price: null,
    change24h: null,
    iconColor: 'bg-cyan-600'
  },
  {
    id: 'usdt',
    symbol: 'USDT',
    name: TONSWAP_NETWORK === 'mainnet' ? 'Tether' : 'Tether (Testnet)',
    kind: 'jetton',
    decimals: decimals('USDT'),
    address: TESTNET_ADDRESSES.usdtRoot,
    balance: null,
    balanceUsd: null,
    price: null,
    change24h: null,
    iconColor: 'bg-blue-500'
  },
  {
    id: 'usdc',
    symbol: 'USDC',
    name: TONSWAP_NETWORK === 'mainnet' ? 'USD Coin' : 'USD Coin (Testnet)',
    kind: 'jetton',
    decimals: decimals('USDC'),
    address: TESTNET_ADDRESSES.usdcRoot,
    balance: null,
    balanceUsd: null,
    price: null,
    change24h: null,
    iconColor: 'bg-indigo-600'
  },
  {
    id: 'kusd',
    symbol: 'KUSD',
    name: TONSWAP_NETWORK === 'mainnet' ? 'KUSD' : 'KUSD (Testnet)',
    kind: 'jetton',
    decimals: decimals('KUSD'),
    address: TESTNET_ADDRESSES.kusdRoot,
    balance: null,
    balanceUsd: null,
    price: null,
    change24h: null,
    iconColor: 'bg-slate-700'
  },
  {
    id: 'ts',
    symbol: 'TS',
    name: 'TONSWAP',
    kind: 'jetton',
    decimals: 9,
    address: TESTNET_ADDRESSES.tsMinter,
    balance: null,
    balanceUsd: null,
    price: null,
    change24h: null,
    iconColor: 'bg-indigo-600'
  },
  ...(release?.tokens ?? [])
    .filter(token => !CORE_TOKEN_SYMBOLS.includes(token.symbol))
    .map((token, index) => ({
      id: `release-${index + 1}-${token.symbol.toLowerCase()}`,
      symbol: token.symbol,
      name: token.symbol,
      kind: 'jetton' as const,
      decimals: token.decimals,
      address: token.root,
      balance: null,
      balanceUsd: null,
      price: null,
      change24h: null,
      iconColor: 'bg-fuchsia-500'
    }))
];

export const EARN_TABS = EARN_TAB_IDS;

export const REGISTRY_KEYS = {
  T3_HUB: 0x54334842,
  T3_USDT_VAULT: 0x54335655,
  T3_USDC_VAULT: 0x54335643,
  T3_KUSD_VAULT: 0x5433564b,
  T3_ROOT: 0x54335254,
  LPIN: 0x4c50494e
} as const;
