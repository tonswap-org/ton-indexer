
import type { ValuationQuote } from './services/assetValuations';
import type { ViewId } from './routes.mjs';

export interface Token {
  valuation?: ValuationQuote;
  id: string;
  symbol: string;
  name: string;
  address?: string;
  kind?: 'native' | 'jetton';
  decimals?: number;
  balance?: number | null;
  balanceExact?: string | null;
  balanceUsd?: number | null;
  price?: number | null;
  change24h?: number | null; // percentage
  iconColor: string;
}

export interface Pool {
  id: string;
  pair: string;
  address?: string;
  walletCodeHash?: bigint | null;
  liquidity?: number | null;
  liquidityObservation?: { scope: 'active_bin'; observedAt: number; assets: { assetId: string; amount: string }[] };
  rewardToken?: string | null;
  userStaked?: number | null;
  userStakedUsd?: number | null;
  iconColors: [string, string];
  type?: 'DLMM' | 'Stableswap';
}

export interface Presale {
  id: string;
  name: string;
  ticker: string;
  logo?: string;
  description: string;
  telegram?: string;
  x?: string;
  softCap: string | null;
  hardCap: string | null;
  raised: string | null;
  status: 'active' | 'ended' | 'upcoming' | 'unknown';
  model: 'fixed' | 'bonding' | 'auction';
  endDate: string;
  rate: string;
  insured?: boolean;
  minBuy?: string;
  maxBuy?: string;
  startPrice?: string;
  reservePrice?: string;
}

export interface Position {
  id: string;
  type: 'Long' | 'Short' | 'Option' | 'Insurance';
  asset: string;
  entryPrice?: number;
  markPrice?: number;
  size?: string;
  pnl?: number;
  pnlPercent?: number;
  leverage?: number;
  expiry?: string;
  strike?: number;
}

export interface Proposal {
  id: string;
  title: string;
  description: string;
  status: 'Active' | 'Passed' | 'Failed' | 'Cancelled' | 'Queued' | 'Executed';
  votesFor?: number | null;
  votesAgainst?: number | null;
  endDate: string;
  type: string;
}

/** Top-level destinations; defined by the route manifest (routes.mjs). */
export type ViewType = ViewId;
