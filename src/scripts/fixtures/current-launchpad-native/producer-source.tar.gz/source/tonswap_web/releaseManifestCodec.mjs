import { sha256_sync } from '@ton/crypto';

// Canonical wire validation shared by browser boot and Node release staging.
export const ROLES = [
  'Governance', 'USDT', 'USDC', 'KUSD', 'T3Hub', 'Treasury', 'GasVault', 'BuybackExecutor', 'FeeRouter',
  'DlmmPoolFactory', 'SwapCoordinator', 'SpotOrderFactory', 'EmissionsSplitter', 'ReferralRegistry', 'SaleFactory',
  'RiskVault', 'PerpsEngine', 'OptionVault', 'OptionFactory', 'OptionSeriesManager',
  'CoverVault', 'ParisianPolicyManager', 'CoverAutomationUpkeep',
  'GenesisDistributor', 'TSMinter', 'MerkleClaim', 'Remint', 'TestnetFaucet',
];
export const TEMPLATES = ['T3Wallet', 'T3RecoveryProof', 'JettonV21Wallet', 'DlmmPool', 'SpotOrder', 'ShoutOption', 'OutperformanceOption', 'SaleFixed', 'SaleBonding', 'SaleAuction', 'VestingVault', 'LpVault', 'JettonV21Minter'];

export const stableJson = value => {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(',')}}`;
  }
  return JSON.stringify(value);
};
export const manifestHash = manifest => {
  const { manifestHash: _, ...body } = manifest;
  return sha256_sync(stableJson(body)).toString('hex');
};

/** TLS services or explicit loopback development services, without credentials, query or fragment. */
export const releaseServiceUrl = value => {
  if (typeof value !== 'string' || value !== value.trim() || !/^https?:\/\//.test(value)) return null;
  try {
    const url = new URL(value);
    if (!url.hostname || url.username || url.password || url.search || url.hash) return null;
    if (url.protocol !== 'https:' && !(url.protocol === 'http:' &&
      ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname))) return null;
    return url;
  } catch { return null; }
};

const isObject = value => !!value && typeof value === 'object' && !Array.isArray(value);
const isDigest = value => typeof value === 'string' && /^[0-9a-f]{64}$/.test(value);
const isAddress = value => typeof value === 'string' && /^0:[0-9a-f]{64}$/.test(value) && value !== `0:${'0'.repeat(64)}`;
const isUint = value => typeof value === 'string' && /^(0|[1-9][0-9]*)$/.test(value);
const isInt = (value, min, max) => Number.isSafeInteger(value) && value >= min && value <= max;
const isSymbol = value => typeof value === 'string' && /^[A-Z0-9_.$-]{1,32}$/.test(value);
const sameKeys = (value, keys) => isObject(value) && stableJson(Object.keys(value).sort()) === stableJson([...keys].sort());
const KEYS = ['schema', 'network', 'globalId', 'releaseId', 'createdAt', 'source', 'services', 'contracts', 'templates', 'tokens',
  'spotMarkets', 'perpsMarkets', 'options', 'vendor', 'campaign', 'supplyBase', 'orderKeeper', 'manifestHash'];
const GLOBAL_ID = { 'ton:mainnet': -239, 'ton:testnet': -3, 'ton:localnet': -3 };
const isNetwork = value => typeof value === 'string' && Object.prototype.hasOwnProperty.call(GLOBAL_ID, value);

export const validReleaseAsset = value => isObject(value) && isDigest(value.sha256)
  && (value.path === `release-assets/${value.sha256}.json` || value.path === `release-assets/${value.sha256}.boc`)
  && isInt(value.bytes, 1, 512 * 1024 * 1024);

const WALLET_BUDGET_WIDTHS = {
  senderGas: 32, walletBounceGas: 32, burnWalletGas: 32, smallPayloadCells: 16,
  largeWalletGas: 32, largeSenderGas: 32, rentSeconds: 32, rentBits: 32, rentCells: 16,
  initBits: 32, initCells: 16, initCopies: 8, transferBits: 16, transferCells: 8, transferCopies: 8,
};
/** The native wallet profile's exact bounded wire, including explicit credit protection. */
export function validJettonWalletProfile(walletGas, walletGram, budget) {
  if (!isUint(walletGram) || !sameKeys(budget, [...Object.keys(WALLET_BUDGET_WIDTHS), 'creditProtection'])) return false;
  if (!Object.entries(WALLET_BUDGET_WIDTHS).every(([key, width]) =>
    isInt(budget[key], key === 'walletBounceGas' ? 0 : 1, 2 ** width - 1))) return false;
  return typeof budget.creditProtection === 'boolean'
    && budget.walletBounceGas <= 500000 && budget.senderGas >= 10000
    && budget.initCopies <= 4 && budget.transferBits >= 880 && budget.transferCopies >= 3 && budget.transferCopies <= 8
    && isInt(walletGas, 10000, 500000) && budget.senderGas <= walletGas
    && budget.burnWalletGas >= budget.senderGas && budget.burnWalletGas <= 2000000
    && budget.largeSenderGas >= budget.senderGas && budget.largeWalletGas >= walletGas
    && budget.largeSenderGas <= budget.largeWalletGas && budget.largeWalletGas <= 2000000
    && BigInt(walletGram) <= 500000000n;
}


/** Shape plus address, spot and instrument invariants; no operational policy literals. */
export function validateReleaseManifest(manifest, expectedNetwork) {
  const errors = [];
  const need = (ok, label) => { if (!ok) errors.push(label); };
  if (!isObject(manifest)) return { ok: false, errors: ['manifest must be an object'] };
  need(sameKeys(manifest, KEYS), 'top-level keys');
  need(manifest.schema === 'tonswap-release-v1', 'schema');
  need(isNetwork(manifest.network) && manifest.globalId === GLOBAL_ID[manifest.network], 'network/globalId');
  if (expectedNetwork !== undefined) need(isNetwork(expectedNetwork) && manifest.network === expectedNetwork, 'expectedNetwork');
  need(typeof manifest.releaseId === 'string' && /^[a-z]+-[A-Za-z0-9._-]+-[0-9a-f]{12}$/.test(manifest.releaseId)
    && isObject(manifest.source) && manifest.releaseId.endsWith(`-${String(manifest.source.build).slice(0, 12)}`), 'releaseId');
  need(typeof manifest.createdAt === 'string' && !Number.isNaN(Date.parse(manifest.createdAt)), 'createdAt');
  need(sameKeys(manifest.source, ['contracts', 'build']) && typeof manifest.source.contracts === 'string'
    && /^[0-9a-f]{40}$/.test(manifest.source.contracts) && isDigest(manifest.source.build), 'source');
  need(sameKeys(manifest.services, ['indexer', 'tonRpc', 'platform'])
    && Object.values(manifest.services).every(releaseServiceUrl), 'services');
  const indexer = releaseServiceUrl(manifest.services?.indexer);
  need(indexer && manifest.services.indexer === `${indexer.origin}/api/indexer`, 'services.indexer must use /api/indexer');

  const addresses = new Set();
  const unique = (address, label) => { need(!addresses.has(address), `${label} duplicates an address`); addresses.add(address); };
  need(isObject(manifest.contracts) && Object.keys(manifest.contracts).length > 0, 'contracts');
  for (const [role, binding] of Object.entries(isObject(manifest.contracts) ? manifest.contracts : {})) {
    need(ROLES.includes(role), `contracts.${role} is not a role`);
    need(sameKeys(binding, ['address', 'codeHash']) && isAddress(binding.address) && isDigest(binding.codeHash), `contracts.${role}`);
    if (isObject(binding)) unique(binding.address, `contracts.${role}`);
  }
  need(sameKeys(manifest.templates, TEMPLATES) && Object.values(manifest.templates).every(isDigest), 'templates');

  const vendor = manifest.vendor?.stablecoin;
  need(sameKeys(manifest.vendor, ['stablecoin']) && sameKeys(vendor, ['provenance', 'minter', 'wallet'])
    && sameKeys(vendor.provenance, ['path', 'sha256', 'bytes']) && validReleaseAsset(vendor.provenance)
    && [vendor.minter, vendor.wallet].every(asset => sameKeys(asset, ['path', 'sha256', 'bytes', 'codeHash'])
      && validReleaseAsset(asset) && isDigest(asset.codeHash)), 'vendor');
  const campaign = manifest.campaign;
  need(sameKeys(campaign, ['id', 'root', 'count', 'total', 'start', 'leaves', 'proofs'])
    && isUint(campaign.id) && BigInt(campaign.id) < (1n << 256n) && isDigest(campaign.root)
    && isInt(campaign.count, 1, 2 ** 24) && isUint(campaign.total) && BigInt(campaign.total) > 0n
    && BigInt(campaign.total) < (1n << 120n) && isInt(campaign.start, 0, 0xffffffff)
    && [campaign.leaves, campaign.proofs].every(asset => sameKeys(asset, ['path', 'sha256', 'bytes']) && validReleaseAsset(asset)), 'campaign');
  need(isUint(manifest.supplyBase) && isUint(campaign?.total) && BigInt(manifest.supplyBase) <= BigInt(campaign.total), 'supplyBase');
  const keeper = manifest.orderKeeper;
  need(sameKeys(keeper, ['address']) && isAddress(keeper.address), 'orderKeeper');
  if (isObject(keeper) && isAddress(keeper.address)) unique(keeper.address, 'orderKeeper');


  const tokens = Array.isArray(manifest.tokens) ? manifest.tokens : [];
  need(Array.isArray(manifest.tokens) && tokens.some(token => token?.symbol === 'T3'), 'tokens');
  const symbols = new Set(), roots = new Set();
  tokens.forEach((token, index) => {
    need(sameKeys(token, ['symbol', 'root', 'decimals', 'masterCodeHash', 'walletCodeHash']) && isSymbol(token.symbol) && !symbols.has(token.symbol)
      && isAddress(token.root) && !roots.has(token.root) && isInt(token.decimals, 0, 18)
      && isDigest(token.masterCodeHash) && isDigest(token.walletCodeHash), `tokens[${index}]`);
    symbols.add(token?.symbol); roots.add(token?.root);
  });
  if (isObject(manifest.contracts)) for (const token of tokens) {
    if (!isObject(token) || !isSymbol(token.symbol)) continue;
    const role = token.symbol === 'T3' ? 'T3Hub' : token.symbol === 'TS' ? 'TSMinter' : token.symbol;
    need(token.root === manifest.contracts[role]?.address && token.masterCodeHash === manifest.contracts[role]?.codeHash, `tokens.${token.symbol} master`);
    if (token.symbol === 'TS') need(token.masterCodeHash === manifest.templates?.JettonV21Minter, 'tokens.TS minter');
    if (token.symbol === 'T3' || token.symbol === 'TS') {
      need(token.walletCodeHash === manifest.templates?.[token.symbol === 'T3' ? 'T3Wallet' : 'JettonV21Wallet'], `tokens.${token.symbol} wallet`);
    }
  }

  const spots = Array.isArray(manifest.spotMarkets) ? manifest.spotMarkets : [];
  need(Array.isArray(manifest.spotMarkets) && spots.length > 0, 'spotMarkets');
  const spotSymbols = new Set();
  spots.forEach((spot, index) => {
    need(sameKeys(spot, ['symbol', 'pool', 'binSpacing', 'feePips', 'xDecimals', 'walletGasX', 'walletGramX', 'walletBudgetX']) && spot.symbol !== 'T3' && symbols.has(spot.symbol)
      && !spotSymbols.has(spot.symbol) && isAddress(spot.pool) && !roots.has(spot.pool)
      && isInt(spot.binSpacing, 1, 0x7fffffff) && isInt(spot.feePips, 0, 0xffffffff)
      && spot.xDecimals === tokens.find(token => token?.symbol === spot.symbol)?.decimals
      && validJettonWalletProfile(spot.walletGasX, spot.walletGramX, spot.walletBudgetX), `spotMarkets[${index}]`);
    if (isObject(spot)) { spotSymbols.add(spot.symbol); unique(spot.pool, `spotMarkets[${index}]`); }
  });
  const pool = symbol => spots.find(spot => spot?.symbol === symbol)?.pool;

  const perps = Array.isArray(manifest.perpsMarkets) ? manifest.perpsMarkets : [];
  need(Array.isArray(manifest.perpsMarkets), 'perpsMarkets');
  const marketIds = new Set();
  perps.forEach((market, index) => {
    need(sameKeys(market, ['marketId', 'symbol', 'pool']) && isInt(market.marketId, 1, 0xffffffff)
      && !marketIds.has(market.marketId) && isSymbol(market.symbol) && spotSymbols.has(market.symbol)
      && isAddress(market.pool) && pool(market.symbol) === market.pool, `perpsMarkets[${index}]`);
    marketIds.add(market?.marketId);
  });

  const options = Array.isArray(manifest.options) ? manifest.options : [];
  need(Array.isArray(manifest.options), 'options');
  const series = new Set();
  options.forEach((option, index) => {
    const label = `options[${index}]`;
    if (!isObject(option)) return errors.push(label);
    need(isInt(option.templateId, 1, 0xffffffff) && ['shout', 'outperformance'].includes(option.kind) && spotSymbols.has(option.symbol), label);
    need(option.kind === 'outperformance' ? spotSymbols.has(option.comparisonSymbol) && option.comparisonSymbol !== option.symbol
      : !('comparisonSymbol' in option), `${label}.comparisonSymbol`);
    const listed = ['seriesId', 'option', 'expiry'].filter(key => key in option).length;
    need(listed === 0 || (listed === 3 && isUint(option.seriesId) && !series.has(option.seriesId)
      && isAddress(option.option) && isUint(option.expiry)), `${label}.series`);
    if (listed === 3) { series.add(option.seriesId); unique(option.option, label); }
  });
  try { need(isDigest(manifest.manifestHash) && manifest.manifestHash === manifestHash(manifest), 'manifestHash'); }
  catch { need(false, 'manifestHash'); }
  return errors.length ? { ok: false, errors } : { ok: true, m: manifest };
}
