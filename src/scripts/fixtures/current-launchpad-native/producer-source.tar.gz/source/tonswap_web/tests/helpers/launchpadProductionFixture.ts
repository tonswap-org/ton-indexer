import type { IExecutor } from '../../../tonswap_tolk/node_modules/@ton/sandbox';
import { createT3HubWorld } from '../../../tonswap_tolk/simulations/t3/harness';
import { Address,Cell,toNano } from '../../../tonswap_tolk/node_modules/@ton/core';
import { JettonV21Minter,JettonV21Wallet,jettonOnchainMetadata } from '../../../tonswap_tolk/wrappers/Jetton';
import { DlmmPoolFactory } from '../../../tonswap_tolk/wrappers/DlmmPoolFactory';
import { DlmmPool } from '../../../tonswap_tolk/wrappers/DlmmPool';
import { SaleFactory } from '../../../tonswap_tolk/wrappers/SaleFactory';
import { Sale } from '../../../tonswap_tolk/wrappers/utils/launchpadInit';
import { LpVault } from '../../../tonswap_tolk/wrappers/LpVault';
import { VestingVault } from '../../../tonswap_tolk/wrappers/VestingVault';
import { t3JettonWalletProfile } from '../../../tonswap_tolk/wrappers/jettonWalletBudget';
import { fixedPricingToCell,bondingPricingToCell,auctionPricingToCell,type SaleTerms } from '../../../tonswap_tolk/wrappers/utils/launchpadSaleConfigCodec';
import { publicPoolId } from '../../../tonswap_tolk/tests/fixtures/spotPool';
import { contractCode } from './contractSandbox';
/** Production Hub and real reserve deposits. No issuance shim or account edits. */
export async function launchpadProductionFixture(config:'default'|'x6',kind:number,vestingEnabled:boolean,executor:IExecutor){
 const hubWorld=await createT3HubWorld(config,executor);await hubWorld.pair();const {chain,issuer:admin,owner,other,hub:t3}=hubWorld;
 const feeSink=await chain.treasury('launchpad-fee'),treasury=await chain.treasury('launchpad-treasury'),t3Profile=t3JettonWalletProfile(hubWorld.walletCode);
 await hubWorld.wallet(owner.address).sendTransfer(owner.getSender(),toNano('10'),{queryId:100n,amount:toNano('1000'),destination:other.address,response:owner.address,forwardValue:0n});
 const x=chain.openContract(JettonV21Minter.createFromConfig({admin:admin.address,metadata:jettonOnchainMetadata({symbol:'PROJECT',decimals:'9'})},await contractCode('JettonV21Minter')));
 await x.sendDeploy(admin.getSender(),toNano('1'));for(const to of[owner,other])await x.sendMint(admin.getSender(),toNano('1'),{recipient:to.address,amount:10n**30n,tonAmount:toNano('.5'),responseDestination:admin.address});
 const dlmmFactory=chain.openContract(DlmmPoolFactory.createFromIdentity({governance:admin.address,feeSink:feeSink.address,treasury:treasury.address,t3Master:t3.address,t3Wallet:t3Profile,blockedX:null,poolCode:await contractCode('DlmmPool')},await contractCode('DlmmPoolFactory')));await dlmmFactory.sendDeploy(admin.getSender(),toNano('1'));
 const id=publicPoolId(x.address,9),pool=chain.openContract(DlmmPool.createFromAddress(await dlmmFactory.getPoolAddress(id))),codes=await Promise.all(['SaleFixed','SaleBonding','SaleAuction','LpVault','VestingVault'].map(contractCode)) as[Cell,Cell,Cell,Cell,Cell];
 const factory=chain.openContract(SaleFactory.createFromConfig({governance:admin.address,t3Master:t3.address,t3Wallet:t3Profile,feeSink:feeSink.address,dlmmFactory:dlmmFactory.address,codes},await contractCode('SaleFactory')));await factory.sendDeploy(admin.getSender(),toNano('2'));await factory.sendGate(admin.getSender(),toNano('.1'),false);
 const terms:SaleTerms={projectMaster:x.address,lpRecipient:owner.address,xDecimals:9,startTime:chain.now!+300,endTime:chain.now!+1200,seedBin:0,caps:{softCap:toNano('10'),hardCap:toNano('20'),minContribution:toNano('1'),maxContribution:toNano('20'),saleSupply:toNano('20')},pricing:kind===0?fixedPricingToCell({price:10n**18n}):kind===1?bondingPricingToCell({curveKind:1,basePrice:10n**18n,slopeNumerator:0n,slopeDenominator:1n}):auctionPricingToCell({startPrice:2n*10n**18n,reservePrice:10n**18n,decayInterval:30,tickSize:10n**17n}),vesting:vestingEnabled?{beneficiary:other.address,amount:toNano('5'),cliff:60,duration:300,period:30}:null};
 const nonce=1n,children=await factory.getChildAddresses(owner.address,nonce,kind),sale=chain.openContract(Sale.createFromAddress(children.sale)),lp=chain.openContract(LpVault.createFromAddress(children.lp)),vesting=chain.openContract(VestingVault.createFromAddress(children.vesting));
 const wallet=async(side:number,who:Address)=>chain.openContract(JettonV21Wallet.createFromAddress(await(side===0?t3:x).getWalletAddress(who))),ownerWallets=[await wallet(0,owner.address),await wallet(1,owner.address)],poolWallets=[await wallet(0,pool.address),await wallet(1,pool.address)];
 return{hubWorld,chain,admin,owner,other,feeSink,treasury,t3,t3Profile,x,dlmmFactory,pool,id,codes,factory,kind,nonce,terms,sale,lp,vesting,wallet,ownerWallets,poolWallets,freshT3:{minter:t3,walletCode:hubWorld.walletCode,proofCodeHash:BigInt('0x'+hubWorld.proofCode.hash().toString('hex')),profile:t3Profile}};
}
