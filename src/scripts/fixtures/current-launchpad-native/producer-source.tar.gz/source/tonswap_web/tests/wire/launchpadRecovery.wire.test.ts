import { expect,it } from 'vitest';
import { describeWire,webCell } from '../helpers/contractSandbox';
import { launchpadNativeWorld } from '../helpers/launchpadNativeWire';
import { nativeLaunchpadProof } from '../helpers/launchpadEvidence';
import { prepareLaunchControl,prepareLaunchTransfer } from '../../services/launchpadContracts';
import { inspectLaunchpadEvidence } from '../../services/launchpadOperationSettlement';

describeWire('Launchpad retained financial recovery',()=>{
 it.each(['default','x6'] as const)('failed sale refunds the exact contribution and returns vesting inventory (%s)',async config=>{const f=await launchpadNativeWorld(config,0,true,true);try{await f.arm();f.chain.now=f.terms.startTime;
  const buy=await prepareLaunchTransfer({owner:f.buyerAddress,target:f.saleAddress,kind:'contribute',amount:5_000_000_000n,minTokens:1n,queryId:40n},f.options);await f.send(buy,f.other);f.chain.now=f.terms.endTime;
  const finish=await prepareLaunchControl({owner:f.buyerAddress,target:f.saleAddress,kind:'finalize',queryId:41n},f.options),start=f.captured.length;await f.send(finish,f.other);expect(nativeLaunchpadProof(f,finish,'finalize',start,f.buyerAddress,41n).result.status).toBe('delivered');
  const refund=await prepareLaunchControl({owner:f.buyerAddress,target:f.saleAddress,kind:'claim',queryId:42n},f.options),refundStart=f.captured.length;await f.send(refund,f.other);expect(nativeLaunchpadProof(f,refund,'claim',refundStart,f.buyerAddress,42n).result).toMatchObject({status:'delivered',amountRaw:'5000000000'});
  const vest=await prepareLaunchControl({owner:f.ownerAddress,target:f.vestAddress,kind:'vest-return',queryId:43n},f.options),vestStart=f.captured.length;await f.send(vest);expect(nativeLaunchpadProof(f,vest,'vest-return',vestStart,f.ownerAddress,43n).result.status).toBe('delivered');
  if(process.env.TONSWAP_LAUNCHPAD_RECOVERY_COMPLETE_DIR)await f.exportNative(process.env.TONSWAP_LAUNCHPAD_RECOVERY_COMPLETE_DIR);
 }finally{await f.close();}},90000);
});
