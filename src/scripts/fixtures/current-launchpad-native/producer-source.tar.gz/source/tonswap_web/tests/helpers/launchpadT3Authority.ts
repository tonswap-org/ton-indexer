import { Address, beginCell, Cell, Contract, contractAddress, ContractProvider, Sender, SendMode, toNano } from '../../../tonswap_tolk/node_modules/@ton/core';
import { Blockchain, SandboxContract, TreasuryContract } from '../../../tonswap_tolk/node_modules/@ton/sandbox';
import { ROOT } from '../../../tonswap_tolk/scripts/build/build';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
import { contractCode as compile } from './contractSandbox';
import { jettonOnchainMetadata, type JettonV21Mint } from '../../../tonswap_tolk/wrappers/Jetton';
import { t3JettonWalletProfile } from '../../../tonswap_tolk/wrappers/jettonWalletBudget';

/** Test-only issuance authority; discovery and every transfer use the production fresh wallet. */
export const launchpadT3AuthoritySource = `tolk 1.5.0
import "../t3/wallet_types";
import "../t3/wallet_budget";
import "@gen/op/tep";
import "../shared/jetton/tep89_codec";
struct State { authority: address; walletCode: cell; proofCodeHash: uint256; supply: coins; metadata: cell }
fun onInternalMessage(in: InMessage) {
 if(in.body.remainingBitsCount()<32){return;} var b=in.body;val op=b.loadUint(32);var st=State.fromCell(contract.getData());
 if(op==OP_TEP89_PROVIDE_WALLET_ADDRESS){val p=parse_tep89_provide_wallet_address(in.body);val owner=p.ownerAddress as address;
 createMessage({bounce:BounceMode.NoBounce,value:0,dest:in.senderAddress,body:build_tep89_take_wallet_address(p.queryId,
 t3_wallet_init(owner,contract.getAddress(),st.proofCodeHash,st.walletCode).calculateAddress(),owner,p.includeAddress)}).send(64);return;}
 if(op!=0xe501){return;}assert(in.senderAddress==st.authority) throw 811;
 val query=b.loadUint(64) as uint64;val owner=b.loadAddress();val amount=b.loadCoins();b.assertEnd();
 st.supply+=amount;contract.setData(st.toCell());val value=t3_wallet_mint_value(query,st.authority,st.walletCode);
 createMessage({bounce:BounceMode.RichBounce,dest:t3_wallet_init(owner,contract.getAddress(),st.proofCodeHash,st.walletCode),value,
 body:t3_wallet_mint_body(query,amount,beginCell().storeUint(blockchain.logicalTime(),64).endCell(),st.authority)}).send(17);
}
get fun get_wallet_address(owner: address): address {val st=State.fromCell(contract.getData());return t3_wallet_init(owner,contract.getAddress(),st.proofCodeHash,st.walletCode).calculateAddress();}
get fun get_jetton_data(): (coins, bool, address, cell, cell) { val st=State.fromCell(contract.getData()); return (st.supply,true,st.authority,st.metadata,st.walletCode); }
`;
let fixtureCode: Promise<Cell> | undefined;
function masterCode() {
    fixtureCode ??= (async () => {
        const path = 'contracts/testing/web_launchpad_t3_authority.tolk', worker = require('../../../tonswap_tolk/scripts/build/worker.cjs');
        return Cell.fromBase64((await worker.compileTolk(ROOT, { [path]: launchpadT3AuthoritySource }, path)).codeBoc64);
    })();
    return fixtureCode;
}
class FreshT3Fixture implements Contract {
    constructor(readonly address: Address, readonly init: { code: Cell; data: Cell }) {}
    async sendDeploy(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: Cell.EMPTY });
    }
    async sendMint(provider: ContractProvider, via: Sender, value: bigint, p: JettonV21Mint) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().storeUint(0xe501,32).storeUint(p.queryId ?? 0n,64).storeAddress(p.recipient).storeCoins(p.amount).endCell() });
    }
    async getWalletAddress(provider: ContractProvider, owner: Address) {
        return (await provider.get('get_wallet_address', [{type:'slice',cell:beginCell().storeAddress(owner).endCell()}])).stack.readAddress();
    }
}
export async function deployFreshT3(chain: Blockchain, authority: SandboxContract<TreasuryContract>, walletCodeOverride?: Cell) {
    const [code, walletCode, proofCode] = await Promise.all([masterCode(),walletCodeOverride ?? compile('T3Wallet'),compile('T3RecoveryProof')]);
    const proofCodeHash = BigInt('0x'+proofCode.hash().toString('hex'));
    const init = {code,data:beginCell().storeAddress(authority.address).storeRef(walletCode).storeUint(proofCodeHash,256).storeCoins(0n).storeRef(jettonOnchainMetadata({name:'Web Launchpad T3 authority',symbol:'T3',decimals:'9'})).endCell()};
    const minter = chain.openContract(new FreshT3Fixture(contractAddress(0,init),init));
    await minter.sendDeploy(authority.getSender(),toNano('1'));
    return {minter,walletCode,proofCodeHash,profile:t3JettonWalletProfile(walletCode)};
}
