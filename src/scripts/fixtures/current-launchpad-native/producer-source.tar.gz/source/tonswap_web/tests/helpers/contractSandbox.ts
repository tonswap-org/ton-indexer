/**
 * Delivers web-built wallet requests to the compiled contracts in a sandbox, so a wire test binds a
 * builder, its values and its observer to contract code instead of to bytes the test wrote itself.
 *
 * The build directory is TONSWAP_CONTRACT_BUILD_DIR and nothing else. The sandbox and the contracts' own
 * @ton/core live in the sibling contracts checkout and are loaded on first use, so this file and a wire
 * test still load where only the web repository is checked out. For the same reason a wire test imports
 * a wrapper with `await import()` inside its suite and never at the top of the file.
 *
 * The two @ton/core copies do not share classes: cells cross between them as BOC bytes (runtimeCell,
 * webCell). Everything this file takes from or hands to web code is a string or a web cell.
 */
import { readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { Cell } from '@ton/core';
import { describe, it } from 'vitest';
import releaseManifest from '../fixtures/release-manifest.localnet.json';
import type { Blockchain, BlockchainTransaction, TreasuryContract } from '../../../tonswap_tolk/node_modules/@ton/sandbox';
import type { Cell as RuntimeCell, Message, TupleItem } from '../../../tonswap_tolk/node_modules/@ton/core';

const sandbox = () => import('../../../tonswap_tolk/node_modules/@ton/sandbox');
const runtime = () => import('../../../tonswap_tolk/node_modules/@ton/core');

type Environment = Record<string, string | undefined>;

/** How a wire suite is registered: it runs, or it is skipped or failed for the reason given. */
export function wireSuitePlan(env: Environment = process.env): { mode: 'run' } | { mode: 'skip' | 'fail'; reason: string } {
  const directory = env.TONSWAP_CONTRACT_BUILD_DIR?.trim();
  const reason = !directory ? 'TONSWAP_CONTRACT_BUILD_DIR is not set'
    : statSync(directory, { throwIfNoEntry: false })?.isDirectory() ? null
      : `TONSWAP_CONTRACT_BUILD_DIR is not a directory: ${directory}`;
  if (reason === null) return { mode: 'run' };
  return { mode: env.TONSWAP_REQUIRE_WIRE_CONFORMANCE === '1' ? 'fail' : 'skip', reason };
}

export const contractsAvailable = wireSuitePlan().mode === 'run';

/**
 * A suite that needs the compiled contracts. Without them its body is not evaluated: the suite is
 * skipped with a warning that says why. The release gate sets TONSWAP_REQUIRE_WIRE_CONFORMANCE=1, and a
 * missing build then fails the suite instead of passing unseen.
 */
export function describeWire(name: string, fn: () => void): void {
  const plan = wireSuitePlan();
  if (plan.mode === 'run') { describe(name, fn); return; }
  const { mode, reason } = plan;
  if (mode === 'skip') console.warn(`Wire suite skipped: ${name}. ${reason}.`);
  (mode === 'skip' ? describe.skip : describe)(`${name} (${reason})`, () => {
    it('needs the compiled contracts', () => { throw new Error(reason); });
  });
}

function buildDirectory(): string {
  const plan = wireSuitePlan();
  if (plan.mode !== 'run') throw new Error(plan.reason);
  return path.resolve(process.env.TONSWAP_CONTRACT_BUILD_DIR!.trim());
}

function codeBytes(name: string): Buffer {
  if (!/^[A-Za-z0-9]+$/.test(name)) throw new Error(`${name} is not a build target name`);
  return readFileSync(path.join(buildDirectory(), `${name}.boc`));
}

/** The compiled code of a build target, `<Name>.boc`, as the contracts' @ton/core reads it (what a wrapper takes). */
export async function contractCode(name: string): Promise<RuntimeCell> {
  const roots = (await runtime()).Cell.fromBoc(codeBytes(name));
  if (roots.length !== 1) throw new Error(`${name}.boc must hold exactly one root cell`);
  return roots[0];
}

const releaseCodeHashes = new Set([
  ...Object.values(releaseManifest.contracts).map(contract => contract.codeHash), ...Object.values(releaseManifest.templates)
]);

/** Which bytecode a suite ran: `deployed-r2` when the release manifest fixture names this code hash, otherwise the build directory. */
export function bytecodeLabel(name: string): string {
  return releaseCodeHashes.has(Cell.fromBoc(codeBytes(name))[0].hash().toString('hex')) ? 'deployed-r2' : buildDirectory();
}

/** A web cell, or its base64 BOC, as a cell of the contracts' @ton/core. */
export async function runtimeCell(cell: Cell | string): Promise<RuntimeCell> {
  return (await runtime()).Cell.fromBase64(typeof cell === 'string' ? cell : cell.toBoc().toString('base64'));
}

/** A cell of the contracts' @ton/core as a web cell. */
export function webCell(cell: RuntimeCell): Cell {
  return Cell.fromBoc(cell.toBoc())[0];
}

/** A fresh sandbox chain. Wallets are its treasuries: `await chain.treasury('owner')`. */
export async function openChain(): Promise<Blockchain> {
  return (await sandbox()).Blockchain.create();
}

/** One message of a wallet request, as the web hands it to the wallet. */
export type WireMessage = { address: string; amount: string; payload?: string; stateInit?: string };

export type DeliveredTransaction = {
  /** Raw address of the account the transaction ran on. */
  account: string;
  aborted: boolean;
  /** The compute exit code; the action result code when compute succeeded and the action phase failed; null when compute was skipped. */
  exitCode: number | null;
  /** The transaction sent its incoming message back to the sender. */
  bounced: boolean;
  valueIn: bigint;
  /** The sum of the internal messages the transaction sent. */
  valueOut: bigint;
  /** The whole transaction as the sandbox decoded it (contracts' @ton/core). */
  transaction: BlockchainTransaction;
};

function summarize(transaction: BlockchainTransaction): DeliveredTransaction {
  const { description, inMessage } = transaction;
  if (description.type !== 'generic' || !inMessage || inMessage.info.type === 'external-out') throw new Error('A delivery holds ordinary transactions only');
  const { computePhase: compute, actionPhase: action } = description;
  let valueOut = 0n;
  for (const message of transaction.outMessages.values()) if (message.info.type === 'internal') valueOut += message.info.value.coins;
  return {
    account: inMessage.info.dest.toRawString(),
    aborted: description.aborted,
    exitCode: compute.type !== 'vm' ? null : compute.success && action && !action.success ? action.resultCode : compute.exitCode,
    bounced: description.bouncePhase?.type === 'ok',
    valueIn: inMessage.info.type === 'internal' ? inMessage.info.value.coins : 0n,
    valueOut,
    transaction
  };
}

/**
 * Sends the messages of one wallet request from the owner's wallet, as a wallet does: one external
 * message, every internal message with its fee paid separately and the bounce flag of its address.
 * Returns every transaction that followed, in execution order; the first is the wallet's own.
 */
export async function deliver(
  chain: Blockchain, owner: Pick<TreasuryContract, 'address' | 'createTransfer'>, messages: readonly WireMessage[]
): Promise<DeliveredTransaction[]> {
  const core = await runtime();
  const transfer = owner.createTransfer({
    sendMode: core.SendMode.PAY_GAS_SEPARATELY + core.SendMode.IGNORE_ERRORS,
    messages: messages.map(message => {
      const to = core.Address.isFriendly(message.address) ? core.Address.parseFriendly(message.address)
        : { address: core.Address.parseRaw(message.address), isBounceable: true };
      return core.internal({
        to: to.address, bounce: to.isBounceable, value: BigInt(message.amount),
        body: message.payload === undefined ? undefined : core.Cell.fromBase64(message.payload),
        init: message.stateInit === undefined ? undefined : core.loadStateInit(core.Cell.fromBase64(message.stateInit).beginParse())
      });
    })
  });
  const { transactions } = await chain.sendMessage(core.external({ to: owner.address, body: transfer }));
  return transactions.map(summarize);
}

export type SandboxStackEntry = [string, unknown];
type SandboxGetterArg = { type: 'int' | 'cell' | 'slice' | 'builder'; value?: bigint; cell?: Cell };
type SandboxBlockId = { workchain: number; shard: string; seqno: number; root_hash: string; file_hash: string };
type SandboxMessageRow = { source: string; destination: string; value: string; msg_data: { body: string } };
export type SandboxTransactionRow = {
  utime: number;
  /** The original transaction cell, base64. */
  data: string;
  transaction_id: { lt: string; hash: string };
  in_msg?: SandboxMessageRow;
  out_msgs: SandboxMessageRow[];
};

/** The three chain reads an observer makes, answered by a sandbox chain in the shapes `services/toncenter.ts` returns. */
export type SandboxRpc = {
  /** Takes the arguments of the service's `runGetMethod`. An account without code answers exit code -13, as the RPC does. */
  runGetMethod(address: string, method: string, stack?: readonly SandboxGetterArg[]): Promise<{
    stack: SandboxStackEntry[]; exit_code: number; gas_used: number; block_id: SandboxBlockId;
  }>;
  getAddressInformation(address: string): Promise<{
    state: 'active' | 'uninitialized' | 'frozen'; balance: string; code: string; data: string;
    last_transaction_id: { lt: string; hash: string }; block_id: SandboxBlockId; sync_utime: number;
  }>;
  /** Raw history, newest first. The cursor is inclusive, as on the RPC; its hash is base64 or hex. */
  getTransactions(address: string, limit?: number, cursor?: { lt: string; hash: string }): Promise<SandboxTransactionRow[]>;
};

const base64 = (cell: RuntimeCell) => cell.toBoc().toString('base64');

const stackEntry = (item: TupleItem): SandboxStackEntry =>
  item.type === 'int' ? ['num', item.value.toString()]
    : item.type === 'cell' || item.type === 'slice' || item.type === 'builder' ? [item.type, { bytes: base64(item.cell) }]
      : item.type === 'tuple' ? ['tuple', item.items.map(stackEntry)] : [item.type, null];

const messageRow = ({ info, body }: Message): SandboxMessageRow => ({
  source: info.type === 'external-in' ? '' : info.src.toRawString(),
  destination: info.type === 'external-out' ? '' : info.dest.toRawString(),
  value: info.type === 'internal' ? info.value.coins.toString() : '0',
  msg_data: { body: base64(body) }
});

const hashBytes = (hash: string) => Buffer.from(hash, /^[0-9a-f]{64}$/i.test(hash) ? 'hex' : 'base64');

export function sandboxRpc(chain: Blockchain): SandboxRpc {
  // The sandbox has no blocks. One step of its logical time stands for one masterchain block, so a read
  // that asks for a real block and its time is answered, and a later read never names an earlier block.
  const head = () => {
    const seqno = Number(chain.lt / 1_000_000n) + 1;
    const hash = (fill: number) => { const bytes = Buffer.alloc(32, fill); bytes.writeUInt32BE(seqno, 28); return bytes.toString('base64'); };
    return {
      block_id: { workchain: -1, shard: '-9223372036854775808', seqno, root_hash: hash(1), file_hash: hash(2) },
      sync_utime: chain.now ?? Math.floor(Date.now() / 1000)
    };
  };
  return {
    async runGetMethod(address, method, stack = []) {
      const core = await runtime(), { GetMethodError } = await sandbox();
      const account = core.Address.parse(address), { block_id } = head();
      if ((await chain.getContract(account)).accountState?.type !== 'active') return { stack: [], exit_code: -13, gas_used: 0, block_id };
      const args = stack.map((item): TupleItem => item.type === 'int' ? { type: 'int', value: item.value ?? 0n }
        : item.cell ? { type: item.type, cell: core.Cell.fromBoc(item.cell.toBoc())[0] } : { type: 'null' });
      try {
        const result = await chain.runGetMethod(account, method, args);
        return { stack: result.stack.map(stackEntry), exit_code: result.exitCode, gas_used: Number(result.gasUsed), block_id };
      } catch (error) {
        if (!(error instanceof GetMethodError)) throw error;
        return { stack: [], exit_code: error.exitCode, gas_used: Number(error.gasUsed), block_id };
      }
    },
    async getAddressInformation(address) {
      const contract = await chain.getContract((await runtime()).Address.parse(address)), state = contract.accountState;
      const active = state?.type === 'active' ? state.state : null;
      return {
        state: active ? 'active' : state?.type === 'frozen' ? 'frozen' : 'uninitialized',
        balance: contract.balance.toString(),
        code: active?.code ? base64(active.code) : '',
        data: active?.data ? base64(active.data) : '',
        last_transaction_id: {
          lt: contract.lastTransactionLt.toString(),
          hash: Buffer.from(contract.lastTransactionHash.toString(16).padStart(64, '0'), 'hex').toString('base64')
        },
        ...head()
      };
    },
    async getTransactions(address, limit = 10, cursor) {
      // The sandbox's own listing reorders its record on every call and cannot match a cursor: order and page here.
      const history = (await chain.getTransactions((await runtime()).Address.parse(address))).sort((a, b) => a.lt < b.lt ? 1 : -1);
      const from = cursor ? history.findIndex(row => row.lt.toString() === cursor.lt && row.hash().equals(hashBytes(cursor.hash))) : 0;
      if (from < 0) throw new Error(`${address} has no transaction ${cursor!.lt}:${cursor!.hash}`);
      return history.slice(from, from + limit).map(row => ({
        utime: row.now,
        data: base64(row.raw),
        transaction_id: { lt: row.lt.toString(), hash: row.hash().toString('base64') },
        in_msg: row.inMessage ? messageRow(row.inMessage) : undefined,
        out_msgs: row.outMessages.values().map(messageRow)
      }));
    }
  };
}
