import { expect,it } from 'vitest';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { describeWire } from '../helpers/contractSandbox';
import { launchpadNativeWorld } from '../helpers/launchpadNativeWire';
import { inspectLaunchpadEvidence, type LaunchpadEvidenceRequest } from '../../services/launchpadOperationSettlement';
import { verifyCurrentT3Transaction } from '../../services/t3CurrentEvidence';
import { TONSWAP_RELEASE } from '../../releaseManifest';
import { prepareLaunchControl, prepareLaunchTransfer, readNativeSale } from '../../services/launchpadContracts';

describeWire('current Launchpad native web requests',()=>{
 for(const kind of [0,1,2] as const)it.each(['default','x6'] as const)(`creates, arms, contributes and claims kind ${kind} with live funding (%s)`,async config=>{
  const f=await launchpadNativeWorld(config,kind,true,true);try{
   await f.arm();f.chain.now=f.terms.startTime;
   const buy=await prepareLaunchTransfer({owner:f.buyerAddress,target:f.saleAddress,kind:'contribute',amount:20_000_000_000n,minTokens:1n,queryId:7n},f.options);
   const buyStart=f.captured.length;await f.send(buy,f.other);
   const proof=(plan:typeof buy|Awaited<ReturnType<typeof prepareLaunchControl>>,kind:LaunchpadEvidenceRequest['kind'],start:number,owner=f.buyerAddress,q=7n)=>{const txs=f.captured.slice(start),dispatch=txs.map(verifyCurrentT3Transaction).find(t=>t.account===owner.toRawString()&&t.tx.outMessages.values().some(m=>m.body.equals(plan.body)))!;
    const transfer='tokenRoot'in plan,assets=transfer?[{root:plan.tokenRoot.toRawString(),masterCodeHash:plan.masterCodeHash,walletCodeHash:plan.walletCodeHash,amountRaw:'20000000000',recipient:f.saleAddress.toRawString()}]:plan.assets.map(a=>({root:a.root.toRawString(),masterCodeHash:a.masterCodeHash,walletCodeHash:a.walletCodeHash,amountRaw:a.amount.toString(),recipient:a.recipient.toRawString()}));
    const p:LaunchpadEvidenceRequest={network:'localnet',releaseId:'native',manifestHash:'a'.repeat(64),kind,owner:owner.toRawString(),factory:f.binding.factory.toRawString(),sale:f.saleAddress.toRawString(),target:transfer?f.saleAddress.toRawString():plan.address.toRawString(),creator:f.ownerAddress.toRawString(),nonce:f.nonce.toString(),model:kind==='contribute'?buy.state.child!.identity.kind:plan.state.child!.identity.kind,queryId:q.toString(),tokenRoot:transfer?plan.tokenRoot.toRawString():assets.length===1?assets[0].root:null,amountRaw:transfer?'20000000000':plan.amount.toString(),minTokensRaw:transfer?'1':null,sourceWallet:transfer?plan.sourceWallet.toRawString():null,assets,bodyBoc:plan.body.toBoc().toString('base64'),bodyHash:plan.body.hash().toString('hex'),valueNano:plan.value.toString(),createdAt:f.chain.now!*1000,dispatch:{lt:dispatch.tx.lt.toString(),hash:dispatch.hash,valueNano:plan.value.toString()}};
    const binding={pool:f.poolProof,state:plan.state,proofCodeHash:TONSWAP_RELEASE!.templates.T3RecoveryProof,v21WalletHash:f.binding.projectWalletHash,stablecoinWalletHash:TONSWAP_RELEASE!.vendor.stablecoin.wallet.codeHash};const result=inspectLaunchpadEvidence(p,binding,txs);if(process.env.TONSWAP_LAUNCHPAD_CAPTURE_DIR){const dir=process.env.TONSWAP_LAUNCHPAD_CAPTURE_DIR;mkdirSync(dir,{recursive:true});const name=`${p.model}-${config}-${kind}.json`;writeFileSync(join(dir,name),JSON.stringify({request:p,result,head:plan.state.head,binding:{factory:p.factory,factoryCodeHash:f.binding.factoryHash,creator:p.creator,t3Root:f.binding.t3Root.toRawString(),t3MasterHash:f.binding.t3MasterHash,t3WalletHash:f.binding.t3WalletHash,projectMasterHashes:f.binding.projectMasterHashes,projectWalletHash:f.binding.projectWalletHash,templates:f.binding.templateHashes,proofCodeHash:binding.proofCodeHash},transactions:txs},null,2),{flag:'wx'});}return{p,txs,binding,result};};
   expect(proof(buy,'contribute',buyStart).result).toMatchObject({status:'delivered',amountRaw:'20000000000'});const before=await readNativeSale(f.saleAddress,f.options);expect(before.sale.entries.get(f.buyerAddress)?.paid).toBe(20_000_000_000n);
   const finalized=await prepareLaunchControl({owner:f.buyerAddress,target:f.saleAddress,kind:'finalize',queryId:8n},f.options);const finalizeStart=f.captured.length;await f.send(finalized,f.other);expect(proof(finalized,'finalize',finalizeStart,f.buyerAddress,8n).result).toMatchObject({status:'delivered'});
   expect((await readNativeSale(f.saleAddress,f.options)).sale.phase).toBe(2);
   const claim=await prepareLaunchControl({owner:f.buyerAddress,target:f.saleAddress,kind:'claim',queryId:9n},f.options);expect(claim.amount).toBe(before.sale.entries.get(f.buyerAddress)?.tokens);const claimStart=f.captured.length;await f.send(claim,f.other);const actual=proof(claim,'claim',claimStart,f.buyerAddress,9n);expect(actual.result).toMatchObject({status:'delivered'});expect(inspectLaunchpadEvidence(actual.p,actual.binding,actual.txs.filter(t=>t.account!==f.buyerAddress.toRawString()))).toMatchObject({status:'pending'});
   expect((await readNativeSale(f.saleAddress,f.options)).sale.entries.has(f.buyerAddress)).toBe(false);
   const seed=await prepareLaunchControl({owner:f.ownerAddress,target:f.lpAddress,kind:'lp-seed',queryId:10n},f.options);const seedStart=f.captured.length;await f.send(seed);expect(proof(seed,'lp-seed',seedStart,f.ownerAddress,10n).result).toMatchObject({status:'delivered'});expect((await f.lp.getState()).t3Bal).toBe(0n);
   f.chain.now+=300;const vest=await prepareLaunchControl({owner:f.buyerAddress,target:f.vestAddress,kind:'vest-claim',queryId:11n},f.options);expect(vest.amount).toBe(f.terms.vesting!.amount);const vestStart=f.captured.length;await f.send(vest,f.other);expect(proof(vest,'vest-claim',vestStart,f.buyerAddress,11n).result).toMatchObject({status:'delivered'});
   f.chain.now=(await f.lp.getState()).unlockAt+1;const release=await prepareLaunchControl({owner:f.ownerAddress,target:f.lpAddress,kind:'lp-release',queryId:12n,remove:true},f.options),releaseStart=f.captured.length;await f.send(release);expect(proof(release,'lp-release',releaseStart,f.ownerAddress,12n).result).toMatchObject({status:'delivered'});
   if(process.env.TONSWAP_LAUNCHPAD_COMPLETE_DIR)await f.exportNative(process.env.TONSWAP_LAUNCHPAD_COMPLETE_DIR);
  }finally{await f.close();}
 },90000);
});
