import fixture from '../fixtures/release-manifest.localnet.json';
import { installReleaseManifest, manifestHash, type ReleaseManifestV1 } from '../../releaseManifest';

/** Install before importing constants or consumers, in the same order as the browser boot. */
export function installTestRelease(services: Partial<ReleaseManifestV1['services']> = {}) {
  const m = { ...fixture, network: 'ton:testnet' as const, services: { indexer: "https://test.tonswap.org/api/indexer", platform: "https://test.tonswap.org/api/platform", tonRpc: "https://testnet.toncenter.com/api/v2/jsonRPC", ...services } } as ReleaseManifestV1;
  return installReleaseManifest({ ...m, manifestHash: manifestHash(m) });
}

installTestRelease();
