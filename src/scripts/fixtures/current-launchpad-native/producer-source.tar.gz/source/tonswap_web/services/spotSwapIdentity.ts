import { Address } from '@ton/core';
import type { ExecutionNetwork } from './executionNetwork';
/** Immutable wallet authorization. Display quotes are stored separately from executed amounts. */
export type SpotDirectSwapIdentity = {
  network: ExecutionNetwork; releaseId: string; manifestHash: string; validUntil: number; wallet: string; pool: string; poolCodeHash: string; payRoot: string; receiveRoot: string;
  payWallet: string; receiveWallet: string; queryId: string; requestBodyHash: string;
  amountInRaw: string; minAmountOutRaw: string; payDecimals: number; receiveDecimals: number; submittedAt: number;
};
export type SpotSwapIdentity = SpotDirectSwapIdentity;
export const spotIdentityFields = ['network','releaseId','manifestHash','validUntil','wallet','pool','poolCodeHash','payRoot','receiveRoot','payWallet','receiveWallet','queryId','requestBodyHash','amountInRaw','minAmountOutRaw','payDecimals','receiveDecimals','submittedAt'] as const;
const canonical = (v: unknown) => { try { return typeof v === 'string' ? Address.parse(v).toRawString() : null; } catch { return null; } };
const positive = (v: unknown): v is string => typeof v === 'string' && /^[1-9]\d{0,36}$/.test(v) && BigInt(v) < 1n << 120n;
const routedFields = ['router','routerCodeHash','marketId','referrer'] as const;
export function isSpotSwapIdentity(v: unknown): v is SpotSwapIdentity {
  const p=v as SpotSwapIdentity|null;
  return !!p && ['mainnet','testnet','localnet'].includes(p.network) &&
    typeof p.releaseId === 'string' && p.releaseId.length > 0 && p.releaseId.length <= 128 &&
    typeof p.manifestHash === 'string' && /^[a-f0-9]{64}$/.test(p.manifestHash) &&
    Number.isSafeInteger(p.validUntil) && p.validUntil > Math.floor(p.submittedAt / 1000) && p.validUntil <= 0xffffffff &&
    [p.wallet,p.pool,p.payRoot,p.receiveRoot,p.payWallet,p.receiveWallet].every(v=>typeof v==='string'&&canonical(v)===v) &&
    [p.payDecimals,p.receiveDecimals].every(d=>Number.isInteger(d)&&d>=0&&d<=30) && p.payRoot!==p.receiveRoot && p.payWallet!==p.receiveWallet &&
    typeof p.poolCodeHash==='string'&&/^[a-f0-9]{64}$/.test(p.poolCodeHash)&&positive(p.queryId)&&BigInt(p.queryId)<1n<<64n&&typeof p.requestBodyHash==='string'&&/^[a-f0-9]{64}$/.test(p.requestBodyHash)&&positive(p.amountInRaw)&&positive(p.minAmountOutRaw)&&Number.isSafeInteger(p.submittedAt)&&p.submittedAt>0 && !routedFields.some(key => key in p);
}
export const sameSpotSwapIdentity = (a: SpotSwapIdentity,b: SpotSwapIdentity) =>
  spotIdentityFields.every(key=>a[key]===b[key]);
