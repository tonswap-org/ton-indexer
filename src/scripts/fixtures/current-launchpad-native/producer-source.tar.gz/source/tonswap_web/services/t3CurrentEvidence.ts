import { Address, Cell, Dictionary, beginCell, contractAddress, loadAccount, loadCommonMessageInfo, loadMessage, loadShardAccount, loadStateInit, loadTransaction, storeMessage } from '@ton/core';
import { Buffer } from 'buffer';
import { TONSWAP_T3_REDEMPTION } from '../releaseManifest';
import { indexerRequest } from './indexer';
import { parseT3RedemptionBinding } from './t3Redemption';
import type { T3RedemptionRecovery } from './t3Redemption';
import type { TransactionRef } from './walletRequest';
import type { T3ReceiptWitness } from './t3Contracts';
import type { T3RedemptionBinding } from './t3RedemptionBinding';
import { T3_OP, readT3HubBurnRecord, readT3HubCreditRecord, readT3Intent, readT3Storage, readT3WalletStorage, readT3WalletRecord, t3WalletInitialData, t3WalletAttemptToCell, t3WalletEvidence, t3RequestIntent, verifyT3Witness } from './t3Contracts';

type RequestIdentity = {
  network: T3RedemptionBinding['network']; releaseId: string; manifestHash: string;
  owner: string; hub: string; queryId: string; amountRaw: string; recipient: string;
  minimumRaw: string; bodyBoc: string; bodyHash: string;
};
export type CurrentT3Request =
  | RequestIdentity & { kind: 'mint'; collateralRoot: string; input: 0 | 1 | 2; sourceWallet: string; valueNano: string; submittedAt: number }
  | RequestIdentity & { kind: 'redeem'; wallet: string; single: boolean; outputToken: 0 | 1 | 2; createdAt: number };

/** Original archive cells. The authenticated source adapter must bind these to
 * its declared network and block; hash consistency alone is not consensus. */
export type CurrentT3TransactionEvidence = {
  account: string; transactionBoc: string; beforeShardAccountBoc: string; afterShardAccountBoc: string;
};
export type CurrentT3ReceiptCandidate = {
  slot: number; key: string; recordBoc: string; recordHash: string; witnessBoc: string;
  owner: string; kind: 'credit' | 'burn'; phase: number | null;
};
export type CurrentT3HubAccount = { address: string; codeBoc: string; dataBoc: string };
const hash = (c: Cell) => c.hash().toString('hex');
function requireEvidence(value: unknown, detail: string): asserts value {
  if (!value) throw Error(`Current T3 evidence: ${detail}`);
}
function address(raw: string): Address {
  const value = Address.parse(raw); requireEvidence(value.workChain === 0 && value.toRawString() === raw, 'invalid account'); return value;
}
function ordinary(cell: Cell) { requireEvidence(!cell.isExotic, 'ordinary cell required'); return cell.beginParse(); }
function uint(raw: string, bits: number) {
  requireEvidence(typeof raw === 'string' && /^(0|[1-9]\d{0,77})$/.test(raw) && BigInt(raw) < 1n << BigInt(bits), 'invalid integer'); return BigInt(raw);
}
export function currentT3Cell(boc: string): Cell {
  requireEvidence(typeof boc === 'string' && boc.length <= 16 * 1024 * 1024, 'invalid BOC size');
  const bytes = Buffer.from(boc, 'base64'); requireEvidence(bytes.toString('base64') === boc, 'noncanonical BOC');
  const cells = Cell.fromBoc(bytes); requireEvidence(cells.length === 1 && !cells[0].isExotic, 'single ordinary BOC required'); return cells[0];
}
function shardAccount(boc: string, account: Address) {
  const cell = currentT3Cell(boc), s = ordinary(cell), shard = loadShardAccount(s); s.endParse();
  requireEvidence(cell.refs.length === 1 && !cell.refs[0].isExotic, 'invalid account cell');
  const inner = ordinary(cell.refs[0]); if (inner.loadBit()) loadAccount(inner); inner.endParse();
  requireEvidence(!shard.account || shard.account.addr.equals(account), 'account identity mismatch');
  return { shard, accountHash: hash(cell.refs[0]) };
}
export function verifyCurrentT3Transaction(e: CurrentT3TransactionEvidence) {
  const account = address(e.account), cell = currentT3Cell(e.transactionBoc), s = ordinary(cell), tx = loadTransaction(s); s.endParse();
  requireEvidence(tx.address === BigInt('0x' + account.hash.toString('hex')) && tx.lt > 0n && tx.prevTransactionLt < tx.lt &&
    ((tx.prevTransactionLt === 0n) === (tx.prevTransactionHash === 0n)), 'transaction identity mismatch');
  requireEvidence(!tx.inMessage || tx.inMessage.info.type !== 'external-out' && tx.inMessage.info.dest.equals(account), 'input endpoint mismatch');
  for (const message of tx.outMessages.values()) requireEvidence(message.info.type !== 'external-in' && message.info.src.equals(account), 'output endpoint mismatch');
  const before = shardAccount(e.beforeShardAccountBoc, account), after = shardAccount(e.afterShardAccountBoc, account);
  requireEvidence(before.accountHash === tx.stateUpdate.oldHash.toString('hex') && after.accountHash === tx.stateUpdate.newHash.toString('hex'), 'state commitment mismatch');
  requireEvidence(before.shard.lastTransactionLt === tx.prevTransactionLt && before.shard.lastTransactionHash === tx.prevTransactionHash &&
    after.shard.lastTransactionLt === tx.lt && after.shard.lastTransactionHash === BigInt('0x' + hash(cell)), 'state transaction mismatch');
  const raw = ordinary(cell); raw.skip(4 + 256 + 64 + 256 + 64 + 32 + 15 + 2 + 2);
  const messages = ordinary(raw.loadRef()), incoming = messages.loadMaybeRef(), outgoing = messages.loadDict(Dictionary.Keys.Uint(15), Dictionary.Values.Cell()); messages.endParse();
  requireEvidence(outgoing.size === tx.outMessagesCount, 'outgoing message count mismatch');
  const d = tx.description;
  const succeeded = d.type === 'generic' && !d.aborted && !d.destroyed && d.computePhase.type === 'vm' && d.computePhase.success &&
    [0, 1].includes(d.computePhase.exitCode) && (!d.actionPhase || d.actionPhase.valid && d.actionPhase.success && d.actionPhase.resultCode === 0);
  return { account: e.account, tx, hash: hash(cell), before: before.shard, after: after.shard, incoming, outgoing, succeeded };
}
export type CurrentT3Transaction = ReturnType<typeof verifyCurrentT3Transaction>;
export function currentT3ActiveState(shard: CurrentT3Transaction['after'], codeHash: string) {
  requireEvidence(shard.account?.storage.state.type === 'active', 'inactive account');
  const state = shard.account.storage.state.state;
  requireEvidence(state.code && state.data && hash(state.code) === codeHash && !state.special && (!state.libraries || state.libraries.size === 0), 'account code mismatch');
  return { code: state.code, data: state.data, splitDepth:state.splitDepth??null };
}

/** Decode the existing receipt-candidate wire format. Membership establishes a
 * live claim only; this function deliberately does not establish delivery. */
export function decodeCurrentT3Receipt(candidate: CurrentT3ReceiptCandidate, hubAccount: CurrentT3HubAccount, request: CurrentT3Request, binding: T3RedemptionBinding) {
  requireEvidence(request.network === binding.network && request.releaseId === binding.releaseId && request.manifestHash === binding.manifestHash &&
    request.hub === binding.hub && hubAccount.address === binding.hub, 'release identity mismatch');
  address(request.owner); address(request.recipient); address(request.hub);
  const body = currentT3Cell(request.bodyBoc); requireEvidence(hash(body) === request.bodyHash, 'original request hash mismatch');
  const code = currentT3Cell(hubAccount.codeBoc); requireEvidence(hash(code) === binding.hubCodeHash, 'hub code mismatch');
  const hubData = currentT3Cell(hubAccount.dataBoc), hub = readT3Storage(hubData);
  requireEvidence(hub.config.governance.equals(address(binding.governance)) && hash(hub.config.walletCode) === binding.walletCodeHash &&
    hub.config.proofCodeHash === BigInt('0x' + binding.recoveryProofCodeHash) && hub.reserves.size === binding.reserves.length, 'hub binding mismatch');
  for (const pin of binding.reserves) {
    const reserve = hub.reserves.get(pin.slot), policy = hub.config.policies.get(pin.slot);
    requireEvidence(reserve && policy && reserve.master.equals(address(pin.master)) && policy.codeHash === BigInt('0x' + pin.walletCodeHash) &&
      policy.scale === 10 ** (9 - pin.decimals) && reserve.optional === (pin.slot === 2), 'reserve pin mismatch');
  }
  const key = uint(candidate.key, 64), record = currentT3Cell(candidate.recordBoc), witness = ordinary(currentT3Cell(candidate.witnessBoc));
  requireEvidence(witness.loadRef().equals(record), 'witness record mismatch'); const proof = witness.loadRef(); witness.endParse();
  const r = ordinary(record); requireEvidence(r.loadUintBig(64) === key, 'receipt key mismatch'); r.loadRef(); r.endParse();
  const expectedSlot = request.kind === 'redeem' ? 3 : request.input;
  requireEvidence(candidate.slot === expectedSlot && candidate.owner === request.owner && hash(record) === candidate.recordHash &&
    hub.receipts[expectedSlot].initialized && key <= hub.receipts[expectedSlot].lastKey &&
    verifyT3Witness(record, key, proof, hub.receipts[expectedSlot].root), 'receipt membership mismatch');
  const amount = uint(request.amountRaw, 120), query = uint(request.queryId, 64), minimum = uint(request.minimumRaw, 120);
  requireEvidence(amount > 0n, 'zero request');
  let intent: Cell;
  if (request.kind === 'redeem') {
    requireEvidence(candidate.kind === 'burn' && candidate.phase === null, 'burn receipt required');
    const receipt = readT3HubBurnRecord(record), a = receipt.attempt, b = ordinary(body);
    requireEvidence(b.loadUint(32) === T3_OP.TEP74_BURN && b.loadUintBig(64) === query && b.loadCoins() === amount &&
      b.loadAddress().equals(address(request.owner)), 'burn request mismatch');
    const custom = b.loadMaybeRef(); b.endParse(); requireEvidence(custom, 'missing burn intent'); intent = custom;
    requireEvidence(a.burn && a.owner.equals(address(request.owner)) && a.recipient.equals(a.owner) && a.amount === amount &&
      a.details.queryId === query && a.details.response?.equals(a.owner) && a.details.forwardValue === 0n &&
      a.details.forwardPayload.equals(beginCell().storeBit(false).endCell()) && a.details.customPayload?.equals(custom), 'burn attempt mismatch');
    const terms = readT3Intent(intent);
    requireEvidence(terms.kind === 'redeem' && terms.recipient.equals(address(request.recipient)) && terms.minimum === minimum &&
      terms.single === request.single && terms.output === request.outputToken && !terms.strict, 'redemption terms mismatch');
    return { kind: 'redeem' as const, candidate, key, record, hub, hubData, receipt, intent, body };
  }
  requireEvidence(candidate.kind === 'credit', 'collateral receipt required');
  const receipt = readT3HubCreditRecord(record); intent = t3RequestIntent(body);
  const b = ordinary(body); requireEvidence(b.loadUint(32) === T3_OP.TEP74_TRANSFER && b.loadUintBig(64) === query && b.loadCoins() === amount &&
    b.loadAddress().equals(address(binding.hub)), 'deposit request mismatch');
  const terms = readT3Intent(intent), pin = binding.reserves.find(p => p.slot === request.input);
  requireEvidence(pin?.master === request.collateralRoot && terms.kind === 'mint' && terms.recipient.equals(address(request.recipient)) && terms.minimum === minimum &&
    candidate.phase === receipt.phase && receipt.credit.owner.equals(address(request.owner)) && receipt.credit.queryId === query &&
    receipt.credit.amount === amount && receipt.credit.intent.equals(intent), 'mint terms mismatch');
  return { kind: 'mint' as const, candidate, key, record, hub, hubData, receipt, intent, body };
}

export type CurrentT3Receipt = ReturnType<typeof decodeCurrentT3Receipt>;
export type CurrentT3Settlement = { txId:string;deliveredRaw:[string,string,string];mintedRaw:string;feeBreakdown:'unavailable' } & ({status:'confirmed'}|{status:'refunded'});
const maybe = <T>(read: () => T): T | null => { try { return read(); } catch { return null; } };
function rawInput(node: CurrentT3Transaction) {
  requireEvidence(node.succeeded && node.incoming, 'successful input required');
  const s = ordinary(node.incoming), message = loadMessage(s); s.endParse();
  requireEvidence(message.info.type === 'internal' && !message.info.bounced, 'original internal input required');
  return message as typeof message & { info: Extract<typeof message.info, { type: 'internal' }> };
}
export function verifyCurrentT3MessageLink(source: CurrentT3Transaction, target: CurrentT3Transaction) {
  // StateInit and body may legally change between inline/reference placement.
  // Compare the complete parsed message, preserving every semantic field and
  // both independently checked original transaction commitments.
  const canonical=(cell:Cell)=>{
    const s=ordinary(cell),info=loadCommonMessageInfo(s);let init=null;
    if(s.loadBit()){if(s.loadBit()){const ref=ordinary(s.loadRef());init=loadStateInit(ref);ref.endParse();}else init=loadStateInit(s);}
    const body=either(s);return beginCell().store(storeMessage({info,init,body})).endCell();
  };
  return !!target.incoming && target.tx.lt>source.tx.lt && source.outgoing.values().some(cell => canonical(cell).equals(canonical(target.incoming!)));
}
const linked=verifyCurrentT3MessageLink;
function hubBoundary(tx: CurrentT3Transaction, decoded: CurrentT3Receipt, binding: T3RedemptionBinding) {
  requireEvidence(tx.account === binding.hub && tx.succeeded, 'hub transaction required');
  const before = currentT3ActiveState(tx.before, binding.hubCodeHash), after = currentT3ActiveState(tx.after, binding.hubCodeHash);
  requireEvidence(before.data.refs[0].equals(decoded.hubData.refs[0]) && after.data.refs[0].equals(decoded.hubData.refs[0]), 'historical hub config mismatch');
  return { before: readT3Storage(before.data), after: readT3Storage(after.data) };
}
function receiptEmitted(tx: CurrentT3Transaction, slot: number, key: bigint, record?: Cell) {
  return tx.tx.outMessages.values().some(m => !!maybe(() => {
    requireEvidence(m.info.type === 'external-out', 'external receipt required'); const s = ordinary(m.body);
    requireEvidence(s.loadUint(32) === T3_OP.T3_HUB_RECEIPT && s.loadUint(2) === slot, 'receipt slot mismatch');
    const emitted = s.loadRef(); s.endParse(); const r = ordinary(emitted);
    requireEvidence(r.loadUintBig(64) === key && (!record || emitted.equals(record)), 'receipt identity mismatch'); return true;
  }));
}
function walletDelta(tx: CurrentT3Transaction, binding: T3RedemptionBinding, owner: string, amount: bigint, decoded: CurrentT3Receipt) {
  const after = currentT3ActiveState(tx.after, binding.walletCodeHash), a = readT3WalletStorage(after.data);
  const expected = contractAddress(0, { code: decoded.hub.config.walletCode,
    data: t3WalletInitialData(address(owner), address(binding.hub), BigInt('0x' + binding.recoveryProofCodeHash)) }).toRawString();
  requireEvidence(tx.account === expected && a.owner.equals(address(owner)) && a.master.equals(address(binding.hub)) &&
    a.proofCodeHash === BigInt('0x' + binding.recoveryProofCodeHash), 'T3 wallet identity mismatch');
  let prior = 0n;
  if (tx.before.account?.storage.state.type === 'active') {
    const b = readT3WalletStorage(currentT3ActiveState(tx.before, binding.walletCodeHash).data);
    requireEvidence(b.owner.equals(a.owner) && b.master.equals(a.master) && b.proofCodeHash === a.proofCodeHash, 'prior T3 identity mismatch'); prior = b.balance;
  } else requireEvidence(!tx.before.account || tx.before.account.storage.state.type === 'uninit', 'frozen T3 wallet');
  requireEvidence(a.balance - prior === amount, 'T3 wallet balance delta mismatch');
}
function reserveDelta(tx: CurrentT3Transaction, pin: T3RedemptionBinding['reserves'][number], owner: string, amount: bigint) {
  const read = (data: Cell) => {
    const s = ordinary(data), governed = data.bits.length % 8 === 6;
    requireEvidence(governed || data.bits.length % 8 === 2, 'reserve profile mismatch');
    if (governed) s.loadUint(4);
    const balance = s.loadCoins(); requireEvidence(s.loadAddress().equals(address(owner)) && s.loadAddress().equals(address(pin.master)), 'reserve wallet identity mismatch');
    s.endParse(); return {balance,governed};
  };
  const afterState=currentT3ActiveState(tx.after,pin.walletCodeHash),after=read(afterState.data);
  requireEvidence(afterState.splitDepth===null||afterState.splitDepth===8,'unsupported reserve prefix');
  requireEvidence(!after.governed||afterState.splitDepth===null,'governed reserve prefix');
  let before = 0n;
  if (tx.before.account?.storage.state.type === 'active') { const beforeState=currentT3ActiveState(tx.before,pin.walletCodeHash),prior=read(beforeState.data);
    requireEvidence(beforeState.splitDepth===afterState.splitDepth && prior.governed === after.governed, 'reserve profile changed'); before=prior.balance; }
  else requireEvidence(!tx.before.account || tx.before.account.storage.state.type === 'uninit', 'frozen reserve wallet');
  requireEvidence(after.balance - before === amount, 'reserve wallet balance delta mismatch');
}
function either(s: ReturnType<Cell['beginParse']>) { const byRef = s.loadBit(), cell = byRef ? s.loadRef() : beginCell().storeSlice(s).endCell(); if (byRef) s.endParse(); return cell; }
function transfer(body: Cell, internal = false) {
  const s = ordinary(body); requireEvidence(s.loadUint(32) === (internal ? 0x178d4519 : T3_OP.TEP74_TRANSFER), 'transfer opcode mismatch');
  const query = s.loadUintBig(64), amount = s.loadCoins(), owner = s.loadAddress(); s.loadMaybeAddress(); if (!internal) s.loadMaybeRef();
  const forwardValue = s.loadCoins(), payload = either(s); return { query, amount, owner, forwardValue, payload };
}
function payoutIdentity(payload: Cell) {
  const s = ordinary(payload); requireEvidence(s.loadUint(32) === 0x54334850, 'payout opcode mismatch'); const r = ordinary(s.loadRef()); s.endParse();
  const id = { domain: r.loadUint(2), slot: r.loadUint(2), key: r.loadUintBig(64), output: r.loadUint(2), attempt: r.loadUintBig(64) }; r.endParse(); return id;
}

/** Verify every physical leg using original message equality and code-pinned
 * before/after balances. Missing legs return null; no aggregate counters qualify. */
export function verifyCurrentT3PhysicalSettlement(request: CurrentT3Request, binding: T3RedemptionBinding,
  decoded: CurrentT3Receipt, transactions: readonly CurrentT3Transaction[]): CurrentT3Settlement | null {
  return maybe(() => {
    const unique = new Set<string>();
    for (const t of transactions) { const key = `${t.account}:${t.tx.lt}`; requireEvidence(!unique.has(key), 'duplicate transaction boundary'); unique.add(key); }
    const amount = BigInt(request.amountRaw), query = BigInt(request.queryId);
    const origin = transactions.find(t => t.account === (request.kind === 'mint' ? request.sourceWallet : request.wallet) &&
      (decoded.kind !== 'redeem' || t.tx.lt === decoded.receipt.attempt.originLt) &&
      (decoded.kind !== 'mint' || transactions.some(c => c.tx.lt === decoded.key && linked(t, c))) && !!maybe(() => {
      const m = rawInput(t); return m.info.src.equals(address(request.owner)) && m.body.equals(decoded.body) &&
        (request.kind !== 'mint' || m.info.value.coins.toString() === request.valueNano);
    }));
    requireEvidence(origin, 'original signed request is missing');
    let acceptance: CurrentT3Transaction | undefined;
    if (request.kind === 'redeem' && decoded.kind === 'redeem') {
      const a = decoded.receipt.attempt;
      requireEvidence(origin.tx.lt === a.originLt, 'original burn LT mismatch');
      walletDelta(origin, binding, request.owner, -amount, decoded);
      acceptance = transactions.find(t => t.account === binding.hub && t.tx.lt === decoded.key && !!maybe(() => {
        const m = rawInput(t), s = ordinary(m.body); requireEvidence(s.loadUint(32) === T3_OP.T3_WALLET_BURN &&
          s.loadRef().equals(t3WalletAttemptToCell(a)), 'accepted burn mismatch'); s.endParse();
        const sender = transactions.find(w => w.account === origin.account && linked(w, t)); requireEvidence(sender, 'burn dispatch missing');
        if (sender !== origin) walletDelta(sender, binding, request.owner, 0n, decoded);
        const boundary = hubBoundary(t, decoded, binding);
        requireEvidence(boundary.before.economy.supply - boundary.after.economy.supply === amount && receiptEmitted(t, 3, decoded.key), 'burn supply acceptance mismatch'); return true;
      }));
    } else if (request.kind === 'mint' && decoded.kind === 'mint') {
      const pin = binding.reserves.find(p => p.slot === request.input), vault = decoded.hub.reserves.get(request.input)?.wallet;
      requireEvidence(pin && vault, 'reserve route missing'); reserveDelta(origin, pin, request.owner, -amount);
      const credit = transactions.find(t => t.account === vault.toRawString() && t.tx.lt === decoded.key && linked(origin, t) && !!maybe(() => {
        const wire = transfer(rawInput(t).body, true); requireEvidence(wire.query === query && wire.amount === amount && wire.owner.equals(address(request.owner)), 'collateral transfer mismatch');
        reserveDelta(t, pin, binding.hub, amount); return true;
      }));
      requireEvidence(credit, 'collateral credit missing');
      acceptance = transactions.find(t => t.account === binding.hub && linked(credit, t) && !!maybe(() => {
        const m = rawInput(t), s = ordinary(m.body); requireEvidence(s.loadUint(32) === 0x7362d09c && s.loadUintBig(64) === query &&
          s.loadCoins() === amount && s.loadAddress().equals(address(request.owner)) && either(s).equals(decoded.intent), 'collateral notification mismatch');
        hubBoundary(t, decoded, binding); requireEvidence(receiptEmitted(t, request.input, decoded.key), 'collateral receipt missing'); return true;
      }));
      requireEvidence(decoded.receipt.phase === 2 && decoded.receipt.mint || decoded.receipt.phase === 3 && decoded.receipt.mint === null && decoded.receipt.payout, 'mint is not accepted or refunded');
    } else throw Error('Current T3 evidence: request kind mismatch');
    requireEvidence(acceptance, 'hub acceptance missing');
    const delivered: [string, string, string] = ['0', '0', '0']; let minted = 0n;
    if (decoded.kind === 'mint' && decoded.receipt.phase === 2) {
      const mint = decoded.receipt.mint!;
      requireEvidence(mint.status === 0 && mint.recipient.equals(address(request.recipient)) && mint.amount >= BigInt(request.minimumRaw), 'mint claim mismatch');
      const dispatch = transactions.find(t => t.account === binding.hub && t.tx.lt === mint.sentLt && receiptEmitted(t, decoded.candidate.slot, decoded.key, decoded.record));
      requireEvidence(dispatch, 'mint dispatch missing'); hubBoundary(dispatch, decoded, binding);
      const credit = transactions.find(t => linked(dispatch, t) && !!maybe(() => {
        const s = ordinary(rawInput(t).body); requireEvidence(s.loadUint(32) === T3_OP.T3_WALLET_MINT && s.loadUintBig(64) === query && s.loadCoins() === mint.amount, 'mint delivery mismatch');
        const i = ordinary(s.loadRef()); requireEvidence(i.loadUint(2) === 0 && i.loadUint(2) === decoded.candidate.slot && i.loadUintBig(64) === decoded.key &&
          i.loadUint(2) === 0 && i.loadUintBig(64) === mint.attempt, 'mint identity mismatch'); i.endParse(); s.loadMaybeAddress(); s.endParse();
        walletDelta(t, binding, request.recipient, mint.amount, decoded); return true;
      }));
      requireEvidence(credit, 'mint physical credit missing'); minted = mint.amount;
    }
    const payout = decoded.receipt.payout;
    if (request.kind === 'redeem') requireEvidence(payout, 'redemption payout missing');
    if (payout) {
      requireEvidence(payout.owner.equals(address(request.owner)) && payout.recipient.equals(address(request.recipient)) && payout.queryId === query, 'payout identity mismatch');
      for (let slot = 0; slot < 3; slot++) {
        const leg = payout.legs[slot]; if (!leg.amount) continue;
        const pin = binding.reserves.find(p => p.slot === slot), vault = decoded.hub.reserves.get(slot)?.wallet;
        requireEvidence(pin && vault && leg.status === 0 && leg.recipient.equals(address(request.recipient)), 'payout claim mismatch');
        const dispatch = transactions.find(t => t.account === binding.hub && t.tx.lt === leg.sentLt);
        requireEvidence(dispatch && receiptEmitted(dispatch, decoded.candidate.slot, decoded.key), 'payout dispatch missing'); hubBoundary(dispatch, decoded, binding);
        const source = transactions.find(t => t.account === vault.toRawString() && linked(dispatch, t) && !!maybe(() => {
          const wire = transfer(rawInput(t).body), id = payoutIdentity(wire.payload);
          requireEvidence(wire.query === query && wire.amount === leg.amount && wire.owner.equals(leg.recipient) &&
            id.domain === (request.kind === 'redeem' ? 1 : 0) && id.slot === decoded.candidate.slot && id.key === decoded.key && id.output === slot && id.attempt === leg.attempt, 'payout command mismatch');
          reserveDelta(t, pin, binding.hub, -leg.amount); return true;
        }));
        requireEvidence(source, 'payout source debit missing');
        const target = transactions.find(t => linked(source, t) && !!maybe(() => {
          const wire = transfer(rawInput(t).body, true); requireEvidence(wire.query === query && wire.amount === leg.amount && wire.owner.equals(address(binding.hub)), 'payout internal transfer mismatch');
          reserveDelta(t, pin, request.recipient, leg.amount); return true;
        }));
        requireEvidence(target, 'payout physical credit missing'); delivered[slot] = leg.amount.toString();
      }
    }
    const refunded=decoded.kind==='mint' && decoded.receipt.phase===3;
    if(refunded){requireEvidence(request.kind==='mint' && payout && payout.recipient.equals(address(request.owner)) && delivered[request.input]===request.amountRaw && delivered.every((v,i)=>i===request.input||v==='0'), 'refund exact amount mismatch');}
    return { status: refunded?'refunded':'confirmed', txId: `${acceptance.tx.lt}:${acceptance.hash}`, deliveredRaw: delivered, mintedRaw: minted.toString(), feeBreakdown: 'unavailable' };
  });
}

export type CurrentT3Claim = { witness:T3ReceiptWitness; actions:('accept'|'refund'|'mintRetry'|'payoutRetry')[]; output?:0|1|2 };
export type CurrentT3Evidence = CurrentT3Settlement | {status:'pending'|'unavailable';claims?:CurrentT3Claim[];reason?:string};
const plain=(v:unknown):v is Record<string,unknown>=>!!v&&typeof v==='object'&&!Array.isArray(v);
const exact=(v:unknown,keys:string[]):v is Record<string,unknown>=>plain(v)&&Object.keys(v).sort().join()===keys.sort().join();
const digest=(v:unknown):v is string=>typeof v==='string'&&/^[0-9a-f]{64}$/.test(v)&&!/^(0{64})$/.test(v);
/** Project only the endpoint's exact request fields. No UI/store metadata is sent. */
export function currentT3Request(request:CurrentT3Request,binding:T3RedemptionBinding):CurrentT3Request{
 const p=request;requireEvidence(p.kind==='mint'||p.kind==='redeem','request kind');
 requireEvidence(p.network===binding.network&&p.releaseId===binding.releaseId&&p.manifestHash===binding.manifestHash&&p.hub===binding.hub,'saved release differs');
 address(p.owner);address(p.recipient);address(p.hub);requireEvidence(p.owner===p.recipient,'redirected owner claim');
 const amount=uint(p.amountRaw,120),query=uint(p.queryId,64),minimum=uint(p.minimumRaw,120);requireEvidence(amount>0n&&query>0n,'empty request');
 requireEvidence(p.bodyBoc.length<=128*1024,'request size');const body=currentT3Cell(p.bodyBoc);requireEvidence(hash(body)===p.bodyHash,'saved body differs');
 const s=ordinary(body),opcode=s.loadUint(32);requireEvidence(s.loadUintBig(64)===query&&s.loadCoins()===amount,'saved amount differs');
 let custom:Cell;
 if(p.kind==='mint'){
  requireEvidence(opcode===T3_OP.TEP74_TRANSFER&&s.loadAddress().equals(address(p.hub))&&s.loadMaybeAddress()?.equals(address(p.owner))&&!s.loadMaybeRef(),'mint body differs');
  s.loadCoins();custom=either(s);address(p.sourceWallet);address(p.collateralRoot);requireEvidence(uint(p.valueNano,120)>0n&&binding.reserves.find(r=>r.slot===p.input)?.master===p.collateralRoot,'mint reserve differs');
 }else{
  requireEvidence(opcode===T3_OP.TEP74_BURN&&s.loadAddress().equals(address(p.owner)),'burn body differs');const ref=s.loadMaybeRef();s.endParse();requireEvidence(ref,'burn intent missing');custom=ref;
  address(p.wallet);requireEvidence(typeof p.single==='boolean'&&[0,1,2].includes(p.outputToken)&&(!p.single?p.outputToken===0&&minimum===0n:binding.reserves.some(r=>r.slot===p.outputToken)),'burn mode differs');
 }
 const terms=readT3Intent(custom);requireEvidence(terms.kind===(p.kind==='mint'?'mint':'redeem')&&terms.recipient.equals(address(p.recipient))&&terms.minimum===minimum,'request intent differs');
 if(p.kind==='redeem')requireEvidence(terms.kind==='redeem'&&terms.single===p.single&&terms.output===p.outputToken&&!terms.strict,'redemption intent differs');
 const timestamp=p.kind==='mint'?p.submittedAt:p.createdAt;requireEvidence(Number.isSafeInteger(timestamp)&&timestamp>0,'request timestamp');
 const common={kind:p.kind,network:p.network,releaseId:p.releaseId,manifestHash:p.manifestHash,owner:p.owner,hub:p.hub,queryId:p.queryId,amountRaw:p.amountRaw,recipient:p.recipient,minimumRaw:p.minimumRaw,bodyBoc:p.bodyBoc,bodyHash:p.bodyHash};
 return p.kind==='mint'?{...common,kind:'mint',collateralRoot:p.collateralRoot,input:p.input,sourceWallet:p.sourceWallet,valueNano:p.valueNano,submittedAt:p.submittedAt}:{...common,kind:'redeem',wallet:p.wallet,single:p.single,outputToken:p.outputToken,createdAt:p.createdAt};
}
/** Release-bound indexer observations are the consensus source for this envelope.
 * Local checks authenticate original cell commitments, live membership and every
 * physical transfer; this is not an independent light-client block proof. */
export function decodeCurrentT3Evidence(value:unknown,request:CurrentT3Request,binding:T3RedemptionBinding,now=Date.now()):CurrentT3Evidence{
 try{
  const p=currentT3Request(request,binding);
  requireEvidence(Buffer.byteLength(JSON.stringify(value),'utf8')<=8*1024*1024,'response limit');
  requireEvidence(exact(value,['schema','releaseId','manifestHash','asOf','request','coverage','hub','receipts','transactions'])&&value.schema==='tonswap-t3-operation-evidence-v1'&&value.releaseId===binding.releaseId&&value.manifestHash===binding.manifestHash,'envelope release');
  const head=value.asOf;requireEvidence(exact(head,['masterchainSeqno','unixTime','blockRootHash'])&&Number.isSafeInteger(head.masterchainSeqno)&&(head.masterchainSeqno as number)>0&&Number.isSafeInteger(head.unixTime)&&(head.unixTime as number)>0&&digest(head.blockRootHash),'head identity');
  const time=head.unixTime as number;requireEvidence(time*1000<=now+5000&&now-time*1000<=30_000,'stale head');
  requireEvidence(exact(value.request,['kind','owner','bodyHash'])&&value.request.kind===p.kind&&value.request.owner===p.owner&&value.request.bodyHash===p.bodyHash,'request echo');
  requireEvidence(exact(value.coverage,['complete','gaps'])&&typeof value.coverage.complete==='boolean'&&Array.isArray(value.coverage.gaps),'coverage shape');
  requireEvidence(value.coverage.gaps.length<=256&&value.coverage.gaps.every(g=>plain(g)&&typeof g.code==='string'&&g.code.length>0&&g.code.length<=128&&typeof g.account==='string'&&!!address(g.account)&&(g.lt===undefined||typeof g.lt==='string'&&uint(g.lt,64)>=0n)),'coverage gaps');
  requireEvidence(!value.coverage.complete||value.coverage.gaps.length===0,'inconsistent coverage');
  requireEvidence(exact(value.hub,['address','codeBoc','dataBoc'])&&Array.isArray(value.receipts)&&value.receipts.length<=32&&Array.isArray(value.transactions)&&value.transactions.length<=256,'evidence limits');
  const hub=value.hub as CurrentT3HubAccount;
  // Validate the authenticated current hub even when no matching receipt exists.
  requireEvidence(hub.address===binding.hub&&hash(currentT3Cell(hub.codeBoc))===binding.hubCodeHash,'current hub');
  const currentHub=readT3Storage(currentT3Cell(hub.dataBoc));requireEvidence(hash(currentHub.config.walletCode)===binding.walletCodeHash&&currentHub.config.proofCodeHash===BigInt('0x'+binding.recoveryProofCodeHash)&&currentHub.config.governance.equals(address(binding.governance)),'hub configuration');
  requireEvidence(currentHub.reserves.size===binding.reserves.length,'reserve count');
  for(const pin of binding.reserves){const r=currentHub.reserves.get(pin.slot),policy=currentHub.config.policies.get(pin.slot);requireEvidence(r&&policy&&r.master.equals(address(pin.master))&&policy.codeHash===BigInt('0x'+pin.walletCodeHash)&&policy.scale===10**(9-pin.decimals)&&r.optional===(pin.slot===2),'reserve configuration');}
  const decoded=value.receipts.map(c=>{requireEvidence(exact(c,['slot','key','recordBoc','recordHash','witnessBoc','owner','kind','phase']),'receipt shape');return decodeCurrentT3Receipt(c as CurrentT3ReceiptCandidate,hub,p,binding);});
  const receiptIds=new Set(decoded.map(r=>`${r.candidate.slot}:${r.key}`));requireEvidence(receiptIds.size===decoded.length,'duplicate receipt');
  const transactions=value.transactions.map(t=>{requireEvidence(exact(t,['account','transactionBoc','beforeShardAccountBoc','afterShardAccountBoc']),'transaction shape');const parsed=verifyCurrentT3Transaction(t as CurrentT3TransactionEvidence);requireEvidence(parsed.tx.now<=time,'transaction beyond head');return parsed;});
  const txIds=new Set(transactions.map(t=>`${t.account}:${t.tx.lt}`));requireEvidence(txIds.size===transactions.length,'duplicate transaction');
  if(decoded.length>1)return{status:'pending',reason:'ambiguous_current_claim'};
  const claims:CurrentT3Claim[]=[];
  for(const d of decoded){
   if(value.coverage.complete){const settled=verifyCurrentT3PhysicalSettlement(p,binding,d,transactions);if(settled)return settled;}
   const packed=ordinary(currentT3Cell(d.candidate.witnessBoc));packed.loadRef();const proof=packed.loadRef();packed.endParse();const witness={slot:d.candidate.slot as 0|1|2|3,record:d.record,proof};
   if(d.kind==='mint'&&(d.receipt.phase===0||d.receipt.phase===4))claims.push({witness,actions:['accept','refund']});
   if(d.kind==='mint'&&d.receipt.phase===2&&d.receipt.mint?.status===1)claims.push({witness,actions:['mintRetry']});
   d.receipt.payout?.legs.forEach((leg,output)=>{if(leg.amount>0n&&leg.status===1&&leg.recipient.equals(address(p.recipient)))claims.push({witness,actions:['payoutRetry'],output:output as 0|1|2});});
  }
  return{status:value.coverage.complete?'pending':'unavailable',...(claims.length?{claims}:{}),reason:value.coverage.complete?'delivery_unproven':'incomplete_evidence'};
 }catch{return{status:'unavailable',reason:'invalid_evidence'};}
}
export async function readCurrentT3Evidence(request:CurrentT3Request,signal?:AbortSignal):Promise<CurrentT3Evidence>{
 signal?.throwIfAborted();
 try{
  const binding=parseT3RedemptionBinding(TONSWAP_T3_REDEMPTION);requireEvidence(binding,'release unavailable');
  const p=currentT3Request(request,binding),value=await indexerRequest('/v1/t3/operation-evidence',{method:'POST',body:p,timeoutMs:8000,maxAttempts:1,cache:'no-store',signal});
  signal?.throwIfAborted();requireEvidence(JSON.stringify(parseT3RedemptionBinding(TONSWAP_T3_REDEMPTION))===JSON.stringify(binding)&&JSON.stringify(currentT3Request(request,binding))===JSON.stringify(p),'request scope changed during read');return decodeCurrentT3Evidence(value,p,binding);
 }catch(error){if(signal?.aborted)throw error;return{status:'unavailable',reason:'evidence_unavailable'};}
}

export type CurrentT3WalletEvidence={status:'pending'|'unavailable';recovery?:T3RedemptionRecovery[];reason?:string};
/** Wallet history witnesses authorize a recovery action, never a payment result.
 * The resolved first hop comes from the shared wallet-request verifier and ties
 * the selected current attempt to the actual saved burn, including after retries. */
export function decodeCurrentT3WalletEvidence(value:unknown,request:Extract<CurrentT3Request,{kind:'redeem'}>,binding:T3RedemptionBinding,origin:TransactionRef,now=Date.now()):CurrentT3WalletEvidence{
 try{
  const p=currentT3Request(request,binding);requireEvidence(p.kind==='redeem','redemption required');
  requireEvidence(origin&&uint(origin.lt,64)>0n&&digest(origin.hash)&&Number.isSafeInteger(origin.utime)&&origin.utime>0,'verified original burn');
  requireEvidence(Buffer.byteLength(JSON.stringify(value),'utf8')<=8*1024*1024,'response limit');
  requireEvidence(exact(value,['schema','releaseId','manifestHash','asOf','request','coverage','wallet','claims'])&&value.schema==='tonswap-t3-wallet-claim-evidence-v1'&&value.releaseId===binding.releaseId&&value.manifestHash===binding.manifestHash,'wallet envelope release');
  const head=value.asOf;requireEvidence(exact(head,['masterchainSeqno','unixTime','blockRootHash'])&&Number.isSafeInteger(head.masterchainSeqno)&&(head.masterchainSeqno as number)>0&&Number.isSafeInteger(head.unixTime)&&(head.unixTime as number)>0&&digest(head.blockRootHash),'head identity');
  const time=head.unixTime as number;requireEvidence(time*1000<=now+5000&&now-time*1000<=30_000&&origin.utime<=time,'stale or earlier head');
  requireEvidence(exact(value.request,['kind','owner','wallet','bodyHash'])&&value.request.kind==='redeem'&&value.request.owner===p.owner&&value.request.wallet===p.wallet&&value.request.bodyHash===p.bodyHash,'request echo');
  requireEvidence(exact(value.coverage,['complete','gaps'])&&typeof value.coverage.complete==='boolean'&&Array.isArray(value.coverage.gaps),'coverage shape');
  requireEvidence(value.coverage.gaps.length<=256&&value.coverage.gaps.every(g=>plain(g)&&typeof g.code==='string'&&g.code.length>0&&g.code.length<=128&&typeof g.account==='string'&&!!address(g.account)&&(g.lt===undefined||typeof g.lt==='string'&&uint(g.lt,64)>=0n)),'coverage gaps');
  requireEvidence(!value.coverage.complete||value.coverage.gaps.length===0,'inconsistent coverage');
  if(!value.coverage.complete)return{status:'unavailable',reason:'incomplete_wallet_history'};
  requireEvidence(exact(value.wallet,['address','codeBoc','dataBoc'])&&value.wallet.address===p.wallet,'wallet identity');
  const code=currentT3Cell(value.wallet.codeBoc as string),state=readT3WalletStorage(currentT3Cell(value.wallet.dataBoc as string));
  requireEvidence(hash(code)===binding.walletCodeHash&&state.owner.equals(address(p.owner))&&state.master.equals(address(binding.hub))&&state.proofCodeHash===BigInt('0x'+binding.recoveryProofCodeHash),'wallet runtime pin');
  requireEvidence(contractAddress(0,{code,data:t3WalletInitialData(address(p.owner),address(binding.hub),state.proofCodeHash)}).toRawString()===p.wallet,'canonical wallet');
  const claims=value.claims;
  requireEvidence(exact(claims,['root','count','records','failureRoot','failureCount','failures'])&&typeof claims.root==='string'&&/^[0-9a-f]{64}$/.test(claims.root)&&typeof claims.failureRoot==='string'&&/^[0-9a-f]{64}$/.test(claims.failureRoot),'claims shape');
  requireEvidence(BigInt('0x'+claims.root)===state.root&&uint(claims.count as string,65)===state.count&&BigInt('0x'+claims.failureRoot)===state.failureRoot&&uint(claims.failureCount as string,64)===state.failures,'current wallet roots');
  requireEvidence(Array.isArray(claims.records)&&claims.records.length<=32&&Array.isArray(claims.failures)&&claims.failures.length<=32,'wallet claim limits');
  const original=ordinary(currentT3Cell(p.bodyBoc));original.loadUint(32);original.loadUintBig(64);original.loadCoins();original.loadAddress();const intent=original.loadMaybeRef()!;original.endParse();
  const records=claims.records.map(row=>{
   requireEvidence(exact(row,['id','recordBoc','recordHash','proofBoc','failed','cancelled','attempt','originLt','owner','recipient','queryId','amountRaw','burn']),'wallet record shape');
   const record=currentT3Cell(row.recordBoc as string),proof=currentT3Cell(row.proofBoc as string),r=readT3WalletRecord(record),a=r.attempt;
   requireEvidence(hash(record)===row.recordHash&&uint(row.id as string,64)===a.id&&a.id<state.count&&verifyT3Witness(record,a.id,proof,state.root),'wallet record membership');
   requireEvidence(row.failed===r.failed&&row.cancelled===r.cancelled&&!(r.failed&&r.cancelled)&&uint(row.attempt as string,64)===a.attempt&&uint(row.originLt as string,64)===a.originLt&&a.originLt.toString()===origin.lt,'wallet attempt origin');
   requireEvidence(row.owner===p.owner&&row.recipient===p.owner&&row.queryId===p.queryId&&row.amountRaw===p.amountRaw&&row.burn===true&&a.burn&&a.owner.equals(address(p.owner))&&a.recipient.equals(a.owner)&&a.amount===BigInt(p.amountRaw)&&a.details.queryId===BigInt(p.queryId)&&a.details.response?.equals(a.owner)&&a.details.forwardValue===0n&&a.details.forwardPayload.equals(beginCell().storeBit(false).endCell())&&a.details.customPayload?.equals(intent),'original burn claim');
   return{row,record,proof,r,attemptHash:hash(t3WalletAttemptToCell(a))};
  });
  requireEvidence(new Set(records.map(r=>r.r.attempt.id.toString())).size===records.length,'duplicate wallet claim');
  const failures=claims.failures.map(row=>{
   requireEvidence(exact(row,['index','evidenceBoc','proofBoc','attemptHash']),'failure shape');
   const index=uint(row.index as string,64),evidence=currentT3Cell(row.evidenceBoc as string),proof=currentT3Cell(row.proofBoc as string),record=records.find(r=>r.attemptHash===row.attemptHash);
   requireEvidence(record&&index<state.failures&&evidence.equals(t3WalletEvidence(address(p.wallet),record.r.attempt))&&verifyT3Witness(evidence,index,proof,state.failureRoot,1),'failure journal membership');
   return{row,record};
  });
  requireEvidence(new Set(failures.map(f=>f.row.index)).size===failures.length,'duplicate failure');
  if(records.length>1)return{status:'pending',reason:'ambiguous_wallet_claim'};
  const recovery:T3RedemptionRecovery[]=[];
  for(const r of records){
   if(r.r.cancelled)continue;
   const witness={recordBoc:r.row.recordBoc as string,proofBoc:r.row.proofBoc as string};
   if(r.r.failed){
    if(r.r.attempt.attempt<(1n<<64n)-1n)recovery.push({action:'burn-retry',...witness});
    recovery.push({action:'cancel-burn',...witness});
   }else{const failure=failures.find(f=>f.record===r);if(failure)recovery.push({action:'mark-burn-failed',...witness,evidenceIndex:failure.row.index as string,evidenceProofBoc:failure.row.proofBoc as string});}
  }
  return{status:'pending',...(recovery.length?{recovery}:{}),reason:recovery.length?'wallet_recovery_available':'wallet_delivery_unproven'};
 }catch{return{status:'unavailable',reason:'invalid_wallet_evidence'};}
}
export async function readCurrentT3WalletEvidence(request:Extract<CurrentT3Request,{kind:'redeem'}>,origin:TransactionRef,signal?:AbortSignal):Promise<CurrentT3WalletEvidence>{
 signal?.throwIfAborted();
 try{
  const binding=parseT3RedemptionBinding(TONSWAP_T3_REDEMPTION);requireEvidence(binding,'release unavailable');
  const p=currentT3Request(request,binding);requireEvidence(p.kind==='redeem','redemption required');
  const original={...origin},value=await indexerRequest('/v1/t3/wallet-claim-evidence',{method:'POST',body:p,timeoutMs:8000,maxAttempts:1,cache:'no-store',signal});
  signal?.throwIfAborted();requireEvidence(JSON.stringify(parseT3RedemptionBinding(TONSWAP_T3_REDEMPTION))===JSON.stringify(binding)&&JSON.stringify(currentT3Request(request,binding))===JSON.stringify(p)&&JSON.stringify(origin)===JSON.stringify(original),'request scope changed during read');
  return decodeCurrentT3WalletEvidence(value,p,binding,original);
 }catch(error){if(signal?.aborted)throw error;return{status:'unavailable',reason:'wallet_evidence_unavailable'};}
}
