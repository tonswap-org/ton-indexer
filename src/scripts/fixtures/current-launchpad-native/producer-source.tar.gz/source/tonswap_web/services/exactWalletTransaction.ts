import { Address } from '@ton/core';
import type { SendTransactionRequest } from '@tonconnect/sdk';

function sameFields(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object' || Array.isArray(a) !== Array.isArray(b)) return false;
  const left = Object.keys(a), right = Object.keys(b);
  if (left.length !== right.length || Array.isArray(a) && a.length !== (b as unknown[]).length) return false;
  return left.every(key => Object.prototype.hasOwnProperty.call(b, key) &&
    sameFields((a as Record<string, unknown>)[key], (b as Record<string, unknown>)[key]));
}

function normalized(transaction: Readonly<SendTransactionRequest>) {
  return {
    ...transaction,
    messages: transaction.messages.map(message => {
      const raw = Address.isRaw(message.address);
      const friendly = raw ? null : Address.parseFriendly(message.address);
      if (transaction.network === '-239' && friendly?.isTestOnly) throw new Error('Testnet-only destination');
      const address = raw ? Address.parseRaw(message.address) : friendly!.address;
      return { ...message, address: [address.toRawString(), friendly?.isBounceable ?? true] };
    })
  };
}

/** TonConnect changes destination spelling before review. Compare its effective
 * address and bounce flag while retaining every other reviewed request field. */
export function sameWalletTransaction(actual: Readonly<SendTransactionRequest>, expected: Readonly<SendTransactionRequest>): boolean {
  try { return sameFields(normalized(actual), normalized(expected)); } catch { return false; }
}
