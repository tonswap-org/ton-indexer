import { Address, type Cell } from '@ton/core';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { stableJson } from '../releaseManifestCodec.mjs';
import { decodeFreshPoolId, FreshStack, spotError, type FreshChainRead } from './spotContracts';
import { ChainReadError } from './chainReadError';
import type { ChainCall, ChainObservation, ReadChainOptions } from './toncenter';

const raw = (value: string) => Address.parse(value).toRawString();
export function spotPoolIdentity(pool: string, payRoot: string, receiveRoot: string) {
  const release = TONSWAP_RELEASE;
  const market = release?.spotMarkets.find(m => raw(m.pool) === raw(pool));
  const t3 = release?.tokens.find(t => t.symbol === 'T3');
  const x = release?.tokens.find(t => t.symbol === market?.symbol);
  if (!release || !market || !t3 || !x || raw(t3.root) === raw(x.root)
    || ![t3.root, x.root].map(raw).includes(raw(payRoot))
    || ![t3.root, x.root].map(raw).includes(raw(receiveRoot)) || raw(payRoot) === raw(receiveRoot)) throw spotError('Pair is not a current release pool');
  return { release, market, t3, x, pool: raw(pool), inSide: (raw(payRoot) === raw(t3.root) ? 0 : 1) as 0 | 1 };
}
export type SpotPoolIdentity = ReturnType<typeof spotPoolIdentity>;
export function spotGetter(observation: ChainObservation, index: number): FreshStack {
  const result = observation.results[index];
  if (!result || result.kind !== 'getter' || result.exitCode !== 0) throw spotError('Pool getter unavailable');
  return new FreshStack(result.stack);
}

/** Code, immutable pool identity and requested values are observed at one block. */
export async function readSpotPool(read: FreshChainRead, identity: SpotPoolIdentity, calls: readonly ChainCall[], options: ReadChainOptions = {}) {
  options.signal?.throwIfAborted();
  const observation = await read([
    { kind: 'account', address: identity.pool }, { kind: 'getter', address: identity.pool, method: 'get_pool_info' }, ...calls
  ], { ...options, lane: options.lane ?? 'user', anchored: true });
  options.signal?.throwIfAborted();
  const { head } = observation;
  if (!head || !Number.isSafeInteger(head.seqno) || head.seqno <= 0 || observation.results.length !== calls.length + 2) throw new ChainReadError('unavailable');
  const account = observation.results[0];
  if (account.kind !== 'account' || account.state !== 'active' || account.code?.hash().toString('hex') !== identity.release.templates.DlmmPool) throw spotError('Pool code differs from current release');
  const s = spotGetter(observation, 1), id = decodeFreshPoolId(s.cell()!);
  const factory = s.address()!, feeSink = s.address()!, treasury = s.address()!, t3 = s.address()!;
  const flags = s.number(8), ready = s.bool(), activeBinBig = s.int();
  const reserveT = s.uint(), reserveX = s.uint(), protocolFeesT3 = s.uint(), binCount = s.number(16), positionCount = s.number(16), campaignCount = s.number(8); s.end();
  const { market, release } = identity;
  if (!id.xMaster.equals(Address.parse(identity.x.root)) || !t3.equals(Address.parse(identity.t3.root))
    || factory.toRawString() !== release.contracts.DlmmPoolFactory?.address
    || feeSink.toRawString() !== release.contracts.FeeRouter?.address || treasury.toRawString() !== release.contracts.Treasury?.address
    || id.binSpacing !== market.binSpacing || id.feePips !== market.feePips || id.xDecimals !== market.xDecimals
    || id.walletGasX !== market.walletGasX || id.walletGramX !== BigInt(market.walletGramX)
    || stableJson(id.walletBudgetX) !== stableJson(market.walletBudgetX)
    || activeBinBig < -2147483648n || activeBinBig > 2147483647n) throw spotError('Pool identity differs from current release');
  return { observation, head, id, flags, ready, activeBin: Number(activeBinBig), reserveT, reserveX, protocolFeesT3, binCount, positionCount, campaignCount };
}
export function spotQuoteStack(s: FreshStack) {
  const quote = { status: s.number(8), amountOut: s.uint(), grossFeeT3: s.uint(), protocolFeeT3: s.uint(), finalBin: s.int(), binsLoaded: s.number(8) }; s.end();
  if (quote.status > 17 || quote.status === 9 || quote.finalBin < -2147483648n || quote.finalBin > 2147483647n || quote.binsLoaded > 7
    || quote.protocolFeeT3 > quote.grossFeeT3 || quote.status !== 0 && quote.amountOut !== 0n) throw spotError('Malformed pool quote');
  return quote;
}
export function spotBinPrice(cell: Cell | null): bigint | null {
  if (!cell) return null;
  const s = cell.beginParse(); s.loadCoins(); s.loadCoins(); s.loadUintBig(256); const pq = s.loadUintBig(128); s.endParse();
  if (pq <= 0n) throw spotError('Invalid active bin price');
  return pq;
}
