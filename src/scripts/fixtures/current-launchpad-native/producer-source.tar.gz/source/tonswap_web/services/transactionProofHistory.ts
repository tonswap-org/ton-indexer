import { Address, Cell, loadTransaction, type Transaction } from '@ton/core';
import { getTransactions } from './toncenter';

const PAGE_SIZE = 32, MAX_SCOPES = 8, MAX_ROWS_PER_ACCOUNT = 8192;
type Cursor = { lt: string; hash: string };
type Scan = { rows: unknown[]; cursor?: Cursor; complete: boolean };
class InvalidTransactionProof extends Error {}
const invalid = (): never => { throw new InvalidTransactionProof('Original transaction history is not a complete authenticated chain.'); };
export const predecessor = (transaction: Transaction): Cursor | undefined => transaction.prevTransactionLt === 0n ? undefined : {
  lt: transaction.prevTransactionLt.toString(), hash: transaction.prevTransactionHash.toString(16).padStart(64, '0'),
};

export function decodeLinkedPage(account: string, rows: unknown[], cursor?: Cursor): Transaction[] {
  if (!Array.isArray(rows) || rows.length > PAGE_SIZE || cursor && !rows.length) return invalid();
  const accountHash = BigInt(`0x${Address.parse(account).hash.toString('hex')}`);
  const decoded = rows.map(row => {
    try {
      const data = (row as { data?: unknown })?.data;
      if (typeof data !== 'string' || !data) return invalid();
      const cell = Cell.fromBase64(data), slice = cell.beginParse(), transaction = loadTransaction(slice);
      if (slice.remainingBits || slice.remainingRefs || transaction.address !== accountHash || transaction.lt <= 0n ||
        transaction.prevTransactionLt >= transaction.lt || (transaction.prevTransactionLt === 0n) !== (transaction.prevTransactionHash === 0n)) return invalid();
      return transaction;
    } catch { return invalid(); }
  });
  for (const [index, transaction] of decoded.entries()) {
    const expected = index ? predecessor(decoded[index - 1]) : cursor;
    if (index && !expected || expected && (transaction.lt.toString() !== expected.lt ||
      transaction.hash().toString('hex') !== expected.hash)) return invalid();
  }
  return decoded;
}

export type ReadRawTransactions = (account: string, cursor?: Cursor, limit?: number, signal?: AbortSignal) => Promise<unknown[]>;
const readRawTransactions: ReadRawTransactions = (account, cursor, limit, signal) => getTransactions(account, limit,
  cursor && { lt: cursor.lt, hash: Buffer.from(cursor.hash, 'hex').toString('base64') },
  { raw: true, forceNetwork: true, signal, lane: 'background' });

async function advance(scan: Scan, account: string, cutoff: number, pageLimit: number, readRaw: ReadRawTransactions, signal?: AbortSignal) {
  for (let page = 0; page < pageLimit && !scan.complete; page++) {
    if (signal?.aborted) throw signal.reason;
    // TON history cursors are inclusive. Request the predecessor itself, not the
    // last returned transaction, and bind that first row to the prior BOC's hash.
    const rows = await readRaw(account, scan.cursor, PAGE_SIZE, signal);
    if (signal?.aborted) throw signal.reason;
    const transactions = decodeLinkedPage(account, rows, scan.cursor);
    if (scan.rows.length + rows.length > MAX_ROWS_PER_ACCOUNT) return invalid();
    // Commit only a fully verified page; a failed read cannot poison saved progress.
    scan.rows.push(...rows);
    const last = transactions.at(-1);
    scan.cursor = last && predecessor(last);
    scan.complete = !last || last.now < cutoff || !scan.cursor;
  }
}

/** Each consumer owns its cache. It contains only validated immutable pages,
 * scoped to the complete original authorization, accounts and submission cutoff.
 * Transport failures keep safe progress; invalid chains discard it. Completed
 * scans are consumed once, so a pre-inclusion head is refreshed on the next check. */
export function createTransactionProofReader(readRaw: ReadRawTransactions = readRawTransactions) {
  const scopes = new Map<string, Map<string, Scan>>();
  const active = new Map<string, Promise<Map<string, unknown[]> | null>>();
  return async (identity: string, accounts: string[], cutoff: number, pageLimit: number, signal?: AbortSignal): Promise<Map<string, unknown[]> | null> => {
    if (signal?.aborted) throw signal.reason;
    if (!Number.isSafeInteger(cutoff) || cutoff < 0 || !Number.isInteger(pageLimit) || pageLimit < 1 || pageLimit > 4 ||
      !accounts.length || new Set(accounts).size !== accounts.length) return invalid();
    const key = JSON.stringify([identity, accounts, cutoff]);
    if (active.has(key)) {
      const result = await active.get(key)!;
      if (signal?.aborted) throw signal.reason;
      return result;
    }
    let scans = scopes.get(key);
    if (!scans) {
      if (scopes.size >= MAX_SCOPES) scopes.delete(scopes.keys().next().value!);
      scans = new Map(accounts.map(account => [account, { rows: [], complete: false }])); scopes.set(key, scans);
    }
    for (const scan of scans.values()) if (!scan.rows.length) scan.complete = false;
    const captured = scans;
    const pending = (async () => {
      const results = await Promise.allSettled(accounts.map(account => advance(captured.get(account)!, account, cutoff, pageLimit, readRaw, signal)));
      if (signal?.aborted) { scopes.delete(key); throw signal.reason; }
      const failure = results.find((result): result is PromiseRejectedResult => result.status === 'rejected');
      if (results.some(result => result.status === 'rejected' && result.reason instanceof InvalidTransactionProof)) scopes.delete(key);
      if (failure) throw failure.reason;
      if (![...captured.values()].every(scan => scan.complete)) return null;
      scopes.delete(key);
      return new Map(accounts.map(account => [account, captured.get(account)!.rows]));
    })();
    active.set(key, pending);
    try { return await pending; } finally { if (active.get(key) === pending) active.delete(key); }
  };
}
