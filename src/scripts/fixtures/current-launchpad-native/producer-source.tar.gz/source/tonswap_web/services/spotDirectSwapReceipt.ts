import { Cell } from '@ton/core';
import { decodeSwapEvent, decodeSwapResult, SwapStatus, type SwapEvent } from './spotContracts';
import type { SpotSwapIdentity } from './spotSwapIdentity';

/** SWR3 is a transfer payload, not a durable receipt or proof of token credit. */
export function parseDirectSwapReceipt(cell: Cell) { return decodeSwapResult(cell); }

/** The exact pool execution disposition. Physical wallet movements are checked separately. */
export function directSwapOutcome(cell: Cell, p: SpotSwapIdentity, inSide: 0 | 1): SwapEvent | null {
  const event = decodeSwapEvent(cell);
  if (!event || event.queryId.toString() !== p.queryId || event.origin.toRawString() !== p.wallet ||
    event.inSide !== inSide || event.amountIn.toString() !== p.amountInRaw) return null;
  if (event.status === SwapStatus.EXECUTED) return event.reason === 0 && event.amountOut >= BigInt(p.minAmountOutRaw) ? event : null;
  return event.reason !== 0 && event.amountOut === 0n ? event : null;
}
