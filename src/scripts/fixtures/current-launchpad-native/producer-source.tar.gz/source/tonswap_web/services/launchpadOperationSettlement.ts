import { Address, Cell, beginCell, contractAddress, storeStateInit } from '@ton/core';
import { Buffer } from 'buffer';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { assertLaunchpadCreatedChild,verifyLaunchpadCreationState } from './launchpadCreationState';
import { indexerRequest } from './indexer';
import { appExecutionNetwork } from './appExecutionNetwork';
import { currentT3ActiveState, verifyCurrentT3Transaction, verifyCurrentT3MessageLink, type CurrentT3Transaction, type CurrentT3TransactionEvidence } from './t3CurrentEvidence';
import { decodeSpotTokenTransfer, verifySpotPoolBoundary } from './spotSwapChainProof';
import { nativePoolBook, verifyNativePoolRemoval, type PoolProofBinding } from './poolOperationEvidence';
import { resolveNativePoolIdentity } from './liquidityContracts';
import { readSpotWallets } from './spotPoolWallets';
import { readLaunchpadArchiveState,launchpadConsumedArchiveRoot } from './launchpadArchivedClaims';
import { verifyArchivedSpotClaim } from './spotContracts';
import { readChain } from './toncenter';
import { readT3ReceiptTree, readT3WalletStorage, t3WalletInitialData, t3WalletAttemptFromCell, t3WalletAttemptToCell, readT3WalletRecord, verifyT3Witness, T3_OP } from './t3Contracts';
import { decodeLaunchChild, decodeLaunchSale, decodeLaunchLp, decodeLaunchVesting, decodeLaunchTerms, launchChildren, launchChildAddress, launchpadReleaseBinding, readLaunchpadState, readLaunchpadRecoveryReceipt, readLaunchpadRecoveryState, LAUNCH_OP, type NativeLaunchState } from './launchpadContracts';
import { validLaunchpadRequest, readLaunchpadJournal, reconcileLaunchpadAttempt, launchpadAttemptOpen, type LaunchpadScope, type LaunchpadRequest, type LaunchpadEffect } from './launchpadOperationStore';
export type LaunchpadEvidenceRequest=Omit<LaunchpadRequest,'wallet'|'destination'|'validUntil'>&{owner:string;dispatch:{lt:string;hash:string;valueNano:string}};
export type LaunchpadTransferOrigin={wallet:string;transactionHash:string;lt:string;attemptBoc:string};
export type LaunchpadEvidence=(LaunchpadEffect|{status:'pending'|'unavailable'})&{transferOrigins?:LaunchpadTransferOrigin[]};
export type LaunchpadProofBinding={state:NativeLaunchState;proofCodeHash:string;v21WalletHash:string;stablecoinWalletHash:string;pool?:PoolProofBinding};
const raw=(a:Address|null|undefined)=>a?.toRawString()??null;
const hash=(c:Cell)=>c.hash().toString('hex');
const digest=(x:unknown):x is string=>typeof x==='string'&&/^[0-9a-f]{64}$/.test(x);
const exact=(v:unknown,k:string[]):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===k.length&&k.every(x=>Object.hasOwn(v,x));
function check(v:unknown,why:string):asserts v{if(!v)throw Error(`Launchpad evidence: ${why}`);}
const maybe=<T>(f:()=>T):T|null=>{try{return f();}catch{return null;}};
const one=<T>(a:T[])=>a.length===1?a[0]:null;
function input(t:CurrentT3Transaction,from?:string){const m=t.tx.inMessage;check(m?.info.type==='internal'&&!m.info.bounced&&(!from||raw(m.info.src)===from),'incoming identity');return m;}
function either(s:ReturnType<Cell['beginParse']>){if(s.loadBit()){const c=s.loadRef();s.endParse();return c;}return beginCell().storeSlice(s).endCell();}
function child(t:CurrentT3Transaction,p:LaunchpadEvidenceRequest,b:LaunchpadProofBinding,after=true){
 check(t.succeeded,'child execution');const a=(after?t.after:t.before).account;check(a?.storage.state.type==='active'&&a.storage.state.state.data,'child state');
 const d=decodeLaunchChild(a.storage.state.state.data),i=d.identity,slot=i.role===0?i.kind:i.role+2,code=b.state.factory.codes.get(slot)!.code;
 const active=currentT3ActiveState(after?t.after:t.before,hash(code));check(active.splitDepth===null&&i.factory.equals(b.state.binding.factory)&&raw(i.creator)===p.creator&&i.nonce===BigInt(p.nonce)&&i.kind===p.model&&raw(launchChildAddress(i,code))===t.account,'canonical child');
 check(d.config&&d.slots.size===(i.role===2?1:2),'configured child');if(i.role!==2)check(d.slots.get(0)?.master.equals(b.state.binding.t3Root)&&d.slots.get(0)?.budget.creditProtection,'protected T3 slot');return d;
}
function walletBalance(t:CurrentT3Transaction,root:string,owner:string,codeHash:string,b:LaunchpadProofBinding,after=true){
 const state=after?t.after:t.before;if(!state.account||state.account.storage.state.type==='uninit')return 0n;
 const a=currentT3ActiveState(state,codeHash),master=Address.parse(root),holder=Address.parse(owner);let amount:bigint,canonical:Address;
 if(root===raw(b.state.binding.t3Root)){
  check(codeHash===b.state.binding.t3WalletHash&&a.splitDepth===null,'T3 code');const d=readT3WalletStorage(a.data);
  check(d.owner.equals(holder)&&d.master.equals(master)&&d.proofCodeHash===BigInt('0x'+b.proofCodeHash),'T3 identity');amount=d.balance;canonical=contractAddress(0,{code:a.code,data:t3WalletInitialData(holder,master,d.proofCodeHash)});
 }else{
  const v21=codeHash===b.v21WalletHash;check(v21||codeHash===b.stablecoinWalletHash,'qualified external wallet');check(a.splitDepth===(v21?8:null),'wallet layout');const s=a.data.beginParse();if(!v21)s.loadUint(4);amount=s.loadCoins();check(s.loadAddress().equals(holder)&&s.loadAddress().equals(master),'external wallet identity');s.endParse();
  const d=beginCell();if(!v21)d.storeUint(0,4);d.storeCoins(0).storeAddress(holder).storeAddress(master);const init={code:a.code,data:d.endCell(),...(v21?{splitDepth:8}:{})};
  if(v21){const h=beginCell().store(storeStateInit(init)).endCell().hash();h[0]=holder.hash[0];canonical=new Address(0,h);}else canonical=contractAddress(0,init);
 }
 check(raw(canonical)===t.account,'canonical token wallet');return amount;
}
function delta(t:CurrentT3Transaction,root:string,owner:string,code:string,amount:bigint,b:LaunchpadProofBinding){check(t.succeeded&&t.after.account?.storage.state.type==='active','wallet execution');check(walletBalance(t,root,owner,code,b)-walletBalance(t,root,owner,code,b,false)===amount,'physical balance change');}
function delivered(source:CurrentT3Transaction,target:CurrentT3Transaction,r:ReturnType<typeof decodeSpotTokenTransfer>,root:string,from:string,code:string,b:LaunchpadProofBinding){
 check(verifyCurrentT3MessageLink(source,target),'token link');const m=input(target,source.account);
 if(root===raw(b.state.binding.t3Root)){const s=m.body.beginParse();check(s.loadUint(32)===T3_OP.T3_WALLET_DELIVERY,'T3 delivery');const a=t3WalletAttemptFromCell(s.loadRef());s.endParse();
  check(!a.burn&&a.originLt===source.tx.lt&&a.attempt===0n&&raw(a.owner)===from&&raw(a.recipient)===r.owner&&a.amount===r.amount&&a.details.queryId===r.query&&raw(a.details.response)===r.response&&a.details.forwardValue===r.forwardValue&&a.details.customPayload===null&&either(a.details.forwardPayload.beginParse()).equals(r.payload),'original T3 transfer');
 }else{const a=decodeSpotTokenTransfer(m.body,true);check(a.query===r.query&&a.amount===r.amount&&a.owner===from&&a.response===r.response&&a.forwardValue===r.forwardValue&&a.payload.equals(r.payload),'external transfer');}
 delta(source,root,from,code,-r.amount,b);delta(target,root,r.owner!,code,r.amount,b);
}
function transferDelivery(source:CurrentT3Transaction,r:ReturnType<typeof decodeSpotTokenTransfer>,root:string,from:string,code:string,b:LaunchpadProofBinding,txs:CurrentT3Transaction[]){
 const direct=one(txs.filter(t=>!!maybe(()=>{delivered(source,t,r,root,from,code,b);return true;})));if(direct)return{target:direct,origin:null};
 if(root!==raw(b.state.binding.t3Root))return{target:null,origin:null};delta(source,root,from,code,-r.amount,b);
 const outgoing=one(source.tx.outMessages.values().filter(m=>m.info.type==='internal'&&m.body.bits.length>=32&&m.body.beginParse().preloadUint(32)===T3_OP.T3_WALLET_DELIVERY));if(!outgoing)return{target:null,origin:null};
 const initial=t3WalletAttemptFromCell(outgoing.body.refs[0]);check(initial.originLt===source.tx.lt&&initial.attempt===0n&&!initial.burn&&raw(initial.owner)===from&&raw(initial.recipient)===r.owner&&initial.amount===r.amount&&initial.details.queryId===r.query&&raw(initial.details.response)===r.response&&initial.details.forwardValue===r.forwardValue&&initial.details.customPayload===null&&either(initial.details.forwardPayload.beginParse()).equals(r.payload),'original recovery transfer');
 const terms=t3WalletAttemptToCell(initial).refs[0],targets=txs.filter(t=>t.account===source.account&&t.succeeded&&t.tx.lt>source.tx.lt).flatMap(retry=>{
  const target=maybe(()=>{const s=input(retry).body.beginParse();check(s.loadUint(32)===T3_OP.T3_WALLET_RETRY,'retry');const record=s.loadRef(),proof=s.loadRef(),to=s.loadAddress();s.endParse();const item=readT3WalletRecord(record),a=item.attempt,state=readT3WalletStorage(currentT3ActiveState(retry.before,code).data);delta(retry,root,from,code,0n,b);
   check(item.failed&&!item.cancelled&&a.id===initial.id&&a.originLt===initial.originLt&&t3WalletAttemptToCell(a).refs[0].equals(terms)&&to.equals(initial.recipient)&&a.id<state.count&&verifyT3Witness(record,a.id,proof,state.root),'authenticated fixed recipient retry');
   return one(txs.filter(t=>!!maybe(()=>{check(verifyCurrentT3MessageLink(retry,t),'retry link');const v=input(t,retry.account).body.beginParse();check(v.loadUint(32)===T3_OP.T3_WALLET_DELIVERY,'retry delivery');const next=t3WalletAttemptFromCell(v.loadRef());v.endParse();check(next.id===a.id&&next.originLt===a.originLt&&next.attempt===a.attempt+1n&&t3WalletAttemptToCell(next).refs[0].equals(terms),'same transfer retry');delta(t,root,r.owner!,code,r.amount,b);return true;})));
  });return target?[target]:[];
 });
 return{target:one(targets),origin:{wallet:source.account,transactionHash:source.hash,lt:source.tx.lt.toString(),attemptBoc:t3WalletAttemptToCell(initial).toBoc().toString('base64')}};
}
function reachable(start:CurrentT3Transaction,txs:CurrentT3Transaction[]){const seen=new Set([start.hash]);for(const t of txs)if(txs.some(s=>seen.has(s.hash)&&verifyCurrentT3MessageLink(s,t)))seen.add(t.hash);return seen;}
function payouts(origin:CurrentT3Transaction,p:LaunchpadEvidenceRequest,b:LaunchpadProofBinding,txs:CurrentT3Transaction[]){
 const d=child(origin,p,b,false),result:Array<{root:string;amount:bigint;recipient:string;delivered:boolean;tx:CurrentT3Transaction;origin:LaunchpadTransferOrigin|null}>=[];
 for(const source of txs){if(!verifyCurrentT3MessageLink(origin,source))continue;const transfer=maybe(()=>decodeSpotTokenTransfer(input(source,origin.account).body));if(!transfer||transfer.query!==BigInt(p.queryId))continue;
  const slot=d.slots.values().find(s=>raw(s.wallet)===source.account);check(slot,'outgoing canonical holder wallet');const root=raw(slot.master)!,pin=p.assets.find(a=>a.root===root);check(pin,'outgoing token pin');
  const delivery=source.succeeded?transferDelivery(source,transfer,root,origin.account,pin.walletCodeHash,b,txs):{target:null,origin:null},target=delivery.target;
  result.push({root,amount:transfer.amount,recipient:transfer.owner!,delivered:!!target,tx:target??source,origin:delivery.origin});
 }return result;
}
const effect=(p:LaunchpadEvidenceRequest,t:CurrentT3Transaction,status:LaunchpadEffect['status'],amount=BigInt(p.amountRaw)):LaunchpadEffect=>({requestBodyHash:p.bodyHash,transactionHash:t.hash,status,amountRaw:amount.toString()});
/** Original dispatch, canonical contract state and token debit/credit are independently checked. */
export function inspectLaunchpadEvidence(p:LaunchpadEvidenceRequest,b:LaunchpadProofBinding,evidence:readonly CurrentT3TransactionEvidence[]):LaunchpadEvidence{
 try{
  const destination=p.sourceWallet??p.target,r={...p,wallet:p.owner,destination,validUntil:1} as Record<string,unknown>;delete r.owner;delete r.dispatch;check(validLaunchpadRequest(r),'retained request');
  const binding=b.state.binding;check(p.factory===raw(binding.factory)&&raw(launchChildren(b.state,Address.parse(p.creator),BigInt(p.nonce),p.model).sale)===p.sale,'release child identity');
  check(evidence.length<=256,'transaction bound');const txs=evidence.map(verifyCurrentT3Transaction).sort((a,c)=>a.tx.lt<c.tx.lt?-1:1),keys=new Set<string>();
  for(const t of txs){const k=t.account+':'+t.tx.lt;check(!keys.has(k),'duplicate transaction');keys.add(k);}check(new Set(txs.map(t=>t.account)).size<=16&&txs.reduce((n,t)=>n+t.tx.outMessages.size,0)<=1024,'graph bound');
  const owner=one(txs.filter(t=>t.account===p.owner&&t.tx.lt.toString()===p.dispatch.lt&&t.hash===p.dispatch.hash&&t.succeeded));if(!owner)return{status:'pending'};
  check(p.dispatch.valueNano===p.valueNano,'dispatch value');const first=one(txs.filter(t=>t.account===destination&&!!maybe(()=>{const m=input(t,p.owner);return verifyCurrentT3MessageLink(owner,t)&&hash(m.body)===p.bodyHash&&m.info.type==='internal'&&m.info.value.coins.toString()===p.valueNano; })));
  if(!first?.succeeded)return{status:'pending'};check(owner.tx.now*1000>=p.createdAt-300000,'dispatch precedes request');
  if(p.kind==='wallet-retry'||p.kind==='wallet-mark'){const root=b.state.binding.t3Root.toRawString();delta(first,root,p.target,binding.t3WalletHash,0n,b);return effect(p,first,'delivered');}
  if(p.kind==='create'){
   currentT3ActiveState(first.before,binding.factoryHash);currentT3ActiveState(first.after,binding.factoryHash);const body=input(first,p.owner).body.beginParse();check(body.loadUint(32)===LAUNCH_OP.CREATE,'creation body');body.loadUintBig(64);body.loadUintBig(64);body.loadUint(8);const terms=body.loadRef(),parsed=decodeLaunchTerms(terms);body.endParse();
   const children=launchChildren(b.state,Address.parse(p.creator),BigInt(p.nonce),p.model),targets=[children.sale,children.lp,...(parsed.vesting?[children.vesting]:[])];
   for(const address of targets){const init=one(txs.filter(t=>t.account===raw(address)&&verifyCurrentT3MessageLink(first,t)&&t.succeeded));if(!init)return effect(p,first,'accepted');child(init,p,b);const active=currentT3ActiveState(init.after,b.state.factory.codes.get(address.equals(children.sale)?p.model:address.equals(children.lp)?3:4)!.code.hash().toString('hex'));assertLaunchpadCreatedChild(r as unknown as LaunchpadRequest,currentT3ActiveState(first.before,binding.factoryHash).data.toBoc().toString('base64'),address,active.code,active.data,binding);}
   return effect(p,first,'delivered');
  }
  if(['contribute','supply','vest-supply'].includes(p.kind)){
   const transfer=decodeSpotTokenTransfer(input(first,p.owner).body),pin=p.assets[0];check(pin&&pin.root===p.tokenRoot,'input token pin');
   const delivery=transferDelivery(first,transfer,pin.root,p.owner,pin.walletCodeHash,b,txs),credited=delivery.target;if(!credited)return{status:'pending',...(delivery.origin?{transferOrigins:[delivery.origin]}:{})};
   const accepted=one(txs.filter(t=>t.account===p.target&&t.succeeded&&verifyCurrentT3MessageLink(credited,t)));if(!accepted)return{status:'pending'};
   const before=child(accepted,p,b,false),after=child(accepted,p,b);
   if(p.kind==='contribute'){const old=decodeLaunchSale(before),next=decodeLaunchSale(after),a=old.entries.get(Address.parse(p.owner)),z=next.entries.get(Address.parse(p.owner));
    if(z&&z.paid-(a?.paid??0n)===transfer.amount&&z.tokens-(a?.tokens??0n)>=BigInt(p.minTokensRaw!))return effect(p,accepted,'delivered');
    const refund=payouts(accepted,p,b,txs).filter(a=>a.root===p.tokenRoot&&a.recipient===p.owner&&a.amount===transfer.amount);if(refund.length===1&&refund[0].delivered)return effect(p,refund[0].tx,'refunded');return{status:'pending',transferOrigins:refund.flatMap(a=>a.origin?[a.origin]:[])};
   }
   const growth=p.kind==='supply'?decodeLaunchSale(after).inventory-decodeLaunchSale(before).inventory:decodeLaunchVesting(after).deposited-decodeLaunchVesting(before).deposited;
   check(growth===transfer.amount,'inventory custody');return effect(p,accepted,'delivered');
  }
  const before=child(first,p,b,false),after=child(first,p,b);check(raw(after.identity.creator)===p.creator,'fixed creator');
  if(p.kind==='discover')return effect(p,first,'delivered');
  if(p.kind==='holder-claim'){const s=input(first,p.owner).body.beginParse();s.skip(32);const receipt=s.loadRef(),proof=s.loadRef();s.endParse();const rec=readLaunchpadRecoveryReceipt(receipt),old=before.recovery.get(0),next=after.recovery.get(0);check(old&&next&&!rec.claimed,'holder receipt');const a=readLaunchpadRecoveryState(old!),z=readLaunchpadRecoveryState(next!);check(a.tree&&z.tree&&a.pending-z.pending===rec.amount&&verifyT3Witness(receipt,rec.key,proof,readT3ReceiptTree(a.tree).root),'consumed receipt');return effect(p,first,'delivered');}
  if(p.kind==='archive-claim'){check(p.target===p.sale,'archive sale only');const s=input(first,p.owner).body.beginParse();s.skip(32+64);const slot=s.loadUint(8),id=s.loadUintBig(64),owner=s.loadAddress(),amount=s.loadCoins(),proof=s.loadRef();s.endParse();const claim={slot,id,owner,amount,proof},a=readLaunchpadArchiveState(before,slot),z=readLaunchpadArchiveState(after,slot);check(a&&z&&a.count===z.count&&a.total-z.total===amount&&a.count>id&&verifyArchivedSpotClaim(Address.parse(p.sale),claim,a.root)&&launchpadConsumedArchiveRoot(Address.parse(p.sale),claim)===z.root,'consumed exact archive leaf');}
  if(p.kind==='claim'){const a=decodeLaunchSale(before),z=decodeLaunchSale(after),e=a.entries.get(Address.parse(p.owner));check(e&&!z.entries.has(Address.parse(p.owner))&&[2,3].includes(a.phase),'consumed native allocation');check(BigInt(p.amountRaw)===(a.phase===2?e.tokens:e.paid),'claim amount');}
  if(p.kind==='vest-claim'||p.kind==='vest-return'){const a=decodeLaunchVesting(before),z=decodeLaunchVesting(after);check((p.kind==='vest-claim'?z.claimed-a.claimed:z.returned-a.returned)>=BigInt(p.amountRaw),'vesting allocation');}
  if(p.kind==='finalize'||p.kind==='cancel'){const a=decodeLaunchSale(before),z=decodeLaunchSale(after);check(z.phase>=2&&(a.phase===1||a.phase===z.phase),'terminal sale transition');}
  if(p.kind==='lp-seed'){const a=decodeLaunchLp(before),z=decodeLaunchLp(after);check(a.armedAt>0&&a.t3Bal+a.tokenBal>0n&&z.t3Bal===0n&&z.tokenBal===0n,'LP seed allocation');}
  const paid=payouts(first,p,b,txs);if(paid.length!==p.assets.length)return effect(p,first,'accepted');
  const pending=[...paid];for(const asset of p.assets){const i=pending.findIndex(a=>a.root===asset.root&&a.recipient===asset.recipient&&(['owed','vest-claim','vest-return'].includes(p.kind)?a.amount>=BigInt(asset.amountRaw):a.amount===BigInt(asset.amountRaw)));check(i>=0,'reviewed payout changed');pending.splice(i,1);}
  if(paid.some(a=>!a.delivered))return {...effect(p,first,'accepted'),transferOrigins:paid.flatMap(a=>a.origin?[a.origin]:[])};
  if(p.kind==='lp-seed')for(const a of paid){
   const pool=one(txs.filter(t=>t.account===a.recipient&&t.succeeded&&verifyCurrentT3MessageLink(a.tx,t)));if(!pool||!b.pool)return effect(p,first,'accepted');
   const lp=decodeLaunchLp(before);check(raw(lp.pool)===pool.account&&b.pool.identity.pool===pool.account,'canonical seed pool');verifySpotPoolBoundary(pool,b.pool);
   const old=nativePoolBook(currentT3ActiveState(pool.before,binding.poolHash).data,p.target),next=nativePoolBook(currentT3ActiveState(pool.after,binding.poolHash).data,p.target),growth=(next.positions.get(lp.seedBin)?.shares??0n)-(old.positions.get(lp.seedBin)?.shares??0n);check(growth>0n,'LP shares actually minted');
  }
  if(p.kind==='lp-release'){
   const s=input(first,p.owner).body.beginParse();s.skip(96);s.loadCoins();s.loadCoins();if(s.loadBit()){
    const lp=decodeLaunchLp(before),pool=one(txs.filter(t=>t.account===raw(lp.pool)&&verifyCurrentT3MessageLink(first,t)&&t.tx.inMessage?.body.beginParse().preloadUint(32)===0x4c515233));if(!pool||!b.pool)return effect(p,first,'accepted');
    check(b.pool.identity.pool===raw(lp.pool),'canonical removal pool');const result=verifyNativePoolRemoval(pool,p.target,raw(lp.lpRecipient)!,input(pool,p.target).body,b.pool,txs);if(result.status!=='delivered')return effect(p,first,'accepted');
   }
  }
  return effect(p,paid.at(-1)?.tx??first,'delivered',['owed','vest-claim','vest-return'].includes(p.kind)?paid[0]?.amount??0n:BigInt(p.amountRaw));
 }catch{return{status:'unavailable'};}
}
export function decodeLaunchpadEvidence(value:unknown,p:LaunchpadEvidenceRequest,b:LaunchpadProofBinding,now=Date.now()):LaunchpadEvidence{
 try{
  check(Buffer.byteLength(JSON.stringify(value),'utf8')<=8*1024*1024,'response bound');check(exact(value,['schema','releaseId','manifestHash','asOf','request','coverage','transactions'])&&value.schema==='tonswap-launchpad-operation-evidence-v1'&&value.releaseId===p.releaseId&&value.manifestHash===p.manifestHash,'envelope');const h=value.asOf;
  check(exact(h,['masterchainSeqno','unixTime','blockRootHash'])&&Number.isSafeInteger(h.masterchainSeqno)&&h.masterchainSeqno>=b.state.head.seqno&&digest(h.blockRootHash)&&Number.isSafeInteger(h.unixTime)&&h.unixTime>0&&h.unixTime*1000<=now+5000&&now-h.unixTime*1000<=30000&&(h.masterchainSeqno!==b.state.head.seqno||h.blockRootHash===b.state.head.rootHashHex),'authenticated head');
  check(exact(value.request,['kind','owner','bodyHash'])&&value.request.kind===p.kind&&value.request.owner===p.owner&&value.request.bodyHash===p.bodyHash,'request echo');check(exact(value.coverage,['complete','gaps'])&&value.coverage.complete===true&&Array.isArray(value.coverage.gaps)&&value.coverage.gaps.length===0,'coverage');
  check(Array.isArray(value.transactions)&&value.transactions.length<=256&&value.transactions.every((t:unknown)=>exact(t,['account','transactionBoc','beforeShardAccountBoc','afterShardAccountBoc'])),'original transactions');check(value.transactions.every((t:CurrentT3TransactionEvidence)=>verifyCurrentT3Transaction(t).tx.now<=h.unixTime),'transaction after head');return inspectLaunchpadEvidence(p,b,value.transactions as CurrentT3TransactionEvidence[]);
 }catch{return{status:'unavailable'};}
}
export function launchpadEvidenceRequest(r:LaunchpadRequest,dispatch:LaunchpadEvidenceRequest['dispatch']):LaunchpadEvidenceRequest{const{wallet,destination,validUntil,...p}=r;return{...p,owner:wallet,dispatch};}
export async function readLaunchpadOperationSettlement(request:LaunchpadEvidenceRequest,signal?:AbortSignal):Promise<LaunchpadEvidence>{
 try{signal?.throwIfAborted();const r=TONSWAP_RELEASE;check(r&&r.network===`ton:${request.network}`&&request.network===appExecutionNetwork&&r.releaseId===request.releaseId&&r.manifestHash===request.manifestHash,'current release');const p=structuredClone(request),state=await readLaunchpadState(null,{signal});
  let pool:PoolProofBinding|undefined;if(p.kind==='lp-seed'||p.kind==='lp-release'){const child=await readLaunchpadState(Address.parse(p.target),{signal}),lp=decodeLaunchLp(child.child!);check(lp.pool,'LP pool unavailable');const identity=await resolveNativePoolIdentity(lp.pool!.toRawString()),wallets=await readSpotWallets(readChain,identity,lp.lpRecipient.toRawString(),{signal});pool={identity,wallets,minSeqno:wallets.head.seqno,minBlockRootHash:wallets.head.rootHashHex!};}
  const value=await indexerRequest('/v1/launchpad/operation-evidence',{method:'POST',body:p,signal,cache:'no-store',maxAttempts:1,timeoutMs:20000});signal?.throwIfAborted();check(TONSWAP_RELEASE===r&&JSON.stringify(request)===JSON.stringify(p),'changed read');const effect=decodeLaunchpadEvidence(value,p,{state,proofCodeHash:r.templates.T3RecoveryProof,v21WalletHash:r.templates.JettonV21Wallet,stablecoinWalletHash:r.vendor.stablecoin.wallet.codeHash,pool});
  if(p.kind==='create'&&(effect.status==='accepted'||effect.status==='delivered')){
   const original=(value as {transactions:CurrentT3TransactionEvidence[]}).transactions.map(verifyCurrentT3Transaction).find(t=>t.hash===effect.transactionHash&&t.account===p.factory);check(original,'Original factory receipt missing');
   const {owner,dispatch,...fields}=p,retained={...fields,wallet:owner,destination:p.factory,validUntil:1} as LaunchpadRequest;
   const current=await verifyLaunchpadCreationState(retained,currentT3ActiveState(original!.before,state.binding.factoryHash).data.toBoc().toString('base64'),{signal});
   check(TONSWAP_RELEASE===r&&JSON.stringify(request)===JSON.stringify(p),'Creation changed during verification');return{...effect,status:current.state==='fulfilled'?'delivered':'accepted'};
  }return effect;
 }catch(error){if(signal?.aborted)throw error;return{status:'unavailable'};}
}

/** Read the actual retained original after owner-wallet finality and exact first-hop execution. */
export async function readLaunchpadOperationRequest(scope:LaunchpadScope,queryId:string,signal?:AbortSignal):Promise<LaunchpadEvidenceRequest|null>{
 const saved=readLaunchpadJournal(scope).attempts.find(a=>a.request.queryId===queryId);if(!saved||!launchpadAttemptOpen(saved)||!saved.ticket)return null;
 const result=await reconcileLaunchpadAttempt(scope,queryId,null,{signal}),a=result.attempt;
 if(!a||!launchpadAttemptOpen(a)||result.outcome?.status!=='observed'||!result.outcome.final||result.firstHop?.status!=='executed')return null;
 signal?.throwIfAborted();if(JSON.stringify(readLaunchpadJournal(scope).attempts.find(v=>v.request.queryId===queryId))!==JSON.stringify(a))return null;
 return launchpadEvidenceRequest(a.request,{lt:result.outcome.transaction.lt,hash:result.outcome.transaction.hash,valueNano:a.request.valueNano});
}
