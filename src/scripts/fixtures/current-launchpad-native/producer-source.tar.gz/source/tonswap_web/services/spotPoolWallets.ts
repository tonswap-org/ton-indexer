import { Address, Dictionary } from '@ton/core';
import { freshAddressArg, FreshStack, spotError, type FreshChainRead } from './spotContracts';
import { decodeJettonWalletBudget, jettonWalletBudgetToCell, validateJettonWalletProfile, type JettonWalletProfile } from './jettonWalletProfile';
import { readSpotPool, spotGetter, type SpotPoolIdentity } from './spotPoolRead';
import type { ChainAccountResult, ChainCall, ChainObservation, ReadChainOptions } from './toncenter';

export type SpotWalletIdentity = { root: string; owner: string; address: string; codeHash: string };
export function spotWalletPlan(identity: SpotPoolIdentity, owner: string) {
  const pay = identity.inSide === 0 ? identity.t3 : identity.x, receive = identity.inSide === 0 ? identity.x : identity.t3;
  const tokens = [pay, receive], calls: ChainCall[] = [], entries: Array<{ token: typeof pay; owner: string; index: number }> = [];
  for (const token of tokens) {
    calls.push({ kind: 'account', address: token.root });
    for (const holder of [Address.parse(owner).toRawString(), identity.pool]) {
      const index = calls.length;
      calls.push({ kind: 'getter', address: token.root, method: 'get_wallet_address', args: [freshAddressArg(Address.parse(holder))] });
      entries.push({ token, owner: holder, index });
    }
  }
  return { calls, entries, tokens };
}
export function verifySpotWalletPlan(plan: ReturnType<typeof spotWalletPlan>, observation: ChainObservation, offset = 2) {
  for (const [i, token] of plan.tokens.entries()) {
    const master = observation.results[offset + i * 3];
    if (master?.kind !== 'account' || master.state !== 'active' || master.code?.hash().toString('hex') !== token.masterCodeHash) throw spotError('Token master differs from release');
  }
  const wallets = plan.entries.map(entry => {
    const s = spotGetter(observation, offset + entry.index), address = s.address()!; s.end();
    return { root: entry.token.root, owner: entry.owner, address: address.toRawString(), codeHash: entry.token.walletCodeHash };
  });
  if (new Set(wallets.map(w => w.address)).size !== wallets.length) throw spotError('Token wallet identities collide');
  return { pay: wallets[0], poolPay: wallets[1], receive: wallets[2], poolReceive: wallets[3] };
}
export async function readSpotWallets(read: FreshChainRead, identity: SpotPoolIdentity, owner: string, options: ReadChainOptions = {}) {
  const plan = spotWalletPlan(identity, owner);
  const batch = await readSpotPool(read, identity, plan.calls, options);
  return { ...verifySpotWalletPlan(plan, batch.observation), head: batch.head, plan };
}
export function verifySpotWallet(account: ChainObservation['results'][number], result: ChainObservation['results'][number], wallet: SpotWalletIdentity): { balance: bigint; account: ChainAccountResult } {
  if (!account || account.kind !== 'account' || account.state !== 'active' || !account.code || account.code.hash().toString('hex') !== wallet.codeHash
    || !result || result.kind !== 'getter' || result.exitCode !== 0) throw spotError('Token wallet is not active with the pinned code');
  const s = new FreshStack(result.stack), balance = s.uint(), owner = s.address()!, master = s.address()!, code = s.cell()!; s.end();
  if (owner.toRawString() !== wallet.owner || master.toRawString() !== wallet.root || code.hash().toString('hex') !== wallet.codeHash) throw spotError('Token wallet owner, master or code is unverified');
  return { balance, account };
}
/** A cold input recipient is deployed by the token transfer at the master-selected address.
 * An active recipient still needs its code and wallet data qualified at this same head. */
export function verifySpotPoolInputWallet(account: ChainObservation['results'][number], result: ChainObservation['results'][number] | undefined, wallet: SpotWalletIdentity): void {
  if (account?.kind === 'account' && account.state === 'uninitialized' && account.code === null && account.data === null) return;
  if (!result) throw spotError('Pool input wallet changed before its data could be verified');
  verifySpotWallet(account, result, wallet);
}
export function verifySpotSlotProfiles(s: FreshStack, identity: SpotPoolIdentity, wallets: Pick<Awaited<ReturnType<typeof readSpotWallets>>, 'poolPay' | 'poolReceive'>) {
  const root = s.cell(true); s.end();
  const slots = Dictionary.loadDirect(Dictionary.Keys.Uint(8), { serialize() { throw spotError('Read-only slot codec'); }, parse(p) {
    const value = { master: p.loadAddress(), wallet: p.loadMaybeAddress(), walletGas: p.loadUint(32), walletGram: p.loadCoins(), optional: p.loadBit(), budget: decodeJettonWalletBudget(p.loadRef()) }; p.endParse(); return value;
  } }, root);
  const x = slots.get(1), t3 = slots.get(0), { market } = identity;
  if (slots.size !== 2 || !x || !t3 || !x.optional || t3.optional
    || x.master.toRawString() !== identity.x.root || t3.master.toRawString() !== identity.t3.root
    || slots.get(identity.inSide)?.wallet?.toRawString() !== wallets.poolPay.address
    || slots.get(1 - identity.inSide)?.wallet?.toRawString() !== wallets.poolReceive.address
    || x.walletGas !== market.walletGasX || x.walletGram !== BigInt(market.walletGramX)
    || !jettonWalletBudgetToCell(x.budget).equals(jettonWalletBudgetToCell(market.walletBudgetX))) throw spotError('Pool token slots differ from release/master wallet identities');
  validateJettonWalletProfile(x); validateJettonWalletProfile(t3);
  const profile = (slot: JettonWalletProfile): JettonWalletProfile => ({ walletGas: slot.walletGas, walletGram: slot.walletGram, budget: slot.budget });
  return { input: profile(identity.inSide === 0 ? t3 : x), output: profile(identity.inSide === 0 ? x : t3) };
}
export function verifySpotSlots(s: FreshStack, identity: SpotPoolIdentity, wallets: Pick<Awaited<ReturnType<typeof readSpotWallets>>, 'poolPay' | 'poolReceive'>) {
  return verifySpotSlotProfiles(s, identity, wallets).input;
}
