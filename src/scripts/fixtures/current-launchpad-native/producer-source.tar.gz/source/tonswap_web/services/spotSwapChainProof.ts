import { Address, beginCell, Cell, Dictionary, loadCommonMessageInfo, loadShardAccount, loadStateInit, storeMessage, type Slice } from '@ton/core';
import { Buffer } from 'buffer';
import { indexerRequest } from './indexer';
import { walletRequestChain } from './walletRequestChain';
import { decodeLinkedPage } from './transactionProofHistory';
import { appExecutionNetwork } from './appExecutionNetwork';
import { isSpotSwapIdentity, type SpotSwapIdentity } from './spotSwapIdentity';
import type { SpotSwapAmounts } from './spotSwapAmounts';
import { readChain } from './toncenter';
import { decodeSwap, decodeSwapResult, SwapStatus } from './spotContracts';
import { decodeJettonWalletBudget, jettonWalletBudgetToCell } from './jettonWalletProfile';
import { spotPoolIdentity, type SpotPoolIdentity } from './spotPoolRead';
import { readSpotWallets, type SpotWalletIdentity } from './spotPoolWallets';
import { directSwapOutcome } from './spotDirectSwapReceipt';
import { currentT3ActiveState, currentT3Cell, verifyCurrentT3Transaction, type CurrentT3Transaction, type CurrentT3TransactionEvidence } from './t3CurrentEvidence';
import { readT3WalletStorage, t3WalletAttemptFromCell, T3_OP } from './t3Contracts';

export type SpotChainOutcome =
  | ({ status: 'confirmed'; txId: string; source: 'chain' } & SpotSwapAmounts)
  | { status: 'failed'; txId: string; reason: string; source: 'chain' }
  | { status: 'pending' | 'unavailable' };
export type SpotChainWallets = { pay: SpotWalletIdentity; receive: SpotWalletIdentity; poolPay: SpotWalletIdentity; poolReceive: SpotWalletIdentity };
export type SpotDispatch = { lt: string; hash: string; valueNano: string };
/** Supplied only after readFirstHop has linked this transaction to the retained wallet ticket. */
export type SpotProofBinding = { identity: SpotPoolIdentity; wallets: SpotChainWallets; minSeqno: number; minBlockRootHash: string; dispatch: SpotDispatch };
const digest = (c: Cell) => c.hash().toString('hex');
const raw = (a: Address | null) => a?.toRawString() ?? null;
function requireProof(value: unknown, detail: string): asserts value { if (!value) throw Error(`Direct Spot proof: ${detail}`); }
function ordinary(c: Cell) { requireProof(!c.isExotic, 'ordinary cell required'); return c.beginParse(); }
const maybe = <T>(fn: () => T): T | null => { try { return fn(); } catch { return null; } };
const one = <T>(xs: readonly T[]) => xs.length === 1 ? xs[0] : null;
function either(s: Slice) { if (s.loadBit()) { const c = s.loadRef(); s.endParse(); return c; } return beginCell().storeSlice(s).endCell(); }
export function decodeSpotTokenTransfer(body: Cell, internal = false) {
  const s = ordinary(body); requireProof(s.loadUint(32) === (internal ? 0x178d4519 : 0x0f8a7ea5), 'TEP74 transfer');
  const query = s.loadUintBig(64), amount = s.loadCoins(), owner = raw(s.loadAddress()), response = raw(s.loadMaybeAddress());
  const custom = internal ? null : s.loadMaybeRef(), forwardValue = s.loadCoins(), payload = either(s);
  return { query, amount, owner, response, custom, forwardValue, payload };
}
function message(cell: Cell) {
  const s = ordinary(cell), info = loadCommonMessageInfo(s); let init = null;
  if (s.loadBit()) { if (s.loadBit()) { const ref = ordinary(s.loadRef()); init = loadStateInit(ref); ref.endParse(); } else init = loadStateInit(s); }
  const body = either(s); return {info,init,body};
}
function input(tx: CurrentT3Transaction, source?: string) {
  requireProof(tx.incoming, 'original incoming cell'); const m = message(tx.incoming);
  requireProof(m.info.type === 'internal' && !m.info.bounced && (source === undefined || raw(m.info.src) === source), 'input source'); return m;
}
export function verifySpotMessageLink(a: CurrentT3Transaction, b: CurrentT3Transaction) {
  // TON permits inline/reference placement for StateInit and body. Compare the whole
  // parsed message canonically while retaining both original transaction commitments.
  const canonical = (cell: Cell) => { return beginCell().store(storeMessage(message(cell))).endCell(); };
  return !!b.incoming && b.tx.lt > a.tx.lt && a.outgoing.values().some(c => canonical(c).equals(canonical(b.incoming!)));
}
function boundIdentity(p: SpotSwapIdentity, b: SpotProofBinding) {
  requireProof(isSpotSwapIdentity(p), 'authorization');
  requireProof(/^[a-f0-9]{64}$/.test(b.minBlockRootHash), 'authenticated read head');
  requireProof(b.dispatch && /^[1-9]\d*$/.test(b.dispatch.lt) && BigInt(b.dispatch.lt) < 1n<<64n && /^[a-f0-9]{64}$/.test(b.dispatch.hash) && /^(0|[1-9]\d*)$/.test(b.dispatch.valueNano) && BigInt(b.dispatch.valueNano) < 1n<<120n, 'resolved wallet dispatch');
  const { identity: i, wallets: w } = b, r = i.release, pay = i.inSide === 0 ? i.t3 : i.x, receive = i.inSide === 0 ? i.x : i.t3;
  requireProof(`ton:${p.network}` === r.network && p.releaseId === r.releaseId && p.manifestHash === r.manifestHash && p.pool === i.pool &&
    p.poolCodeHash === r.templates.DlmmPool && p.payRoot === pay.root && p.receiveRoot === receive.root &&
    p.payDecimals === pay.decimals && p.receiveDecimals === receive.decimals, 'release identity');
  for (const [wallet, token, owner] of [[w.pay,pay,p.wallet],[w.receive,receive,p.wallet],[w.poolPay,pay,p.pool],[w.poolReceive,receive,p.pool]] as const)
    requireProof(wallet.root === token.root && wallet.codeHash === token.walletCodeHash && wallet.owner === owner && Address.parse(wallet.address).toRawString() === wallet.address, 'wallet pin');
  requireProof(w.pay.address === p.payWallet && w.receive.address === p.receiveWallet && new Set(Object.values(w).map(x => x.address)).size === 4, 'master-selected wallets');
}
/** Authenticate the immutable pool identity and discovered wallets in original state. */
export function verifySpotPoolData(data: Cell, b: { identity: SpotPoolIdentity; wallets: Pick<SpotChainWallets,'poolPay'|'poolReceive'> }) {
  const s = ordinary(data), { identity: i, wallets: w } = b;
  s.loadUint(8); const spacing = s.loadUint(16), fee = s.loadUint(32), decimals = s.loadUint(8);
  s.loadInt(32); s.loadCoins(); s.loadUint(16); s.loadUint(16); s.loadUint(8);
  const jet = ordinary(s.loadRef()); s.loadRef(); s.loadRef(); const cold = ordinary(s.loadRef()); s.endParse();
  requireProof(raw(cold.loadAddress()) === i.release.contracts.DlmmPoolFactory?.address && raw(cold.loadAddress()) === i.release.contracts.FeeRouter?.address &&
    raw(cold.loadAddress()) === i.release.contracts.Treasury?.address && spacing === i.market.binSpacing && fee === i.market.feePips && decimals === i.market.xDecimals, 'pool configuration');
  const slots = jet.loadDict(Dictionary.Keys.Uint(8), { serialize() { throw Error('read only'); }, parse(s) {
    const v = { master: raw(s.loadAddress()), wallet: raw(s.loadMaybeAddress()), gas: s.loadUint(32), gram: s.loadCoins(), optional: s.loadBit(), budget: decodeJettonWalletBudget(s.loadRef()) }; s.endParse(); return v;
  } });
  const t = slots.get(0), x = slots.get(1);
  requireProof(slots.size === 2 && t && x && t.master === i.t3.root && x.master === i.x.root && !t.optional && x.optional &&
    slots.get(i.inSide)?.wallet === w.poolPay.address && slots.get(1-i.inSide)?.wallet === w.poolReceive.address &&
    x.gas === i.market.walletGasX && x.gram === BigInt(i.market.walletGramX) &&
    jettonWalletBudgetToCell(x.budget).equals(jettonWalletBudgetToCell(i.market.walletBudgetX)), 'pool slots');
}
export function verifySpotPoolBoundary(tx: CurrentT3Transaction, b: { identity: SpotPoolIdentity; wallets: Pick<SpotChainWallets,'poolPay'|'poolReceive'> }) {
  requireProof(tx.succeeded && tx.account === b.identity.pool, 'pool execution');
  for (const state of [tx.before, tx.after]) verifySpotPoolData(currentT3ActiveState(state, b.identity.release.templates.DlmmPool).data, b);
}
/** Caller must authenticate the master-selected wallet identity for this release.
 * Layout selection follows the release code pin, never a shape-based fallback. */
export function readSpotWalletBalance(state: CurrentT3Transaction['after'], wallet: SpotWalletIdentity, b: Pick<SpotProofBinding,'identity'>) {
  requireProof([b.identity.t3,b.identity.x].some(token=>token.root===wallet.root && token.walletCodeHash===wallet.codeHash), 'release token identity');
  const isT3 = wallet.root === b.identity.t3.root, isV21 = wallet.codeHash === b.identity.release.templates.JettonV21Wallet;
  const read = (data: Cell) => {
    if (isT3) {
      requireProof(wallet.codeHash === b.identity.release.templates.T3Wallet, 'T3 code pin'); const d = readT3WalletStorage(data);
      requireProof(raw(d.owner) === wallet.owner && raw(d.master) === wallet.root && d.proofCodeHash === BigInt('0x' + b.identity.release.templates.T3RecoveryProof), 'T3 wallet configuration'); return d.balance;
    }
    requireProof(isV21 || wallet.codeHash === b.identity.release.vendor.stablecoin.wallet.codeHash, 'unsupported wallet code');
    const s = ordinary(data); if (!isV21) s.loadUint(4);
    const balance = s.loadCoins(); requireProof(raw(s.loadAddress()) === wallet.owner && raw(s.loadAddress()) === wallet.root, 'token wallet configuration'); s.endParse(); return balance;
  };
  if (!state.account || state.account.storage.state.type === 'uninit') return 0n;
  const active = currentT3ActiveState(state,wallet.codeHash);
  requireProof(active.splitDepth === null || isV21 && active.splitDepth === 8, 'wallet split depth');
  return read(active.data);
}
export function verifySpotWalletDelta(tx: CurrentT3Transaction, wallet: SpotWalletIdentity, delta: bigint, b: Pick<SpotProofBinding,'identity'>) {
  requireProof(tx.succeeded && tx.account === wallet.address, 'successful wallet transaction');
  const after = currentT3ActiveState(tx.after,wallet.codeHash), amount = readSpotWalletBalance(tx.after,wallet,b);
  let prior = 0n;
  if (tx.before.account?.storage.state.type === 'active') {
    const before = currentT3ActiveState(tx.before,wallet.codeHash); requireProof(before.splitDepth === after.splitDepth, 'wallet layout changed'); prior = readSpotWalletBalance(tx.before,wallet,b);
  } else requireProof(delta > 0n && (!tx.before.account || tx.before.account.storage.state.type === 'uninit'), 'wallet prior state');
  requireProof(amount - prior === delta, 'physical balance delta');
}
export function verifySpotTokenDelivery(source: CurrentT3Transaction, destination: CurrentT3Transaction, request: ReturnType<typeof decodeSpotTokenTransfer>, from: SpotWalletIdentity, to: SpotWalletIdentity, b: Pick<SpotProofBinding,'identity'>) {
  requireProof(from.root === to.root && from.codeHash === to.codeHash, 'same-token delivery');
  requireProof(verifySpotMessageLink(source,destination), 'delivery message linkage'); const m = input(destination,from.address);
  if (from.root === b.identity.t3.root) {
    const s = ordinary(m.body); requireProof(s.loadUint(32) === T3_OP.T3_WALLET_DELIVERY, 'T3 delivery'); const a = t3WalletAttemptFromCell(s.loadRef()); s.endParse();
    requireProof(!a.burn && a.originLt === source.tx.lt && a.attempt === 0n && raw(a.owner) === from.owner && raw(a.recipient) === to.owner && a.amount === request.amount &&
      a.details.queryId === request.query && raw(a.details.response) === request.response && a.details.forwardValue === request.forwardValue && a.details.customPayload === null &&
      either(ordinary(a.details.forwardPayload)).equals(request.payload), 'T3 original transfer binding');
  } else {
    const d = decodeSpotTokenTransfer(m.body,true); requireProof(d.query === request.query && d.amount === request.amount && d.owner === from.owner && d.response === request.response &&
      d.forwardValue === request.forwardValue && d.payload.equals(request.payload), 'TEP74 original transfer binding');
  }
  verifySpotWalletDelta(source,from,-request.amount,b); verifySpotWalletDelta(destination,to,request.amount,b);
}

/** Original messages and committed balances are both required. SWR3/SWE3 alone cannot settle. */
export function inspectSpotSwapChain(p: SpotSwapIdentity, b: SpotProofBinding, evidence: readonly CurrentT3TransactionEvidence[]): SpotChainOutcome {
  try {
    boundIdentity(p,b); requireProof(evidence.length <= 256, 'transaction limit');
    const txs = evidence.map(verifyCurrentT3Transaction); requireProof(new Set(txs.map(t => t.hash)).size === txs.length, 'duplicate transaction');
    const at = (account: string) => txs.filter(t => t.account === account), w = b.wallets;
    const first = one(at(p.payWallet).filter(t => maybe(() => digest(input(t,p.wallet).body) === p.requestBodyHash) === true));
    if (!first) return {status:'pending'};
    requireProof(first.tx.lt.toString() === b.dispatch.lt && first.hash === b.dispatch.hash, 'wallet ticket first-hop mismatch');
    const original = input(first,p.wallet), request = decodeSpotTokenTransfer(original.body), swap = decodeSwap(request.payload);
    requireProof(original.info.type === 'internal' && original.info.value.coins.toString() === b.dispatch.valueNano, 'wallet dispatch value');
    requireProof(request.query.toString() === p.queryId && request.amount.toString() === p.amountInRaw && request.owner === p.pool && request.response === p.wallet && request.custom === null && request.forwardValue > 0n &&
      swap && swap.minOut.toString() === p.minAmountOutRaw && swap.deadline === p.validUntil && raw(swap.recipient) === p.wallet && raw(swap.refundTo) === p.wallet && !swap.notifyOrigin && swap.fwdGram === 0n && swap.refundFwdGram === 0n && swap.fwdPayload === null, 'original SWP3 authorization');
    if (!first.succeeded) return {status:'pending'}; // Ticket-bound first-hop rejection is handled by the wallet resolver.
    const credit = one(at(w.poolPay.address).filter(t => maybe(() => { verifySpotTokenDelivery(first,t,request,w.pay,w.poolPay,b); return true; })));
    if (!credit) return {status:'pending'};
    const execution = one(at(p.pool).filter(t => maybe(() => {
      requireProof(verifySpotMessageLink(credit,t), 'notification linkage'); const s = ordinary(input(t,w.poolPay.address).body);
      requireProof(s.loadUint(32) === 0x7362d09c && s.loadUintBig(64) === request.query && s.loadCoins() === request.amount && raw(s.loadAddress()) === p.wallet && either(s).equals(request.payload), 'TEP74 notification');
      verifySpotPoolBoundary(t,b); return true;
    })));
    if (!execution) return {status:'pending'};
    const event = one(execution.tx.outMessages.values().flatMap(m => m.info.type === 'external-out' ? [directSwapOutcome(m.body,p,b.identity.inSide)].filter(x => x !== null) : []));
    if (!event || event.status === SwapStatus.INPUT_OWED) return {status:'pending'};
    const refund = event.status !== SwapStatus.EXECUTED, source = refund ? w.poolPay : w.poolReceive, target = refund ? w.pay : w.receive, amount = refund ? request.amount : event.amountOut;
    const dispatched = at(source.address).flatMap(tx => {
      const leg = maybe(() => {
        requireProof(verifySpotMessageLink(execution,tx), 'pool payout linkage'); const transferRequest = decodeSpotTokenTransfer(input(tx,p.pool).body);
        requireProof(transferRequest.query === request.query && transferRequest.amount === amount && transferRequest.owner === p.wallet && transferRequest.response === p.wallet && transferRequest.custom === null && transferRequest.forwardValue === 0n, 'pool payout terms');
        if (event.status === SwapStatus.REFUND_PLAIN) requireProof(transferRequest.payload.bits.length === 0 && transferRequest.payload.refs.length === 0, 'plain refund');
        else { const result = decodeSwapResult(transferRequest.payload); requireProof(result && result.queryId === request.query && raw(result.origin) === p.wallet && result.status === (refund?1:0) && result.reason === event.reason && result.amountIn === request.amount && result.amountOut === event.amountOut && result.user === null, 'SWR3 outcome'); }
        return transferRequest;
      }); return leg ? [{tx,leg}] : [];
    });
    const completed = dispatched.flatMap(({tx,leg}) => at(target.address).filter(t => maybe(() => { verifySpotTokenDelivery(tx,t,leg,source,target,b); return true; })));
    const final = one(completed); if (!final) return {status:'pending'};
    const txId = `${final.tx.lt}:${Buffer.from(final.hash,'hex').toString('base64')}`;
    return refund ? {status:'failed',source:'chain',txId,reason:'The pool could not execute the swap. The full input was returned to your token wallet.'} :
      {status:'confirmed',source:'chain',txId,paidInputRaw:p.amountInRaw,consumedInputRaw:p.amountInRaw,returnedInputRaw:'0',outputRaw:event.amountOut.toString()};
  } catch { return {status:'unavailable'}; }
}

const plain = (v: unknown): v is Record<string, any> => !!v && typeof v === 'object' && !Array.isArray(v);
const exact = (v: unknown, keys: string[]): v is Record<string, any> => plain(v) && Object.keys(v).length === keys.length && keys.every(k => k in v);
/** The release-bound indexer is the consensus source. Local verification checks original
 * commitments and the complete physical graph; these cells are not a light-client proof. */
export function decodeCurrentSpotEvidence(value: unknown, p: SpotSwapIdentity, b: SpotProofBinding, now = Date.now()): SpotChainOutcome {
  try {
    boundIdentity(p,b); requireProof(Buffer.byteLength(JSON.stringify(value),'utf8') <= 8*1024*1024, 'response limit');
    requireProof(exact(value,['schema','releaseId','manifestHash','asOf','request','coverage','pool','wallets','accounts','transactions']) && value.schema === 'tonswap-spot-operation-evidence-v1' && value.releaseId === p.releaseId && value.manifestHash === p.manifestHash, 'envelope');
    const h = value.asOf; requireProof(exact(h,['masterchainSeqno','unixTime','blockRootHash']) && Number.isSafeInteger(h.masterchainSeqno) && h.masterchainSeqno > 0 && h.masterchainSeqno >= b.minSeqno && Number.isSafeInteger(h.unixTime) && h.unixTime > 0 && typeof h.blockRootHash === 'string' && /^[a-f0-9]{64}$/.test(h.blockRootHash) && h.unixTime*1000 <= now+5000 && now-h.unixTime*1000 <= 30000, 'head');
    requireProof(h.masterchainSeqno > b.minSeqno || h.blockRootHash === b.minBlockRootHash, 'same-height fork');
    requireProof(exact(value.request,['kind','owner','bodyHash']) && value.request.kind === 'direct' && value.request.owner === p.wallet && value.request.bodyHash === p.requestBodyHash, 'request echo');
    const c = value.coverage; requireProof(exact(c,['complete','gaps']) && typeof c.complete === 'boolean' && Array.isArray(c.gaps) && c.gaps.length <= 256 && c.gaps.every((g: unknown) => plain(g) && typeof g.code === 'string' && g.code.length > 0) && (!c.complete || c.gaps.length === 0), 'coverage');
    requireProof(exact(value.wallets,['pay','receive','poolPay','poolReceive']) && Object.entries(b.wallets).every(([name,w]) => value.wallets[name] === w.address), 'master-selected envelope wallets');
    requireProof(Array.isArray(value.accounts) && value.accounts.length <= 16, 'current account bound');
    const current = new Map<string,ReturnType<typeof loadShardAccount>>();
    for (const row of value.accounts) {
      requireProof(exact(row,['address','shardAccountBoc']) && typeof row.address === 'string' && Address.parse(row.address).toRawString() === row.address && !current.has(row.address), 'current account identity');
      const cell = currentT3Cell(row.shardAccountBoc), s = ordinary(cell), shard = loadShardAccount(s); s.endParse();
      requireProof(cell.refs.length === 1 && !cell.refs[0].isExotic && (!shard.account || raw(shard.account.addr) === row.address), 'current original account'); current.set(row.address,shard);
    }
    // An unused output wallet may never have existed on a fully refunded swap.
    // No absence envelope is invented; every actual debit/credit still needs its original boundary.
    requireProof([p.pool,p.wallet,b.wallets.pay.address,b.wallets.poolPay.address].every(address=>current.has(address)), 'missing current input account');
    const currentPool = currentT3ActiveState(current.get(p.pool)!,p.poolCodeHash);
    const pool = value.pool; requireProof(exact(pool,['address','codeBoc','dataBoc']) && pool.address === p.pool && digest(currentT3Cell(pool.codeBoc)) === p.poolCodeHash, 'current pool'); requireProof(currentPool.code.equals(currentT3Cell(pool.codeBoc)) && currentPool.data.equals(currentT3Cell(pool.dataBoc)), 'pool envelope differs from original current account'); verifySpotPoolData(currentT3Cell(pool.dataBoc),b);
    requireProof(Array.isArray(value.transactions) && value.transactions.length <= 256, 'transaction count');
    for (const row of value.transactions) { requireProof(exact(row,['account','transactionBoc','beforeShardAccountBoc','afterShardAccountBoc']), 'transaction envelope'); requireProof(verifyCurrentT3Transaction(row as CurrentT3TransactionEvidence).tx.now <= h.unixTime, 'transaction after head'); }
    const result = inspectSpotSwapChain(p,b,value.transactions);
    if (result.status === 'confirmed') requireProof([b.wallets.receive.address,b.wallets.poolReceive.address].every(address=>current.has(address)), 'missing current output account');
    return result.status === 'pending' && !c.complete ? {status:'unavailable'} : result;
  } catch { return {status:'unavailable'}; }
}
export async function readSpotSwapChainProof(p: SpotSwapIdentity, dispatch: SpotDispatch, signal?: AbortSignal): Promise<SpotChainOutcome> {
  if (!isSpotSwapIdentity(p) || p.network !== appExecutionNetwork) return {status:'unavailable'};
  try {
    signal?.throwIfAborted(); const identity = spotPoolIdentity(p.pool,p.payRoot,p.receiveRoot);
    const observed = await readSpotWallets(readChain,identity,p.wallet,{signal,lane:'background',deadlineMs:12000});
    const binding: SpotProofBinding = {identity,wallets:{pay:observed.pay,receive:observed.receive,poolPay:observed.poolPay,poolReceive:observed.poolReceive},minSeqno:observed.head.seqno,minBlockRootHash:observed.head.rootHashHex??'',dispatch}; boundIdentity(p,binding);
    const rows = await walletRequestChain.readTransactions(p.payWallet,dispatch,1,signal);
    const [source] = decodeLinkedPage(p.payWallet,rows,dispatch); requireProof(source && rows.length === 1,'exact dispatched source transaction');
    const original = source.inMessage; requireProof(original?.info.type === 'internal' && !original.info.bounced && raw(original.info.src) === p.wallet && digest(original.body) === p.requestBodyHash && original.info.value.coins.toString() === dispatch.valueNano,'dispatched source message');
    const body = {kind:'direct',network:p.network,releaseId:p.releaseId,manifestHash:p.manifestHash,owner:p.wallet,pool:p.pool,payRoot:p.payRoot,receiveRoot:p.receiveRoot,sourceWallet:p.payWallet,valueNano:dispatch.valueNano,bodyBoc:original.body.toBoc().toString('base64'),bodyHash:p.requestBodyHash};
    const value = await indexerRequest<unknown>('/v1/spot/operation-evidence',{method:'POST',body,signal,maxAttempts:1,timeoutMs:12000});
    signal?.throwIfAborted(); requireProof(spotPoolIdentity(p.pool,p.payRoot,p.receiveRoot).release === identity.release,'release changed');
    return decodeCurrentSpotEvidence(value,p,binding);
  } catch (error) { signal?.throwIfAborted(); return {status:'unavailable'}; }
}
