import type { MessageParams } from '../i18n/message.ts';

/**
 * A failure a person can read. Services throw `AppError` with a catalog key as
 * the code; screens render it with `messageFor`. A service never builds a
 * sentence for the screen, and a screen never shows `error.message`.
 *
 * `code` is a full catalog key in any namespace (`errors.wallet.unavailable`,
 * `release.kusd.closed`, `swap.error.noPool`). Cross-cutting codes live in the
 * `errors` namespace; a code that belongs to one screen lives in that screen's
 * namespace. `params` fill the message's `{placeholders}`.
 *
 * `devMessage` is the English sentence for logs and developers. It is never
 * rendered.
 */
export class AppError extends Error {
  readonly code: string;
  readonly params: MessageParams;
  readonly devMessage: string;

  constructor(code: string, params: MessageParams = {}, options: { devMessage?: string; cause?: unknown } = {}) {
    const devMessage = options.devMessage ?? code;
    super(devMessage, options.cause === undefined ? undefined : { cause: options.cause });
    this.name = 'AppError';
    this.code = code;
    this.params = params;
    this.devMessage = devMessage;
  }
}

export const isAppError = (value: unknown): value is AppError => value instanceof AppError;

/** The slice of the i18n API `messageFor` needs. `useI18n()` satisfies it. */
export interface ErrorTranslator {
  t(key: string, params?: MessageParams): string;
  has(key: string): boolean;
}

/** Fallback code when the failure is not an AppError or its code has no message. */
export const UNKNOWN_ERROR_CODE = 'errors.unknown';

/**
 * The plain-language message for any thrown value. An AppError whose code has a
 * catalog message renders that message; everything else renders the generic
 * `errors.unknown`. Raw `Error.message` text is never shown.
 */
export function messageFor(error: unknown, i18n: ErrorTranslator): string {
  if (isAppError(error) && i18n.has(error.code)) return i18n.t(error.code, error.params);
  return i18n.t(UNKNOWN_ERROR_CODE);
}
