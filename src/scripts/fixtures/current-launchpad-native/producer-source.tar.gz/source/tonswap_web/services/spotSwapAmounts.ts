/** Atomic execution amounts. Authorization input is the amount paid, not necessarily consumed. */
export type SpotSwapAmounts = { paidInputRaw: string; consumedInputRaw: string; returnedInputRaw: string; outputRaw: string };
const atomic = (value: unknown): value is string => typeof value === 'string' && /^(0|[1-9]\d{0,36})$/.test(value) && BigInt(value) < 1n << 120n;
export function isSpotSwapAmounts(value: unknown, original: { amountInRaw: string; minAmountOutRaw: string }): value is SpotSwapAmounts {
  const a = value as SpotSwapAmounts | null;
  return !!a && [a.paidInputRaw, a.consumedInputRaw, a.returnedInputRaw, a.outputRaw].every(atomic) &&
    a.paidInputRaw === original.amountInRaw && BigInt(a.consumedInputRaw) > 0n && BigInt(a.outputRaw) > 0n &&
    BigInt(a.paidInputRaw) === BigInt(a.consumedInputRaw) + BigInt(a.returnedInputRaw) && BigInt(a.outputRaw) >= BigInt(original.minAmountOutRaw);
}

export function formatSpotAmount(raw: string, decimals: number): string {
  const amount = BigInt(raw), scale = 10n ** BigInt(decimals);
  const fraction = (amount % scale).toString().padStart(decimals, '0').replace(/0+$/, '');
  return `${amount / scale}${fraction ? `.${fraction}` : ''}`;
}

export const sameSpotSwapAmounts = (a: SpotSwapAmounts, b: SpotSwapAmounts) =>
  a.paidInputRaw === b.paidInputRaw && a.consumedInputRaw === b.consumedInputRaw && a.returnedInputRaw === b.returnedInputRaw && a.outputRaw === b.outputRaw;
