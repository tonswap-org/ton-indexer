import { Address, beginCell, Cell, contractAddress, Dictionary, type DictionaryValue, type Slice } from '@ton/core';
import { sha256_sync } from '@ton/crypto';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { AppError } from './appError';
import { ChainReadError } from './chainReadError';
import { freshAddressArg, freshInt, FreshStack, type FreshChainRead, type FreshJettonSlot } from './spotContracts';
import { decodeJettonWalletBudget, validateJettonWalletProfile, jettonWalletBudgetToCell, standardJettonWalletProfile, prepareJettonTransfer } from './jettonWalletProfile';
import { readJettonQuotePrices, ConfigHeadMismatchError } from './jettonConfigPrices';
import { verifySpotWallet, verifySpotPoolInputWallet } from './spotPoolWallets';
import { t3WalletAttemptToCell, t3WalletTransferBody } from './t3Contracts';
import { readChain, type ChainCall, type ChainObservation, type ReadChainOptions } from './toncenter';

export const LAUNCH_OP = { CREATE:0x53464e57, CREATED:0x53464556, CONTRIBUTE:0x53434f4e, FINALIZE:0x5346494e, CLAIM:0x53434c4d, CANCEL:0x5343414e,
  DISCOVER:0x44534357, OWED:0x434c4d4a, LP_SEED:0x4c565344, LP_RELEASE:0x4c56524c, VEST_CLAIM:0x5656434c, VEST_RETURN:0x56565254, EVENT:0x53455654 } as const;
export type NativeSaleKind = 0 | 1 | 2;
export type NativeLaunchRole = 0 | 1 | 2;
export type NativeSaleIdentity = { factory:Address; creator:Address; nonce:bigint; kind:NativeSaleKind; role:NativeLaunchRole };
export type NativeSaleCaps = { softCap:bigint; hardCap:bigint; minContribution:bigint; maxContribution:bigint; saleSupply:bigint };
export type NativeSaleVesting = { beneficiary:Address; amount:bigint; cliff:number; duration:number; period:number };
export type NativeSaleTerms = { projectMaster:Address; lpRecipient:Address; xDecimals:number; startTime:number; endTime:number; seedBin:number;
  caps:NativeSaleCaps; pricing:Cell; vesting:NativeSaleVesting|null };
export type NativeSalePricing = { kind:0; price:bigint } | { kind:1; curveKind:1; basePrice:bigint; slopeNumerator:bigint; slopeDenominator:bigint }
  | { kind:2; startPrice:bigint; reservePrice:bigint; decayInterval:number; tickSize:bigint };
export const launchContractError = (message:string) => new AppError('launch.load.unreadable', {}, {devMessage:message});
function fail(message:string):never {throw launchContractError(message);}
const ordinary = (c:Cell) => {if(c.isExotic)fail('Exotic launchpad state');return c.beginParse();};
const addr = (s:Slice) => {const a=s.loadAddress();if(a.workChain!==0)fail('Launchpad requires basechain addresses');return a;};
const optionalAddr = (s:Slice) => {const a=s.loadMaybeAddress();if(a&&a.workChain!==0)fail('Launchpad requires basechain addresses');return a;};
const end = <T>(s:Slice,value:T):T => {s.endParse();return value;};
const codec = <T>(parse:(s:Slice)=>T):DictionaryValue<T> => ({serialize(){fail('Read-only launchpad codec');},parse});
const kind = (v:number):NativeSaleKind => {if(v!==0&&v!==1&&v!==2)fail('Unknown sale kind');return v as NativeSaleKind;};
const role = (v:number):NativeLaunchRole => {if(v!==0&&v!==1&&v!==2)fail('Unknown launchpad role');return v as NativeLaunchRole;};
const query = (op:number,q:bigint) => {if(q<=0n||q>=1n<<64n)fail('Invalid launchpad query');return beginCell().storeUint(op,32).storeUint(q,64);};
export const launchControlBody = (op:number,q:bigint) => query(op,q).endCell();
export const launchContributeBody = (minTokens:bigint) => {if(minTokens<=0n)fail('Minimum token amount required');return beginCell().storeUint(LAUNCH_OP.CONTRIBUTE,32).storeCoins(minTokens).endCell();};
export const launchSeedBody = (q:bigint,t3:bigint,x:bigint) => query(LAUNCH_OP.LP_SEED,q).storeCoins(t3).storeCoins(x).endCell();
export const launchReleaseBody = (q:bigint,t3:bigint,x:bigint,remove:boolean) => query(LAUNCH_OP.LP_RELEASE,q).storeCoins(t3).storeCoins(x).storeBit(remove).endCell();
export const launchOwedBody = (q:bigint,slot:0|1,owner:Address) => query(LAUNCH_OP.OWED,q).storeUint(slot,8).storeAddress(owner).endCell();
export function launchPricingCell(p:NativeSalePricing):Cell {
  if(p.kind===0)return beginCell().storeCoins(p.price).endCell();
  if(p.kind===1)return beginCell().storeUint(p.curveKind,8).storeCoins(p.basePrice).storeCoins(p.slopeNumerator).storeCoins(p.slopeDenominator).endCell();
  return beginCell().storeCoins(p.startPrice).storeCoins(p.reservePrice).storeUint(p.decayInterval,32).storeCoins(p.tickSize).endCell();
}
export function decodeLaunchPricing(k:NativeSaleKind,c:Cell):NativeSalePricing {
  const s=ordinary(c);if(k===0)return end(s,{kind:k,price:s.loadCoins()});
  if(k===1){const curveKind=s.loadUint(8);if(curveKind!==1)fail('Unknown native sale curve');return end(s,{kind:k,curveKind:1,basePrice:s.loadCoins(),slopeNumerator:s.loadCoins(),slopeDenominator:s.loadCoins()});}
  return end(s,{kind:k,startPrice:s.loadCoins(),reservePrice:s.loadCoins(),decayInterval:s.loadUint(32),tickSize:s.loadCoins()});
}
export function launchTermsCell(t:NativeSaleTerms):Cell {
  const c=t.caps,v=t.vesting;
  return beginCell().storeAddress(t.projectMaster).storeAddress(t.lpRecipient).storeUint(t.xDecimals,8).storeUint(t.startTime,32).storeUint(t.endTime,32).storeInt(t.seedBin,32)
    .storeRef(beginCell().storeCoins(c.softCap).storeCoins(c.hardCap).storeCoins(c.minContribution).storeCoins(c.maxContribution).storeCoins(c.saleSupply).endCell()).storeRef(t.pricing)
    .storeMaybeRef(v?beginCell().storeAddress(v.beneficiary).storeCoins(v.amount).storeUint(v.cliff,32).storeUint(v.duration,32).storeUint(v.period,32).endCell():null).endCell();
}
export function decodeLaunchTerms(c:Cell):NativeSaleTerms {
  const s=ordinary(c),projectMaster=addr(s),lpRecipient=addr(s),xDecimals=s.loadUint(8),startTime=s.loadUint(32),endTime=s.loadUint(32),seedBin=s.loadInt(32),a=ordinary(s.loadRef());
  const caps=end(a,{softCap:a.loadCoins(),hardCap:a.loadCoins(),minContribution:a.loadCoins(),maxContribution:a.loadCoins(),saleSupply:a.loadCoins()}),pricing=s.loadRef(),v=s.loadMaybeRef(),p=v?ordinary(v):null;
  return end(s,{projectMaster,lpRecipient,xDecimals,startTime,endTime,seedBin,caps,pricing,vesting:p?end(p,{beneficiary:addr(p),amount:p.loadCoins(),cliff:p.loadUint(32),duration:p.loadUint(32),period:p.loadUint(32)}):null});
}
export const launchCreateBody = (q:bigint,nonce:bigint,k:NativeSaleKind,terms:NativeSaleTerms) => query(LAUNCH_OP.CREATE,q).storeUint(nonce,64).storeUint(k,8).storeRef(launchTermsCell(terms)).endCell();
export function launchInitialData(id:NativeSaleIdentity):Cell {
  const identity=beginCell().storeAddress(id.factory).storeAddress(id.creator).storeUint(id.nonce,64).storeUint(id.kind,8).storeUint(id.role,8).endCell();
  const book=id.role===0?beginCell().storeUint(0,16).storeCoins(0).storeCoins(0).storeCoins(0).storeCoins(0).storeCoins(0).storeUint(0,16).storeDict(null).endCell()
    :id.role===1?beginCell().storeAddress(null).storeUint(0,64).storeCoins(0).storeCoins(0).endCell():beginCell().storeCoins(0).storeCoins(0).storeCoins(0).storeUint(0,32).storeBit(false).endCell();
  return beginCell().storeRef(identity).storeMaybeRef(null).storeRef(beginCell().storeDict(null).storeDict(null).storeDict(null).endCell()).storeRef(book).endCell();
}
export const launchChildAddress = (id:NativeSaleIdentity,code:Cell) => contractAddress(0,{code,data:launchInitialData(id)});
const codeCodec=codec(s=>end(s,{code:s.loadRef(),bits:s.loadUint(32),cells:s.loadUint(16)}));
export function decodeLaunchFactory(c:Cell) {
  const s=ordinary(c),governance=addr(s),closed=s.loadBit(),p=ordinary(s.loadRef()),t3Master=addr(p),feeSink=addr(p),dlmmFactory=addr(p),profile=ordinary(p.loadRef());p.endParse();
  const t3Profile=end(profile,{walletGas:profile.loadUint(32),walletGram:profile.loadCoins(),budget:decodeJettonWalletBudget(profile.loadRef())});validateJettonWalletProfile(t3Profile);
  return end(s,{governance,closed,t3Master,feeSink,dlmmFactory,t3Profile,feeBps:s.loadUint(16),codes:s.loadDict(Dictionary.Keys.Uint(8),codeCodec)});
}
const slotCodec=codec<FreshJettonSlot>(s=>{const slot=end(s,{master:addr(s),wallet:optionalAddr(s),walletGas:s.loadUint(32),walletGram:s.loadCoins(),optional:s.loadBit(),budget:decodeJettonWalletBudget(s.loadRef())});validateJettonWalletProfile(slot);return slot;});
export function decodeLaunchChild(c:Cell) {
  const s=ordinary(c),i=ordinary(s.loadRef()),identity=end(i,{factory:addr(i),creator:addr(i),nonce:i.loadUintBig(64),kind:kind(i.loadUint(8)),role:role(i.loadUint(8))});
  const config=s.loadMaybeRef(),m=ordinary(s.loadRef()),slots=m.loadDict(Dictionary.Keys.Uint(8),slotCodec),owed=m.loadMaybeRef(),recovery=m.loadDict(Dictionary.Keys.Uint(8),Dictionary.Values.Cell());m.endParse();
  return end(s,{identity,config,slots,owed,recovery,book:s.loadRef()});
}
export const launchEntryCodec=codec(s=>end(s,{paid:s.loadCoins(),tokens:s.loadCoins()}));
export function decodeLaunchSale(child:ReturnType<typeof decodeLaunchChild>) {
  if(child.identity.role!==0||!child.config)fail('Unconfigured sale');
  const s=ordinary(child.config!),feeBps=s.loadUint(16),p=ordinary(s.loadRef()),peers=end(p,{feeSink:addr(p),lpVault:addr(p),vestingVault:optionalAddr(p)}),termsCell=s.loadRef();s.endParse();
  const terms=decodeLaunchTerms(termsCell),b=ordinary(child.book),book=end(b,{ready:b.loadUint(8),phase:b.loadUint(8),inventory:b.loadCoins(),raised:b.loadCoins(),sold:b.loadCoins(),t3Due:b.loadCoins(),tokDue:b.loadCoins(),openEntries:b.loadUint(16),entries:b.loadDict(Dictionary.Keys.Address(),launchEntryCodec)});
  if(book.phase<1||book.phase>4||book.openEntries!==book.entries.size||book.openEntries>16384||feeBps>500)fail('Invalid sale book');
  const armed=!!child.slots.get(0)?.wallet&&!!child.slots.get(1)?.wallet&&book.inventory>=terms.caps.saleSupply+terms.caps.saleSupply/2n&&(book.ready&1)!==0&&(!terms.vesting||(book.ready&2)!==0);
  return{...child,feeBps,...peers,terms,termsCell,pricing:decodeLaunchPricing(child.identity.kind,terms.pricing),...book,armed};
}
export function decodeLaunchLp(child:ReturnType<typeof decodeLaunchChild>) {
  if(child.identity.role!==1||!child.config)fail('Unconfigured LP vault');
  const s=ordinary(child.config!),p=ordinary(s.loadRef()),peers=end(p,{sale:addr(p),lpRecipient:addr(p),dlmmFactory:addr(p)}),seedBin=s.loadInt(32),poolId=s.loadRef();s.endParse();
  const b=ordinary(child.book);return{...child,...peers,seedBin,poolId,...end(b,{pool:optionalAddr(b),armedAt:b.loadUint(32),unlockAt:b.loadUint(32),t3Bal:b.loadCoins(),tokenBal:b.loadCoins()})};
}
export function decodeLaunchVesting(child:ReturnType<typeof decodeLaunchChild>) {
  if(child.identity.role!==2||!child.config)fail('Unconfigured vesting vault');
  const s=ordinary(child.config!),sale=addr(s),v=ordinary(s.loadRef());s.endParse();const terms=end(v,{beneficiary:addr(v),amount:v.loadCoins(),cliff:v.loadUint(32),duration:v.loadUint(32),period:v.loadUint(32)});
  const b=ordinary(child.book);return{...child,sale,terms,...end(b,{deposited:b.loadCoins(),claimed:b.loadCoins(),returned:b.loadCoins(),start:b.loadUint(32),failed:b.loadBit()})};
}
export type LaunchpadBinding={factory:Address;factoryHash:string;governance:Address;feeSink:Address;dlmmFactory:Address;dlmmFactoryHash:string;poolHash:string;projectMasterHashes:readonly string[];projectWalletHash:string;t3Root:Address;t3MasterHash:string;t3WalletHash:string;templateHashes:readonly[string,string,string,string,string]};
export function launchpadReleaseBinding():LaunchpadBinding {
  const r=TONSWAP_RELEASE;if(!r)return fail('Current Launchpad release unavailable');
  const contract=(key:'SaleFactory'|'Governance'|'FeeRouter'|'DlmmPoolFactory')=>{const c=r.contracts[key];if(!c)fail(`Missing ${key}`);return{address:Address.parse(c.address),hash:c.codeHash};};
  const f=contract('SaleFactory'),t=r.tokens.find(t=>t.symbol==='T3');if(!t)fail('Missing T3');
  return{factory:f.address,factoryHash:f.hash,governance:contract('Governance').address,feeSink:contract('FeeRouter').address,dlmmFactory:contract('DlmmPoolFactory').address,dlmmFactoryHash:contract('DlmmPoolFactory').hash,poolHash:r.templates.DlmmPool,projectMasterHashes:[r.templates.JettonV21Minter],projectWalletHash:r.templates.JettonV21Wallet,
    t3Root:Address.parse(t!.root),t3MasterHash:t!.masterCodeHash,t3WalletHash:t!.walletCodeHash,templateHashes:[r.templates.SaleFixed,r.templates.SaleBonding,r.templates.SaleAuction,r.templates.LpVault,r.templates.VestingVault]};
}

export type LaunchControlKind='claim'|'finalize'|'cancel'|'discover'|'lp-seed'|'lp-release'|'vest-claim'|'vest-return'|'owed';
const controlOps:Record<LaunchControlKind,number>={claim:LAUNCH_OP.CLAIM,finalize:LAUNCH_OP.FINALIZE,cancel:LAUNCH_OP.CANCEL,discover:LAUNCH_OP.DISCOVER,'lp-seed':LAUNCH_OP.LP_SEED,'lp-release':LAUNCH_OP.LP_RELEASE,'vest-claim':LAUNCH_OP.VEST_CLAIM,'vest-return':LAUNCH_OP.VEST_RETURN,owed:LAUNCH_OP.OWED};
export type LaunchControlRequest={owner:Address;target:Address;kind:LaunchControlKind;queryId:bigint;slot?:0|1;remove?:boolean};
export async function prepareLaunchControl(r:LaunchControlRequest,options:LaunchReadOptions={}) {
  const b=options.binding??launchpadReleaseBinding(),op=controlOps[r.kind];
  for(let retry=0;retry<3;retry++){
    const start=await readLaunchpadState(r.target,options);if(!start.child?.config)fail('Control recipient is not configured');const id=start.child.identity;
    const lp=id.role===1?decodeLaunchLp(start.child):null;
    const calls:ChainCall[]=[launchGetter(r.target,r.kind==='owed'?'get_min_claim':'get_min_value',r.kind==='owed'?r.slot??0:op),{kind:'account',address:r.owner.toRawString()}];
    const extra:(number|undefined)[]=[];let fwdT3=0n,fwdX=0n;
    if(r.kind==='lp-seed'){
      if(!lp)fail('Only the LP vault seeds liquidity');const pre=await readLaunchpadState(r.target,{...options,calls:[launchGetter(r.target,'get_seed_floor',0),launchGetter(r.target,'get_seed_floor',1)]});
      if(pre.head.seqno!==start.head.seqno||pre.head.rootHashHex!==start.head.rootHashHex)continue;fwdT3=uintQuote(pre.extra(0));fwdX=uintQuote(pre.extra(1));
      calls.push(launchGetter(r.target,'get_seed_value',fwdT3,fwdX));
    }else if(r.kind==='discover'&&lp&&!lp.pool){
      calls.push({kind:'account',address:b.dlmmFactory.toRawString()},{kind:'getter',address:b.dlmmFactory.toRawString(),method:'get_create_min_value_for',args:[{type:'cell',cell:lp.poolId}]});
    }else if(r.kind==='owed')calls.push({kind:'getter',address:r.target.toRawString(),method:'get_owed',args:[freshInt(r.slot??0),freshAddressArg(r.owner)]});
    else if(r.kind==='lp-release'){
      if(!lp)fail('Only the LP vault releases liquidity');for(const slot of [0,1]){const token=lp.slots.get(slot);if(!token?.wallet)fail('LP token wallets not discovered');extra.push(calls.length);
        calls.push({kind:'account',address:token!.master.toRawString()},{kind:'getter',address:token!.master.toRawString(),method:'get_wallet_address',args:[freshAddressArg(r.target)]},{kind:'account',address:token!.wallet!.toRawString()},{kind:'getter',address:token!.wallet!.toRawString(),method:'get_wallet_data'});}
      if(r.remove){if(!lp.pool)fail('LP pool unavailable');extra.push(calls.length);calls.push({kind:'account',address:lp.pool!.toRawString()},launchGetter(lp.pool!,'get_min_forward',0x4c515233,0));}
    }
    const projectRoot=start.child.slots.get(id.role===2?0:1)!.master,projectIndex=calls.length;
    calls.push({kind:'account',address:projectRoot.toRawString()},{kind:'account',address:b.t3Root.toRawString()});
    const state=await readLaunchpadState(r.target,{...options,calls});if(state.head.seqno!==start.head.seqno||state.head.rootHashHex!==start.head.rootHashHex)continue;
    const child=state.child!;if(!child.config||!child.identity.creator.equals(id.creator)||child.identity.nonce!==id.nonce||child.identity.kind!==id.kind||child.identity.role!==id.role)fail('Control identity changed');
    let value=uintQuote(state.extra(0)),body=launchControlBody(op,r.queryId),amount=0n;const assets:Array<{root:Address;amount:bigint;recipient:Address}>=[];
    if(r.kind==='claim'||r.kind==='finalize'||r.kind==='cancel'){
      const sale=decodeLaunchSale(child),c=sale.terms.caps;
      if(r.kind==='claim'){const entry=sale.entries.get(r.owner);if(!entry||(sale.phase!==2&&sale.phase!==3))fail('No native sale claim');amount=sale.phase===2?entry.tokens:entry.paid;assets.push({root:sale.phase===2?sale.terms.projectMaster:b.t3Root,amount,recipient:r.owner});}
      if(r.kind==='finalize'&&sale.phase===1&&state.chainNow<sale.terms.endTime&&sale.raised!==c.hardCap&&sale.sold!==c.saleSupply)fail('Finalization is not open');
      if(r.kind==='cancel'&&(!id.creator.equals(r.owner)||sale.phase!==1||sale.raised!==0n||(sale.armed&&state.chainNow>=sale.terms.startTime)))fail('Cancellation is not open');
      if((r.kind==='finalize'||r.kind==='cancel')&&sale.phase===1){const success=r.kind==='finalize'&&sale.sold>0n&&sale.raised>=c.softCap;if(success){const fee=sale.raised*BigInt(sale.feeBps)/10000n,net=sale.raised-fee,lpT3=net/2n,lpX=sale.sold/2n;
        assets.push({root:b.t3Root,amount:fee,recipient:sale.feeSink},{root:b.t3Root,amount:lpT3,recipient:sale.lpVault},{root:b.t3Root,amount:net-lpT3,recipient:id.creator},{root:sale.terms.projectMaster,amount:lpX,recipient:sale.lpVault},{root:sale.terms.projectMaster,amount:sale.inventory-sale.sold-lpX,recipient:id.creator});
      }else assets.push({root:sale.terms.projectMaster,amount:sale.inventory,recipient:id.creator});}
    }else if(r.kind==='owed'){
      if(id.role!==0)fail('Only sales have a native owed book');const s=state.extra(2);amount=s.uint();s.end();if(amount<=0n)fail('No retained payout available');const token=child.slots.get(r.slot??0);if(!token)fail('Owed token unavailable');
      body=launchOwedBody(r.queryId,r.slot??0,r.owner);assets.push({root:token!.master,amount,recipient:r.owner});
    }else if(r.kind==='vest-claim'||r.kind==='vest-return'){
      const vest=decodeLaunchVesting(child),v=vest.terms,elapsed=state.chainNow-vest.start;
      const vested=vest.start===0||elapsed<v.cliff?0n:elapsed>=v.duration?vest.deposited:vest.deposited*BigInt(Math.floor(elapsed/v.period)*v.period)/BigInt(v.duration);
      if(r.kind==='vest-claim'){if(!v.beneficiary.equals(r.owner)||vest.failed||vest.start===0)fail('Vesting claim unavailable');amount=vested-vest.claimed;}
      else{if(!id.creator.equals(r.owner)||!vest.failed)fail('Vesting return unavailable');amount=vest.deposited-vest.returned;}
      if(amount<=0n)fail('Nothing vested or returnable');assets.push({root:child.slots.get(0)!.master,amount,recipient:r.owner});
    }else if(r.kind==='discover'&&lp&&!lp.pool){const f=state.result(2);if(f.kind!=='account'||f.state!=='active'||f.code?.hash().toString('hex')!==b.dlmmFactoryHash)fail('Pool factory code differs');value+=uintQuote(state.extra(3));}
    else if(r.kind==='lp-seed'){
      const current=decodeLaunchLp(child);if(current.armedAt<=0||state.chainNow>=current.unlockAt||!current.pool||!current.slots.get(0)?.wallet||!current.slots.get(1)?.wallet||current.t3Bal+current.tokenBal<=0n)fail('LP seed unavailable');
      value=uintQuote(state.extra(2));body=launchSeedBody(r.queryId,fwdT3,fwdX);assets.push({root:b.t3Root,amount:current.t3Bal,recipient:current.pool},{root:current.slots.get(1)!.master,amount:current.tokenBal,recipient:current.pool});
    }else if(r.kind==='lp-release'){
      const current=decodeLaunchLp(child);if(current.unlockAt===0||state.chainNow<current.unlockAt)fail('LP vault remains locked');const amounts:bigint[]=[];
      for(const [slot,index] of extra.slice(0,2).entries()){const n=index!,token=current.slots.get(slot)!,pin=slot===0?{masterHashes:[b.t3MasterHash],walletHash:b.t3WalletHash}:launchProjectPin(token.master,b),master=state.result(n),w=state.extra(n+1),wallet=w.address()!;w.end();
        if(master.kind!=='account'||master.state!=='active'||!master.code||!pin.masterHashes.includes(master.code.hash().toString('hex'))||!wallet.equals(token.wallet!))fail('LP release wallet not canonical');
        const balance=verifySpotWallet(state.result(n+2),state.result(n+3),{root:token.master.toRawString(),owner:r.target.toRawString(),address:wallet.toRawString(),codeHash:pin.walletHash}).balance;amounts.push(balance);assets.push({root:token.master,amount:balance,recipient:current.lpRecipient});}
      if(r.remove){const n=extra[2]!,pool=state.result(n);if(!current.pool||pool.kind!=='account'||pool.state!=='active'||pool.code?.hash().toString('hex')!==b.poolHash)fail('LP pool code differs');value+=uintQuote(state.extra(n+1));}
      if(amounts[0]+amounts[1]===0n&&!r.remove)fail('No LP assets available');body=launchReleaseBody(r.queryId,amounts[0],amounts[1],!!r.remove);
    }
    const owner=state.result(1);if(owner.kind!=='account'||owner.state!=='active'||owner.balance<=value)fail('Insufficient GRAM for control request');
    const project=state.result(projectIndex),projectPin=checkProjectMaster(project,projectRoot,b),t3=state.result(projectIndex+1);
    if(t3.kind!=='account'||t3.state!=='active'||t3.code?.hash().toString('hex')!==b.t3MasterHash)fail('Current T3 master is unavailable');
    return{address:r.target,value,body,amount,assets:assets.filter(a=>a.amount>0n).map(a=>({...a,masterCodeHash:a.root.equals(b.t3Root)?b.t3MasterHash:(project as Extract<typeof project,{kind:'account'}>).code!.hash().toString('hex'),walletCodeHash:a.root.equals(b.t3Root)?b.t3WalletHash:projectPin.walletHash})),head:state.head,state};
  }
  throw new ChainReadError('unavailable',{devMessage:'Launchpad control head moved; refresh review'});
}
export const launchGetter=(address:Address,method:string,...args:(number|bigint)[]):ChainCall=>({kind:'getter',address:address.toRawString(),method,args:args.map(freshInt)});
export function launchStack(o:ChainObservation,index:number):FreshStack {const r=o.results[index];if(!r||r.kind!=='getter'||r.exitCode!==0)return fail('Native Launchpad getter unavailable');return new FreshStack(r.stack);}
export type LaunchReadOptions=ReadChainOptions&{binding?:LaunchpadBinding;read?:FreshChainRead;calls?:readonly ChainCall[]};
/** Canonical identity, peer links, code and every appended quote share one authenticated block. */
export async function readLaunchpadState(address:Address|null=null,options:LaunchReadOptions={}) {
  const {binding=launchpadReleaseBinding(),read=readChain,calls=[],...readOptions}=options;
  const observation=await read([{kind:'account',address:binding.factory.toRawString()},...(address?[{kind:'account' as const,address:address.toRawString()}]:[]),...calls],{...readOptions,anchored:true,lane:readOptions.lane??'user'}),head=observation.head;
  if(!head||!Number.isSafeInteger(head.seqno)||head.seqno<=0||!head.utime||!head.rootHashHex||observation.results.length!==1+(address?1:0)+calls.length)throw new ChainReadError('unavailable');
  const f=observation.results[0];if(f.kind!=='account'||f.state!=='active'||!f.data||f.code?.hash().toString('hex')!==binding.factoryHash)fail('Factory code differs from release');
  const factory=decodeLaunchFactory(f.data!);
  if(!factory.governance.equals(binding.governance)||!factory.t3Master.equals(binding.t3Root)||!factory.feeSink.equals(binding.feeSink)||!factory.dlmmFactory.equals(binding.dlmmFactory)||factory.codes.size!==5||factory.feeBps>500
    ||binding.templateHashes.some((hash,slot)=>factory.codes.get(slot)?.code.hash().toString('hex')!==hash))fail('Launchpad factory peers or templates differ from release');
  let child:ReturnType<typeof decodeLaunchChild>|null=null;
  if(address){const a=observation.results[1];if(a.kind!=='account'||a.state!=='active'||!a.data||!a.code)fail('Launchpad child unavailable');child=decodeLaunchChild(a.data!);const id=child.identity,slot=id.role===0?id.kind:id.role+2,code=factory.codes.get(slot)!.code;
    if(!id.factory.equals(binding.factory)||!code.equals(a.code!)||!launchChildAddress(id,code).equals(address))fail('Launchpad child is not canonical');
    if(child.config){const token=child.slots.get(id.role===2?0:1),t3=child.slots.get(0);if(!token||child.slots.size!==(id.role===2?1:2)||!token.optional||token.budget.creditProtection||(id.role!==2&&(!t3?.master.equals(binding.t3Root)||t3.optional||!t3.budget.creditProtection)))fail('Launchpad token slots differ from native roles');}
  }
  return{binding,observation,head,chainNow:head.utime,factory,child,extra:(index:number)=>launchStack(observation,1+(address?1:0)+index),result:(index:number)=>observation.results[1+(address?1:0)+index]};
}
export type NativeLaunchState=Awaited<ReturnType<typeof readLaunchpadState>>;
export function launchChildren(state:Pick<NativeLaunchState,'binding'|'factory'>,creator:Address,nonce:bigint,k:NativeSaleKind) {
  const child=(r:NativeLaunchRole)=>launchChildAddress({factory:state.binding.factory,creator,nonce,kind:k,role:r},state.factory.codes.get(r===0?k:r+2)!.code);
  return{sale:child(0),lp:child(1),vesting:child(2)};
}
export async function readNativeSale(address:Address,options:LaunchReadOptions={}) {
  const state=await readLaunchpadState(address,options);if(!state.child)fail('Sale missing');const sale=decodeLaunchSale(state.child!),id=sale.identity,children=launchChildren(state,id.creator,id.nonce,id.kind);
  if(!sale.feeSink.equals(state.binding.feeSink)||!sale.lpVault.equals(children.lp)||!!sale.vestingVault!==!!sale.terms.vesting||(sale.vestingVault&&!sale.vestingVault.equals(children.vesting))||!sale.slots.get(1)!.master.equals(sale.terms.projectMaster))fail('Native sale peers or project wallet differ');
  return{...state,sale,children,open:sale.phase===1&&sale.armed&&state.chainNow>=sale.terms.startTime&&state.chainNow<sale.terms.endTime&&sale.raised<sale.terms.caps.hardCap&&sale.sold<sale.terms.caps.saleSupply};
}

/** Native public-pool price, including its exact bounded integer rounding. */
export function launchBinPrice(bin:number,decimals:number):bigint {
  if(!Number.isInteger(bin)||Math.abs(bin)>200000||!Number.isInteger(decimals)||decimals<0||decimals>18)return 0n;
  const q=1n<<128n,limit=1n<<224n;let factor=q+q*2500n/1000000n,power=q,n=Math.abs(bin);
  while(n>0){if(n%2){if(factor>=limit||power>(limit-1n)*q/factor)return 0n;power=power*factor/q;}n=Math.floor(n/2);if(n)factor=factor>=limit||factor>(limit-1n)*q/factor?limit:factor*factor/q;}
  if(bin<0)power=q*q/power;const raw=power*10n**BigInt(decimals)/(1000000000n*(1n<<64n));return raw>=1n<<32n&&raw<1n<<128n?raw:0n;
}
export function validateNativeSaleTerms(k:NativeSaleKind,t:NativeSaleTerms,chainNow:number):void {
  const c=t.caps,p=decodeLaunchPricing(k,t.pricing),v=t.vesting,max=(1n<<120n)-1n,scale=10n**18n;
  if(t.projectMaster.workChain!==0||t.lpRecipient.workChain!==0||!launchBinPrice(t.seedBin,t.xDecimals)||t.startTime<chainNow+300||t.endTime<t.startTime+900||t.endTime-t.startTime>7776000
    ||c.softCap<10000000000n||c.softCap>c.hardCap||c.minContribution<=0n||c.minContribution>c.maxContribution||c.maxContribution>c.hardCap||c.minContribution*16384n<c.hardCap||c.saleSupply<=0n||c.saleSupply>=1n<<118n
    ||Object.values(c).some(n=>n<0n||n>max))fail('Sale terms exceed native bounds');
  if(v&&(v.beneficiary.workChain!==0||v.amount<=0n||v.amount>max||v.cliff>v.duration||v.duration>315360000||v.period<=0||v.period>v.duration))fail('Invalid vesting terms');
  if(p.kind===1){if(p.basePrice<=0n||p.basePrice>max||p.slopeDenominator<=0n||p.slopeNumerator*c.saleSupply>p.slopeDenominator*(max-p.basePrice))fail('Invalid bonding pricing');
    const d=2n*p.slopeDenominator*scale,cost=(c.saleSupply*(2n*p.slopeDenominator*p.basePrice+p.slopeNumerator*c.saleSupply)+d-1n)/d;if(cost<c.softCap)fail('Bonding supply cannot reach the soft cap');
  }else{const low=p.kind===0?p.price:p.reservePrice,high=p.kind===0?p.price:p.startPrice;
    if(low<=0n||low>high||high>max||c.minContribution*scale/high<=0n||(c.saleSupply*low+scale-1n)/scale<c.softCap||(p.kind===2&&(p.decayInterval<=0||p.tickSize<=0n)))fail('Invalid fixed or falling sale pricing');}
  // Canonical encoding also rejects out-of-range timestamp, integer and Coins fields.
  launchTermsCell(t);
}
const uintQuote=(s:FreshStack)=>{const n=s.uint();s.end();if(n<=0n)fail('Native funding quote unavailable');return n;};
export function launchProjectPin(root:Address,binding=launchpadReleaseBinding()) {
  const r=TONSWAP_RELEASE;if(!r)fail('Current token release unavailable');const pinned=r!.tokens.find(t=>Address.parse(t.root).equals(root));
  return{root:root.toRawString(),masterHashes:pinned?[pinned.masterCodeHash]:binding.projectMasterHashes,walletHash:pinned?.walletCodeHash??binding.projectWalletHash,decimals:pinned?.decimals??null};
}
function checkProjectMaster(account:ChainObservation['results'][number],root:Address,binding:LaunchpadBinding) {
  const pin=launchProjectPin(root,binding);if(account.kind!=='account'||account.state!=='active'||!account.code||!pin.masterHashes.includes(account.code.hash().toString('hex')))fail('Project token master is not qualified by this release');return pin;
}
export async function prepareNativeSaleCreate(request:{owner:Address;nonce:bigint;kind:NativeSaleKind;terms:NativeSaleTerms;queryId:bigint},options:LaunchReadOptions={}) {
  const b=options.binding??launchpadReleaseBinding(),t=request.terms;
  const state=await readLaunchpadState(null,{...options,calls:[launchGetter(b.factory,'get_create_value',request.kind,t.vesting?-1:0,t.vesting?.duration??0),
    {kind:'account',address:t.projectMaster.toRawString()},{kind:'account',address:request.owner.toRawString()}]});
  validateNativeSaleTerms(request.kind,t,state.chainNow);if(state.factory.closed)fail('Sale factory is closed');checkProjectMaster(state.result(1),t.projectMaster,b);
  const children=launchChildren(state,request.owner,request.nonce,request.kind),excluded=[t.projectMaster,b.t3Root,b.factory,b.feeSink,b.dlmmFactory,...Object.values(children)];
  for(const payable of [request.owner,t.lpRecipient,...(t.vesting?[t.vesting.beneficiary]:[])])if(payable.workChain!==0||excluded.some(a=>a.equals(payable)))fail('Invalid fixed recipient');
  if(excluded.slice(1).some(a=>a.equals(t.projectMaster)))fail('Project root collides with a protocol address');
  const value=uintQuote(state.extra(0)),owner=state.result(2);if(owner.kind!=='account'||owner.state!=='active'||owner.balance<=value)fail('Insufficient creator GRAM');
  return{address:b.factory,value,body:launchCreateBody(request.queryId,request.nonce,request.kind,t),head:state.head,state,children};
}
export type LaunchTransferRequest={owner:Address;target:Address;kind:'contribute'|'supply'|'vest-supply';amount:bigint;minTokens?:bigint;queryId:bigint};
/** The T3 outgoing_value getter or qualified external profile prices funds the complete exact request. */
export async function prepareLaunchTransfer(request:LaunchTransferRequest,options:LaunchReadOptions&{prices?:typeof readJettonQuotePrices}={}) {
  const {prices=readJettonQuotePrices,...opts}=options,b=opts.binding??launchpadReleaseBinding(),r=request;
  if(r.owner.workChain!==0||r.amount<=0n||r.amount>=1n<<120n)fail('Invalid Launchpad transfer');
  const payload=r.kind==='contribute'?launchContributeBody(r.minTokens??0n):null;
  for(let retry=0;retry<3;retry++){
    const seed=await readLaunchpadState(r.target,opts);if(!seed.child?.config)fail('Launchpad recipient is not configured');
    const slot=r.kind==='vest-supply'?0:r.kind==='supply'?1:0,ledger=seed.child!.slots.get(slot);if(!ledger)fail('Launchpad slot missing');
    if((r.kind==='vest-supply')!==(seed.child!.identity.role===2)||seed.child!.identity.role===1)fail('Incorrect transfer role');
    const root=ledger!.master,base:ChainCall[]=[{kind:'account',address:root.toRawString()},
      {kind:'getter',address:root.toRawString(),method:'get_wallet_address',args:[freshAddressArg(r.owner)]},
      {kind:'getter',address:root.toRawString(),method:'get_wallet_address',args:[freshAddressArg(r.target)]},launchGetter(r.target,'get_min_forward',r.kind==='contribute'?LAUNCH_OP.CONTRIBUTE:0,slot)];
    const start=await readLaunchpadState(r.target,{...opts,calls:base}),a=start.extra(1),z=start.extra(2),source=a.address()!,target=z.address()!,forwardValue=uintQuote(start.extra(3));a.end();z.end();
    const pin=r.kind==='contribute'?{root:b.t3Root.toRawString(),masterHashes:[b.t3MasterHash],walletHash:b.t3WalletHash}:launchProjectPin(root,b);
    if(source.equals(target))fail('Token source and target collide');
    const fp=payload?beginCell().storeBit(true).storeRef(payload).endCell():beginCell().storeBit(false).endCell();
    const transfer={queryId:r.queryId,amount:r.amount,destination:r.target,response:r.owner,forwardValue,forwardPayload:fp};
    const outgoing=t3WalletAttemptToCell({id:0n,originLt:0n,attempt:0n,owner:r.owner,recipient:r.target,burn:false,amount:r.amount,details:{queryId:r.queryId,response:r.owner,forwardValue,forwardPayload:fp,customPayload:null}});
    const final=await readLaunchpadState(r.target,{...opts,calls:[...base,{kind:'account',address:source.toRawString()},{kind:'getter',address:source.toRawString(),method:'get_wallet_data'},
      {kind:'account',address:target.toRawString()},{kind:'getter',address:target.toRawString(),method:'get_wallet_data'},{kind:'account',address:r.owner.toRawString()},
      ...(r.kind==='contribute'?[{kind:'getter' as const,address:source.toRawString(),method:'outgoing_value',args:[{type:'cell' as const,cell:outgoing}]},launchGetter(r.target,'get_quote',r.amount)]:[])]});
    if(final.head.seqno!==start.head.seqno||final.head.rootHashHex!==start.head.rootHashHex)continue;
    const master=final.result(0);if(master.kind!=='account'||master.state!=='active'||!master.code||!pin.masterHashes.includes(master.code.hash().toString('hex')))fail('Token master differs from release');
    const sa=final.extra(1),ta=final.extra(2),fw=uintQuote(final.extra(3));if(!sa.address()!.equals(source)||!ta.address()!.equals(target)||fw!==forwardValue)fail('Launchpad wallet or funding changed');sa.end();ta.end();
    if(!final.child?.slots.get(slot)?.wallet?.equals(target)||!final.child.slots.get(slot)!.master.equals(root))fail('Recipient wallet discovery is not authenticated');
    const sourceIdentity={root:root.toRawString(),owner:r.owner.toRawString(),address:source.toRawString(),codeHash:pin.walletHash};
    const balance=verifySpotWallet(final.result(4),final.result(5),sourceIdentity).balance;verifySpotPoolInputWallet(final.result(6),final.result(7),{...sourceIdentity,owner:r.target.toRawString(),address:target.toRawString()});
    let body:Cell,value:bigint,quotedTokens=0n;
    if(r.kind==='contribute'){
      const sale=decodeLaunchSale(final.child!),q=final.extra(10),tokens=q.uint(),exactAmount=q.uint(),price=q.uint();q.end();const c=sale.terms.caps,e=sale.entries.get(r.owner);
      if(!sale.slots.get(0)!.budget.creditProtection||sale.phase!==1||!sale.armed||final.chainNow<sale.terms.startTime||final.chainNow>=sale.terms.endTime||tokens<(r.minTokens??0n)||tokens<=0n||price<=0n||sale.sold+tokens>c.saleSupply||sale.raised+r.amount>c.hardCap||(e?.paid??0n)+r.amount<c.minContribution||(e?.paid??0n)+r.amount>c.maxContribution||(!e&&sale.openEntries>=16384)||(sale.identity.kind===1&&sale.sold+tokens===c.saleSupply&&exactAmount!==r.amount))fail('Sale payment no longer qualifies');
      body=t3WalletTransferBody(transfer);value=uintQuote(final.extra(9));quotedTokens=tokens;
    }else{
      if(r.kind==='supply'){const sale=decodeLaunchSale(final.child!);if(sale.phase!==1||sale.raised!==0n||!sale.identity.creator.equals(r.owner)||r.amount>sale.terms.caps.saleSupply+sale.terms.caps.saleSupply/2n-sale.inventory)fail('Project supply changed');}
      else{const vest=decodeLaunchVesting(final.child!);if(!vest.identity.creator.equals(r.owner)||vest.start!==0||vest.failed||r.amount>vest.terms.amount-vest.deposited)fail('Vesting supply changed');}
      const profile=final.child!.slots.get(slot)!,expected=standardJettonWalletProfile(30000);
      if(profile.walletGas!==expected.walletGas||profile.walletGram!==0n||!jettonWalletBudgetToCell(profile.budget).equals(jettonWalletBudgetToCell(expected.budget)))fail('Unqualified project wallet funding profile');
      try{const current=await prices(final.head,opts.signal),plan=prepareJettonTransfer(source,current.prices,profile,{queryId:r.queryId,amount:r.amount,destination:r.target,responseDestination:r.owner,forwardGram:forwardValue,forwardPayload:null});body=plan.body;value=plan.value;}catch(e){if(e instanceof ConfigHeadMismatchError)continue;throw e;}
    }
    const owner=final.result(8);if(balance<r.amount||owner.kind!=='account'||owner.state!=='active'||owner.balance<=value||value<=forwardValue)fail('Insufficient Launchpad funding');
    return{address:source,body,value,forwardValue,head:final.head,state:final,sourceWallet:source,targetWallet:target,tokenRoot:root,masterCodeHash:master.code.hash().toString('hex'),walletCodeHash:pin.walletHash,quotedTokens};
  }
  throw new ChainReadError('unavailable',{devMessage:'Launchpad funding block moved; refresh the review'});
}

/** Code-pinned current master and on-chain metadata; remote token labels never authorize a pool. */
export async function readLaunchpadProjectToken(root:Address,options:LaunchReadOptions={}) {
 const state=await readLaunchpadState(null,{...options,calls:[{kind:'account',address:root.toRawString()},{kind:'getter',address:root.toRawString(),method:'get_jetton_data'}]}),account=state.result(0),pin=checkProjectMaster(account,root,state.binding),s=state.extra(1);
 const totalSupply=s.uint(),mintable=s.bool(),admin=s.address(true),content=s.cell()!,walletCode=s.cell()!;s.end();
 if(walletCode.hash().toString('hex')!==pin.walletHash)fail('Project wallet code differs from approved master');
 const c=ordinary(content);if(c.loadUint(8)!==0)fail('Project decimals require on-chain metadata');const fields=c.loadDict(Dictionary.Keys.BigUint(256),Dictionary.Values.Cell());c.endParse();
 const field=(name:string)=>{const cell=fields.get(BigInt('0x'+sha256_sync(name).toString('hex')));if(!cell)return null;const p=ordinary(cell);if(p.loadUint(8)!==0)return null;const text=p.loadStringTail();return text.includes('\0')?null:text;};
 const text=field('decimals');if(text===null||!/^(0|[1-9]\d?)$/.test(text)||Number(text)>18||pin.decimals!==null&&pin.decimals!==Number(text))fail('Project decimals are not authenticated');
 return{root:root.toRawString(),masterCodeHash:(account as Extract<typeof account,{kind:'account'}>).code!.hash().toString('hex'),walletCodeHash:pin.walletHash,walletCode,content,decimals:Number(text),symbol:field('symbol'),name:field('name'),totalSupply,mintable,admin:admin?.toRawString()??null,head:state.head,releaseId:TONSWAP_RELEASE!.releaseId,manifestHash:TONSWAP_RELEASE!.manifestHash};
}

export function readLaunchpadRecoveryReceipt(receipt:Cell){const s=ordinary(receipt),key=s.loadUintBig(64),item=ordinary(s.loadRef());s.endParse();const incoming=item.loadBit(),slot=item.loadUint(8),amount=item.loadCoins(),claimed=item.loadBit(),body=item.loadRef();item.endParse();if(key===0n||slot!==0||amount<=0n)fail('Invalid Launchpad holder receipt');return{key,incoming,slot:0 as const,amount,claimed,body};}
export function readLaunchpadRecoveryState(cell:Cell){const s=ordinary(cell),dispatched=s.loadUintBig(256),handled=s.loadUintBig(256),pending=s.loadCoins(),tree=s.loadMaybeRef(),restored=s.loadUintBig(256);s.endParse();return{dispatched,handled,pending,tree,restored};}
