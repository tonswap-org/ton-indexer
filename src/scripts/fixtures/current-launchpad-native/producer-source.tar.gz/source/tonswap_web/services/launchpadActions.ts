import { Address,Cell } from '@ton/core';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { appExecutionNetwork } from './appExecutionNetwork';
import { walletRequestDeadline } from './walletRequest';
import { launchpadReleaseBinding, decodeLaunchTerms, decodeLaunchPricing, type NativeSaleTerms, type NativeSaleKind, launchChildren, prepareLaunchTransfer, prepareLaunchControl, type LaunchControlKind, type LaunchReadOptions, type NativeLaunchState } from './launchpadContracts';
import { validLaunchpadRequest, validLaunchpadScope, type LaunchpadScope, type LaunchpadRequest, type LaunchpadAsset, type LaunchpadOperation } from './launchpadOperationStore';
import type { ReviewWalletAction } from './walletAction';
import { rawDisplay } from './displayDecimal';
import { AppError } from './appError';
const fail=(message:string)=>new AppError('launchCreate.error.progress.invalid',{}, {devMessage:message});
export function currentLaunchpadScope(wallet:string,network=appExecutionNetwork):LaunchpadScope {
 const r=TONSWAP_RELEASE,b=launchpadReleaseBinding(),scope={network:network as LaunchpadScope['network'],releaseId:r!.releaseId,manifestHash:r!.manifestHash,wallet:Address.parse(wallet).toRawString(),factory:b.factory.toRawString()};
 if(!validLaunchpadScope(scope)||r!.network!==`ton:${scope.network}`)throw fail('Launchpad network or release mismatch');return scope;
}
export function requireLaunchpadScope(scope:LaunchpadScope){if(JSON.stringify(currentLaunchpadScope(scope.wallet,scope.network))!==JSON.stringify(scope))throw fail('Launchpad owner or release changed');}
export function isCurrentLaunchpadScope(scope:LaunchpadScope){try{requireLaunchpadScope(scope);return true;}catch{return false;}}
export function launchRequest(scope:LaunchpadScope,kind:LaunchpadOperation,queryId:bigint,state:NativeLaunchState,plan:{address:Address;value:bigint;body:import('@ton/core').Cell},fields:{target:Address;amount:bigint;tokenRoot?:Address;sourceWallet?:Address;minTokens?:bigint;assets?:LaunchpadAsset[]},validUntil=walletRequestDeadline()):LaunchpadRequest {
 const id=state.child?.identity;if(!id)throw fail('Native child identity required');const sale=launchChildren(state,id.creator,id.nonce,id.kind).sale;
 const r:LaunchpadRequest={...scope,kind,sale:sale.toRawString(),target:fields.target.toRawString(),creator:id.creator.toRawString(),nonce:id.nonce.toString(),model:id.kind,queryId:queryId.toString(),tokenRoot:fields.tokenRoot?.toRawString()??null,amountRaw:fields.amount.toString(),minTokensRaw:fields.minTokens?.toString()??null,sourceWallet:fields.sourceWallet?.toRawString()??null,assets:fields.assets??[],destination:plan.address.toRawString(),valueNano:plan.value.toString(),bodyBoc:plan.body.toBoc().toString('base64'),bodyHash:plan.body.hash().toString('hex'),createdAt:Date.now(),validUntil};
 if(!validLaunchpadRequest(r))throw fail('Invalid current Launchpad request');return r;
}
export async function prepareLaunchpadContribution(scope:LaunchpadScope,sale:string,amount:bigint,minTokens:bigint,q:bigint,validUntil?:number,options:LaunchReadOptions={}){
 requireLaunchpadScope(scope);const p=await prepareLaunchTransfer({owner:Address.parse(scope.wallet),target:Address.parse(sale),kind:'contribute',amount,minTokens,queryId:q},options);
 return{...p,request:launchRequest(scope,'contribute',q,p.state,p,{target:Address.parse(sale),amount,tokenRoot:p.tokenRoot,sourceWallet:p.sourceWallet,minTokens,assets:[{root:p.tokenRoot.toRawString(),masterCodeHash:p.masterCodeHash,walletCodeHash:p.walletCodeHash,amountRaw:amount.toString(),recipient:sale}]},validUntil)};
}
export async function prepareLaunchpadControl(scope:LaunchpadScope,target:string,kind:LaunchControlKind,q:bigint,validUntil?:number,options:LaunchReadOptions&{slot?:0|1;remove?:boolean}={}){
 requireLaunchpadScope(scope);const {slot,remove,...readOptions}=options,p=await prepareLaunchControl({owner:Address.parse(scope.wallet),target:Address.parse(target),kind,queryId:q,slot,remove},readOptions);
 const assets=p.assets.map(a=>({root:a.root.toRawString(),masterCodeHash:a.masterCodeHash,walletCodeHash:a.walletCodeHash,amountRaw:a.amount.toString(),recipient:a.recipient.toRawString()}));
 return{...p,request:launchRequest(scope,kind,q,p.state,p,{target:Address.parse(target),amount:p.amount,assets,tokenRoot:p.assets.length===1?p.assets[0].root:undefined},validUntil)};
}
export function sameLaunchRequest(a:LaunchpadRequest,b:LaunchpadRequest){return JSON.stringify({...a,createdAt:0})===JSON.stringify({...b,createdAt:0});}
export const launchCatalogId=(id:string)=>id.replace(/-([a-z])/g,(_,c:string)=>c.toUpperCase());
export function launchWalletReview(r:LaunchpadRequest,token?:{symbol:string;decimals:number},creation?:{feeBps:number}):ReviewWalletAction {
 if(!validLaunchpadRequest(r))throw fail('Invalid native Launchpad review');const t3=launchpadReleaseBinding().t3Root.toRawString();
 const symbol=token?.symbol&&/^[^\s]{1,32}$/.test(token.symbol)?token.symbol:null;
 const rows:ReviewWalletAction['rows']=[{labelKey:'launch.current.review.sale',value:{type:'address',address:r.sale}},{labelKey:'launch.current.review.target',value:{type:'address',address:r.target}}];
 for(const [index,a] of r.assets.entries()){rows.push({labelKey:a.root!==t3&&!token?'launch.current.review.rawAmount':r.kind==='owed'?'launch.current.review.minimum':'launch.current.review.amount',value:a.root===t3||symbol?{type:'amount',amount:rawDisplay(BigInt(a.amountRaw),a.root===t3?9:token?.decimals??0)!,symbol:a.root===t3?'T3':symbol!}:{type:'text',text:rawDisplay(BigInt(a.amountRaw),token?.decimals??0)!},emphasis:true,
  ...(['contribute','supply','vest-supply'].includes(r.kind)&&index===0?{bind:{kind:'jetton-transfer' as const,messageIndex:0,field:'amount' as const,decimals:a.root===t3?9:token?.decimals??0}}:{})});if(a.root!==t3)rows.push({labelKey:'launchCreate.review.row.tokenContract',value:{type:'address',address:a.root}});rows.push({labelKey:'launch.current.review.recipient',value:{type:'address',address:a.recipient}});}
 if(r.minTokensRaw)rows.push({labelKey:'launch.current.review.minimumTokens',value:{type:'amount',amount:rawDisplay(BigInt(r.minTokensRaw),token?.decimals??0)!,symbol:token?.symbol??''}});
 if(r.kind==='create'){
  const body=Cell.fromBase64(r.bodyBoc).beginParse();body.skip(32+64+64+8);const terms=decodeLaunchTerms(body.loadRef());body.endParse();if(!creation||!Number.isInteger(creation.feeBps)||creation.feeBps<0||creation.feeBps>500)throw fail('Reviewed creation fee required');rows.push(...launchPriceReviewRows(terms,r.model,creation.feeBps));
  rows.push({labelKey:'launchCreate.review.row.tokenContract',value:{type:'address',address:terms.projectMaster.toRawString()}},
   ...[['launchCreate.review.row.minimum',terms.caps.softCap],['launchCreate.review.row.maximum',terms.caps.hardCap],['launchCreate.review.row.walletMin',terms.caps.minContribution],['launchCreate.review.row.walletMax',terms.caps.maxContribution]].map(([labelKey,n])=>({labelKey:labelKey as string,value:{type:'amount' as const,amount:rawDisplay(n as bigint,9)!,symbol:'T3'}})),
   {labelKey:'launch.current.creation.supply',value:{type:'amount',amount:rawDisplay(terms.caps.saleSupply+terms.caps.saleSupply/2n,terms.xDecimals)!,symbol:token?.symbol??terms.projectMaster.toRawString()}},
   {labelKey:'launch.current.creation.starts',value:{type:'date',seconds:terms.startTime}},{labelKey:'launch.current.creation.ends',value:{type:'date',seconds:terms.endTime}},
   {labelKey:'launch.current.creation.lpRecipient',value:{type:'address',address:terms.lpRecipient.toRawString()}});
  if(terms.vesting)rows.push({labelKey:'launch.current.vesting.beneficiary',value:{type:'address',address:terms.vesting.beneficiary.toRawString()}},{labelKey:'launch.current.vesting.amount',value:{type:'amount',amount:rawDisplay(terms.vesting.amount,terms.xDecimals)!,symbol:token?.symbol??terms.projectMaster.toRawString()}});
 }
 return{kind:'review',titleKey:`launch.current.action.${launchCatalogId(r.kind)}`,summaryKey:`launch.current.review.${launchCatalogId(r.kind)}`,rows};
}

/** Values come from the encoded contract terms, including rounding in the native price curve. */
export function launchPriceReviewRows(terms:NativeSaleTerms,model:NativeSaleKind,feeBps:number):ReviewWalletAction['rows'] {
 const p=decodeLaunchPricing(model,terms.pricing),price=(labelKey:string,value:bigint)=>({labelKey,value:{type:'amount' as const,amount:rawDisplay(value,27-terms.xDecimals)!,symbol:'T3'}});
 const rows:ReviewWalletAction['rows']=[price('launch.current.creation.startPrice',p.kind===0?p.price:p.kind===1?p.basePrice:p.startPrice),{labelKey:'launch.current.creation.saleFee',value:{type:'text',text:`${rawDisplay(BigInt(feeBps),2)!} %`}}];
 if(p.kind===1)rows.push(price('launch.current.creation.endPrice',p.basePrice+terms.caps.saleSupply*p.slopeNumerator/p.slopeDenominator));
 if(p.kind===2)rows.push(price('launch.current.creation.floorPrice',p.reservePrice),price('launch.current.creation.priceStep',p.tickSize),{labelKey:'launch.current.creation.decayInterval',value:{type:'text',text:String(p.decayInterval)}});
 if(terms.vesting)for(const [key,value] of [['cliff',terms.vesting.cliff],['duration',terms.vesting.duration],['period',terms.vesting.period]] as const)rows.push({labelKey:`launch.current.vesting.${key}`,value:{type:'text',text:String(value/86400)}});
 return rows;
}
