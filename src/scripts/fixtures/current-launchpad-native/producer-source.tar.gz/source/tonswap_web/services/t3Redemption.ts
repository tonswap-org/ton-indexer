import { Address, Cell } from '@ton/core';
import type { SendTransactionRequest, SendTransactionResponse } from '@tonconnect/sdk';
import { TONSWAP_T3_REDEMPTION } from '../releaseManifest';
import { AppError } from './appError';
import { chainReadNotSent, isChainReadError } from './chainReadError';
import type { MessageParams } from '../i18n/message';
import type { ExecutionNetwork } from './executionNetwork';
import { readChain, type ChainHead } from './toncenter';
import { walletRequestDeadline, type TransactionRef } from './walletRequest';
import type { FreshChainRead } from './spotContracts';
import { T3_OP, createT3Hub, createT3Wallet, prepareT3Redemption, prepareT3Claim, prepareT3WalletRecovery,
  readT3Intent, readT3HubBurnRecord, readT3WalletRecord,
  type T3TransactionPlan, type T3WalletAttempt } from './t3Contracts';
import type { T3RedemptionBinding } from './t3RedemptionBinding';
export type { T3RedemptionBinding } from './t3RedemptionBinding';

export type T3RedemptionIntent = {
  network: ExecutionNetwork; releaseId: string; manifestHash: string; owner: string; hub: string; recipient: string;
  queryId: string; amountRaw: string; single: boolean; outputToken: 0 | 1 | 2; slippageBps: number;
};
export type T3RedemptionAction = 'burn' | 'payout-retry' | 'burn-retry' | 'cancel-burn' | 'mark-burn-failed';
export type T3RedemptionPlan = { address: string; valueRaw: string; bodyBoc: string; bodyHash: string; head: ChainHead };
export type T3RedemptionReview = {
  intent: T3RedemptionIntent; observedAt: number; action: T3RedemptionAction; wallet: string; balanceRaw: string;
  minimumRaw: string; estimatedNetQuoteRaw: [string, string, string] | null; plan: T3RedemptionPlan | null;
  canBurn: boolean; preflightIssue: AppError | null;
};
export type T3RedemptionOriginal = { intent: T3RedemptionIntent; binding: T3RedemptionBinding; wallet: string;
  burnBodyBoc: string; burnBodyHash: string; minimumRaw: string; burnTransaction: TransactionRef | null };
export type T3RedemptionRecovery = { action: Exclude<T3RedemptionAction, 'burn'>; recordBoc: string; proofBoc: string;
  outputToken?: 0 | 1 | 2; evidenceIndex?: string; evidenceProofBoc?: string };
export type T3RedemptionReadCapabilities = { read?: FreshChainRead; now?: () => number };
export const T3_REDEMPTION_REVIEW_MAX_AGE_MS = 30_000;
export const t3Failure = (code: string, devMessage: string, params: MessageParams = {}) => new AppError(`getT3.${code}`, params, { devMessage });
const unavailable = () => t3Failure('error.chainUnreadable', 'Current T3 identity, state or authenticated evidence is unavailable.');
const canonical = (value: string) => { const a = Address.parse(value); if (a.workChain !== 0 || a.toRawString() !== value) throw unavailable(); return a; };
const hash = (v: unknown): v is string => typeof v === 'string' && /^[0-9a-f]{64}$/.test(v);
const atomic = (v: unknown, bits: number, positive = false): v is string => typeof v === 'string' && /^(0|[1-9]\d*)$/.test(v)
  && v.length <= 78 && BigInt(v) < 1n << BigInt(bits) && (!positive || BigInt(v) > 0n);
const exact = (value: unknown, keys: string[]) => !!value && typeof value === 'object' && !Array.isArray(value)
  && Object.keys(value).sort().join(',') === keys.sort().join(',');
export function parseT3RedemptionBinding(value: unknown): T3RedemptionBinding | null {
  try {
    const b = value as T3RedemptionBinding;
    if (!exact(b, ['network','releaseId','manifestHash','hub','governance','hubCodeHash','walletCodeHash','recoveryProofCodeHash','reserves'])
      || !['localnet','testnet','mainnet'].includes(b.network) || typeof b.releaseId !== 'string' || !b.releaseId
      || ![b.manifestHash,b.hubCodeHash,b.walletCodeHash,b.recoveryProofCodeHash].every(hash)
      || !Array.isArray(b.reserves) || b.reserves.length < 2 || b.reserves.length > 3) return null;
    canonical(b.hub); canonical(b.governance);
    for (const [index,r] of b.reserves.entries()) {
      if (!exact(r,['slot','symbol','master','masterCodeHash','walletCodeHash','decimals']) || r.slot !== index
        || r.symbol !== ['USDT','USDC','KUSD'][index] || !hash(r.masterCodeHash) || !hash(r.walletCodeHash)
        || !Number.isInteger(r.decimals) || r.decimals < 0 || r.decimals > 9) return null;
      canonical(r.master);
    }
    if (new Set(b.reserves.map(r=>r.master)).size !== b.reserves.length) return null;
    return { network:b.network,releaseId:b.releaseId,manifestHash:b.manifestHash,hub:b.hub,governance:b.governance,
      hubCodeHash:b.hubCodeHash,walletCodeHash:b.walletCodeHash,recoveryProofCodeHash:b.recoveryProofCodeHash,reserves:b.reserves.map(r=>({...r})) };
  } catch { return null; }
}
export function validateT3RedemptionIntent(p: T3RedemptionIntent): void {
  if (!exact(p,['network','releaseId','manifestHash','owner','hub','recipient','queryId','amountRaw','single','outputToken','slippageBps'])
    || !['mainnet','testnet','localnet'].includes(p.network) || typeof p.releaseId !== 'string' || !p.releaseId || !hash(p.manifestHash)
    || !atomic(p.queryId,64,true) || !atomic(p.amountRaw,120,true) || typeof p.single !== 'boolean'
    || ![0,1,2].includes(p.outputToken) || !p.single && p.outputToken !== 0
    || !Number.isInteger(p.slippageBps) || p.slippageBps < 0 || p.slippageBps > 10000 || p.owner !== p.recipient) throw unavailable();
  [p.owner,p.hub,p.recipient].forEach(canonical);
}
function assertBinding(p: T3RedemptionIntent, binding: T3RedemptionBinding) {
  validateT3RedemptionIntent(p);
  const b = parseT3RedemptionBinding(binding), configured = parseT3RedemptionBinding(TONSWAP_T3_REDEMPTION);
  if (!b || !configured || JSON.stringify(b) !== JSON.stringify(configured) || p.network !== b.network || p.releaseId !== b.releaseId
    || p.manifestHash !== b.manifestHash || p.hub !== b.hub || p.single && !b.reserves.some(r=>r.slot===p.outputToken))
    throw t3Failure('error.noBinding','This release has no matching verified T3 redemption binding.');
}
export function nextT3RedemptionQueryId(previous: bigint, now = Date.now()): bigint {
  if (previous < 0n || previous >= 1n<<64n || !Number.isSafeInteger(now) || now <= 0) throw unavailable();
  const query = BigInt(now)>previous?BigInt(now):previous+1n;
  if (query>=1n<<64n) throw t3Failure('error.queryIdsExhausted','This wallet has exhausted its redemption query IDs.');
  return query;
}
function fresh(head: ChainHead, now: number) {
  if (!Number.isSafeInteger(now) || !Number.isSafeInteger(head.seqno) || head.seqno<=0 || !Number.isSafeInteger(head.utime)
    || head.utime!*1000>now+5000 || now-head.utime!*1000>T3_REDEMPTION_REVIEW_MAX_AGE_MS) throw unavailable();
}
async function readers(p:T3RedemptionIntent,b:T3RedemptionBinding,reads:T3RedemptionReadCapabilities) {
  assertBinding(p,b);
  const read = reads.read ?? readChain, hub=createT3Hub(read,canonical(b.hub),{codeHash:b.hubCodeHash,walletCodeHash:b.walletCodeHash,
    proofCodeHash:b.recoveryProofCodeHash,governance:canonical(b.governance),reserves:b.reserves.map(r=>({...r,master:canonical(r.master)}))});
  const snapshot=await hub.getSnapshot(); fresh(snapshot.head,(reads.now??Date.now)());
  const wallet=createT3Wallet(read,canonical(p.owner),hub,snapshot.state.config.walletCode);
  return {hub,wallet};
}
function transaction(plan:T3TransactionPlan,now:number):T3RedemptionPlan {
  fresh(plan.head,now); return{address:plan.address.toRawString(),valueRaw:plan.value.toString(),bodyBoc:plan.body.toBoc().toString('base64'),bodyHash:plan.body.hash().toString('hex'),head:plan.head};
}
/** Recheck at both review preparation and the final handoff. A wallet review may
 * remain open longer than the chain quote, and installing another release must
 * invalidate that review before anything is signed. */
export function assertCurrentT3RedemptionReview(review:T3RedemptionReview,intent:T3RedemptionIntent,binding:T3RedemptionBinding,action:T3RedemptionAction,now=Date.now()) {
  assertBinding(intent,binding);
  if(JSON.stringify(review.intent)!==JSON.stringify(intent)||review.action!==action||!review.plan||review.preflightIssue||action==='burn'&&!review.canBurn)
    throw t3Failure('error.stepNotReady','Current evidence does not permit this action.');
  if(now<review.observedAt||now-review.observedAt>T3_REDEMPTION_REVIEW_MAX_AGE_MS)
    throw t3Failure('error.reviewExpired','This redemption review expired.');
  fresh(review.plan.head,now);
}
/** A current quote authorizes a new burn only; it says nothing about past requests or delivery. */
export async function readT3RedemptionReview(intent:T3RedemptionIntent,binding:T3RedemptionBinding,reads:T3RedemptionReadCapabilities={}):Promise<T3RedemptionReview>{
  const {hub,wallet}=await readers(intent,binding,reads), snapshot=await wallet.getSnapshot(), observedAt=(reads.now??Date.now)(); fresh(snapshot.head,observedAt);
  const base={intent:{...intent},observedAt,action:'burn' as const,wallet:wallet.address.toRawString(),balanceRaw:snapshot.state.balance.toString(),minimumRaw:'0',estimatedNetQuoteRaw:null,plan:null,canBurn:false};
  if(snapshot.state.balance<BigInt(intent.amountRaw))return{...base,preflightIssue:t3Failure('redeem.issue.insufficientT3','Your current T3 balance is below the requested redemption.')};
  const plan=await prepareT3Redemption(hub,wallet,{recipient:canonical(intent.recipient),input:0,amount:BigInt(intent.amountRaw),queryId:BigInt(intent.queryId),
    single:intent.single,output:intent.outputToken,slippageBps:intent.slippageBps});
  // This estimate is an independent fresh quote, not proof that any payout arrived.
  const body=plan.body.beginParse();body.loadUint(32);body.loadUintBig(64);body.loadCoins();body.loadMaybeAddress();const terms=body.loadMaybeRef()!;body.endParse();
  const quote=await hub.getQuote(terms,0,BigInt(intent.amountRaw),0n,true), now=(reads.now??Date.now)();
  fresh(quote.head,now);if(quote.status!==0)throw unavailable();
  return{...base,observedAt:now,minimumRaw:plan.minimum.toString(),estimatedNetQuoteRaw:quote.payout.map(String) as [string,string,string],
    plan:transaction(plan,now),canBurn:true,preflightIssue:null};
}
export function readOriginalRedemption(original:T3RedemptionOriginal) {
  validateT3RedemptionIntent(original.intent); const p=original.intent;
  const body=Cell.fromBase64(original.burnBodyBoc);if(body.isExotic||body.hash().toString('hex')!==original.burnBodyHash)throw unavailable();
  const s=body.beginParse();if(s.loadUint(32)!==0x595f07bc||s.loadUintBig(64)!==BigInt(p.queryId)||s.loadCoins()!==BigInt(p.amountRaw)
    ||s.loadMaybeAddress()?.toRawString()!==p.owner)throw unavailable();
  const payload=s.loadMaybeRef();s.endParse();if(!payload)throw unavailable();const t=readT3Intent(payload);
  if(t.kind!=='redeem'||t.recipient.toRawString()!==p.recipient||t.single!==p.single||t.output!==p.outputToken||t.strict||t.minimum.toString()!==original.minimumRaw)throw unavailable();
  return {body,payload,terms:t};
}
function bindAttempt(original:T3RedemptionOriginal,a:T3WalletAttempt){
  const {payload}=readOriginalRedemption(original),p=original.intent;
  if(!original.burnTransaction||a.originLt.toString()!==original.burnTransaction.lt||!a.burn||a.owner.toRawString()!==p.owner||a.recipient.toRawString()!==p.owner
    ||a.amount!==BigInt(p.amountRaw)||a.details.queryId!==BigInt(p.queryId)||a.details.response?.toRawString()!==p.owner
    ||a.details.forwardValue!==0n||!a.details.customPayload?.equals(payload)||a.details.forwardPayload.bits.length!==1
    ||a.details.forwardPayload.refs.length!==0||a.details.forwardPayload.beginParse().loadBit())throw unavailable();
}
/** Persist the exact action encoded by the reviewed body. A corrupted local
 * action label must never turn another successful first hop into a cancellation. */
export function validateT3RedemptionRecoveryBody(original:T3RedemptionOriginal,evidence:T3RedemptionRecovery,body:Cell){
  if(body.isExotic)throw unavailable();
  const record=Cell.fromBase64(evidence.recordBoc),proof=Cell.fromBase64(evidence.proofBoc),s=body.beginParse();
  if(record.isExotic||proof.isExotic)throw unavailable();
  if(evidence.action==='payout-retry'){
    if(![0,1,2].includes(evidence.outputToken!)||evidence.evidenceIndex!==undefined||evidence.evidenceProofBoc!==undefined)throw unavailable();
    const receipt=readT3HubBurnRecord(record);bindAttempt(original,receipt.attempt);
    if(s.loadUint(32)!==T3_OP.T3_HUB_PAYOUT_RETRY||s.loadUint(2)!==3||s.loadUint(2)!==evidence.outputToken||s.loadMaybeAddress()!==null)throw unavailable();
    const w=s.loadRef().beginParse();if(!w.loadRef().equals(record)||!w.loadRef().equals(proof))throw unavailable();w.endParse();
  }else{
    if(evidence.outputToken!==undefined)throw unavailable();const claim=readT3WalletRecord(record);bindAttempt(original,claim.attempt);
    if(claim.cancelled)throw unavailable();
    const op=evidence.action==='burn-retry'?T3_OP.T3_WALLET_RETRY:evidence.action==='cancel-burn'?T3_OP.T3_WALLET_CANCEL:evidence.action==='mark-burn-failed'?T3_OP.T3_WALLET_MARK:null;
    if(op===null||s.loadUint(32)!==op||!s.loadRef().equals(record)||!s.loadRef().equals(proof))throw unavailable();
    if(evidence.action==='mark-burn-failed'){
      if(claim.failed||!atomic(evidence.evidenceIndex,64)||!evidence.evidenceProofBoc||s.loadUintBig(64)!==BigInt(evidence.evidenceIndex)||!s.loadRef().equals(Cell.fromBase64(evidence.evidenceProofBoc)))throw unavailable();
    }else{
      if(!claim.failed||evidence.evidenceIndex!==undefined||evidence.evidenceProofBoc!==undefined)throw unavailable();
      if(evidence.action==='burn-retry'&&!s.loadAddress().equals(claim.attempt.recipient))throw unavailable();
    }
  }
  s.endParse();
}
/** Witnesses are admitted against current on-chain roots by the SDK. The saved
 * first-hop transaction separately binds their physical origin to this request. */
export async function readT3RedemptionRecovery(original:T3RedemptionOriginal,evidence:T3RedemptionRecovery,reads:T3RedemptionReadCapabilities={}):Promise<T3RedemptionReview>{
  const {hub,wallet}=await readers(original.intent,original.binding,reads);if(wallet.address.toRawString()!==original.wallet)throw unavailable();
  const record=Cell.fromBase64(evidence.recordBoc),proof=Cell.fromBase64(evidence.proofBoc);let plan:T3TransactionPlan;
  if(evidence.action==='payout-retry'){
    bindAttempt(original,readT3HubBurnRecord(record).attempt);
    plan=await prepareT3Claim(hub,{kind:'payoutRetry',caller:canonical(original.intent.owner),witness:{slot:3,record,proof},output:evidence.outputToken});
  }else{
    bindAttempt(original,readT3WalletRecord(record).attempt);
    const kind=evidence.action==='burn-retry'?'retry':evidence.action==='cancel-burn'?'cancelBurn':evidence.action==='mark-burn-failed'?'mark':null;if(!kind)throw unavailable();
    plan=await prepareT3WalletRecovery(wallet,{kind,record,proof,caller:canonical(original.intent.owner),
      evidenceIndex:evidence.evidenceIndex===undefined?undefined:BigInt(evidence.evidenceIndex),evidenceProof:evidence.evidenceProofBoc?Cell.fromBase64(evidence.evidenceProofBoc):undefined});
  }
  validateT3RedemptionRecoveryBody(original,evidence,plan.body);
  const observedAt=(reads.now??Date.now)();return{intent:{...original.intent},observedAt,action:evidence.action,wallet:original.wallet,balanceRaw:'0',minimumRaw:original.minimumRaw,
    estimatedNetQuoteRaw:null,plan:transaction(plan,observedAt),canBurn:false,preflightIssue:null};
}
export async function sendT3RedemptionAction(options:{intent:T3RedemptionIntent;binding:T3RedemptionBinding;action:T3RedemptionAction;current:()=>boolean;
  original?:T3RedemptionOriginal;recovery?:T3RedemptionRecovery;send:(request:SendTransactionRequest,review:T3RedemptionReview)=>Promise<SendTransactionResponse|null>;
  read?:typeof readT3RedemptionReview;readRecovery?:typeof readT3RedemptionRecovery;beforeSend?:(review:T3RedemptionReview,request:SendTransactionRequest)=>void}){
  assertBinding(options.intent,options.binding);const intent=structuredClone(options.intent),binding=parseT3RedemptionBinding(options.binding)!,action=options.action;
  const saved=JSON.stringify({intent,binding,action,original:options.original,recovery:options.recovery});
  const guard=()=>{assertBinding(intent,binding);if(!options.current()||JSON.stringify({intent:options.intent,binding:parseT3RedemptionBinding(options.binding),action:options.action,original:options.original,recovery:options.recovery})!==saved)
    throw t3Failure('error.changed','The wallet, release, or redemption changed before dispatch.');};guard();
  let review:T3RedemptionReview;
  try{review=action==='burn'?await(options.read??readT3RedemptionReview)(intent,binding):
    options.original&&options.recovery&&options.recovery.action===action?await(options.readRecovery??readT3RedemptionRecovery)(options.original,options.recovery):(()=>{throw unavailable();})();}
  catch(error){throw isChainReadError(error)?chainReadNotSent(error):error;}guard();
  assertCurrentT3RedemptionReview(review,intent,binding,action);
  const request:SendTransactionRequest={validUntil:walletRequestDeadline(),messages:[{address:review.plan!.address,amount:review.plan!.valueRaw,payload:review.plan!.bodyBoc}]};
  options.beforeSend?.(review,request);guard();const result=await options.send(request,review);
  return{status:result?'submitted' as const:'cancelled' as const,review};
}
