import { Address } from '@ton/core';
import { TONSWAP_RELEASE, type ReleaseManifestV1 } from '../releaseManifest';
import { platformRequest } from './platformApi';
import { displayDecimalString, multiplyDisplay } from './displayDecimal';

type Network = 'mainnet' | 'testnet';
export const ASSET_VALUATION_MAX_AGE_MS = 120_000;
export const ASSET_VALUATION_FUTURE_SKEW_MS = 5_000;
export const T3_USD_DISPLAY_ASSUMPTION = Object.freeze({ kind: 'fixed-t3-usd', t3Usd: '1', scope: 'current-display-only' } as const);
export interface ValuationQuote {
  assetId: string;
  /** Current display value under displayAssumption; never historical USD evidence. */
  priceUsd: string | null;
  priceT3?: string | null;
  quoteAssetId?: string | null;
  network?: Network;
  releaseManifestHash?: string | null;
  displayAssumption?: typeof T3_USD_DISPLAY_ASSUMPTION;
  observedAt: string | null;
  source: string;
  stale: boolean;
  status: 'available' | 'unavailable';
  evidence: Record<string, unknown>;
  issues: string[];
}
export interface AssetValuationResponse { network: Network; currency: 'USD'; requestedAt: string; quotes: ValuationQuote[] }
const object = (value: unknown): Record<string, unknown> => value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
const hash = (value: unknown): value is string => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const positiveInteger = (value: unknown): value is string => typeof value === 'string' && /^[1-9][0-9]{0,155}$/.test(value);
const currentRelease = (network: Network): ReleaseManifestV1 | null => TONSWAP_RELEASE?.network === `ton:${network}` ? TONSWAP_RELEASE : null;
const quoteToken = (release: ReleaseManifestV1) => release.tokens.find(token => token.symbol === 'T3' && token.root === release.contracts.T3Hub?.address);
const boundRelease = (evidence: Record<string, unknown>, release: ReleaseManifestV1): boolean => {
  const identity = object(evidence.release);
  return identity.releaseId === release.releaseId && identity.manifestHash === release.manifestHash;
};
const freshTime = (value: unknown, now: number): number | null => {
  if (typeof value !== 'string') return null;
  const time = Date.parse(value);
  return Number.isFinite(time) && time > 0 && time <= now + ASSET_VALUATION_FUTURE_SKEW_MS && now - time <= ASSET_VALUATION_MAX_AGE_MS ? time : null;
};
const isAssumption = (value: unknown): boolean => {
  const assumption = object(value);
  return assumption.kind === T3_USD_DISPLAY_ASSUMPTION.kind && assumption.t3Usd === '1' && assumption.scope === 'current-display-only';
};
/** Reproduce the platform's 80-significant-digit, half-up Decimal result with integers. */
function ratioDisplay(numerator: bigint, denominator: bigint): string {
  let exponent = numerator.toString().length - denominator.toString().length;
  if (exponent >= 0 ? numerator < denominator * 10n ** BigInt(exponent) : numerator * 10n ** BigInt(-exponent) < denominator) exponent--;
  const scale = 79 - exponent;
  const scaled = numerator * 10n ** BigInt(scale);
  const rounded = scaled / denominator + (scaled % denominator * 2n >= denominator ? 1n : 0n);
  return displayDecimalString({ coefficient: rounded, scale });
}
function validDexQuote(value: unknown, assetId: string, network: Network, release: ReleaseManifestV1, now: number): boolean {
  const quote = object(value), evidence = object(quote.evidence), roots = object(evidence.rootBindings), ratio = object(evidence.exactRatio), head = object(evidence.head);
  const token = release.tokens.find(token => token.root === assetId), t3 = quoteToken(release);
  const market = token && release.spotMarkets.find(market => market.symbol === token.symbol);
  const rootContract = Object.values(release.contracts).find(contract => contract?.address === assetId);
  if (!token || !t3 || !market || !rootContract || quote.assetId !== assetId || quote.source !== 'tonswap-dex' || quote.status !== 'available' ||
      quote.stale !== false || quote.change24h !== null || !Array.isArray(quote.issues) || quote.issues.length !== 0 ||
      evidence.method !== 'active_pool_q64' || evidence.precision !== 'indicative_display' || evidence.network !== network || evidence.assetId !== assetId ||
      evidence.currency !== 'T3' || evidence.quoteAssetId !== t3.root || !boundRelease(evidence, release) ||
      evidence.marketKey !== `spot:${token.symbol}-T3` || evidence.marketAddress !== market.pool || evidence.codeHash !== release.templates.DlmmPool ||
      roots.assetRoot !== token.root || roots.quoteRoot !== t3.root || roots.assetCodeHash !== rootContract.codeHash || roots.quoteCodeHash !== release.contracts.T3Hub?.codeHash ||
      !['ton-indexer/http4', 'ton-indexer/lite'].includes(String(evidence.source)) ||
      head.workchain !== -1 || head.shard !== '-9223372036854775808' || !Number.isSafeInteger(head.seqno) || Number(head.seqno) <= 0 ||
      !hash(head.rootHashHex) || !hash(head.fileHashHex) || !Number.isInteger(evidence.activeBin) || Number(evidence.activeBin) < -2147483648 || Number(evidence.activeBin) > 2147483647 ||
      !positiveInteger(evidence.executableDepthT3Raw) || !positiveInteger(evidence.executableDepthAssetRaw) || !positiveInteger(evidence.q64) ||
      !positiveInteger(ratio.numerator) || !positiveInteger(ratio.denominator)) return false;
  const observed = freshTime(quote.observedAt, now), queried = freshTime(evidence.queriedAt, now);
  const activity = typeof evidence.lastMarketObservationAt === 'string' ? Date.parse(evidence.lastMarketObservationAt) : NaN;
  if (observed === null || queried === null || evidence.observedAt !== quote.observedAt || observed > queried + ASSET_VALUATION_FUTURE_SKEW_MS ||
      !Number.isFinite(activity) || activity <= 0 || activity > observed) return false;
  try {
    const q64 = BigInt(evidence.q64), numerator = BigInt(ratio.numerator), denominator = BigInt(ratio.denominator);
    if (q64 >= 1n << 128n || BigInt(evidence.executableDepthT3Raw) >= 1n << 128n || BigInt(evidence.executableDepthAssetRaw) >= 1n << 128n) return false;
    const expectedNumerator = (1n << 64n) * 10n ** BigInt(token.decimals), expectedDenominator = q64 * 10n ** BigInt(t3.decimals);
    return numerator * expectedDenominator === denominator * expectedNumerator && quote.price === ratioDisplay(expectedNumerator, expectedDenominator);
  } catch { return false; }
}

/** Current display admission, including a separately labelled T3 denomination identity. */
export function validAssetValuation(quote: ValuationQuote | null | undefined): quote is ValuationQuote {
  if (!quote || quote.status !== 'available' || quote.stale || !quote.network || !isAssumption(quote.displayAssumption) ||
      !isAssumption(object(quote.evidence).displayAssumption) || quote.priceT3 !== quote.priceUsd) return false;
  const release = currentRelease(quote.network), t3 = release && quoteToken(release);
  if (!release || !t3 || quote.releaseManifestHash !== release.manifestHash || quote.quoteAssetId !== t3.root) return false;
  if (quote.source === 't3-denomination') return quote.assetId === t3.root && quote.priceT3 === '1' && quote.observedAt === null &&
    quote.evidence.method === 'quote_asset_identity' && quote.evidence.network === quote.network && quote.evidence.assetId === t3.root &&
    quote.evidence.quoteAssetId === t3.root && boundRelease(quote.evidence, release);
  return validDexQuote({ ...quote, price: quote.priceT3, change24h: null }, quote.assetId, quote.network, release, Date.now());
}
export function assetUsdValue(amount: number | string | null | undefined, quote?: ValuationQuote): string | null {
  return validAssetValuation(quote) ? multiplyDisplay(amount, quote.priceUsd) : null;
}
export function tokenUsdValue(token: { balance?: number | null; balanceExact?: string | null; valuation?: ValuationQuote }): string | null {
  return assetUsdValue(token.balanceExact ?? token.balance, token.valuation);
}
const unavailable = (network: Network, assetId: string, issue = 'dex_quote_unavailable'): ValuationQuote => ({
  assetId, network, priceT3: null, priceUsd: null, observedAt: null, source: 'unavailable', stale: false,
  status: 'unavailable', evidence: {}, issues: [issue],
});
function t3Identity(network: Network, release: ReleaseManifestV1): ValuationQuote {
  const assetId = quoteToken(release)!.root;
  return { assetId, network, priceT3: '1', priceUsd: '1', quoteAssetId: assetId, releaseManifestHash: release.manifestHash,
    displayAssumption: T3_USD_DISPLAY_ASSUMPTION, observedAt: null, source: 't3-denomination', stale: false, status: 'available', issues: [],
    evidence: { method: 'quote_asset_identity', network, assetId, quoteAssetId: assetId,
      release: { releaseId: release.releaseId, manifestHash: release.manifestHash }, displayAssumption: T3_USD_DISPLAY_ASSUMPTION } };
}
// Watermarks fence out-of-order responses, without retaining prices as an outage fallback.
const watermarks = new Map<string, { observed: number; head: number }>();
export async function getAssetValuations(network: Network, assets: string[]): Promise<ValuationQuote[]> {
  const identities = [...new Set(assets)], release = currentRelease(network), t3 = release && quoteToken(release);
  if (!release || !t3) return identities.map(assetId => unavailable(network, assetId, 'dex_release_unavailable'));
  const resolved = new Map<string, ValuationQuote>();
  const requestAssets: string[] = [];
  for (const assetId of identities) {
    if (assetId === t3.root) { resolved.set(assetId, t3Identity(network, release)); continue; }
    let canonical = false;
    try { canonical = Address.parse(assetId).toRawString() === assetId; } catch { /* Native/symbol aliases have no market in this release. */ }
    const token = release.tokens.find(token => token.root === assetId);
    if (canonical && token && release.spotMarkets.some(market => market.symbol === token.symbol)) requestAssets.push(assetId);
    else resolved.set(assetId, unavailable(network, assetId, 'dex_market_not_in_release'));
  }
  for (let offset = 0; offset < requestAssets.length; offset += 50) {
    const batch = requestAssets.slice(offset, offset + 50);
    try {
      const response = object(await platformRequest<unknown>('/v1/dex-prices?network=' + network + '&assets=' + encodeURIComponent(batch.join(',')),
        { sessionScope: null, credentials: 'omit', cache: 'no-store', redirect: 'error' }));
      const now = Date.now();
      if (TONSWAP_RELEASE !== release || response.network !== network || response.currency !== 'T3' || response.quoteAssetId !== t3.root ||
          !boundRelease({ release: response.release }, release) || freshTime(response.requestedAt, now) === null || !Array.isArray(response.quotes) ||
          response.quotes.length !== batch.length || response.quotes.some(value => !batch.includes(String(object(value).assetId)))) throw new Error('DEX response binding mismatch');
      for (const assetId of batch) {
        const matches = response.quotes.filter(value => object(value).assetId === assetId);
        if (matches.length !== 1 || !validDexQuote(matches[0], assetId, network, release, now)) {
          resolved.set(assetId, unavailable(network, assetId, 'dex_quote_invalid')); continue;
        }
        const quote = object(matches[0]), evidence = object(quote.evidence);
        const watermark = { observed: Date.parse(String(quote.observedAt)), head: Number(object(evidence.head).seqno) };
        const key = `${network}:${release.manifestHash}:${assetId}`, previous = watermarks.get(key);
        if (previous && (previous.observed > watermark.observed || previous.head > watermark.head)) {
          resolved.set(assetId, unavailable(network, assetId, 'dex_observation_regressed')); continue;
        }
        watermarks.set(key, watermark);
        resolved.set(assetId, { assetId, network, priceT3: String(quote.price), priceUsd: String(quote.price), quoteAssetId: t3.root,
          releaseManifestHash: release.manifestHash, displayAssumption: T3_USD_DISPLAY_ASSUMPTION,
          observedAt: String(quote.observedAt), source: 'tonswap-dex', stale: false, status: 'available', issues: [],
          evidence: { ...evidence, displayAssumption: T3_USD_DISPLAY_ASSUMPTION } });
      }
    } catch { for (const assetId of batch) resolved.set(assetId, unavailable(network, assetId, 'dex_feed_unavailable')); }
  }
  return identities.map(assetId => resolved.get(assetId)!);
}
