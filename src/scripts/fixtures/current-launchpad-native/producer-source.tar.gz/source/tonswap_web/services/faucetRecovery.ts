import { Address, beginCell, Cell, contractAddress, loadShardAccount } from '@ton/core';
import { Buffer } from 'buffer';
import { createFaucet, faucetClaimBody, readFaucetRecovery, readFaucetState, type FaucetTransactionPlan } from './faucetContracts';
import { currentT3Cell, currentT3ActiveState, verifyCurrentT3Transaction, type CurrentT3Transaction } from './t3CurrentEvidence';
import { readT3ReceiptTree, readT3WalletStorage, t3WalletInitialData, verifyT3Witness } from './t3Contracts';
import { decodeSpotTokenTransfer, verifySpotMessageLink } from './spotSwapChainProof';
import type { FaucetEvidenceBinding, FaucetEvidenceRequest } from './faucetEvidence';
import type { FreshChainRead } from './spotContracts';
import { indexerRequest } from './indexer';
import { AppError } from './appError';

export type FaucetRecoveryPhase = 'certificate-required' | 'claim-receipt' | 'restore-cooldown' | 'retry-ready' | 'superseded';
export type FaucetRecoveryReady = {
  status: FaucetRecoveryPhase; request: FaucetEvidenceRequest; asset: 0; amountRaw: string; wire: string;
  head: { seqno: number; utime: number; rootHashHex: string }; sourceWallet: string;
  sourceFailure: { sourceLt: string; sourceHash: string; targetWallet: string; targetLt: string; targetHash: string; commandBoc: string; wire: string; amountRaw: string };
  root: string; key: string; recordBoc: string | null; proofBoc: string;
};
export type FaucetRecoveryState = FaucetRecoveryReady | { status: 'unavailable' };
export type FaucetRecoveryPlan = FaucetTransactionPlan & { kind: 'claim-receipt' | 'restore-cooldown'; originalBodyHash: string;
  asset: 0; amountRaw: string; wire: string; sourceLt: string; sourceHash: string; receiptBoc: string; proofBoc: string };
const exact = (v: unknown, keys: string[]): v is Record<string, any> => !!v && typeof v === 'object' && !Array.isArray(v)
  && Object.keys(v).length === keys.length && keys.every(k => Object.hasOwn(v, k));
function check(v: unknown): asserts v { if (!v) throw new AppError('wallet.faucet.error.verifyFaucet', {}, { devMessage: 'Current faucet recovery is unverified or stale' }); }
const uint = (v: unknown, bits = 64) => { check(typeof v === 'string' && /^(0|[1-9][0-9]{0,36})$/.test(v)); const n = BigInt(v); check(n < 1n << BigInt(bits)); return n; };
const hash = (v: unknown) => { check(typeof v === 'string' && /^[0-9a-f]{64}$/.test(v)); return v; };
const raw = (a: Address) => a.toRawString();
const only = <T>(v: T[]) => { check(v.length === 1); return v[0]; };
export function readFaucetRecoveryReceipt(record: Cell) {
  const s = record.beginParse(), key = s.loadUintBig(64), item = s.loadRef().beginParse(); s.endParse();
  const incoming = item.loadBit(), asset = item.loadUint(8), amount = item.loadCoins(), claimed = item.loadBit(), body = item.loadRef(); item.endParse();
  check(!incoming && asset === 0 && amount > 0n); return { key, asset: 0 as const, amount, claimed, body };
}
function absence(key: bigint, proof: Cell, root: bigint) {
  let h = beginCell().storeUint(0, 8).endCell().hash(), node = proof;
  for (let i = 0; i < 64; i++) {
    check(!node.isExotic); const s = node.beginParse(), sibling = s.loadBuffer(32), tail = s.loadMaybeRef(); s.endParse(); check((tail === null) === (i === 63));
    h = ((key >> BigInt(i)) & 1n) === 0n ? beginCell().storeUint(4, 8).storeBuffer(h).storeBuffer(sibling).endCell().hash()
      : beginCell().storeUint(4, 8).storeBuffer(sibling).storeBuffer(h).endCell().hash();
    if (tail) node = tail;
  } return BigInt('0x' + h.toString('hex')) === root;
}
/** Current native receipt membership and original failure boundaries authorize
 * recovery. They deliberately do not establish any recipient token credit. */
export function decodeFaucetRecovery(value: unknown, p: FaucetEvidenceRequest, binding: FaucetEvidenceBinding, now = Date.now()): FaucetRecoveryState {
  try {
    const { pins, release } = binding;
    check(p.asset === 0 && p.network === release.network.slice(4) && p.releaseId === release.releaseId && p.manifestHash === release.manifestHash
      && p.faucet === raw(pins.address) && release.contracts.TestnetFaucet?.codeHash === pins.codeHash && pins.tokens[0].master.equals(Address.parse(release.contracts.T3Hub!.address))
      && pins.tokens[0].walletCodeHash === release.templates.T3Wallet);
    check(faucetClaimBody(0, uint(p.queryId)).equals(currentT3Cell(p.bodyBoc)) && currentT3Cell(p.bodyBoc).hash().toString('hex') === p.bodyHash);
    check(Buffer.byteLength(JSON.stringify(value)) <= 8 * 1024 * 1024);
    check(exact(value, ['schema', 'releaseId', 'manifestHash', 'asOf', 'request', 'coverage', 'faucet', 'sourceWallet', 'receipts', 'sourceFailure', 'transactions'])
      && value.schema === 'tonswap-faucet-recovery-evidence-v1' && value.releaseId === p.releaseId && value.manifestHash === p.manifestHash);
    const h = value.asOf; check(exact(h, ['masterchainSeqno', 'unixTime', 'blockRootHash']) && Number.isSafeInteger(h.masterchainSeqno) && h.masterchainSeqno >= binding.minSeqno
      && h.masterchainSeqno > 0 && Number.isSafeInteger(h.unixTime) && h.unixTime > 0 && h.unixTime <= 0xffffffff && hash(h.blockRootHash)
      && (h.masterchainSeqno > binding.minSeqno || h.blockRootHash === binding.minBlockRootHash) && h.unixTime * 1000 <= now + 5000 && now - h.unixTime * 1000 <= 30000);
    check(exact(value.request, ['kind', 'owner', 'bodyHash']) && value.request.kind === 'claim' && value.request.owner === p.owner && value.request.bodyHash === p.bodyHash);
    check(exact(value.coverage, ['complete', 'gaps']) && value.coverage.complete === true && Array.isArray(value.coverage.gaps) && value.coverage.gaps.length === 0);
    check(exact(value.faucet, ['address', 'shardAccountBoc']) && value.faucet.address === p.faucet && exact(value.sourceWallet, ['address', 'shardAccountBoc']));
    const faucetShard = loadShardAccount(currentT3Cell(value.faucet.shardAccountBoc).beginParse()), active = currentT3ActiveState(faucetShard, pins.codeHash), state = readFaucetState(active.data);
    check(state.supplyBase === pins.supplyBase && state.slots.get(0)?.master.equals(pins.tokens[0].master));
    const wallet = value.sourceWallet.address; check(wallet === state.slots.get(0)?.wallet?.toRawString());
    const walletShard = loadShardAccount(currentT3Cell(value.sourceWallet.shardAccountBoc).beginParse()), wa = currentT3ActiveState(walletShard, pins.tokens[0].walletCodeHash), ws = readT3WalletStorage(wa.data);
    check(ws.owner.equals(pins.address) && ws.master.equals(pins.tokens[0].master) && ws.proofCodeHash === BigInt('0x' + release.templates.T3RecoveryProof)
      && contractAddress(0, { code: wa.code, data: t3WalletInitialData(pins.address, pins.tokens[0].master, ws.proofCodeHash) }).toRawString() === wallet);
    const treeCell = state.recoveries.get(0), recovery = treeCell ? readFaucetRecovery(treeCell) : null; check(recovery);
    const tree = recovery.tree ? readT3ReceiptTree(recovery.tree) : { root: BigInt('80355962451499150200844324337340404487209003436766272097586724178421748362113'), initialized: false, lastKey: 0n };
    const rs = value.receipts; check(exact(rs, ['root', 'initialized', 'lastKey', 'count', 'records']) && rs.root === tree.root.toString(16).padStart(64, '0')
      && rs.initialized === tree.initialized && uint(rs.lastKey) === tree.lastKey && uint(rs.count) <= 10000n && Array.isArray(rs.records) && rs.records.length === 1);
    const failure = value.sourceFailure; check(exact(failure, ['sourceLt', 'sourceHash', 'targetWallet', 'targetLt', 'targetHash', 'commandBoc', 'wire', 'amountRaw']));
    const sourceLt = uint(failure.sourceLt), targetLt = uint(failure.targetLt); check(sourceLt > 0n && targetLt >= sourceLt); hash(failure.sourceHash); hash(failure.targetHash);
    const command = currentT3Cell(failure.commandBoc), transfer = decodeSpotTokenTransfer(command), amount = uint(failure.amountRaw, 120), wire = uint(failure.wire);
    check(transfer.query === wire && transfer.amount === amount && transfer.owner === p.owner && transfer.response === p.owner && !transfer.custom
      && transfer.forwardValue === 0n && transfer.payload.bits.length === 0 && transfer.payload.refs.length === 0 && amount === state.grants[0]);
    check(Array.isArray(value.transactions) && value.transactions.length <= 10000);
    const txs: CurrentT3Transaction[] = value.transactions.map((e: unknown) => { check(exact(e, ['account', 'transactionBoc', 'beforeShardAccountBoc', 'afterShardAccountBoc']));
      const t = verifyCurrentT3Transaction(e as any); check(t.tx.now <= h.unixTime); return t; }); check(new Set(txs.map(t => t.hash)).size === txs.length);
    const owner = only(txs.filter(t => t.account === p.owner && t.tx.lt.toString() === p.dispatch.lt && t.hash === p.dispatch.hash)); check(owner.succeeded);
    const claim = only(txs.filter(t => t.account === p.faucet && verifySpotMessageLink(owner, t) && t.tx.inMessage?.body.equals(currentT3Cell(p.bodyBoc))));
    check(claim.succeeded && claim.tx.inMessage?.body.hash().toString('hex') === p.bodyHash && claim.tx.inMessage.info.type === 'internal'
      && !claim.tx.inMessage.info.bounced && raw(claim.tx.inMessage.info.src) === p.owner && claim.tx.inMessage.info.value.coins.toString() === p.dispatch.valueNano);
    const prior = readFaucetState(currentT3ActiveState(claim.before, pins.codeHash).data), after = readFaucetState(currentT3ActiveState(claim.after, pins.codeHash).data);
    check(prior.nextWire === wire && after.nextWire === wire + 1n && prior.grants[0] === amount && prior.available[0] - after.available[0] === amount
      && after.claimers.get(Address.parse(p.owner))?.wire[0] === wire && after.claimers.get(Address.parse(p.owner))?.last[0] === claim.tx.now
      && prior.slots.get(0)?.wallet?.toRawString() === wallet && after.slots.get(0)?.wallet?.toRawString() === wallet);
    const source = only(txs.filter(t => t.account === wallet && t.tx.lt === sourceLt && t.hash === failure.sourceHash));
    check(!source.succeeded && verifySpotMessageLink(claim, source) && source.tx.inMessage?.body.equals(command));
    if (failure.targetWallet === wallet) {
      check(targetLt === sourceLt && failure.targetHash === failure.sourceHash && source.tx.outMessages.values().every(m => m.info.type !== 'internal'));
    } else {
      check(failure.targetWallet === p.faucet && targetLt > sourceLt);
      const holder = only(txs.filter(t => t.account === p.faucet && t.tx.lt === targetLt && t.hash === failure.targetHash));
      check(!holder.succeeded && verifySpotMessageLink(source, holder) && holder.tx.inMessage?.info.type === 'internal' && holder.tx.inMessage.info.bounced);
    }
    const r = rs.records[0]; check(exact(r, ['key', 'recordBoc', 'proofBoc']) && uint(r.key) === sourceLt);
    const proof = currentT3Cell(r.proofBoc), current = state.claimers.get(Address.parse(p.owner));
    let phase: FaucetRecoveryPhase;
    if (r.recordBoc === null) { check(absence(sourceLt, proof, tree.root)); phase = 'certificate-required'; }
    else {
      const record = currentT3Cell(r.recordBoc), rec = readFaucetRecoveryReceipt(record);
      check(rec.key === sourceLt && rec.amount === amount && rec.body.equals(command) && verifyT3Witness(record, sourceLt, proof, tree.root));
      phase = !rec.claimed ? 'claim-receipt' : current?.wire[0] !== wire ? 'superseded' : current.last[0] === 0 ? 'retry-ready' : 'restore-cooldown';
    }
    if (phase === 'restore-cooldown') check(current?.wire[0] === wire);
    return { status: phase, request: structuredClone(p), asset: 0, amountRaw: amount.toString(), wire: wire.toString(), sourceWallet: wallet,
      head: { seqno: h.masterchainSeqno, utime: h.unixTime, rootHashHex: h.blockRootHash }, sourceFailure: { sourceLt: String(sourceLt), sourceHash: failure.sourceHash, targetWallet: failure.targetWallet, targetLt: String(targetLt), targetHash: failure.targetHash, commandBoc: failure.commandBoc, wire: String(wire), amountRaw: String(amount) }, root: rs.root,
      key: r.key, recordBoc: r.recordBoc, proofBoc: r.proofBoc };
  } catch { return { status: 'unavailable' }; }
}
export async function readFaucetRecoveryEvidence(request: FaucetEvidenceRequest, binding: FaucetEvidenceBinding, signal?: AbortSignal): Promise<FaucetRecoveryState> {
  try { const value = await indexerRequest('/v1/faucet/recovery-evidence', { method: 'POST', body: request, signal, timeoutMs: 20_000, maxAttempts: 1, health: 'chain', cache: 'no-store' });
    signal?.throwIfAborted(); return decodeFaucetRecovery(value, request, binding); } catch { return { status: 'unavailable' }; }
}
/** Caller persists this independently reviewable action before wallet review and
 * its ticket in beforeDispatch. A fresh response is required after every step. */
export async function prepareFaucetRecovery(state: FaucetRecoveryState, binding: FaucetEvidenceBinding, read: FreshChainRead): Promise<FaucetRecoveryPlan> {
  check(state.status === 'claim-receipt' || state.status === 'restore-cooldown'); check(state.recordBoc);
  const plan = await createFaucet(read, binding.pins).prepareRecovery(Address.parse(state.request.owner), currentT3Cell(state.recordBoc), currentT3Cell(state.proofBoc), state.status === 'restore-cooldown');
  check(plan.head.seqno >= state.head.seqno && (plan.head.seqno > state.head.seqno || plan.head.rootHashHex === state.head.rootHashHex));
  return { ...plan, kind: state.status, originalBodyHash: state.request.bodyHash, asset: 0, amountRaw: state.amountRaw, wire: state.wire,
    sourceLt: state.sourceFailure.sourceLt, sourceHash: state.sourceFailure.sourceHash, receiptBoc: state.recordBoc, proofBoc: state.proofBoc };
}
