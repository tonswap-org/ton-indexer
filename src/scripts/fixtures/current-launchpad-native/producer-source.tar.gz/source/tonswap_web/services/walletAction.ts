import { Address } from '@ton/core';
import type { SendTransactionRequest, SendTransactionResponse } from '@tonconnect/sdk';
import type { I18n } from '../i18n';
import type { MessageParams } from '../i18n/message.ts';
import type { WalletRequestTicket } from './walletRequest';
import { NATIVE_ASSET_SYMBOL } from '../constants';
import { appExecutionNetwork } from './appExecutionNetwork';
import { decodeRequestMessages, type DecodedMessage, type WalletRequestReview } from './walletRequestIntent';
import { formatWalletRequestTon } from './walletRequestNotSent';

/*
 * What a wallet request is FOR. Every request names its action, so the review dialog always says what
 * the person is about to sign and never falls back to a generic sentence.
 *
 * Two shapes exist:
 *  - `review`: the structured model. The caller picks catalog keys and typed values; the dialog formats
 *    them, so a screen never builds an English sentence for it. Use it for ordinary actions (a swap,
 *    a claim, a pool deposit) whose request the caller assembled itself. The dialog adds the two facts a
 *    caller must never state: the network and the GRAM that leaves the wallet, both read from the frozen
 *    request. So `rows` holds only the caller's own terms (no network row, no funding row).
 *  - typed `wallet-transfer` requests: the request is rebuilt and checked against the
 *    frozen transaction by the owning service before the dialog opens, so the figures on screen cannot
 *    differ from what will be signed.
 *
 * Whatever the kind, the dialog also shows a payload summary decoded from the frozen request itself
 * (`describePayload`): where each message goes, the exact GRAM it carries and, for a token transfer, the
 * raw token amount and the recipient. A caller's rows are context; the payload summary is the evidence.
 */

export type WalletRequestPhase = 'idle' | 'review' | 'awaiting-signature';

/** The network a request is for, as the person knows it. */
type ReviewNetwork = 'mainnet' | 'testnet' | 'localnet';

/**
 * A figure the dialog formats. `amount` is the exact canonical decimal (digits, one optional point), shown
 * as given with its symbol, never rounded. `address` is shown in full, wrapped, with a copy button.
 * `date` is Unix seconds, shown in UTC. `text` is plain text that is already final (a memo, a pair name).
 * There is no network value and no GRAM funding value: the dialog derives the network and the GRAM that
 * leaves the wallet from the frozen request itself, so a caller can neither omit nor misstate them.
 */
export type ReviewValue =
  | { type: 'amount'; amount: string; symbol: string }
  | { type: 'address'; address: string }
  | { type: 'text'; text: string }
  | { type: 'date'; seconds: number };

/**
 * Says which part of which signed message a row states, so the controller can check the row against the
 * decoded message instead of trusting the caller. `messageIndex` counts from 0.
 *  - `native-transfer`: the message is a plain GRAM transfer (no body or a text comment). `destination`
 *    is an address row, `value` an amount row in GRAM.
 *  - `jetton-transfer`: the body is a TEP-74 transfer. `recipient` and `responseDestination` are address
 *    rows (the recipient is the OWNER, not the token wallet), `amount` an amount row in the token's
 *    smallest units scaled by `decimals`, `forwardAmount` an amount row in GRAM.
 * A row that does not match, or a message that does not have that shape, rejects the request as
 * `review.notSent.rowMismatch`.
 */
export type RowBind =
  | { kind: 'native-transfer'; messageIndex: number; field: 'destination' | 'value' }
  | { kind: 'jetton-transfer'; messageIndex: number; field: 'recipient' | 'responseDestination' | 'forwardAmount' }
  | { kind: 'jetton-transfer'; messageIndex: number; field: 'amount'; decimals: number };

export type ReviewRow = {
  /** Catalog key of the row label. It is also the stable test seam: `data-row="<labelKey>"`. */
  labelKey: string;
  labelParams?: MessageParams;
  value: ReviewValue;
  /** The figures that matter most (what you pay, what you get at least) are set in heavier type. */
  emphasis?: boolean;
  /** Ties this row to the signed message it describes; the controller verifies it. */
  bind?: RowBind;
};

/** The structured review model. Title, summary and note are catalog keys that share `params`. */
export type ReviewWalletAction = {
  kind: 'review';
  titleKey: string;
  /** One or two plain sentences about what happens, shown before the exact rows. */
  summaryKey?: string;
  params?: MessageParams;
  rows: ReviewRow[];
  /** A risk or consequence note, shown under the rows. */
  noteKey?: string;
  /** Set when this is one of several approvals in a sequence (for example 2 of 4). */
  step?: { current: number; total: number };
  /**
   * Catalog key that names the first row, the GRAM total that leaves the wallet. The default,
   * `review.row.networkFunding`, says "Total GRAM sent". Name it differently when part of that total is
   * spent rather than held (a proposal's execution value). The amount is still read from the frozen request.
   */
  fundingLabelKey?: string;
};

/**
 * A native or token payment from the wallet. `fee.mode` says how the GRAM beside the payment is used:
 *  - `reserve`: a balance the person must keep for network fees; the app checks the balance covers the
 *    payment plus this amount, and nothing is attached to the request (native payments);
 *  - `attached`: sent with the request to run the transfer; any unused part may be returned (token payments);
 * `validateWalletTransferWalletAction` in services/walletTransfer.ts rebuilds the request from the saved
 * transfer record and is passed to the dispatcher as `options.verify`.
 */
export type WalletTransferWalletAction = {
  kind: 'wallet-transfer';
  step: 'transfer';
  /** The asset being sent. */
  symbol: string;
  /** Canonical decimal amount of `symbol`. */
  amount: string;
  /** The recipient exactly as it will be signed, in full. */
  recipient: string;
  memo: string | null;
  fee: { amount: string; mode: 'reserve' | 'attached' };
};

export type TypedWalletAction = WalletTransferWalletAction;

export type WalletActionDetails = ReviewWalletAction | TypedWalletAction;

export type WalletDispatchOptions = {
  /** Revalidate an action after review and immediately before wallet handoff. Throwing prevents dispatch. */
  beforeDispatch?: (ticket: WalletRequestTicket) => void | Promise<void>;
  keepNano?: bigint;
  feeReserveNano?: bigint;
  /**
   * Check the frozen, network-bound request against the facts the caller holds (a saved record, a quote).
   * The request is deeply frozen first, so a verifier can read and refuse but never change what is
   * signed. It runs before the review opens: throwing, rejecting, returning or resolving `false`, or not
   * answering within WALLET_VERIFY_TIMEOUT_MS means nothing is shown and nothing is sent. Required for
   * `wallet-transfer`, whose request cannot be rebuilt from the action alone.
   */
  verify?: (transaction: Readonly<SendTransactionRequest>) => void | boolean | Promise<void | boolean>;
};

/** `action` is required: there is no generic request, so there is no generic review. */
export type SendWalletTransaction = (
  transaction: SendTransactionRequest,
  action: WalletActionDetails,
  options?: WalletDispatchOptions
) => Promise<SendTransactionResponse | null>;

/* -------------------------------------------------------------------------------------------------
 * What the dialog shows
 * ----------------------------------------------------------------------------------------------- */

/**
 * `address` is shown in full, wrapped; `short-address` is the same address shortened to its first and
 * last 6 characters with `address` as the full friendly text behind it (for copying). Addresses are
 * encoded for the request's network.
 */
export type ReviewValueView =
  | { kind: 'text'; text: string }
  | { kind: 'address'; address: string }
  | { kind: 'short-address'; text: string; address: string };
/** `raw` is the exact integer behind an amount (nanograms or token units), exposed as `data-raw` for tests. */
export type ReviewRowView = { key: string; label: string; value: ReviewValueView; emphasis: boolean; raw?: string };
/**
 * A `payload` section holds what one signed message does, decoded from the frozen request; `heading` names
 * the message ("Message 1 of 2") when there are several. Payload sections are not in `ReviewView.sections`
 * (those are the caller's context); they are in `ReviewView.payload`.
 */
export type ReviewSectionView = { id: 'lead' | 'payload' | 'terms' | 'group'; label: string; heading?: string | null; rows: ReviewRowView[] };
/** The technical rest of one signed message, shown under "Transaction details": full addresses, ids. */
export type ReviewDetailView = { index: number; kind: 'transfer' | 'jetton-transfer' | 'call'; rows: ReviewRowView[] };
/** Everything the dialog renders, already in the person's language. The dialog has no per-kind branch. */
export type ReviewView = {
  title: string;
  /** "Wallet approval 2 of 4", when this is one of several approvals. */
  step: string | null;
  /** The network, shown at the top, unless a row already states it. */
  network: string | null;
  /** The plain sentence that comes before the exact rows. */
  summary: string | null;
  sections: ReviewSectionView[];
  /** A risk or consequence note, one tap away from the rows. */
  note: string | null;
  /** What happens to the GRAM that travels with the request. */
  footnote: string | null;
  /** True for every network except mainnet: addresses are encoded with the test-network flag. */
  testnet: boolean;
  /**
   * What the signed messages do, one section per message, decoded from the frozen request. The dialog shows
   * them in the main view right after the `lead` section; nothing a caller or a verifier supplies is in them.
   */
  payload: ReviewSectionView[];
  /** The technical rest of each signed message, for the details under the rows. */
  details: ReviewDetailView[];
};

type ViewInput = Pick<WalletRequestReview, 'action' | 'transaction' | 'totalNano'>;
type ViewI18n = Pick<I18n, 't' | 'd' | 'locale'>;
type Parts = {
  title: string; summary: string | null; lead: ReviewRowView[]; terms: ReviewRowView[]; groups: ReviewSectionView[];
  note: string | null; footnote: string | null; termsLabel: string;
  /** True when a row already says which network the request is for. */
  statesNetwork?: boolean;
};

const GRAM = NATIVE_ASSET_SYMBOL;
/** A raw account address (`0:` and 64 hex digits) in an owner service's text is shown as a full friendly address. */
const plainRow = (key: string, label: string, text: string, emphasis = false): ReviewRowView => ({ key, label, value: { kind: 'text', text }, emphasis });
const networkOf = (transaction: SendTransactionRequest): ReviewNetwork =>
  appExecutionNetwork === 'localnet' ? 'localnet' : String(transaction.network) === '-3' ? 'testnet' : 'mainnet';

/* ---- the payload summary ---- */

const encodeAddress = (raw: string, testOnly: boolean, bounceable: boolean) => Address.parseRaw(raw).toString({ urlSafe: true, bounceable, testOnly });
/** The first and last 6 characters of an address: enough to recognise it, with the full text one tap away. */
const shortAddress = (full: string) => (full.length <= 13 ? full : `${full.slice(0, 6)}…${full.slice(-6)}`);
const hexOp = (op: number) => `0x${op.toString(16).padStart(8, '0')}`;

/** What one signed message does, as a section of the main view and a list of technical details. */
function describeMessage(message: DecodedMessage, count: number, { t }: ViewI18n, testOnly: boolean): { section: ReviewSectionView; detail: ReviewDetailView } {
  const key = (name: string) => `payload.${message.index}.${name}`;
  const row = (name: string, label: string, value: ReviewValueView, raw?: string): ReviewRowView =>
    ({ key: key(name), label, value, emphasis: false, ...(raw === undefined ? {} : { raw }) });
  const text = (name: string, label: string, value: string, raw?: string) => row(name, label, { kind: 'text', text: value }, raw);
  const short = (name: string, label: string, raw: string, bounceable: boolean) => {
    const full = encodeAddress(raw, testOnly, bounceable);
    return row(name, label, { kind: 'short-address', text: shortAddress(full), address: full });
  };
  const full = (name: string, label: string, raw: string, bounceable: boolean) => row(name, label, { kind: 'address', address: encodeAddress(raw, testOnly, bounceable) });
  const gram = (value: bigint) => t('common.format.amountWithSymbol', { amount: formatWalletRequestTon(value.toString()), symbol: GRAM });
  const amount = text('amount', t('review.payload.row.amount'), gram(message.value), message.value.toString());
  const deploys = message.deploys ? [text('deploys', t('review.payload.row.deploys'), t('review.payload.value.deploys'))] : [];
  const action = (name: string) => text('action', t('review.payload.row.action'), t(`review.payload.action.${name}`));
  const detailRows = (rows: ReviewRowView[]) => rows.map(item => ({ ...item, key: `detail.${message.index}.${item.key.split('.').at(-1)}` }));
  const label = t('review.payload.title');
  const heading = count > 1 ? t('review.payload.message', { index: message.index + 1, count }) : null;
  const body = message.body;
  if (body.kind === 'jetton-transfer') {
    return {
      section: { id: 'payload', label, heading, rows: [
        action('jettonTransfer'),
        text('tokenAmount', t('review.payload.row.tokenAmount'), body.amount.toString(), body.amount.toString()),
        short('tokenRecipient', t('review.payload.row.tokenRecipient'), body.destination, false),
        short('contract', t('review.payload.row.contract'), message.destination, message.bounceable),
        amount, ...deploys] },
      detail: { index: message.index, kind: 'jetton-transfer', rows: detailRows([
        full('tokenRecipient', t('review.payload.detail.tokenRecipient'), body.destination, false),
        full('contract', t('review.payload.detail.contract'), message.destination, message.bounceable),
        body.responseDestination === null
          ? text('response', t('review.payload.detail.response'), t('review.payload.value.none'))
          : full('response', t('review.payload.detail.response'), body.responseDestination, false),
        text('queryId', t('review.payload.detail.queryId'), body.queryId.toString()),
        text('forwardAmount', t('review.payload.detail.forwardAmount'), gram(body.forwardAmount), body.forwardAmount.toString())]) }
    };
  }
  if (body.kind === 'none' || body.kind === 'comment') {
    return {
      section: { id: 'payload', label, heading, rows: [
        action('transfer'),
        short('to', t('review.payload.row.to'), message.destination, message.bounceable),
        amount,
        ...(body.kind === 'comment' ? [text('comment', t('review.payload.row.comment'), body.text)] : []),
        ...deploys] },
      detail: { index: message.index, kind: 'transfer', rows: detailRows([full('to', t('review.payload.detail.destination'), message.destination, message.bounceable)]) }
    };
  }
  return {
    section: { id: 'payload', label, heading, rows: [
      action('call'),
      text('opCode', t('review.payload.row.opCode'), body.op === null ? t('review.payload.value.opUnknown') : hexOp(body.op)),
      short('contract', t('review.payload.row.contract'), message.destination, message.bounceable),
      amount, ...deploys] },
    detail: { index: message.index, kind: 'call', rows: detailRows([full('contract', t('review.payload.detail.contract'), message.destination, message.bounceable)]) }
  };
}

function formatValue(value: ReviewValue, { t, d }: ViewI18n): ReviewValueView {
  switch (value.type) {
    case 'amount': return { kind: 'text', text: t('common.format.amountWithSymbol', { amount: value.amount, symbol: value.symbol }) };
    case 'address': return { kind: 'address', address: value.address };
    case 'text': return { kind: 'text', text: value.text };
    case 'date': return { kind: 'text', text: d(value.seconds * 1000, {
      year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', second: '2-digit', timeZone: 'UTC', timeZoneName: 'short' }) };
  }
}
const catalogRow = (row: ReviewRow, i18n: ViewI18n): ReviewRowView => ({
  key: row.labelKey, label: i18n.t(row.labelKey, row.labelParams), value: formatValue(row.value, i18n), emphasis: row.emphasis === true });
const amountRow = (key: string, i18n: ViewI18n, amount: string, symbol: string, emphasis = false): ReviewRowView =>
  catalogRow({ labelKey: key, value: { type: 'amount', amount, symbol }, emphasis }, i18n);

/** The GRAM that travels with the request, the row that must stay above the fold. */
const fundingRow = (input: ViewInput, i18n: ViewI18n, labelKey = 'review.row.networkFunding') =>
  amountRow(labelKey, i18n, formatWalletRequestTon(input.totalNano), GRAM);

function describeReview(action: ReviewWalletAction, input: ViewInput, i18n: ViewI18n): Parts {
  const { t } = i18n;
  return { title: t(action.titleKey, action.params), summary: action.summaryKey ? t(action.summaryKey, action.params) : null,
    lead: [fundingRow(input, i18n, action.fundingLabelKey)], terms: action.rows.map(row => catalogRow(row, i18n)), groups: [], note: action.noteKey ? t(action.noteKey, action.params) : null,
    footnote: null, termsLabel: t('review.terms.request') };
}

function describeTransfer(action: WalletTransferWalletAction, input: ViewInput, i18n: ViewI18n): Parts {
  const { t } = i18n;
  const terms: ReviewRowView[] = [];
  terms.push(amountRow('review.transfer.row.amount', i18n, action.amount, action.symbol, true));
  terms.push(catalogRow({ labelKey: 'review.transfer.row.to', value: { type: 'address', address: action.recipient }, emphasis: true }, i18n));
  terms.push(catalogRow({ labelKey: 'review.transfer.row.memo', value: { type: 'text', text: action.memo ?? t('common.state.none') } }, i18n));
  terms.push(plainRow('common.label.network', t('common.label.network'), t(`review.network.${networkOf(input.transaction)}`)));
  const fee = { reserve: 'review.transfer.row.feeReserve', attached: 'review.transfer.row.feeAttached' }[action.fee.mode];
  terms.push(action.fee.mode === 'reserve'
    ? plainRow(fee, t(fee), t('review.transfer.atLeast', { amount: action.fee.amount, symbol: GRAM }))
    : amountRow(fee, i18n, action.fee.amount, GRAM));
  return { title: t('review.transfer.title.send', { amount: action.amount, symbol: action.symbol }),
    summary: t('review.transfer.summary.send', { amount: action.amount, symbol: action.symbol }),
    lead: [], terms, groups: [], note: null, termsLabel: t('review.terms.transfer'), statesNetwork: true,
    footnote: t(`review.footnote.${action.fee.mode}`, { amount: action.fee.amount, symbol: GRAM }) };
}

function describeParts(input: ViewInput, i18n: ViewI18n): Parts {
  const action = input.action;
  if (action.kind === 'review') return describeReview(action, input, i18n);
  if (action.kind === 'wallet-transfer') return describeTransfer(action, input, i18n);
  throw new Error('Unknown wallet review action');
}

/**
 * Turns a validated request into what the dialog shows: plain summary first, then the GRAM total, what
 * the signed messages do (`payload`, decoded from the frozen request, never from the caller's rows), then
 * the caller's exact rows (`sections`). Throws when a message cannot be read: a request that cannot be shown is not signed.
 */
export function describeWalletRequest(input: ViewInput, i18n: ViewI18n): ReviewView {
  const { t } = i18n;
  const parts = describeParts(input, i18n);
  const step = input.action.kind === 'review' && input.action.step
    ? t('review.dialog.step', { current: input.action.step.current, total: input.action.step.total }) : null;
  const network = networkOf(input.transaction), testnet = network !== 'mainnet';
  const decoded = decodeRequestMessages(input.transaction).map((message, _index, all) => describeMessage(message, all.length, i18n, testnet));
  const sections: ReviewSectionView[] = [];
  if (parts.lead.length) sections.push({ id: 'lead', label: t('review.terms.summary'), rows: parts.lead });
  if (parts.terms.length) sections.push({ id: 'terms', label: parts.termsLabel, rows: parts.terms });
  sections.push(...parts.groups);
  return { title: parts.title, step, summary: parts.summary, sections, note: parts.note, footnote: parts.footnote,
    network: parts.statesNetwork === true ? null : t(`review.network.${network}`), testnet, payload: decoded.map(item => item.section), details: decoded.map(item => item.detail) };
}
