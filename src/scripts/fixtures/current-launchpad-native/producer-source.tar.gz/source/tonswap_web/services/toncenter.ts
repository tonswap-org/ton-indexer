import {
  Address,
  Cell,
  beginCell,
  loadTransaction,
  contractAddress,
  storeStateInit
} from '@ton/core';
import { Buffer } from 'buffer';
import { TESTNET_CONFIG } from '../constants';
import { isToncenterHostname } from '../urlSecurity';
import { getNodeEndpoint, isLocalNodeEndpoint, resolveConfiguredEndpoint } from './nodeEndpoint';
import { t3WalletInitialData } from './t3Contracts';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { ChainReadError, isChainReadError } from './chainReadError';
import { RELEASE_HEADER, assertReleaseResponse, currentReleaseHash, isIndexerRpcEndpoint, isReleaseMismatchError } from './releaseTransport';
import { transportBreaker, TRANSPORT_SLOW_THRESHOLD_MS } from './transportHealth';
import {
  getIndexerAccountState,
  readIndexerBalances,
  readIndexerFresh,
  type IndexerFreshCall,
  getIndexerRunGetMethod,
  getIndexerTransactionsForAddresses,
  isIndexerEnabled,
  isFreshIndexerConfigured,
  type IndexerTxEntry
} from './indexer';

const processEnv = typeof process !== 'undefined' && process.env ? process.env : undefined;
const importMetaEnv =
  ((import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env ?? {}) as
    | Record<string, string | undefined>
    | undefined;
const runtimeEnv = { ...(importMetaEnv ?? {}), ...(processEnv ?? {}) };
const DISABLE_RPC_FALLBACK =
  runtimeEnv.TONSWAP_DISABLE_RPC_FALLBACK === '1' ||
  runtimeEnv.VITE_TONSWAP_DISABLE_RPC_FALLBACK === '1';
type ToncenterRpcResponse<T> = {
  ok: boolean;
  result?: T;
  error?: string;
  code?: number;
  failure?: 'limited' | 'not-ready' | 'rejected' | 'unavailable';
  retryAfterMs?: number;
};

type ToncenterStackEntry = [string, unknown];

type ToncenterRunResult = {
  stack: ToncenterStackEntry[];
  exit_code: number;
  gas_used: number | null;
  block_id?: RpcBlock;
  sync_utime?: number;
};

type ToncenterTransactionId = {
  lt?: string | number;
  hash?: string;
};

type ToncenterTransaction = {
  transaction_id?: ToncenterTransactionId;
  utime?: number;
  in_msg?: unknown;
  out_msgs?: unknown;
  description?: unknown;
  data?: string;
};

export type ToncenterTxStatus = {
  status: 'success' | 'failed' | 'unknown';
  reason?: string;
};

type RpcBlock = { workchain?: number; seqno?: number; root_hash?: string; file_hash?: string };
type ToncenterAddressInfo = {
  balance?: string;
  last_transaction_id?: { lt: string; hash: string };
  block_id?: RpcBlock;
  sync_utime?: number;
  state?: string;
  code?: string | { bytes?: string } | null;
  data?: string | { bytes?: string } | null;
};

const TONCENTER_TIMEOUT_MS = 12_000;
const TONCENTER_MAX_ATTEMPTS = 4;
const TONCENTER_RETRY_BASE_MS = 450;
const TONCENTER_RETRY_RATE_LIMIT_BASE_MS = 3_000;
const TONCENTER_RATE_LIMIT_MIN_WINDOW_MS = 2_500;
const TONCENTER_CACHE_TTL_DEFAULT_MS = 2_000;
const TONCENTER_CACHE_STALE_WINDOW_MS = 15_000;
const TONCENTER_CACHE_MAX_ENTRIES = 800;
// Toncenter permits one request per second without a key. Keep a margin and
// serialize those requests; owned/authenticated endpoints can overlap reads.
const TONCENTER_MIN_REQUEST_GAP_BASE_MS = 300;
const TONCENTER_ANONYMOUS_REQUEST_GAP_MS = 1_100;
const TONCENTER_MIN_REQUEST_GAP_DECAY_STEP_MS = 20;
const TONCENTER_MIN_REQUEST_GAP_MAX_MS = 1_500;
const TONCENTER_MIN_REQUEST_GAP_RATE_LIMIT_MULTIPLIER = 1.6;
const TONCENTER_MAX_CONCURRENT_REQUESTS = 4;
const TONCENTER_CACHE_TTL_BY_METHOD: Record<string, number> = {
  getAddressBalance: 3_000,
  getAddressInformation: 3_000,
  getTransactions: 1_500,
  runGetMethod: 2_000
};

const globalScope = globalThis as typeof globalThis & { Buffer?: typeof Buffer };
if (!globalScope.Buffer) {
  globalScope.Buffer = Buffer;
}

export const isLocalRpcEndpoint = (value: string | undefined | null) => {
  const trimmed = value?.trim().toLowerCase();
  if (!trimmed) return false;
  if (
    trimmed.startsWith('localhost') ||
    trimmed.startsWith('127.0.0.1') ||
    trimmed.startsWith('0.0.0.0') ||
    trimmed.startsWith('[::1]')
  ) {
    return true;
  }
  try {
    const host = new URL(trimmed).hostname.trim().toLowerCase();
    return host === 'localhost' || host === '127.0.0.1' || host === '0.0.0.0' || host === '::1';
  } catch {
    return false;
  }
};

export const resolveJettonWriteResponseDestination = (address: string | null | undefined) => address ?? null;

const releaseToken = (root: string) => TONSWAP_RELEASE?.tokens.find(token => token.root === Address.parse(root).toRawString());
const matchesMaster = (account: ChainAccountResult, token: NonNullable<ReturnType<typeof releaseToken>>) =>
  account.state === 'active' && account.code?.hash().toString('hex') === token.masterCodeHash;

/** Wallet code is authenticated against its specific master and manifest pin at one head. */
export const getJettonWalletCodeFromRoot = async (root: string, options: { fresh?: boolean } = {}): Promise<Cell | null> => {
  const token = releaseToken(root);
  if (!token) return null;
  const observation = await readChain([{ kind: 'account', address: token.root },
    { kind: 'getter', address: token.root, method: 'get_jetton_data' }] as const, { anchored: true, lane: 'user' });
  const [account, result] = observation.results;
  if (!matchesMaster(account, token) || result.exitCode !== 0) return null;
  const data = await readCanonicalJettonData(result.stack);
  return data?.walletCode?.hash().toString('hex') === token.walletCodeHash ? data.walletCode : null;
};
const resolveJettonWalletCode = async (root: string, options: { fresh?: boolean } = {}): Promise<Cell> => {
  const code = await getJettonWalletCodeFromRoot(root, options);
  if (!code) throw new ChainReadError('unavailable', { devMessage: 'The token master did not authenticate its release wallet code.' });
  return code;
};

export const getResolvedJettonWalletCode = async (root: string): Promise<Cell | null> => {
  try {
    return await resolveJettonWalletCode(root);
  } catch (error) {
    if (isReleaseMismatchError(error)) throw error;
    return null;
  }
};

export type JettonData = {
  totalSupply: bigint | null;
  mintable: boolean | null;
  admin: string | null;
  content: Cell | null;
  walletCode: Cell | null;
} | null;

type JettonDataCacheEntry = {
  value?: JettonData;
  expiresAt: number;
  pending?: Promise<JettonData>;
};

export const readCanonicalJettonData = async (
  stack: ToncenterStackEntry[]
): Promise<Exclude<JettonData, null> | null> => {
  if (!Array.isArray(stack) || stack.length !== 5) return null;
  const totalSupply = readStackBigInt(stack[0]);
  const mintableRaw = readStackBigInt(stack[1]);
  const [adminCell, admin, content, walletCode] = await Promise.all([
    readStackCell(stack[2]),
    readStackAddress(stack[2]),
    readStackCell(stack[3]),
    readStackCell(stack[4])
  ]);
  if (
    totalSupply === null ||
    totalSupply < 0n ||
    (mintableRaw !== 0n && mintableRaw !== -1n) ||
    !adminCell ||
    !content ||
    !walletCode
  ) {
    return null;
  }
  return {
    totalSupply,
    mintable: mintableRaw === -1n,
    admin,
    content,
    walletCode
  };
};

const JETTON_DATA_CACHE_TTL_MS = 30_000;
const jettonDataCache = new Map<string, JettonDataCacheEntry>();

export const getJettonData = async (
  root: string,
  options: { fresh?: boolean; forceNetwork?: boolean } = {}
): Promise<JettonData> => {
  const now = Date.now();
  const cached = jettonDataCache.get(root);
  if (cached && options.fresh !== true && options.forceNetwork !== true) {
    if (cached.expiresAt > now && cached.value !== undefined) {
      return cached.value;
    }
    if (cached.pending) {
      return cached.pending;
    }
  }

  const getterOptions =
    options.fresh === true || options.forceNetwork === true
      ? {
          forceNetwork: true
        }
      : undefined;
  const pending = (async () => {
    const res = await runGetMethod(root, 'get_jetton_data', [], getterOptions);
    if (!res || res.exit_code !== 0) return null;
    return readCanonicalJettonData(res.stack);
  })();

  jettonDataCache.set(root, { expiresAt: now + JETTON_DATA_CACHE_TTL_MS, pending });
  const value = await pending;
  jettonDataCache.set(root, {
    value,
    expiresAt: Date.now() + JETTON_DATA_CACHE_TTL_MS
  });
  return value;
};

const stackEntryBytes = (value: unknown) => {
  if (typeof value === 'string') return value;
  if (value && typeof value === 'object' && 'bytes' in value && typeof value.bytes === 'string') {
    return value.bytes;
  }
  return null;
};

const parseBocCell = (value: string | null | undefined): Cell | null => {
  const bytes = value?.trim();
  if (!bytes) return null;
  try {
    const roots = Cell.fromBoc(Buffer.from(bytes, 'base64'));
    return roots.length === 1 ? roots[0] : null;
  } catch {
    return null;
  }
};

const asRecord = (value: unknown): Record<string, unknown> | null => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
};

const readBoolean = (value: unknown) => (typeof value === 'boolean' ? value : null);
const readNumber = (value: unknown) =>
  typeof value === 'number' && Number.isFinite(value) ? value : null;
const readString = (value: unknown) => (typeof value === 'string' ? value : null);

const stableStringify = (value: unknown): string => {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map((entry) => stableStringify(entry)).join(',')}]`;
  }
  const entries = Object.entries(value as Record<string, unknown>).sort(([left], [right]) =>
    left.localeCompare(right)
  );
  return `{${entries.map(([key, entry]) => `${JSON.stringify(key)}:${stableStringify(entry)}`).join(',')}}`;
};

const resolveRpcCacheTtlMs = (method: string) =>
  TONCENTER_CACHE_TTL_BY_METHOD[method] ?? TONCENTER_CACHE_TTL_DEFAULT_MS;

type ToncenterRpcCacheEntry = {
  response: ToncenterRpcResponse<unknown>;
  expiresAt: number;
  staleUntil: number;
};

type ToncenterEndpointState = {
  responseCache: Map<string, ToncenterRpcCacheEntry>;
  inFlight: Map<string, RpcFlight>;
  rateLimitedUntil: number;
  activeRequests: number;
  nextDispatchAt: number;
  dispatchTimer: ReturnType<typeof setTimeout> | null;
  dispatchQueue: Array<() => void>;
  backgroundQueue: Array<() => void>;
  minDispatchGapMs: number;
  maxConcurrentRequests: number;
  dispatchGapMs: number;
  warnedRateLimit: boolean;
};

const toncenterEndpointStates = new Map<string, ToncenterEndpointState>();
const normalizeAddressKey = (value: string | null | undefined) => {
  const trimmed = value?.trim();
  if (!trimmed) return null;
  try {
    return Address.parse(trimmed).toRawString();
  } catch {
    return trimmed.toLowerCase();
  }
};

const buildIndexerAddressCandidates = (address: string) => {
  const trimmed = address?.trim?.() ?? '';
  if (!trimmed) return [] as string[];
  try { return [Address.parse(trimmed).toRawString()]; }
  catch { return [trimmed]; }
};

const getIndexerAccountStateForAddress = async (
  address: string,
  options: { timeoutMs?: number; maxAttempts?: number } = {}
) => {
  const candidates = buildIndexerAddressCandidates(address);
  const lookupCandidates = candidates.length ? candidates : [address];
  let lastError: unknown = null;
  for (const candidate of lookupCandidates) {
    try {
      return await getIndexerAccountState(candidate, options);
    } catch (error) {
      if (isReleaseMismatchError(error)) throw error;
      lastError = error;
    }
  }
  throw (lastError as Error | null) ?? new Error('Indexer account state lookup failed.');
};

const stripTrailingSlashes = (value: string) => value.replace(/\/+$/, '');

const canUseJsonRpcInStrictMode = (endpoint = getNodeEndpoint()) => {
  if (!DISABLE_RPC_FALLBACK) return true;
  const selectedRpc = resolveConfiguredEndpoint(endpoint);
  const configuredIndexer = resolveConfiguredEndpoint(TESTNET_CONFIG.indexerEndpoint);
  const normalizedRpc = stripTrailingSlashes(selectedRpc || '').toLowerCase();
  const normalizedIndexer = stripTrailingSlashes(configuredIndexer || '').toLowerCase();
  if (!normalizedRpc) return false;
  if (normalizedIndexer && normalizedRpc === `${normalizedIndexer}/jsonrpc`) return true;
  return isLocalNodeEndpoint(selectedRpc);
};

const isToncenterHost = (endpoint: string) => {
  try {
    const base =
      typeof window !== 'undefined' && window.location?.href ? window.location.href : 'http://localhost';
    const { hostname } = new URL(endpoint, base);
    return isToncenterHostname(hostname);
  } catch {
    return false;
  }
};

const getToncenterEndpointState = (endpoint: string): ToncenterEndpointState => {
  let state = toncenterEndpointStates.get(endpoint);
  if (!state) {
    const anonymousToncenter = isToncenterHost(endpoint) && !TESTNET_CONFIG.toncenterApiKey;
    const minDispatchGapMs = anonymousToncenter
      ? TONCENTER_ANONYMOUS_REQUEST_GAP_MS
      : TONCENTER_MIN_REQUEST_GAP_BASE_MS;
    state = {
      responseCache: new Map(),
      inFlight: new Map(),
      rateLimitedUntil: 0,
      activeRequests: 0,
      nextDispatchAt: 0,
      dispatchTimer: null,
      dispatchQueue: [],
      backgroundQueue: [],
      minDispatchGapMs,
      maxConcurrentRequests: anonymousToncenter ? 1 : TONCENTER_MAX_CONCURRENT_REQUESTS,
      dispatchGapMs: minDispatchGapMs,
      warnedRateLimit: false
    };
    toncenterEndpointStates.set(endpoint, state);
  }
  return state;
};

const buildRpcCacheKey = (method: string, params: Record<string, unknown>) =>
  `${method}:${stableStringify({ ...params, ...(typeof params.address === 'string' ? { address: normalizeAddressKey(params.address) } : {}) })}`;

const pruneRpcCache = (state: ToncenterEndpointState) => {
  if (state.responseCache.size <= TONCENTER_CACHE_MAX_ENTRIES) return;
  const now = Date.now();
  for (const [key, entry] of state.responseCache.entries()) {
    if (entry.staleUntil <= now) {
      state.responseCache.delete(key);
    }
  }
  while (state.responseCache.size > TONCENTER_CACHE_MAX_ENTRIES) {
    const oldestKey = state.responseCache.keys().next().value as string | undefined;
    if (!oldestKey) break;
    state.responseCache.delete(oldestKey);
  }
};

const scheduleToncenterDispatch = (state: ToncenterEndpointState) => {
  if (state.activeRequests >= state.maxConcurrentRequests) return;
  if (state.dispatchQueue.length + state.backgroundQueue.length === 0) return;
  if (state.dispatchTimer) return;

  const delay = Math.max(0, Math.max(state.nextDispatchAt, state.rateLimitedUntil) - Date.now());
  state.dispatchTimer = setTimeout(() => {
    state.dispatchTimer = null;
    while (
      state.activeRequests < state.maxConcurrentRequests &&
      state.dispatchQueue.length + state.backgroundQueue.length > 0 &&
      Date.now() >= Math.max(state.nextDispatchAt, state.rateLimitedUntil)
    ) {
      const release = (state.dispatchQueue.shift() ?? state.backgroundQueue.shift());
      if (!release) break;
      state.activeRequests += 1;
      state.nextDispatchAt = Date.now() + state.dispatchGapMs;
      release();
    }
    if (state.dispatchQueue.length + state.backgroundQueue.length > 0) {
      scheduleToncenterDispatch(state);
    }
  }, delay);
};

const acquireToncenterDispatchSlot = async (state: ToncenterEndpointState, signal: AbortSignal, lane: ReadLane) => {
  const queue = lane === 'background' ? state.backgroundQueue : state.dispatchQueue;
  await new Promise<void>((resolve, reject) => {
    const admit = () => { signal.removeEventListener('abort', cancel); resolve(); };
    const cancel = () => {
      const index = queue.indexOf(admit);
      if (index !== -1) queue.splice(index, 1);
      signal.removeEventListener('abort', cancel);
      if (state.dispatchQueue.length + state.backgroundQueue.length === 0 && state.dispatchTimer !== null) {
        clearTimeout(state.dispatchTimer); state.dispatchTimer = null;
      }
      reject(signal.reason);
    };
    if (signal.aborted) { cancel(); return; }
    signal.addEventListener('abort', cancel, { once: true });
    queue.push(admit);
    scheduleToncenterDispatch(state);
  });
};

const releaseToncenterDispatchSlot = (state: ToncenterEndpointState) => {
  state.activeRequests = Math.max(0, state.activeRequests - 1);
  scheduleToncenterDispatch(state);
};

const waitForToncenterRateLimitWindow = async (state: ToncenterEndpointState, signal: AbortSignal) => {
  const remaining = state.rateLimitedUntil - Date.now();
  if (remaining <= 0) return;
  await new Promise<void>((resolve, reject) => {
    let timer: ReturnType<typeof setTimeout> | null = null;
    const cancel = () => {
      if (timer !== null) clearTimeout(timer);
      signal.removeEventListener('abort', cancel);
      reject(signal.reason);
    };
    if (signal.aborted) { cancel(); return; }
    signal.addEventListener('abort', cancel, { once: true });
    timer = setTimeout(() => { signal.removeEventListener('abort', cancel); resolve(); }, remaining);
  });
};

const registerToncenterRateLimitWindow = (
  state: ToncenterEndpointState,
  endpoint: string,
  retryAfterHeader: string | null,
  attempt: number
) => {
  const delay = parseRetryDelayMs(retryAfterHeader, attempt, 429);
  const rateLimitWindow = Math.max(delay, TONCENTER_RATE_LIMIT_MIN_WINDOW_MS);
  state.rateLimitedUntil = Math.max(state.rateLimitedUntil, Date.now() + rateLimitWindow);

  // Back off the global dispatch rate when the endpoint starts returning 429s.
  state.dispatchGapMs = Math.min(
    TONCENTER_MIN_REQUEST_GAP_MAX_MS,
    Math.max(
      state.minDispatchGapMs,
      Math.round(state.dispatchGapMs * TONCENTER_MIN_REQUEST_GAP_RATE_LIMIT_MULTIPLIER)
    )
  );

  if (!state.warnedRateLimit && typeof window !== 'undefined') {
    state.warnedRateLimit = true;
    console.warn(
      `[tonswap] RPC rate limited (HTTP 429). Endpoint=${endpoint}. ` +
        'Set VITE_TONCENTER_API_KEY for toncenter, or pick a different testnet node in Settings.'
    );
  }
  return delay;
};

const registerToncenterSuccess = (state: ToncenterEndpointState) => {
  if (state.dispatchGapMs <= state.minDispatchGapMs) return;
  state.dispatchGapMs = Math.max(
    state.minDispatchGapMs,
    Math.round(state.dispatchGapMs - TONCENTER_MIN_REQUEST_GAP_DECAY_STEP_MS)
  );
};

const withRetryJitter = (delayMs: number) => {
  const jitter = 0.85 + Math.random() * 0.3;
  return Math.max(delayMs, Math.round(delayMs * jitter));
};

const parseRetryDelayMs = (
  retryAfterHeader: string | null,
  attempt: number,
  status: number | null = null
) => {
  const fallback =
    status === 429
      ? TONCENTER_RETRY_RATE_LIMIT_BASE_MS * 2 ** attempt
      : TONCENTER_RETRY_BASE_MS * Math.max(1, attempt + 1);
  if (!retryAfterHeader) return fallback;
  const asSeconds = Number.parseFloat(retryAfterHeader);
  if (Number.isFinite(asSeconds) && asSeconds >= 0) {
    const parsedDelayMs = Math.round(asSeconds * 1000);
    if (status === 429) {
      return Math.max(TONCENTER_RATE_LIMIT_MIN_WINDOW_MS, parsedDelayMs);
    }
    return Math.max(fallback, parsedDelayMs);
  }
  return fallback;
};

export const cellToBase64 = async (cell: Cell) => {
  return Buffer.from(cell.toBoc()).toString('base64');
};

export const readStackCell = async (entry: ToncenterStackEntry | undefined): Promise<Cell | null> => {
  if (!entry) return null;
  const [type, value] = entry;
  if (typeof type !== 'string') return null;
  const normalized = type.toLowerCase();
  if (!['cell', 'slice', 'tvm.cell', 'tvm.slice'].includes(normalized)) return null;
  const bytes = stackEntryBytes(value);
  if (!bytes) return null;
  return parseBocCell(bytes);
};

export const readStackBigInt = (entry: ToncenterStackEntry | undefined) => {
  if (!entry) return null;
  const [type, value] = entry;
  if (type !== 'num') return null;
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return null;
    const signedHexMatch = trimmed.match(/^([+-]?)0x([0-9a-fA-F]+)$/);
    if (signedHexMatch) {
      const sign = signedHexMatch[1] === '-' ? -1n : 1n;
      try {
        const parsed = BigInt(`0x${signedHexMatch[2]}`);
        return sign < 0n ? -parsed : parsed;
      } catch {
        return null;
      }
    }
    if (!/^[+-]?[0-9]+$/.test(trimmed)) return null;
    try {
      return BigInt(trimmed);
    } catch {
      return null;
    }
  }
  if (typeof value === 'number' && Number.isSafeInteger(value)) return BigInt(value);
  return null;
};

export const readStackAddress = async (entry: ToncenterStackEntry | undefined) => {
  const cell = await readStackCell(entry);
  if (!cell) return null;
  try {
    const slice = cell.beginParse();
    const address = slice.loadMaybeAddress();
    if (slice.remainingBits !== 0 || slice.remainingRefs !== 0) return null;
    return address ? address.toRawString() : null;
  } catch {
    // Some getters return an address slice without Maybe semantics.
  }
  try {
    const slice = cell.beginParse();
    const address = slice.loadAddressAny();
    if (slice.remainingBits !== 0 || slice.remainingRefs !== 0) return null;
    if (!address) return null;
    if (address instanceof Address) {
      return address.toRawString();
    }
    if (typeof address.toString === 'function') {
      return Address.parse(address.toString()).toRawString();
    }
    return null;
  } catch {
    return null;
  }
};

type RpcFlight = { promise: Promise<ToncenterRpcResponse<unknown>>; controller: AbortController; waiters: number };
const rpcWaiting = new Map<AbortSignal, number>();
const countRpcWait = (signal: AbortSignal | undefined, delta: number) => {
  if (!signal) return;
  const next = (rpcWaiting.get(signal) ?? 0) + delta;
  if (next > 0) rpcWaiting.set(signal, next); else rpcWaiting.delete(signal);
};
const abortableDelay = (ms: number, signal?: AbortSignal): Promise<void> => new Promise((resolve, reject) => {
  if (signal?.aborted) { reject(signal.reason); return; }
  const done = () => { signal?.removeEventListener('abort', cancel); resolve(); };
  const timer = setTimeout(done, ms);
  const cancel = () => { clearTimeout(timer); signal?.removeEventListener('abort', cancel); reject(signal?.reason); };
  signal?.addEventListener('abort', cancel, { once: true });
});
function joinRpc<T>(flight: RpcFlight, signal?: AbortSignal): Promise<ToncenterRpcResponse<T>> {
  return new Promise((resolve, reject) => {
    flight.waiters++;
    let settled = false;
    const finish = (error: boolean, value: unknown) => {
      if (settled) return;
      settled = true;
      signal?.removeEventListener('abort', cancel);
      if (--flight.waiters === 0) flight.controller.abort();
      if (error) reject(value); else resolve(value as ToncenterRpcResponse<T>);
    };
    const cancel = () => finish(true, signal?.reason);
    flight.promise.then(value => finish(false, value), error => finish(true, error));
    if (signal?.aborted) cancel(); else signal?.addEventListener('abort', cancel, { once: true });
  });
}

export const toncenterRpc = async <T>(method: string, params: Record<string, unknown>, options: {
  forceNetwork?: boolean; maxAttempts?: number; timeoutMs?: number; admissionTimeoutMs?: number; signal?: AbortSignal; lane?: ReadLane
} = {}): Promise<ToncenterRpcResponse<T>> => {
  options.signal?.throwIfAborted();
  const endpoint = getNodeEndpoint(), state = getToncenterEndpointState(endpoint);
  if (!canUseJsonRpcInStrictMode(endpoint)) return { ok: false, failure: 'unavailable' };
  const cacheKey = buildRpcCacheKey(method, params), now = Date.now(), forceNetwork = options.forceNetwork === true;
  const maxAttempts = Math.min(TONCENTER_MAX_ATTEMPTS, Math.max(1, Math.trunc(options.maxAttempts ?? TONCENTER_MAX_ATTEMPTS)));
  const timeoutMs = Math.min(TONCENTER_TIMEOUT_MS, Math.max(1, Math.trunc(options.timeoutMs ?? TONCENTER_TIMEOUT_MS)));
  const admissionTimeoutMs = Math.min(120_000, Math.max(1, Math.trunc(options.admissionTimeoutMs ?? timeoutMs)));
  const cached = forceNetwork ? undefined : state.responseCache.get(cacheKey);
  const stale = cached && cached.staleUntil > now ? cached.response : null;
  if (cached && cached.expiresAt > now) return cached.response as ToncenterRpcResponse<T>;
  if (cached && cached.staleUntil <= now) state.responseCache.delete(cacheKey);
  if (stale && state.rateLimitedUntil > now) return stale as ToncenterRpcResponse<T>;
  const key = JSON.stringify([cacheKey, maxAttempts, timeoutMs, admissionTimeoutMs]);
  const prior = forceNetwork ? undefined : state.inFlight.get(key);
  if (prior) return joinRpc<T>(prior, options.signal);
  const breaker = transportBreaker('rpc');
  if (!breaker.admit()) return { ok: false, failure: 'unavailable', retryAfterMs: breaker.retryInMs() };
  const controller = new AbortController();
  const flight: RpcFlight = { controller, waiters: 0, promise: Promise.resolve({ ok: false }) };
  flight.promise = (async (): Promise<ToncenterRpcResponse<unknown>> => {
    let last: ToncenterRpcResponse<unknown> = { ok: false, failure: 'unavailable' };
    let health: 'failed' | 'slow' | null = null;
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      controller.signal.throwIfAborted();
      const attemptController = new AbortController();
      const forward = () => attemptController.abort(controller.signal.reason);
      controller.signal.addEventListener('abort', forward, { once: true });
      let timer = setTimeout(() => attemptController.abort(new DOMException('RPC admission timed out', 'TimeoutError')), admissionTimeoutMs);
      let acquired = false, queued = true, retryDelay = 0;
      countRpcWait(options.signal, 1);
      try {
        await waitForToncenterRateLimitWindow(state, attemptController.signal);
        await acquireToncenterDispatchSlot(state, attemptController.signal, options.lane ?? 'user');
        acquired = true; queued = false; countRpcWait(options.signal, -1);
        clearTimeout(timer);
        timer = setTimeout(() => attemptController.abort(new DOMException('RPC request timed out', 'TimeoutError')), timeoutMs);
        // The selected endpoint can change while this request waits for its slot.
        if (!canUseJsonRpcInStrictMode(endpoint) || !canUseJsonRpcInStrictMode()) return { ok: false, failure: 'unavailable' };
        const releaseHash = isIndexerRpcEndpoint(resolveConfiguredEndpoint(endpoint)) ? currentReleaseHash() : null;
        const headers: HeadersInit = { 'Content-Type': 'application/json', ...(releaseHash ? { [RELEASE_HEADER]: releaseHash } : {}) };
        if (TESTNET_CONFIG.toncenterApiKey && isToncenterHost(endpoint)) headers['X-API-Key'] = TESTNET_CONFIG.toncenterApiKey;
        const response = await fetch(endpoint, { method: 'POST', headers,
          body: JSON.stringify({ id: 1, jsonrpc: '2.0', method, params }), signal: attemptController.signal });
        if (releaseHash) assertReleaseResponse(response, releaseHash);
        let json: ToncenterRpcResponse<unknown> | null = null;
        try { json = await response.json() as ToncenterRpcResponse<unknown>; } catch { /* classified below */ }
        if (response.ok && json?.ok === true && json.result !== undefined) {
          registerToncenterSuccess(state); breaker.record('ok');
          return json;
        }
        const code = response.ok ? json?.code : response.status;
        const error = typeof json?.error === 'string' ? json.error : `HTTP ${response.status} or invalid RPC envelope`;
        const failure = code === 429 ? 'limited' : code === 500 && error.includes('LITE_SERVER_NOTREADY') ? 'not-ready'
          : code !== undefined && code >= 400 && code < 500 && code !== 408 && code !== 425 ? 'rejected' : 'unavailable';
        retryDelay = failure === 'limited'
          ? registerToncenterRateLimitWindow(state, endpoint, response.headers.get('retry-after'), attempt)
          : withRetryJitter(parseRetryDelayMs(response.headers.get('retry-after'), attempt, code ?? null));
        last = { ok: false, code, error, failure,
          ...(failure === 'limited' ? { retryAfterMs: Math.max(0, state.rateLimitedUntil - Date.now()) } : {}) };
        health = failure === 'unavailable' ? 'failed' : null;
        if (failure === 'not-ready' || failure === 'rejected') break;
      } catch (error) {
        if (isReleaseMismatchError(error)) throw error;
        if (controller.signal.aborted) throw controller.signal.reason;
        const timedOut = attemptController.signal.aborted;
        health = queued ? null : timedOut ? timeoutMs >= TRANSPORT_SLOW_THRESHOLD_MS.rpc ? 'slow' : null : 'failed';
        last = { ok: false, failure: 'unavailable', error: error instanceof Error ? error.message : String(error) };
        retryDelay = withRetryJitter(TONCENTER_RETRY_BASE_MS * (attempt + 1));
      } finally {
        clearTimeout(timer); controller.signal.removeEventListener('abort', forward);
        if (queued) countRpcWait(options.signal, -1);
        if (acquired) releaseToncenterDispatchSlot(state);
      }
      if (attempt + 1 < maxAttempts) {
        const limited = last.failure === 'limited';
        if (limited) countRpcWait(options.signal, 1);
        try { await abortableDelay(retryDelay, controller.signal); }
        finally { if (limited) countRpcWait(options.signal, -1); }
      }
    }
    if (health) breaker.record(health);
    return !forceNetwork && stale ? stale : last;
  })().then(response => {
    if (response.ok && !forceNetwork) {
      const ttl = resolveRpcCacheTtlMs(method), at = Date.now();
      state.responseCache.set(cacheKey, { response, expiresAt: at + ttl, staleUntil: at + ttl + TONCENTER_CACHE_STALE_WINDOW_MS });
      pruneRpcCache(state);
    }
    return response;
  }).finally(() => { if (state.inFlight.get(key) === flight) state.inFlight.delete(key); });
  if (!forceNetwork) state.inFlight.set(key, flight);
  return joinRpc<T>(flight, options.signal);
};

const normalizeTransactionId = (tx: ToncenterTransaction | null | undefined) => {
  if (!tx || typeof tx !== 'object') return null;
  const transactionId = tx.transaction_id;
  if (!transactionId || typeof transactionId !== 'object') return null;
  const ltRaw = transactionId.lt;
  const hash = transactionId.hash;
  const lt =
    typeof ltRaw === 'string'
      ? ltRaw
      : typeof ltRaw === 'number' && Number.isFinite(ltRaw)
        ? String(Math.trunc(ltRaw))
        : null;
  if (!lt || !hash) return null;
  return `${lt}:${hash}`;
};

const parseTxId = (txId: string | null | undefined) => {
  if (!txId) return null;
  const separator = txId.indexOf(':');
  if (separator <= 0 || separator >= txId.length - 1) return null;
  const lt = txId.slice(0, separator);
  const hash = txId.slice(separator + 1);
  if (!lt || !hash) return null;
  return { lt, hash };
};

const mapIndexerMessageToToncenter = (
  message:
    | {
        source?: string;
        destination?: string;
        value?: string;
        op?: number;
        body?: string;
      }
    | null
    | undefined
) => {
  if (!message || typeof message !== 'object') return null;
  const mapped: Record<string, unknown> = {};
  if (typeof message.source === 'string' && message.source) mapped.source = message.source;
  if (typeof message.destination === 'string' && message.destination) mapped.destination = message.destination;
  if (typeof message.value === 'string' && message.value) mapped.value = message.value;
  if (typeof message.body === 'string' && message.body) {
    mapped.msg_data = { body: message.body };
  }
  return mapped;
};

const mapIndexerEntryToToncenterTransaction = (entry: IndexerTxEntry): ToncenterTransaction => {
  const txId = parseTxId(entry.txId);
  const transaction_id = {
    lt: entry.lt || txId?.lt || '',
    hash: entry.hash || txId?.hash || ''
  };

  let description: Record<string, unknown> | undefined;
  if (entry.status === 'success') {
    description = {
      aborted: false,
      compute_ph: { success: true, exit_code: 0 },
      action: { success: true, valid: true, result_code: 0 }
    };
  } else if (entry.status === 'failed') {
    description = {
      aborted: false,
      compute_ph: { type: 'skipped', reason: entry.reason ?? 'Transaction failed.' },
      action: { success: false, valid: false, result_code: 1 }
    };
  }

  const in_msg = mapIndexerMessageToToncenter(entry.inMessage ?? null) ?? undefined;
  const out_msgs = Array.isArray(entry.outMessages)
    ? entry.outMessages
        .map((message) => mapIndexerMessageToToncenter(message))
        .filter((message): message is Record<string, unknown> => Boolean(message))
    : [];

  return {
    transaction_id,
    utime: typeof entry.utime === 'number' ? entry.utime : undefined,
    in_msg,
    out_msgs,
    description
  };
};

export const getTransactionId = (tx: ToncenterTransaction | null | undefined) => normalizeTransactionId(tx);

export const getTransactionStatus = (tx: ToncenterTransaction | null | undefined): ToncenterTxStatus => {
  if (!tx) return { status: 'unknown' };
  let description: Record<string, unknown> | null = null;
  if (typeof tx.data === 'string' && tx.data.trim()) {
    try {
      const transactionCell = Cell.fromBoc(Buffer.from(tx.data.trim(), 'base64'))[0];
      description = transactionCell
        ? (loadTransaction(transactionCell.beginParse()).description as unknown as Record<
            string,
            unknown
          >)
        : null;
    } catch {
      return { status: 'unknown', reason: 'Transaction BOC execution status is unavailable.' };
    }
  } else {
    description = asRecord(tx.description);
  }
  if (!description) return { status: 'unknown' };
  const aborted = readBoolean(description.aborted);
  const compute = asRecord(description.compute_ph ?? description.computePhase);
  const action = asRecord(description.action ?? description.actionPhase);

  const computeType = readString(compute?.type);
  const computeSuccess = readBoolean(compute?.success);
  const computeExit = readNumber(compute?.exit_code ?? compute?.exitCode);
  const computeReason = readString(compute?.reason);

  const actionSuccess = readBoolean(action?.success);
  const actionValid = readBoolean(action?.valid);
  const actionResult = readNumber(action?.result_code ?? action?.resultCode);

  if (aborted === true) {
    const reason =
      computeExit !== null
        ? `Transaction aborted (VM exit code ${computeExit}).`
        : 'Transaction aborted by contract.';
    return { status: 'failed', reason };
  }

  if (computeType === 'skipped') {
    return {
      status: 'failed',
      reason: computeReason ? `Compute phase skipped: ${computeReason}.` : 'Compute phase skipped.'
    };
  }

  if (computeSuccess === false) {
    const reason =
      computeExit !== null ? `VM execution failed (exit code ${computeExit}).` : 'VM execution failed.';
    return { status: 'failed', reason };
  }

  if (actionValid === false || actionSuccess === false || (actionResult !== null && actionResult !== 0)) {
    const reason =
      actionResult !== null && actionResult !== 0
        ? `Action phase failed (result code ${actionResult}).`
        : 'Action phase failed.';
    return { status: 'failed', reason };
  }

  const computeOk = computeSuccess === true || (computeSuccess === null && computeExit === 0);
  const actionOk = actionSuccess === true || actionResult === 0;
  if (computeOk || actionOk) {
    return { status: 'success' };
  }

  return { status: 'unknown' };
};

export const getTransactions = async (
  address: string,
  limit = 5,
  cursor?: { lt: string; hash: string },
  options: {
    raw?: boolean;
    signal?: AbortSignal;
    lane?: ReadLane;
    forceNetwork?: boolean;
  } = {}
): Promise<ToncenterTransaction[]> => {
  options.signal?.throwIfAborted();
  if (!options.raw && isIndexerEnabled()) {
    try {
      const candidates = buildIndexerAddressCandidates(address);
      const lookupAddresses = candidates.length ? candidates : [address];
      if (cursor?.lt && cursor?.hash) {
        const response = await getIndexerTransactionsForAddresses(lookupAddresses, {
          cursor,
          timeoutMs: DISABLE_RPC_FALLBACK ? 20_000 : 4_500,
          maxAttempts: 1
        });
        const entries = (response?.txs ?? []).filter((entry) => !(entry.lt === cursor.lt && entry.hash === cursor.hash));
        return entries.slice(0, Math.max(0, limit)).map((entry) => mapIndexerEntryToToncenterTransaction(entry));
      }

      const requestedLimit = Math.max(0, limit);
      if (requestedLimit === 0) return [];

      const txs: IndexerTxEntry[] = [];
      const seenTxIds = new Set<string>();
      let page = 1;
      const pageSafetyLimit = Math.max(2, Math.min(8, Math.ceil(requestedLimit / 20) + 2));
      let stagnantPageCount = 0;
      let previousFirstKey: string | null = null;

      while (txs.length < requestedLimit && page <= pageSafetyLimit) {
        const response = await getIndexerTransactionsForAddresses(lookupAddresses, {
          page,
          timeoutMs: DISABLE_RPC_FALLBACK ? 20_000 : 4_500,
          maxAttempts: 1
        });
        const entries = response?.txs ?? [];
        if (!entries.length) break;
        const firstEntry = entries[0] ?? null;
        const firstKey = firstEntry ? firstEntry.txId || `${firstEntry.lt}:${firstEntry.hash}` : null;
        const beforeCount = txs.length;
        for (const entry of entries) {
          const key = entry.txId || `${entry.lt}:${entry.hash}`;
          if (seenTxIds.has(key)) continue;
          seenTxIds.add(key);
          txs.push(entry);
          if (txs.length >= requestedLimit) break;
        }
        if (txs.length === beforeCount || (firstKey && previousFirstKey === firstKey)) {
          stagnantPageCount += 1;
        } else {
          stagnantPageCount = 0;
        }
        previousFirstKey = firstKey;
        if (stagnantPageCount >= 2) break;
        const pageSize = response.page_size > 0 ? response.page_size : entries.length;
        if (pageSize <= 0 || entries.length < pageSize) break;
        if (response.total_pages !== null && page >= response.total_pages) break;
        if (response.history_complete && response.total_txs > 0 && txs.length >= response.total_txs) break;
        page += 1;
      }
      return txs.slice(0, requestedLimit).map((entry) => mapIndexerEntryToToncenterTransaction(entry));
    } catch (error) {
      if (isReleaseMismatchError(error)) throw error;
      // Fall back to toncenter below.
    }
  }
  if (!canUseJsonRpcInStrictMode()) throw new Error('Transaction history is unavailable.');

  const params: Record<string, unknown> = { address, limit, ...(options.raw ? { archival: true } : {}) };
  if (cursor?.lt && cursor?.hash) {
    params.lt = cursor.lt;
    params.hash = cursor.hash;
  }
  const res = await toncenterRpc<ToncenterTransaction[]>('getTransactions', params, {
    forceNetwork: options.forceNetwork === true,
    maxAttempts: 2,
    timeoutMs: 12_000,
    signal: options.signal, lane: options.lane
  });
  if (!res.ok || !Array.isArray(res.result)) throw new Error('Transaction history is unavailable.');
  return res.result;
};

export type GetterArg = { type: 'int' | 'cell' | 'slice' | 'builder'; value?: bigint; cell?: Cell };
export type ChainStackEntry = [string, unknown];
export type ChainCall = { kind: 'getter'; address: string; method: string; args?: readonly GetterArg[] } | { kind: 'account'; address: string };
export type ChainGetterResult = { kind: 'getter'; exitCode: number; stack: ChainStackEntry[] };
export type ChainAccountResult = { kind: 'account'; state: 'active' | 'uninitialized' | 'frozen'; balance: bigint;
  code: Cell | null; data: Cell | null; lastTx: { lt: string; hash: string } | null };
export type ChainHead = { seqno: number; utime: number | null; rootHashHex?: string; fileHashHex?: string };
export type ReadLane = 'user' | 'background';
export type ReadChainOptions = { signal?: AbortSignal; lane?: ReadLane; deadlineMs?: number; notBefore?: number; anchored?: boolean };
type ResultFor<C> = C extends { kind: 'getter' } ? ChainGetterResult : ChainAccountResult;
export type ChainObservation<C extends readonly ChainCall[] = readonly ChainCall[]> = {
  source: 'indexer' | 'rpc'; head: ChainHead | null; receivedAt: number; results: { [I in keyof C]: ResultFor<C[I]> }
};
export const monotonicNow = () => performance.now();
export const observationAgeMs = (observation: { receivedAt: number }) => Math.max(0, monotonicNow() - observation.receivedAt);
const encodeArgs = (args: readonly GetterArg[] = []): ChainStackEntry[] => args.map(arg => arg.type === 'int'
  ? ['num', (arg.value ?? 0n).toString()]
  : arg.cell ? [`tvm.${arg.type === 'cell' ? 'Cell' : arg.type === 'slice' ? 'Slice' : 'Builder'}`, arg.cell.toBoc().toString('base64')]
  : ['null', null]);
const positiveInteger = (value: unknown): value is number => Number.isSafeInteger(value) && Number(value) > 0;
const blockHashBytes = (value: unknown): Buffer | null => {
  if (typeof value !== 'string') return null;
  const bytes = /^[0-9a-fA-F]{64}$/.test(value) ? Buffer.from(value, 'hex') : Buffer.from(value, 'base64');
  return bytes.length === 32 ? bytes : null;
};
const validBlockHash = (value: unknown) => blockHashBytes(value)?.some(byte => byte !== 0) ?? false;
const decodeAccount = (value: ToncenterAddressInfo, anchored = false): ChainAccountResult => {
  const state = value.state, balance = typeof value.balance === 'string' && /^(0|[1-9]\d*)$/.test(value.balance) ? BigInt(value.balance) : null;
  if (!['active', 'uninitialized', 'frozen'].includes(String(state)) || balance === null || balance < 0n) throw new ChainReadError('unavailable');
  const code = parseBocCell(stackEntryBytes(value.code)), data = parseBocCell(stackEntryBytes(value.data));
  if (state === 'active' && (!code || !data)) throw new ChainReadError('unavailable');
  const tx = value.last_transaction_id;
  let lastTx: ChainAccountResult['lastTx'] = null;
  if (tx != null) {
    const hash = blockHashBytes(tx.hash);
    if (typeof tx.lt !== 'string' || !/^(0|[1-9]\d*)$/.test(tx.lt) || !hash
      || (tx.lt === '0') !== hash.every(byte => byte === 0)) throw new ChainReadError('unavailable');
    if (tx.lt !== '0') lastTx = { lt: tx.lt, hash: hash.toString('hex') };
  } else if (anchored && state === 'active') throw new ChainReadError('unavailable');
  return { kind: 'account', state: state as ChainAccountResult['state'], balance, code, data, lastTx };
};

export async function readChain<const C extends readonly ChainCall[]>(calls: C, options: ReadChainOptions = {}): Promise<ChainObservation<C>> {
  if (!Array.isArray(calls) || calls.length < 1 || calls.length > 32) throw new TypeError('A chain batch must contain 1 to 32 calls');
  options.signal?.throwIfAborted();
  const unique: IndexerFreshCall[] = [], indexes: number[] = [], keys = new Map<string, number>();
  for (const call of calls) {
    let address: string;
    try { address = Address.parse(call.address).toRawString(); } catch { throw new TypeError('Invalid chain account address'); }
    if (call.kind !== 'account' && (call.kind !== 'getter' || typeof call.method !== 'string' || !call.method)) throw new TypeError('Invalid chain call');
    const encoded: IndexerFreshCall = call.kind === 'account' ? { kind: 'account', address }
      : { kind: 'getter', address, method: call.method, stack: encodeArgs(call.args) };
    const key = JSON.stringify(encoded);
    if (!keys.has(key)) { keys.set(key, unique.length); unique.push(encoded); }
    indexes.push(keys.get(key)!);
  }
  if (options.notBefore !== undefined && (!Number.isSafeInteger(options.notBefore) || options.notBefore < 0)) throw new TypeError('Invalid chain head floor');
  if (options.deadlineMs !== undefined && !Number.isFinite(options.deadlineMs)) throw new TypeError('Invalid chain read deadline');
  const controller = new AbortController(), started = monotonicNow();
  const baseBudget = options.lane === 'background' ? 15_000 : 25_000;
  // The anonymous RPC admits one request every 1.1 seconds. A valid 32-call
  // observation already needs more than the old fixed budget just for pacing.
  // Include work ahead in this lane, while bounding the whole observation.
  const pacedBudget = (pending: number) => {
    const state = getToncenterEndpointState(getNodeEndpoint());
    const ahead = state.dispatchQueue.length + (options.lane === 'background' ? state.backgroundQueue.length : 0) + state.activeRequests;
    const wait = Math.max(0, Math.max(state.nextDispatchAt, state.rateLimitedUntil) - Date.now());
    return Math.min(120_000, monotonicNow() - started + baseBudget + wait + Math.max(0, pending + ahead - 1) * state.dispatchGapMs);
  };
  let budget = options.deadlineMs === undefined ? pacedBudget(unique.length) : Math.min(30_000, Math.max(1_000, options.deadlineMs));
  const forward = () => controller.abort(options.signal?.reason);
  options.signal?.addEventListener('abort', forward, { once: true });
  let deadlineError: ChainReadError | null = null;
  const expire = () => {
    const waiting = rpcWaiting.get(controller.signal) ?? 0;
    const state = getToncenterEndpointState(getNodeEndpoint());
    deadlineError = new ChainReadError(waiting > 0 ? 'busy' : 'unavailable', { retryAfterMs: waiting > 0
      ? Math.max(state.rateLimitedUntil - Date.now(), state.dispatchGapMs * waiting) : null });
    controller.abort(deadlineError);
  };
  let timer = setTimeout(expire, budget);
  const allowPacedFallback = (pending: number) => {
    if (options.deadlineMs !== undefined) return;
    const next = pacedBudget(pending);
    if (next > budget) { budget = next; clearTimeout(timer); timer = setTimeout(expire, Math.max(1, budget - (monotonicNow() - started))); }
  };
  const remaining = () => Math.max(1, budget - (monotonicNow() - started));
  const finish = (source: 'indexer' | 'rpc', head: ChainHead | null, results: (ChainGetterResult | ChainAccountResult)[]): ChainObservation<C> => ({
    source, head, receivedAt: monotonicNow(), results: indexes.map(i => results[i]) as ChainObservation<C>['results']
  });
  const observe = async (): Promise<ChainObservation<C>> => {
    controller.signal.throwIfAborted();
    if (isFreshIndexerConfigured()) {
      try {
        const primary = await readIndexerFresh(unique, { signal: controller.signal,
          timeoutMs: Math.min(DISABLE_RPC_FALLBACK ? 20_000 : 10_000, Math.max(remaining() - 1_200 * unique.length, remaining() / 2)) });
        const block = primary.readContext.head;
        const head: ChainHead = { seqno: block.seqno, utime: positiveInteger(block.utime) ? block.utime : null,
          rootHashHex: block.rootHashHex, fileHashHex: block.fileHashHex };
        if (!options.anchored || head.utime !== null && positiveInteger(head.seqno) && block.workchain === -1 && validBlockHash(block.rootHashHex) && validBlockHash(block.fileHashHex)) {
          for (const result of primary.results) {
            if (result.kind === 'account' && result.last_tx_lt && result.last_tx_lt !== '0' && !result.last_tx_hash) throw new ChainReadError('unavailable');
          }
          const results = primary.results.map(result => result.kind === 'getter'
            ? { kind: 'getter' as const, exitCode: result.exit_code, stack: result.stack }
            : decodeAccount({ state: result.account_state, balance: result.balance_raw, code: result.code_boc, data: result.data_boc,
                last_transaction_id: result.last_tx_lt && result.last_tx_hash ? { lt: result.last_tx_lt, hash: result.last_tx_hash } : undefined }, options.anchored));
          return finish('indexer', head, results);
        }
      } catch (error) { if (isReleaseMismatchError(error)) throw error; controller.signal.throwIfAborted(); }
    }
    if ((DISABLE_RPC_FALLBACK && options.anchored) || !canUseJsonRpcInStrictMode()) throw new ChainReadError('unavailable');
    const rpcRead = async (call: IndexerFreshCall, seqno?: number) => {
      for (let attempt = 0; ; attempt++) {
        const response = await toncenterRpc<ToncenterRunResult & ToncenterAddressInfo>(call.kind === 'getter' ? 'runGetMethod' : 'getAddressInformation',
          { address: call.address, ...(call.kind === 'getter' ? { method: call.method, stack: call.stack } : {}), ...(seqno !== undefined ? { seqno } : {}) },
          { forceNetwork: true, maxAttempts: 2, timeoutMs: remaining(), admissionTimeoutMs: remaining(), signal: controller.signal, lane: options.lane });
        if (!response.ok || !response.result) {
          if (seqno !== undefined && response.failure === 'not-ready' && attempt < 2) {
            await abortableDelay([400, 800][attempt], controller.signal); continue;
          }
          throw new ChainReadError('unavailable', { retryAfterMs: response.retryAfterMs });
        }
        const value = response.result;
        if (seqno !== undefined && value.block_id?.seqno !== undefined && value.block_id.seqno !== seqno) throw new ChainReadError('unavailable');
        let result: ChainGetterResult | ChainAccountResult;
        if (call.kind === 'account') result = decodeAccount(value, options.anchored);
        else {
          if (!Number.isSafeInteger(value.exit_code) || !Array.isArray(value.stack) || value.stack.some(entry => !Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== 'string')) throw new ChainReadError('unavailable');
          result = { kind: 'getter', exitCode: value.exit_code, stack: value.stack };
        }
        return { result, value };
      }
    };
    allowPacedFallback(unique.length);
    const first = await rpcRead(unique[0]);
    allowPacedFallback(unique.length - 1);
    const block = first.value.block_id;
    const seqno = positiveInteger(block?.seqno) ? block.seqno : undefined;
    const utime = positiveInteger(first.value.sync_utime) ? first.value.sync_utime : null;
    if (options.anchored && !(seqno !== undefined && block?.workchain === -1 && validBlockHash(block.root_hash) && validBlockHash(block.file_hash) && utime !== null)) throw new ChainReadError('unavailable');
    const others = await Promise.all(unique.slice(1).map(call => rpcRead(call, seqno)));
    return finish('rpc', seqno === undefined ? null : { seqno, utime,
      ...(validBlockHash(block?.root_hash) ? { rootHashHex: blockHashBytes(block.root_hash)!.toString('hex') } : {}),
      ...(validBlockHash(block?.file_hash) ? { fileHashHex: blockHashBytes(block.file_hash)!.toString('hex') } : {})
    }, [first.result, ...others.map(item => item.result)]);
  };
  try {
    let result = await observe();
    if (options.notBefore !== undefined && result.head && result.head.seqno < options.notBefore) {
      await abortableDelay(500, controller.signal); result = await observe();
      if (result.head && result.head.seqno < options.notBefore) throw new ChainReadError('unavailable');
    }
    return result;
  } catch (error) {
    if (isReleaseMismatchError(error)) throw error;
    if (options.signal?.aborted) throw options.signal.reason;
    if (deadlineError) throw deadlineError;
    if (isChainReadError(error)) throw error;
    throw new ChainReadError('unavailable', { cause: error });
  } finally {
    clearTimeout(timer); options.signal?.removeEventListener('abort', forward);
    controller.abort();
  }
}

type LiveWaiter = { call: ChainCall; signal?: AbortSignal; settled: boolean; resolve: (value: ChainGetterResult | ChainAccountResult) => void; reject: (error: unknown) => void; cancel: () => void };
const liveQueues: Record<ReadLane, LiveWaiter[]> = { user: [], background: [] };
function liveRead(call: ChainCall, options: { lane?: ReadLane; signal?: AbortSignal } = {}): Promise<ChainGetterResult | ChainAccountResult> {
  return new Promise((resolve, reject) => {
    const lane = options.lane ?? 'user', queue = liveQueues[lane];
    let batch: { controller: AbortController; waiters: LiveWaiter[] } | undefined;
    const waiter: LiveWaiter = { call, signal: options.signal, settled: false, resolve, reject, cancel: () => {
      if (waiter.settled) return;
      waiter.settled = true; reject(options.signal?.reason);
      if (batch && batch.waiters.every(item => item.settled)) batch.controller.abort();
    } };
    if (options.signal?.aborted) { waiter.cancel(); return; }
    options.signal?.addEventListener('abort', waiter.cancel, { once: true });
    const flush = queue.length === 0;
    // Attach the shared batch before awaiting it, preserving independently abortable callers.
    (waiter as LiveWaiter & { setBatch: (value: typeof batch) => void }).setBatch = value => { batch = value; };
    queue.push(waiter);
    if (flush) queueMicrotask(() => {
      const pending = queue.splice(0).filter(item => !item.settled);
      while (pending.length) {
        const waiters = pending.splice(0, 32), controller = new AbortController();
        for (const item of waiters) (item as LiveWaiter & { setBatch: (value: { controller: AbortController; waiters: LiveWaiter[] }) => void }).setBatch({ controller, waiters });
        void readChain(waiters.map(item => item.call), { lane, signal: controller.signal }).then(observation => {
          waiters.forEach((item, i) => { if (!item.settled) { item.settled = true; item.resolve(observation.results[i]); } });
        }, error => { for (const item of waiters) if (!item.settled) { item.settled = true; item.reject(error); } }).finally(() => {
          for (const item of waiters) item.signal?.removeEventListener('abort', item.cancel);
        });
      }
    });
  });
}

export type GetterReadOptions = { forceNetwork?: boolean; signal?: AbortSignal; lane?: ReadLane };
export const runGetMethod = async (address: string, method: string, stack: GetterArg[] = [], options: GetterReadOptions = {}): Promise<ToncenterRunResult | null> => {
  options.signal?.throwIfAborted();
  const payload = encodeArgs(stack);
  if (options.forceNetwork) {
    try {
      const result = await liveRead({ kind: 'getter', address, method, args: stack }, options) as ChainGetterResult;
      return { stack: result.stack, exit_code: result.exitCode, gas_used: null };
    } catch (error) { if (isChainReadError(error)) return null; throw error; }
  }
  if (isIndexerEnabled()) {
    try { return await getIndexerRunGetMethod(address, method, payload, { signal: options.signal }); }
    catch (error) { if (isReleaseMismatchError(error)) throw error; options.signal?.throwIfAborted(); }
  }
  if (!canUseJsonRpcInStrictMode()) return null;
  const result = await toncenterRpc<ToncenterRunResult>('runGetMethod', { address, method, stack: payload },
    { maxAttempts: 2, timeoutMs: 8_000, signal: options.signal, lane: options.lane });
  return result.ok && result.result ? result.result : null;
};
const liveAccount = async (address: string, options: { signal?: AbortSignal; lane?: ReadLane } = {}) => {
  try { return await liveRead({ kind: 'account', address }, options) as ChainAccountResult; }
  catch (error) { if (isChainReadError(error)) return null; throw error; }
};
export const getTonBalanceRaw = async (address: string): Promise<bigint | null> => (await liveAccount(address))?.balance ?? null;
export const getAddressState = async (
  address: string,
  options: { fresh?: boolean } = {}
): Promise<'active' | 'uninitialized' | 'frozen' | null> => {
  if (options.fresh) return (await liveAccount(address))?.state ?? null;
  const readRpcState = async (): Promise<'active' | 'uninitialized' | 'frozen' | null> => {
    if (!canUseJsonRpcInStrictMode()) return null;
    const res = await toncenterRpc<ToncenterAddressInfo>('getAddressInformation', { address }, { forceNetwork: options.fresh === true, maxAttempts: options.fresh ? 2 : undefined });
    if (!res.ok || !res.result || typeof res.result.state !== 'string') return null;
    const state = res.result.state;
    if (state === 'active' || state === 'uninitialized' || state === 'frozen') return state;
    return null;
  };

  if (options.fresh !== true && isIndexerEnabled()) {
    try {
      const state = await getIndexerAccountStateForAddress(address, {
        timeoutMs: DISABLE_RPC_FALLBACK ? 12_000 : 1_600,
        maxAttempts: 1
      });
      if (state.account_state === 'active') {
        return state.account_state;
      }
      if (state.account_state === 'uninitialized' || state.account_state === 'frozen') {
        const rpcState = await readRpcState().catch(error => { if (isReleaseMismatchError(error)) throw error; return null; });
        if (rpcState === 'active' || rpcState === 'frozen') {
          return rpcState;
        }
        return state.account_state;
      }
      if (!state.last_tx_lt && !state.last_tx_hash) {
        const rpcState = await readRpcState().catch(error => { if (isReleaseMismatchError(error)) throw error; return null; });
        return rpcState ?? 'uninitialized';
      }
      if (state.last_tx_lt && state.last_tx_hash) return 'active';
    } catch (error) {
      if (isReleaseMismatchError(error)) throw error;
      // Fall back to toncenter below.
    }
  }
  return readRpcState();
};

export const getAccountDataCell = async (
  address: string,
  options: { fresh?: boolean } = {}
): Promise<Cell | null> => {
  if (options.fresh) return (await liveAccount(address))?.data ?? null;

  if (options.fresh !== true && isIndexerEnabled()) {
    try {
      const state = await getIndexerAccountStateForAddress(address, {
        timeoutMs: DISABLE_RPC_FALLBACK ? 12_000 : 2_500,
        maxAttempts: 1
      });
      const cell = parseBocCell(state.data_boc);
      if (cell) return cell;
      if (state.account_state === 'uninitialized') return null;
    } catch (error) {
      if (isReleaseMismatchError(error)) throw error;
      // Fall back to toncenter below.
    }
  }
  if (!canUseJsonRpcInStrictMode()) return null;
  const res = await toncenterRpc<ToncenterAddressInfo>('getAddressInformation', { address }, { forceNetwork: options.fresh === true, maxAttempts: options.fresh ? 2 : undefined });
  if (!res.ok || !res.result) return null;
  const data = res.result.data;
  const bytes = stackEntryBytes(data);
  if (!bytes) return null;
  try {
    return Cell.fromBoc(Buffer.from(bytes, 'base64'))[0];
  } catch {
    return null;
  }
};

export const getAccountCodeCell = async (
  address: string,
  options: { fresh?: boolean } = {}
): Promise<Cell | null> => {
  if (options.fresh) return (await liveAccount(address))?.code ?? null;

  if (options.fresh !== true && isIndexerEnabled()) {
    try {
      const state = await getIndexerAccountStateForAddress(address, {
        timeoutMs: DISABLE_RPC_FALLBACK ? 12_000 : 2_500,
        maxAttempts: 1
      });
      const cell = parseBocCell(state.code_boc);
      if (cell) return cell;
      if (state.account_state === 'uninitialized') return null;
    } catch (error) {
      if (isReleaseMismatchError(error)) throw error;
      // Fall back to toncenter below.
    }
  }
  if (!canUseJsonRpcInStrictMode()) return null;
  const res = await toncenterRpc<ToncenterAddressInfo>('getAddressInformation', { address });
  if (!res.ok || !res.result) return null;
  const code = res.result.code;
  const bytes = stackEntryBytes(code);
  if (!bytes) return null;
  try {
    return Cell.fromBoc(Buffer.from(bytes, 'base64'))[0];
  } catch {
    return null;
  }
};

/** Resolve the master-selected address; wallet layouts are token-specific. */
export const computeJettonWalletAddress = async (root: string, owner: string): Promise<string | null> =>
  getJettonWalletAddress(root, owner, { fresh: true });

/** Current T3 alone has an app-owned wallet constructor. External masters deploy their wallets through TEP-74 transfers. */
export const buildJettonWalletStateInit = async (root: string, owner: string, options: { fresh?: boolean } = {}) => {
  const release = TONSWAP_RELEASE;
  if (!release?.contracts.T3Hub || Address.parse(root).toRawString() !== release.contracts.T3Hub.address)
    throw new Error('An external token wallet must be deployed by its token master.');
  const code = await resolveJettonWalletCode(root, options);
  const stateInit = { code, data: t3WalletInitialData(Address.parse(owner), Address.parse(root), BigInt('0x' + release.templates.T3RecoveryProof)) };
  const address = contractAddress(0, stateInit).toRawString();
  if (address !== await getJettonWalletAddress(root, owner, { fresh: true })) throw new ChainReadError('unavailable');
  return { address, stateInitBase64: await cellToBase64(beginCell().store(storeStateInit(stateInit)).endCell()) };
};

export const readCanonicalJettonWalletAddress = async (
  stack: ToncenterStackEntry[]
): Promise<string | null> => {
  if (!Array.isArray(stack) || stack.length !== 1) return null;
  return readStackAddress(stack[0]);
};

const resolveJettonWallet = async (root: string, owner: string, options: { lane?: ReadLane } = {}): Promise<string | null> => {
  const token = releaseToken(root);
  if (!token) return null;
  const observation = await readChain([{ kind: 'account', address: token.root }, { kind: 'getter', address: token.root,
    method: 'get_wallet_address', args: [{ type: 'slice', cell: beginCell().storeAddress(Address.parse(owner)).endCell() }] }] as const,
    { anchored: true, lane: options.lane });
  const [master, addressResult] = observation.results;
  if (!matchesMaster(master, token) || addressResult.exitCode !== 0) return null;
  const value = await readCanonicalJettonWalletAddress(addressResult.stack);
  if (!value) return null;
  const address = Address.parse(value);
  return address.workChain === 0 ? address.toRawString() : null;
};
export const getJettonWalletAddressFromDiscovery = async (master: string, owner: string): Promise<string | null> =>
  resolveJettonWallet(master, owner);
export const getJettonWalletAddress = async (root: string, owner: string, options: { fresh?: boolean; lane?: ReadLane } = {}): Promise<string | null> =>
  resolveJettonWallet(root, owner, options);

export const readCanonicalJettonWalletBalance = async (
  stack: ToncenterStackEntry[],
  expected: { owner: string; root: string; accountCode?: Cell }
): Promise<bigint | null> => {
  if (!Array.isArray(stack) || stack.length !== 4) return null;
  const balanceRaw = readStackBigInt(stack[0]);
  const [walletOwner, walletRoot, walletCode] = await Promise.all([
    readStackAddress(stack[1]),
    readStackAddress(stack[2]),
    readStackCell(stack[3])
  ]);
  if (
    balanceRaw === null ||
    balanceRaw < 0n ||
    normalizeAddressKey(walletOwner) !== normalizeAddressKey(expected.owner) ||
    normalizeAddressKey(walletRoot) !== normalizeAddressKey(expected.root) ||
    !walletCode ||
    (expected.accountCode !== undefined &&
      !walletCode.hash().equals(expected.accountCode.hash()))
  ) {
    return null;
  }
  return balanceRaw;
};

export type OwnerBalance = { root: string | null; wallet: string | null; status: 'ok' | 'not_deployed' | 'unavailable'; raw: bigint | null };
/** Recheck the master, canonical address, wallet code and TEP-74 owner/master/balance at one final head. */
export async function readOwnerBalances(owner: string, roots: readonly string[], options: ReadChainOptions = {}): Promise<{ head: ChainHead | null; native: OwnerBalance; jettons: OwnerBalance[] }> {
  options.signal?.throwIfAborted();
  if (options.deadlineMs !== undefined && !Number.isFinite(options.deadlineMs)) throw new TypeError('Invalid balance read deadline');
  const controller = new AbortController(), forward = () => controller.abort(options.signal?.reason);
  const timeout = new ChainReadError('unavailable', { devMessage: 'The owner balance observation exceeded its deadline.' });
  options.signal?.addEventListener('abort', forward, { once: true });
  const timer = setTimeout(() => controller.abort(timeout), Math.min(30_000, Math.max(1_000, options.deadlineMs ?? 25_000)));
  try { return await readOwnerBalancesAtCurrentHead(owner, roots, { ...options, signal: controller.signal }); }
  finally { clearTimeout(timer); options.signal?.removeEventListener('abort', forward); controller.abort(); }
}
async function readOwnerBalancesAtCurrentHead(owner: string, roots: readonly string[], options: ReadChainOptions): Promise<{ head: ChainHead | null; native: OwnerBalance; jettons: OwnerBalance[] }> {
  const normalizedOwner = Address.parse(owner).toRawString(), normalizedRoots = roots.map(root => Address.parse(root).toRawString());
  if (normalizedRoots.length > 31) throw new TypeError('At most 31 jetton roots fit in an owner balance observation');
  const ownerArg: GetterArg = { type: 'slice', cell: beginCell().storeAddress(Address.parse(owner)).endCell() };
  const jettons: OwnerBalance[] = normalizedRoots.map(root => ({ root, wallet: null, status: 'unavailable', raw: null }));
  const tokens = normalizedRoots.map(releaseToken);
  const candidates: Array<{ index: number; wallet: string }> = [];
  for (let offset = 0; offset < tokens.length; offset += 16) {
    const group = tokens.map((token, index) => ({ token, index })).slice(offset, offset + 16).filter(entry => entry.token);
    if (!group.length) continue;
    const calls: ChainCall[] = group.flatMap(({ token }) => [{ kind: 'account', address: token!.root },
      { kind: 'getter', address: token!.root, method: 'get_wallet_address', args: [ownerArg] }]);
    const discovery = await readChain(calls, { ...options, anchored: true });
    for (const [position, { token, index }] of group.entries()) {
      const master = discovery.results[position * 2] as ChainAccountResult, getter = discovery.results[position * 2 + 1] as ChainGetterResult;
      if (!matchesMaster(master, token!) || getter.exitCode !== 0) continue;
      const address = await readCanonicalJettonWalletAddress(getter.stack);
      if (!address || Address.parse(address).workChain !== 0) continue;
      candidates.push({ index, wallet: Address.parse(address).toRawString() });
    }
  }
  let head: ChainHead | null = null, native: OwnerBalance | undefined;
  // Every final chunk must be the exact same block. A changing head yields no mixed publication.
  for (let offset = 0; offset < Math.max(1, candidates.length); offset += 7) {
    const group = candidates.slice(offset, offset + 7);
    const calls: ChainCall[] = [{ kind: 'account', address: normalizedOwner }, ...group.flatMap(({ index, wallet }): ChainCall[] => [
      { kind: 'account', address: normalizedRoots[index] },
      { kind: 'getter', address: normalizedRoots[index], method: 'get_wallet_address', args: [ownerArg] },
      { kind: 'account', address: wallet }, { kind: 'getter', address: wallet, method: 'get_wallet_data' },
    ])];
    const observation = await readChain(calls, { ...options, anchored: true, notBefore: head?.seqno ?? options.notBefore });
    if (!observation.head || !observation.head.rootHashHex || (head && (observation.head.seqno !== head.seqno
      || observation.head.rootHashHex !== head.rootHashHex || observation.head.utime !== head.utime))) throw new ChainReadError('unavailable');
    head = observation.head;
    native = { root: null, wallet: null, status: 'ok', raw: (observation.results[0] as ChainAccountResult).balance };
    for (const [position, { index, wallet }] of group.entries()) {
      const token = tokens[index]!, start = 1 + position * 4;
      const [master, addressResult, account, balanceResult] = observation.results.slice(start, start + 4) as [ChainAccountResult, ChainGetterResult, ChainAccountResult, ChainGetterResult];
      const row = jettons[index]; row.wallet = wallet;
      if (!matchesMaster(master, token) || addressResult.exitCode !== 0
        || normalizeAddressKey(await readCanonicalJettonWalletAddress(addressResult.stack)) !== wallet) continue;
      if (account.state === 'uninitialized') { row.status = 'not_deployed'; row.raw = 0n; continue; }
      if (account.state !== 'active' || account.code?.hash().toString('hex') !== token.walletCodeHash || balanceResult.exitCode !== 0) continue;
      const raw = await readCanonicalJettonWalletBalance(balanceResult.stack, { owner: normalizedOwner, root: token.root, accountCode: account.code! });
      if (raw !== null) { row.status = 'ok'; row.raw = raw; }
    }
  }
  return { head, native: native!, jettons };
}
export const getJettonBalanceRaw = async (root: string, owner: string, options: { fresh?: boolean; allowIndexerFallback?: boolean } = {}): Promise<bigint | null> => {
  if (!options.fresh && options.allowIndexerFallback !== false && isIndexerEnabled()) {
    try {
      const response = await readIndexerBalances(owner);
      const row = response.rows.find(entry => normalizeAddressKey(entry.root) === normalizeAddressKey(root));
      if (row && (row.status === 'ok' || row.status === 'not_deployed') && row.raw !== null) return BigInt(row.raw);
    } catch (error) { if (isReleaseMismatchError(error)) throw error; /* Fall through to a live observation. */ }
  }
  try {
    return (await readOwnerBalances(owner, [root])).jettons[0].raw;
  } catch (error) { if (isChainReadError(error)) return null; throw error; }
};
