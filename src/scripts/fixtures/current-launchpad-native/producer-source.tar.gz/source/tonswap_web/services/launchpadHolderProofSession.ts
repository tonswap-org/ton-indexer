import { Address, beginCell, Cell, contractAddress, loadMessage, loadShardAccount, loadShardIdent } from '@ton/core';
import { Buffer } from 'buffer';
import artifact from './artifacts/t3RecoveryProof.json';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { appExecutionNetwork } from './appExecutionNetwork';
import { indexerRequest } from './indexer';
import { currentT3ActiveState, currentT3Cell } from './t3CurrentEvidence';
import { t3ProofConfigToCell, t3ProofData, t3WalletInitialData, buildT3ProofStep, type T3ProofConfig } from './t3Contracts';
import { readT3ProofStage, type T3ProofStage, type T3ProofSnapshot, type T3ProofStepPlan } from './t3ProofSession';
import { validateRecoveryProofAnchor, validateRecoveryProofHistory, recoveryAccountPath, recoveryTransactionChunk, type ProofHead, type RecoveryProofAnchor, type RecoveryProofHistory } from './t3ProofBundle';
import { FreshStack, type FreshChainRead } from './spotContracts';
import { readChain, type ChainHead } from './toncenter';
import { readJettonQuotePrices } from './jettonConfigPrices';
import { jettonGasValue, jettonForwardValue, jettonRentValue, payloadGeometry } from './jettonWalletProfile';
import { launchChildren, readLaunchpadState } from './launchpadContracts';
import { decodeLaunchpadHolderRecoveries, validLaunchpadHolderOriginal, type LaunchpadHolderCandidate, type LaunchpadHolderRecovery } from './launchpadHolderRecoveryEvidence';
import type { LaunchpadEvidenceRequest, LaunchpadProofBinding } from './launchpadOperationSettlement';

type SessionCandidate = Omit<LaunchpadHolderCandidate,'recordBoc'|'proofBoc'> & {walletCodeBoc:string};
export type LaunchpadHolderProofSession = {version:1;original:LaunchpadEvidenceRequest;candidate:SessionCandidate;nonce:string;anchor:ProofHead;configBoc:string;address:string};
export type LaunchpadHolderProofResult = {status:'ready';session:LaunchpadHolderProofSession;plan:T3ProofStepPlan}|{status:'recovered';recovery:LaunchpadHolderRecovery}|{status:'unavailable'};
export type LaunchpadHolderProofOptions = {read?:FreshChainRead;signal?:AbortSignal;binding?:LaunchpadProofBinding};
function check(v:unknown):asserts v{if(!v)throw Error('Unverified Launchpad holder proof session');}
const exact=(v:unknown,keys:string[]):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).sort().join()===keys.sort().join();
const canonical=(v:unknown):unknown=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b)).map(([k,n])=>[k,canonical(n)])):v;
const same=(a:unknown,b:unknown)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
const digest=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const uint=(v:unknown,bits=64)=>{check(typeof v==='string'&&/^(0|[1-9][0-9]{0,36})$/.test(v));const n=BigInt(v);check(n<1n<<BigInt(bits));return n;};
function proofHead(v:unknown):v is ProofHead{return exact(v,['seqno','workchain','shard','rootHashHex','fileHashHex','utime'])&&v.workchain===-1&&v.shard==='-9223372036854775808'&&[v.seqno,v.utime].every(n=>Number.isSafeInteger(n)&&n>0&&n<=0xffffffff)&&digest(v.rootHashHex)&&digest(v.fileHashHex);}
function code(b:LaunchpadProofBinding){const c=Cell.fromBase64(artifact.codeBoc);check(c.hash().toString('hex')===artifact.codeHash&&artifact.codeHash===b.proofCodeHash);return c;}
function configOf(f:SessionCandidate,b:LaunchpadProofBinding,nonce:string,anchor:ProofHead):T3ProofConfig{
 const point=(hash:string,lt:string)=>({hash:BigInt('0x'+hash),lt:BigInt(lt),anchor:BigInt('0x'+anchor.rootHashHex)}),holder=Address.parse(f.holder);
 return{nonce:BigInt('0x'+nonce),controller:holder,hub:holder,master:b.state.binding.t3Root,request:currentT3Cell(f.requestBoc),sourceWallet:Address.parse(f.wallet),targetWallet:Address.parse(f.target),queryId:BigInt(f.wire),amount:BigInt(f.amountRaw),walletCodeHash:BigInt('0x'+b.state.binding.t3WalletHash),source:point(f.sourceHash,f.sourceLt),target:point(f.targetHash,f.targetLt)};
}
function fixedCandidate(c:LaunchpadHolderRecovery):SessionCandidate{const{recordBoc,proofBoc,status,head,sourceBeforeAccountBoc,sourceAfterAccountBoc,...fixed}=c;return fixed;}
export function validateLaunchpadHolderProofSession(v:unknown,b:LaunchpadProofBinding):v is LaunchpadHolderProofSession{
 try{
  check(exact(v,['version','original','candidate','nonce','anchor','configBoc','address'])&&v.version===1&&validLaunchpadHolderOriginal(v.original)&&digest(v.nonce)&&proofHead(v.anchor));const f=v.candidate;
  check(exact(f,['key','kind','holder','wallet','sourceLt','sourceHash','target','targetLt','targetHash','requestBoc','receiverRequestBoc','receiptBodyBoc','wire','amountRaw','walletCodeBoc'])&&['notification','failure'].includes(f.kind)&&f.key===`${f.holder}:${f.sourceLt}:${f.sourceHash}`&&digest(f.sourceHash)&&digest(f.targetHash)&&uint(f.sourceLt)>0n&&uint(f.targetLt)>=uint(f.sourceLt)&&uint(f.amountRaw,120)>0n);uint(f.wire);
  const ids=launchChildren(b.state,Address.parse(v.original.creator),BigInt(v.original.nonce),v.original.model);check(v.original.factory===b.state.binding.factory.toRawString()&&v.original.sale===ids.sale.toRawString()&&[ids.sale.toRawString(),ids.lp.toRawString()].includes(f.holder));
  const walletCode=currentT3Cell(f.walletCodeBoc);check(walletCode.hash().toString('hex')===b.state.binding.t3WalletHash&&contractAddress(0,{code:walletCode,data:t3WalletInitialData(Address.parse(f.holder),b.state.binding.t3Root,BigInt('0x'+b.proofCodeHash))}).toRawString()===f.wallet);
  check(f.target===f.wallet?f.kind==='failure'&&f.targetLt===f.sourceLt&&f.targetHash===f.sourceHash:f.target===f.holder&&BigInt(f.targetLt)>BigInt(f.sourceLt));
  const config=t3ProofConfigToCell(configOf(f as SessionCandidate,b,v.nonce,v.anchor));return currentT3Cell(v.configBoc).equals(config)&&contractAddress(0,{code:code(b),data:t3ProofData(config)}).toRawString()===v.address;
 }catch{return false;}
}
export async function readLaunchpadHolderProofSession(record:LaunchpadHolderProofSession,b:LaunchpadProofBinding,read:FreshChainRead=readChain):Promise<T3ProofSnapshot>{
 check(validateLaunchpadHolderProofSession(record,b));const r=await read([{kind:'account',address:record.address}],{anchored:true,lane:'user'}),a=r.results[0],h=r.head;
 check(h&&Number.isSafeInteger(h.seqno)&&h.seqno>=record.anchor.seqno&&digest(h.rootHashHex)&&h.utime&&r.results.length===1&&a?.kind==='account');
 ordered(h,record.anchor);check(h.utime!>=record.anchor.utime);
 const cfg=currentT3Cell(record.configBoc);if(a.state==='uninitialized'){check(!a.code&&!a.data);return{head:h,deployed:false,stage:readT3ProofStage(t3ProofData(cfg),cfg)};}
 check(a.state==='active'&&a.code&&a.data&&a.code.hash().toString('hex')===b.proofCodeHash);return{head:h,deployed:true,stage:readT3ProofStage(a.data,cfg)};
}
const cursor=(s:T3ProofStage)=>({hash:BigInt(s.cursor.hash),key:BigInt(s.cursor.key),bits:s.cursor.bits,lt:BigInt(s.cursor.lt)});
const storedCursor=(c:ReturnType<typeof cursor>)=>({hash:String(c.hash),key:String(c.key),bits:c.bits,lt:String(c.lt)});
function ordered(h:ChainHead,min:ChainHead){check(h.seqno>=min.seqno&&(h.seqno!==min.seqno||h.rootHashHex===min.rootHashHex)&&h.utime);}
async function bindingFor(p:LaunchpadEvidenceRequest,options:LaunchpadHolderProofOptions){
 if(options.binding)return options.binding;const r=TONSWAP_RELEASE;check(r&&r.network===`ton:${p.network}`&&p.network===appExecutionNetwork&&r.releaseId===p.releaseId&&r.manifestHash===p.manifestHash);
 const state=await readLaunchpadState(null,{read:options.read,signal:options.signal});check(TONSWAP_RELEASE===r);return{state,proofCodeHash:r.templates.T3RecoveryProof,v21WalletHash:r.templates.JettonV21Wallet,stablecoinWalletHash:r.vendor.stablecoin.wallet.codeHash};
}
/** Each returned step is separately reviewed and journaled by the caller. A
 * completed verifier never substitutes for a current authenticated receipt. */
export async function prepareLaunchpadHolderProofStep(original:LaunchpadEvidenceRequest,key:string,session?:LaunchpadHolderProofSession,options:LaunchpadHolderProofOptions={}):Promise<LaunchpadHolderProofResult>{
 const signal=options.signal,read=options.read??readChain;
 try{
  const originalIdentity=JSON.stringify(original),saved=session&&JSON.stringify(session);signal?.throwIfAborted();check(validLaunchpadHolderOriginal(original));const b=await bindingFor(original,options);
  if(session)check(validateLaunchpadHolderProofSession(session,b)&&same(original,session.original)&&session.candidate.key===key);
  const proofCode=code(b),nonce=session?.nonce??Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('hex');
  const value=await indexerRequest<unknown>('/v1/launchpad/holder-proof-session',{method:'POST',body:{original,key,nonce,anchor:session?.anchor??null,proofCodeBoc:artifact.codeBoc},signal,timeoutMs:20000,maxAttempts:1,health:'chain',cache:'no-store'});
  signal?.throwIfAborted();check(Buffer.byteLength(JSON.stringify(value))<=8*1024*1024&&exact(value,['schema','releaseId','manifestHash','asOf','recovery','anchor','address','configBoc','source','target','history','sessionShardAccountBoc','transactionBocs'])&&proofHead(value.asOf)&&value.schema==='tonswap-launchpad-holder-proof-session-v1'&&value.releaseId===original.releaseId&&value.manifestHash===original.manifestHash);
  const decoded=decodeLaunchpadHolderRecoveries(value.recovery,original,b);check(decoded.status==='ready');const choices=decoded.candidates.filter(c=>c.key===key);check(choices.length===1);const recovery=choices[0];
  ordered(value.asOf,recovery.head);
  if(recovery.status!=='certificate-required'){check(JSON.stringify(original)===originalIdentity&&(!session||JSON.stringify(session)===saved));return{status:'recovered',recovery};}
  check(proofHead(value.anchor));const anchor=value.anchor,candidate=fixedCandidate(recovery),cfg=t3ProofConfigToCell(configOf(candidate,b,nonce,anchor)),record:LaunchpadHolderProofSession={version:1,original:structuredClone(original),candidate,nonce,anchor:structuredClone(anchor),configBoc:cfg.toBoc().toString('base64'),address:contractAddress(0,{code:proofCode,data:t3ProofData(cfg)}).toRawString()};
  check(validateLaunchpadHolderProofSession(record,b)&&currentT3Cell(value.configBoc).equals(cfg)&&value.address===record.address&&(!session||same(record,session)));
  const source=value.source as RecoveryProofAnchor,target=value.target as RecoveryProofAnchor|null;check(source.account===candidate.wallet&&same(source.head,anchor));validateRecoveryProofAnchor(source);
  const current=await readLaunchpadHolderProofSession(record,b,read);ordered(value.asOf,recovery.head);ordered(current.head,value.asOf);
  if(value.sessionShardAccountBoc!==null){const shard=loadShardAccount(currentT3Cell(value.sessionShardAccountBoc).beginParse());check(shard.account?.addr.toRawString()===record.address);if(current.deployed)check(same(readT3ProofStage(currentT3ActiveState(shard,b.proofCodeHash).data,cfg),current.stage));else check(shard.account?.storage.state.type==='uninit');}else check(!current.deployed);
  const stage=current.stage,next=structuredClone(stage),isTarget=stage.phase>=3&&stage.phase<=5,f=candidate;
  check(stage.phase<=2?stage.evidence===0:stage.evidence===(f.kind==='notification'?1:f.target===f.wallet?0:2));
  if(isTarget){check(target&&target.account===f.target&&same(target.head,anchor));validateRecoveryProofAnchor(target!);}else check(target===null);
  const branch=target??source,point={lt:BigInt(isTarget?f.targetLt:f.sourceLt),hash:BigInt('0x'+(isTarget?f.targetHash:f.sourceHash))};
  let step:number,fields:Parameters<typeof buildT3ProofStep>[1]={},receiverValue=0n,certificate:Cell|null=null;
  if(stage.phase===0||stage.phase===3){const a=validateRecoveryProofAnchor(branch);step=isTarget?20:10;fields.proof=a.bundle;
   if(value.history!==null){const history=value.history as RecoveryProofHistory;check(same(history.anchor,anchor)&&history.head.seqno<=current.head.seqno);fields.history=validateRecoveryProofHistory(history);fields.seqno=anchor.seqno;step+=5;}
   next.phase=stage.phase+1;next.cursor={hash:BigInt('0x'+a.root.hash(0).toString('hex')).toString(),key:String(a.key),bits:256,lt:'0'};
  }else if(stage.phase===1||stage.phase===4){const a=recoveryAccountPath(branch,cursor(stage));step=isTarget?21:11;fields.proof=a.proof;next.cursor=storedCursor(a.next);if(a.done)next.phase++;}
  else if(stage.phase===2||stage.phase===5){check(Array.isArray(value.transactionBocs)&&value.transactionBocs.length<=4);const a=recoveryTransactionChunk(branch.account,value.transactionBocs,cursor(stage),point);fields.proof=a.proof;
   if(!a.done){step=isTarget?22:12;next.cursor=storedCursor(a.next);}
   else if(isTarget){step=24;next.phase=7;next.cursor.bits=1;}
   else{const tx=currentT3Cell(value.transactionBocs.at(-1)),s=tx.beginParse();s.skip(4+256+64+256+64+32+15+4);const messages=s.loadRef().beginParse(),incoming=messages.loadMaybeRef();check(incoming);
    if(f.kind==='notification'){step=16;fields.states=beginCell().storeRef(currentT3Cell(recovery.sourceBeforeAccountBoc)).storeRef(currentT3Cell(recovery.sourceAfterAccountBoc)).endCell();const targetTx=value.recovery.transactions.find((e:any)=>e.account===f.target&&currentT3Cell(e.transactionBoc).hash().toString('hex')===f.targetHash);check(targetTx);const t=currentT3Cell(targetTx.transactionBoc).beginParse();t.skip(4+256+64+256+64+32+15+4);const message=t.loadRef().beginParse().loadMaybeRef();check(message);next.phase=3;next.evidence=1;next.messageHash=BigInt('0x'+message.hash(0).toString('hex')).toString();}
    else if(f.target===f.wallet){step=14;next.phase=7;next.cursor.bits=0;next.messageHash=BigInt('0x'+incoming!.hash(0).toString('hex')).toString();}
    else{step=17;const targetTx=value.recovery.transactions.find((e:any)=>e.account===f.target&&currentT3Cell(e.transactionBoc).hash().toString('hex')===f.targetHash);check(targetTx);const t=currentT3Cell(targetTx.transactionBoc).beginParse();t.skip(4+256+64+256+64+32+15+4);const message=t.loadRef().beginParse().loadMaybeRef();check(message);next.phase=3;next.evidence=2;next.messageHash=BigInt('0x'+message.hash(0).toString('hex')).toString();}
   }
  }else{
   check(stage.phase===7);step=30;const receiver=beginCell().storeRef(currentT3Cell(f.receiverRequestBoc)).storeRef(currentT3Cell(f.walletCodeBoc)).storeRef(currentT3Cell(recovery.proofBoc)).endCell();
   const c=beginCell().storeUint(f.kind==='notification'?0x54334e43:0x54334643,32).storeRef(cfg).storeRef(receiver).storeRef(proofCode);if(f.kind==='notification')c.storeUint(BigInt(stage.messageHash),256);certificate=c.endCell();
   const r=await read([{kind:'getter',address:f.holder,method:'get_min_recovery',args:[{type:'cell',cell:certificate}]}],{anchored:true,lane:'user'});check(r.head);ordered(r.head,current.head);const result=r.results[0];check(result?.kind==='getter'&&result.exitCode===0);const quote=new FreshStack(result.stack);receiverValue=quote.uint();quote.end();check(receiverValue>0n);fields={receiver,value:receiverValue};current.head=r.head;
  }
  const body=buildT3ProofStep(step!,fields),{prices}=await readJettonQuotePrices(current.head,signal),init={code:proofCode,data:t3ProofData(cfg)},geometry=payloadGeometry(beginCell().storeRef(proofCode).storeRef(init.data).endCell());
  let valueNano=jettonGasValue(prices,250000)+jettonRentValue(prices,7*24*60*60,geometry.bits,geometry.cells);if(certificate){const g=payloadGeometry(certificate);valueNano+=receiverValue+jettonForwardValue(prices,g.bits+1024,g.cells+1);}
  signal?.throwIfAborted();check(JSON.stringify(original)===originalIdentity&&(!session||JSON.stringify(session)===saved&&same(record,session)));return{status:'ready',session:record,plan:{address:Address.parse(record.address),body,value:valueNano,bounce:current.deployed,...(!current.deployed?{init}:{}),head:current.head,step:step!,expectedStage:stage,nextStage:next}};
 }catch(e){if(signal?.aborted)throw signal.reason;return{status:'unavailable'};}
}
function anchorParts(body:Cell){const s=body.beginParse();check(s.loadUint(32)===0x54335046);const step=s.loadUint(8);check([10,15,20,25].includes(step));if(step===15||step===25)s.loadUint(32);const proof=s.loadRef(),history=step===15||step===25?s.loadRef():null;s.endParse();const envelope=history??proof;check(envelope.type===3&&envelope.refs.length===1);const block=envelope.refs[0].beginParse().loadRef(),b=block.beginParse();check(b.loadUint(32)===0x11ef55aa);b.loadInt(32);const h=b.loadRef().beginParse();check(h.loadUint(32)===0x9bc7a987);h.skip(32+8+8);const seqno=h.loadUint(32);h.loadUint(32);const shard=loadShardIdent(h);check(shard.workchainId===-1&&shard.shardPrefixBits===0&&shard.shardPrefix===0n);return{proof,seqno,utime:h.loadUint(32)};}
export async function revalidateLaunchpadHolderProofStep(original:LaunchpadEvidenceRequest,key:string,session:LaunchpadHolderProofSession,plan:T3ProofStepPlan,options:LaunchpadHolderProofOptions={}){
 const next=await prepareLaunchpadHolderProofStep(original,key,session,options);check(next.status==='ready'&&same(next.session,session));const p=next.plan;
 check(p.address.equals(plan.address)&&p.value<=plan.value&&p.bounce===plan.bounce&&!!p.init===!!plan.init&&same(p.expectedStage,plan.expectedStage)&&same(p.nextStage,plan.nextStage));
 if(p.step===plan.step&&p.body.equals(plan.body)){if([10,15,20,25].includes(plan.step)){const a=anchorParts(plan.body);check(p.head.seqno>=a.seqno&&p.head.seqno-a.seqno<=8);}return;}
 check([10,15].includes(p.step)&&[10,15].includes(plan.step)||[20,25].includes(p.step)&&[20,25].includes(plan.step));const old=anchorParts(plan.body),fresh=anchorParts(p.body);check(old.proof.equals(fresh.proof)&&p.head.seqno>=old.seqno&&p.head.seqno-old.seqno<=8&&old.utime<=p.head.utime!);
}
