import { ticketId, isWalletRequestTicket, isWalletRequestAnswer } from './walletRequestCodec';
export { isWalletRequestTicket, isWalletRequestAnswer } from './walletRequestCodec';
import { Address, beginCell, Cell, loadMessage, loadTransaction, type Message, type Transaction } from '@ton/core';
import { readonly, ref } from 'vue';
import type { SendTransactionRequest, SendTransactionResponse } from '@tonconnect/sdk';
import type { MessageParams } from '../i18n/message';
import { NATIVE_ASSET_SYMBOL } from '../constants';
import { appExecutionNetwork } from './appExecutionNetwork';
import type { ExecutionNetwork } from './executionNetwork';
import { formatWalletRequestTon } from './walletRequestNotSent';
import { createTransactionProofReader, decodeLinkedPage, predecessor } from './transactionProofHistory';
import { STANDARD_WALLET_CODE_HASHES, walletRequestChain } from './walletRequestChain';

export { STANDARD_WALLET_CODE_HASHES };
export const WALLET_REQUEST_VALIDITY_SECONDS = 300;
export const WALLET_REQUEST_EXPIRY_MARGIN_SECONDS = 60;
export const WALLET_FEE_RESERVE_NANO = 10_000_000n;
export const WALLET_HANDOFF_MIN_SECONDS = 30;
export const WALLET_REQUEST_MAX_CHAIN_VALIDITY_SECONDS = 360;
export const WALLET_HEAD_REFRESH_SECONDS = 30;
export const walletRequestDeadline = (nowMs = Date.now()): number => Math.floor(nowMs / 1000) + WALLET_REQUEST_VALIDITY_SECONDS;
export type StandardWalletKind = 'v3r1' | 'v3r2' | 'v4r2' | 'v5r1';
export type WalletRequestMessage = { destination: string; amount: string; bodyHash: string; init: boolean };
export type WalletRequestTicket = {
  version: 1; id: string; network: ExecutionNetwork; owner: string; validUntil: number;
  messages: WalletRequestMessage[]; baseline: { lt: string; hash: string }; wallet: StandardWalletKind | null;
};
export type WalletRequestAnswer = { bodyHash: string | null; signedValidUntil: number | 'none' | 'unreadable' };
export type TransactionRef = { lt: string; hash: string; utime: number };
export type OwnerHead = {
  lt: string; hash: string; chainTime: number; mcSeqno: number;
  state: 'active' | 'uninitialized' | 'frozen'; wallet: StandardWalletKind | null; seqno: number | null; balance: bigint;
};
export type AccountTip = { lt: string; hash: string; source: 'indexer' | 'rpc' };
export interface WalletRequestChain {
  readOwnerHead(owner: string, signal?: AbortSignal, lane?: 'user' | 'background'): Promise<OwnerHead>;
  readAccountTip(account: string, signal?: AbortSignal): Promise<AccountTip>;
  readTransactions(account: string, from: { lt: string; hash: string }, limit: number, signal?: AbortSignal): Promise<unknown[]>;
}
export type WalletRequestOpenReason = 'in-wallet' | 'checking' | 'signed-late' | 'unavailable' | 'new-wallet' | 'unsupported-wallet' | 'unreadable-answer';
export type WalletRequestOutcome =
  | { status: 'open'; reason: WalletRequestOpenReason; retryAfterMs: number | null }
  | { status: 'observed'; transaction: TransactionRef; boc: string; final: boolean }
  | { status: 'partial'; transaction: TransactionRef; carried: boolean[]; closed: boolean; ambiguous: boolean }
  | { status: 'expired'; anchor: { lt: string; hash: string; chainTime: number; mcSeqno: number; seqno: number } };
export type RequestMatch = { kind: 'none' } | { kind: 'observed'; transaction: Transaction }
  | { kind: 'ambiguous'; transactions: Transaction[] } | { kind: 'partial'; transaction: Transaction; carried: boolean[] };
export type FirstHop = { status: 'pending' } | { status: 'executed'; transaction: TransactionRef }
  | { status: 'rejected'; transaction: TransactionRef; exitCode: number | null; returnedNano: string | null };
export type WalletProvability = 'provable' | 'new-wallet' | 'unsupported-wallet';
export type WalletRequestEntry = { ticket: WalletRequestTicket; sentAt: number; signedValidUntil: number | null; answerUnreadable: boolean };
export type WalletRequestRecord = { version: 1; entries: WalletRequestEntry[] };
export type WalletHandoffOutcome = { status: 'signed'; response: SendTransactionResponse }
  | { status: 'observed'; boc: string; transaction: TransactionRef } | { status: 'rejected' }
  | { status: 'unanswered' } | { status: 'failed'; error: unknown };

const hex = (value: unknown, length: number): value is string => typeof value === 'string' && new RegExp(`^[0-9a-f]{${length}}$`).test(value);
const integer = (value: unknown): value is number => Number.isSafeInteger(value) && Number(value) >= 0;
const coins = (value: unknown): value is string => typeof value === 'string' && /^(0|[1-9][0-9]*)$/.test(value);
const raw = (value: string) => Address.parse(value).toRawString();
const canonical = (value: unknown): value is string => { try { return typeof value === 'string' && raw(value) === value; } catch { return false; } };
const walletKind = (value: unknown): value is StandardWalletKind | null => value === null || ['v3r1', 'v3r2', 'v4r2', 'v5r1'].includes(String(value));
const positionValid = (position: { lt: string; hash: string }) => coins(position?.lt) && hex(position?.hash, 64)
  && (position.lt === '0') === (position.hash === '0'.repeat(64));
const samePosition = (a: { lt: string; hash: string }, b: { lt: string; hash: string }) => a.lt === b.lt && a.hash === b.hash;
const beforePosition = (a: { lt: string; hash: string }, b: { lt: string; hash: string }) => BigInt(a.lt) < BigInt(b.lt)
  || a.lt === b.lt && a.hash !== b.hash;
const txRef = (tx: Transaction): TransactionRef => ({ lt: tx.lt.toString(), hash: tx.hash().toString('hex'), utime: tx.now });
const abort = (signal?: AbortSignal) => { if (signal?.aborted) throw signal.reason; };

export function ticketFor(request: Readonly<SendTransactionRequest>, network: ExecutionNetwork,
  head: { lt: string; hash: string; wallet: StandardWalletKind | null }): WalletRequestTicket {
  if (!request.from) throw new TypeError('A wallet request requires its owner.');
  const fields: Omit<WalletRequestTicket, 'id'> = { version: 1, network, owner: raw(request.from), validUntil: request.validUntil,
    messages: request.messages.map(m => ({ destination: raw(m.address), amount: m.amount,
      bodyHash: (m.payload ? Cell.fromBase64(m.payload) : Cell.EMPTY).hash().toString('hex'), init: !!m.stateInit })),
    baseline: { lt: head.lt, hash: head.hash }, wallet: head.wallet };
  const ticket = { ...fields, id: ticketId(fields) };
  if (!isWalletRequestTicket(ticket)) throw new TypeError('Invalid wallet request ticket.');
  return ticket;
}
const observedResponses = new WeakSet<object>();
export const markObservedResponse = (response: SendTransactionResponse): void => { observedResponses.add(response); };
function messageCell(tx: Transaction): Cell | null {
  const slice = tx.raw.refs[0].beginParse();
  return slice.loadBit() ? slice.loadRef() : null;
}
function messageFrom(value: string | Transaction): Message | null {
  return typeof value === 'string' ? loadMessage(Cell.fromBase64(value).beginParse()) : value.inMessage ?? null;
}
export function signedDeadlineOf(message: string | Transaction, wallet: StandardWalletKind): { validUntil: number; seqno: number } | null {
  try {
    const decoded = messageFrom(message);
    if (!decoded || decoded.info.type === 'external-out') return null;
    const body = decoded.body.beginParse();
    if (wallet === 'v5r1') {
      const op = body.loadUint(32);
      if (op !== 0x7369676e && op !== 0x73696e74) return null;
    } else body.skip(512);
    body.skip(32);
    return { validUntil: body.loadUint(32), seqno: body.loadUint(32) };
  } catch { return null; }
}
export function walletAnswer(ticket: WalletRequestTicket, response: Pick<SendTransactionResponse, 'boc'>): WalletRequestAnswer | null {
  if (!response?.boc || observedResponses.has(response)) return null;
  let message: Message | null = null;
  try { message = messageFrom(response.boc); } catch { /* An unreadable answer must keep its request pending. */ }
  const bodyHash = message?.body.hash().toString('hex') ?? null;
  const kind = ticket.wallet ?? (message?.init?.code ? STANDARD_WALLET_CODE_HASHES[message.init.code.hash().toString('hex')] : null);
  if (!kind) return { bodyHash, signedValidUntil: 'none' };
  const deadline = signedDeadlineOf(response.boc, kind);
  return { bodyHash, signedValidUntil: deadline ? deadline.seqno === 0 ? 'none' : deadline.validUntil : 'unreadable' };
}

const revision = ref(0);
export const walletRequestRevision = readonly(revision);
export const noteWalletRequestChange = (): void => { revision.value++; };
export const walletRequestRecordKey = (network: ExecutionNetwork, owner: string): string => `tonswap.wallet-request.v1:${network}:${raw(owner)}`;
const defaultStorage = (): Storage => globalThis.localStorage;
export function readWalletRequestRecord(network: ExecutionNetwork, owner: string, storage: Pick<Storage, 'getItem'> = defaultStorage()): WalletRequestRecord {
  const text = storage.getItem(walletRequestRecordKey(network, owner));
  if (text === null) return { version: 1, entries: [] };
  const record = JSON.parse(text) as WalletRequestRecord;
  if (record?.version !== 1 || !Array.isArray(record.entries) || !record.entries.every(e => isWalletRequestTicket(e?.ticket)
    && e.ticket.network === network && e.ticket.owner === raw(owner) && integer(e.sentAt) && typeof e.answerUnreadable === 'boolean'
    && (e.signedValidUntil === null || integer(e.signedValidUntil) && e.signedValidUntil <= 0xffffffff))
    || new Set(record.entries.map(e => e.ticket.id)).size !== record.entries.length) throw new TypeError('Invalid wallet request record.');
  return record;
}
/** The updater reads and writes under the record lock; callers must await persistence before handoff. */
export async function writeWalletRequestRecord(network: ExecutionNetwork, owner: string, change: (record: WalletRequestRecord) => void,
  storage: Pick<Storage, 'getItem' | 'setItem'> = defaultStorage(), locks: Pick<LockManager, 'request'> | null = globalThis.navigator?.locks ?? null): Promise<WalletRequestRecord> {
  if (!locks) throw new Error('Wallet request storage requires Web Locks.');
  const key = walletRequestRecordKey(network, owner);
  return locks.request(key, { mode: 'exclusive' }, () => {
    const record = readWalletRequestRecord(network, owner, storage);
    change(record);
    const text = JSON.stringify(record);
    // Validate before writing, so a bad updater cannot destroy the prior record.
    readWalletRequestRecord(network, owner, { getItem: () => text });
    storage.setItem(key, text);
    if (storage.getItem(key) !== text) throw new Error('Wallet request record was not retained.');
    noteWalletRequestChange();
    return readWalletRequestRecord(network, owner, storage);
  });
}
export const entryDeadline = (entry: WalletRequestEntry): number => Math.max(entry.ticket.validUntil, entry.signedValidUntil ?? 0);
export const sharesDestination = (messages: ReadonlyArray<{ destination: string }>, ticket: WalletRequestTicket): boolean =>
  messages.some(m => ticket.messages.some(t => raw(m.destination) === t.destination));
export function walletProvability(head: OwnerHead): WalletProvability {
  if (head.state === 'uninitialized') return 'new-wallet';
  if (head.state !== 'active' || head.wallet === null) return 'unsupported-wallet';
  return head.seqno !== null && head.seqno >= 1 ? 'provable' : 'new-wallet';
}

const heads = new WeakMap<WalletRequestChain, Map<string, { at: number; pending: Promise<OwnerHead> }>>();
export async function readOwnerHead(owner: string, options: { fresh?: boolean; signal?: AbortSignal; chain?: WalletRequestChain; lane?: 'user' | 'background' } = {}): Promise<OwnerHead> {
  abort(options.signal);
  const chain = options.chain ?? walletRequestChain;
  let cache = heads.get(chain);
  if (!cache) { cache = new Map(); heads.set(chain, cache); }
  const key = raw(owner), cached = cache.get(key), now = performance.now();
  if (!options.fresh && cached && now - cached.at < 4_000) {
    const result = await cached.pending; abort(options.signal); return result;
  }
  const entry = { at: now, pending: chain.readOwnerHead(key, options.signal, options.lane) };
  cache.set(key, entry);
  try { const result = await entry.pending; abort(options.signal); return result; }
  catch (error) { if (cache.get(key) === entry) cache.delete(key); throw error; }
}

function sameTarget(out: Message, message: WalletRequestMessage): boolean {
  return out.info.type === 'internal' && out.info.dest.toRawString() === message.destination && out.body.hash().toString('hex') === message.bodyHash;
}
function exact(out: Message, message: WalletRequestMessage): boolean {
  return sameTarget(out, message) && out.info.type === 'internal' && out.info.value.coins === BigInt(message.amount)
    && (!out.info.value.other || out.info.value.other.size === 0) && !!out.init === message.init;
}
function assignment(ticket: WalletRequestTicket, transaction: Transaction, loose = false): Array<Message | undefined> {
  const outs = [...transaction.outMessages.values()], used = new Set<number>();
  const assigned = ticket.messages.map(message => {
    const index = outs.findIndex((out, i) => !used.has(i) && exact(out, message));
    if (index < 0) return undefined;
    used.add(index); return outs[index];
  });
  if (loose) ticket.messages.forEach((message, index) => {
    if (assigned[index]) return;
    const outIndex = outs.findIndex((out, i) => !used.has(i) && sameTarget(out, message));
    if (outIndex >= 0) { used.add(outIndex); assigned[index] = outs[outIndex]; }
  });
  return assigned;
}
export function matchRequest(ticket: WalletRequestTicket, ownerTransactions: readonly Transaction[]): RequestMatch {
  const owner = BigInt(`0x${Address.parse(ticket.owner).hash.toString('hex')}`);
  const rows = ownerTransactions.filter(tx => tx.address === owner && tx.lt > BigInt(ticket.baseline.lt))
    .sort((a, b) => a.lt < b.lt ? -1 : a.lt > b.lt ? 1 : 0);
  const matches = rows.filter(tx => assignment(ticket, tx).every(Boolean));
  if (matches.length === 1) return { kind: 'observed', transaction: matches[0] };
  if (matches.length > 1) return { kind: 'ambiguous', transactions: matches };
  const carried = ticket.messages.map(message => rows.some(tx => [...tx.outMessages.values()].some(out => sameTarget(out, message))));
  const first = rows.find(tx => ticket.messages.some(message => [...tx.outMessages.values()].some(out => sameTarget(out, message))));
  return first ? { kind: 'partial', transaction: first, carried } : { kind: 'none' };
}

type Window = { position: { lt: string; hash: string }; transactions: Transaction[] };
type RequestCache = { window: Window; origin?: Transaction; final?: { deadline: number; answer: string | null; outcome: WalletRequestOutcome } };
const caches = new WeakMap<WalletRequestChain, Map<string, RequestCache>>();
function requestCache(chain: WalletRequestChain, ticket: WalletRequestTicket): RequestCache {
  let cache = caches.get(chain);
  if (!cache) { cache = new Map(); caches.set(chain, cache); }
  let entry = cache.get(ticket.id);
  if (!entry) {
    if (cache.size >= 128) cache.delete(cache.keys().next().value!);
    entry = { window: { position: ticket.baseline, transactions: [] } }; cache.set(ticket.id, entry);
  }
  return entry;
}
async function extendWindow(chain: WalletRequestChain, ticket: WalletRequestTicket, position: { lt: string; hash: string },
  window: Window, pages: number, signal?: AbortSignal): Promise<Window> {
  if (!positionValid(position) || beforePosition(position, window.position)) throw new Error('Wallet history moved behind its baseline.');
  if (samePosition(position, window.position)) return window;
  let cursor: { lt: string; hash: string } | undefined = position;
  const added: Transaction[] = [];
  for (let page = 0; page < pages && cursor; page++) {
    abort(signal);
    const rows = await chain.readTransactions(ticket.owner, cursor, 32, signal);
    abort(signal);
    const transactions = decodeLinkedPage(ticket.owner, rows, cursor);
    for (const tx of transactions) {
      const point = txRef(tx);
      if (samePosition(point, window.position)) return { position, transactions: [...added, ...window.transactions] };
      if (beforePosition(point, window.position)) throw new Error('Wallet history missed its baseline.');
      added.push(tx);
      const prev = predecessor(tx);
      if (!prev) {
        if (window.position.lt !== '0') throw new Error('Wallet history ended before its baseline.');
        return { position, transactions: [...added, ...window.transactions] };
      }
      if (samePosition(prev, window.position)) return { position, transactions: [...added, ...window.transactions] };
      if (beforePosition(prev, window.position)) throw new Error('Wallet history did not link to its baseline.');
    }
    const last = transactions.at(-1);
    if (!last) throw new Error('Empty wallet history page.');
    cursor = predecessor(last);
  }
  throw new Error('Wallet history exceeds this read budget.');
}
const open = (reason: WalletRequestOpenReason, retryAfterMs: number | null = null): WalletRequestOutcome => ({ status: 'open', reason, retryAfterMs });
function closure(head: OwnerHead | null, deadline: number, ticket: WalletRequestTicket, answer?: WalletRequestAnswer | null): WalletRequestOutcome | null {
  if (!head) return open(Date.now() / 1000 < ticket.validUntil ? 'in-wallet' : 'checking', Math.max(0, (deadline + 60) * 1000 - Date.now()));
  if (head.chainTime < ticket.validUntil) return open('in-wallet', (deadline + 60 - head.chainTime) * 1000);
  if (head.chainTime < deadline + 60) return open(deadline > ticket.validUntil ? 'signed-late' : 'checking', (deadline + 60 - head.chainTime) * 1000);
  if (answer?.signedValidUntil === 'unreadable') return open('unreadable-answer');
  if (ticket.wallet === null && head.state !== 'uninitialized') return open('unsupported-wallet');
  const provability = walletProvability(head);
  return provability === 'provable' ? null : open(provability);
}
export async function resolveWalletRequest(ticket: WalletRequestTicket, options: { answer?: WalletRequestAnswer | null;
  signal?: AbortSignal; chain?: WalletRequestChain; storage?: Pick<Storage, 'getItem'> } = {}): Promise<WalletRequestOutcome> {
  abort(options.signal);
  if (!isWalletRequestTicket(ticket) || ticket.network !== appExecutionNetwork || options.answer != null && !isWalletRequestAnswer(options.answer)) return open('unavailable');
  const chain = options.chain ?? walletRequestChain, cache = requestCache(chain, ticket);
  try {
    const record = readWalletRequestRecord(ticket.network, ticket.owner, options.storage);
    const entry = record.entries.find(e => e.ticket.id === ticket.id);
    const answer = entry?.answerUnreadable ? { bodyHash: options.answer?.bodyHash ?? null, signedValidUntil: 'unreadable' as const } : options.answer;
    const deadline = Math.max(ticket.validUntil, typeof answer?.signedValidUntil === 'number' ? answer.signedValidUntil : 0, entry?.signedValidUntil ?? 0);
    const memo = cache.final;
    if (memo && (memo.outcome.status === 'expired' ? deadline <= memo.deadline && answer?.signedValidUntil !== 'unreadable'
      : memo.outcome.status === 'observed' && (memo.answer ? memo.answer === answer?.bodyHash : deadline <= memo.deadline && answer?.signedValidUntil !== 'unreadable'))) return memo.outcome;
    cache.final = undefined;
    let head: OwnerHead | null = null;
    let position: { lt: string; hash: string };
    if (Date.now() >= (deadline + 60) * 1000) {
      head = await readOwnerHead(ticket.owner, { chain, signal: options.signal, lane: 'background' }); position = head;
    } else position = await chain.readAccountTip(ticket.owner, options.signal);
    if (!positionValid(position) || beforePosition(position, ticket.baseline) || beforePosition(position, cache.window.position)) {
      head = await readOwnerHead(ticket.owner, { chain, signal: options.signal, fresh: true, lane: 'background' }); position = head;
      if (!positionValid(position) || beforePosition(position, ticket.baseline) || beforePosition(position, cache.window.position)) return open('unavailable');
    }
    cache.window = await extendWindow(chain, ticket, position, cache.window, 16, options.signal);
    const match = matchRequest(ticket, cache.window.transactions), reason = closure(head, deadline, ticket, answer);
    let chosen = match.kind === 'observed' ? match.transaction : undefined;
    if (match.kind === 'ambiguous' && answer?.bodyHash) {
      const candidates = match.transactions.filter(tx => tx.inMessage?.body.hash().toString('hex') === answer.bodyHash);
      if (candidates.length === 1) chosen = candidates[0];
    }
    if (chosen) {
      const incoming = messageCell(chosen);
      if (!incoming) return open('unavailable');
      cache.origin = chosen;
      const named = !!answer?.bodyHash && chosen.inMessage?.body.hash().toString('hex') === answer.bodyHash;
      const outcome: WalletRequestOutcome = { status: 'observed', transaction: txRef(chosen), boc: incoming.toBoc().toString('base64'), final: named || reason === null };
      if (outcome.final) cache.final = { deadline, answer: named ? answer!.bodyHash : null, outcome };
      return outcome;
    }
    if (match.kind === 'ambiguous') {
      cache.origin = undefined;
      return { status: 'partial', transaction: txRef(match.transactions[0]), carried: ticket.messages.map(() => true), closed: false, ambiguous: true };
    }
    if (match.kind === 'partial') {
      cache.origin = match.transaction;
      return { status: 'partial', transaction: txRef(match.transaction), carried: match.carried, closed: reason === null, ambiguous: false };
    }
    if (reason) return reason;
    const outcome: WalletRequestOutcome = { status: 'expired', anchor: { lt: head!.lt, hash: head!.hash,
      chainTime: head!.chainTime, mcSeqno: head!.mcSeqno, seqno: head!.seqno! } };
    cache.final = { deadline, answer: null, outcome };
    return outcome;
  } catch (error) { abort(options.signal); return open('unavailable'); }
}
export function walletMessageExpired(outcome: WalletRequestOutcome, index: number): boolean {
  return Number.isInteger(index) && index >= 0 && (outcome.status === 'expired' || outcome.status === 'partial'
    && outcome.closed && !outcome.ambiguous && index < outcome.carried.length && outcome.carried[index] === false);
}

export function inspectFirstHop(origin: Transaction, ticket: WalletRequestTicket, index: number, destinationTransactions: readonly Transaction[]): FirstHop {
  const outgoing = assignment(ticket, origin, true)[index];
  if (!outgoing || outgoing.info.type !== 'internal') return { status: 'pending' };
  const out = outgoing.info, destination = BigInt(`0x${out.dest.hash.toString('hex')}`);
  const matches = destinationTransactions.filter(tx => {
    const message = tx.inMessage, info = message?.info;
    return tx.address === destination && info?.type === 'internal' && !info.bounced && info.src.toRawString() === ticket.owner
      && info.dest.equals(out.dest) && info.createdLt === out.createdLt && message!.body.equals(outgoing.body);
  });
  if (matches.length !== 1 || matches[0].description.type !== 'generic') return { status: 'pending' };
  return inspectFirstHopTransaction(matches[0], ticket.owner);
}

/** Classifies an already matched destination transaction; callers must establish the message identity first. */
export function inspectFirstHopTransaction(transaction: Transaction, owner: string): FirstHop {
  const description = transaction.description;
  if (description.type !== 'generic') return { status: 'pending' };
  if (!description.aborted) return { status: 'executed', transaction: txRef(transaction) };
  const compute = description.computePhase;
  const exitCode = compute.type === 'vm' ? !compute.success ? compute.exitCode : description.actionPhase?.resultCode ?? null : null;
  const returned = [...transaction.outMessages.values()].find(m => m.info.type === 'internal' && m.info.bounced && m.info.dest.toRawString() === owner);
  return { status: 'rejected', transaction: txRef(transaction), exitCode,
    returnedNano: returned?.info.type === 'internal' ? returned.info.value.coins.toString() : null };
}
const hopReaders = new WeakMap<WalletRequestChain, ReturnType<typeof createTransactionProofReader>>();
export async function readFirstHop(ticket: WalletRequestTicket, index: number, options: {
  answer?: WalletRequestAnswer | null; signal?: AbortSignal; chain?: WalletRequestChain; storage?: Pick<Storage, 'getItem'>;
} = {}): Promise<FirstHop> {
  const chain = options.chain ?? walletRequestChain;
  const outcome = await resolveWalletRequest(ticket, options);
  if (!(outcome.status === 'observed' || outcome.status === 'partial' && !outcome.ambiguous && outcome.carried[index])) return { status: 'pending' };
  const cache = requestCache(chain, ticket);
  const origin = outcome.status === 'observed' ? cache.origin : cache.window.transactions.find(tx => assignment(ticket, tx, true)[index]);
  const message = ticket.messages[index];
  if (!origin || !message) return { status: 'pending' };
  try {
    let reader = hopReaders.get(chain);
    if (!reader) {
      reader = createTransactionProofReader(async (account, cursor, limit, signal) => {
        const from = cursor ?? await chain.readAccountTip(account, signal);
        return from.lt === '0' ? [] : chain.readTransactions(account, from, limit ?? 32, signal);
      });
      hopReaders.set(chain, reader);
    }
    const history = await reader(`${ticket.id}:${index}:${origin.lt}`, [message.destination], Math.max(0, origin.now - 1), 4, options.signal);
    if (!history) return { status: 'pending' };
    return inspectFirstHop(origin, ticket, index, history.get(message.destination)!.map(row => loadTransaction(Cell.fromBase64((row as { data: string }).data).beginParse())));
  } catch (error) { abort(options.signal); return { status: 'pending' }; }
}

export function requiredGram(messages: ReadonlyArray<{ amount: string }>, feeReserveNano = 0n): bigint {
  if (feeReserveNano < 0n || messages.some(m => !coins(m.amount))) throw new TypeError('Invalid wallet request amount.');
  return messages.reduce((sum, m) => sum + BigInt(m.amount), 0n) + (feeReserveNano > WALLET_FEE_RESERVE_NANO ? feeReserveNano : WALLET_FEE_RESERVE_NANO);
}
export function walletRequestOutcomeMessage(outcome: WalletRequestOutcome): { code: string; params: MessageParams } {
  const names: Record<WalletRequestOpenReason, string> = { 'in-wallet': 'inWallet', checking: 'checking', 'signed-late': 'signedLate', unavailable: 'unavailable',
    'new-wallet': 'newWallet', 'unsupported-wallet': 'unsupportedWallet', 'unreadable-answer': 'unreadableAnswer' };
  return { code: `review.outcome.${outcome.status === 'open' ? names[outcome.reason] : outcome.status === 'partial' && outcome.ambiguous ? 'ambiguous' : outcome.status}`, params: {} };
}
export function firstHopMessage(hop: Pick<Extract<FirstHop, { status: 'rejected' }>, 'exitCode' | 'returnedNano'>): { code: string; params: MessageParams } {
  return { code: `review.outcome.${hop.returnedNano === null ? 'rejectedKept' : 'rejected'}`,
    params: { code: hop.exitCode === null ? '' : String(hop.exitCode), returned: hop.returnedNano === null ? '' : formatWalletRequestTon(hop.returnedNano), symbol: NATIVE_ASSET_SYMBOL } };
}

export function awaitWalletRequest(input: {
  ticket: WalletRequestTicket; response: Promise<SendTransactionResponse> | null; sent: Promise<void> | null;
  isRejection(error: unknown): Promise<boolean>; deadlineInMs: number; chain: WalletRequestChain;
  visible(): boolean; onVisible(listener: () => void): () => void; paused?(): Promise<boolean>; signal: AbortSignal;
}): Promise<WalletHandoffOutcome> {
  return new Promise((resolve, reject) => {
    let done = false, running = false, sent = input.sent === null, next: ReturnType<typeof setTimeout> | undefined;
    let delay = 4_000, window: Window = { position: input.ticket.baseline, transactions: [] };
    const controller = new AbortController();
    const cleanup = () => { clearTimeout(deadline); clearTimeout(next); unlisten(); input.signal.removeEventListener('abort', onAbort); controller.abort(); };
    const finish = (outcome: WalletHandoffOutcome) => { if (!done) { done = true; cleanup(); resolve(outcome); } };
    const onAbort = () => { if (!done) { done = true; cleanup(); reject(input.signal.reason); } };
    const schedule = (ms: number) => { clearTimeout(next); if (!done && sent) next = setTimeout(() => void tick(), ms); };
    const tick = async () => {
      if (done || !sent || running) return;
      running = true;
      try {
        if (await input.paused?.()) return;
        if (done) return;
        const tip = await input.chain.readAccountTip(input.ticket.owner, controller.signal);
        if (done) return;
        window = await extendWindow(input.chain, input.ticket, tip, window, 4, controller.signal);
        const match = matchRequest(input.ticket, window.transactions);
        if (match.kind === 'observed') {
          const cell = messageCell(match.transaction);
          if (cell) { finish({ status: 'observed', boc: cell.toBoc().toString('base64'), transaction: txRef(match.transaction) }); return; }
        }
        delay = tip.source === 'rpc' ? 10_000 : 4_000;
      } catch { delay = Math.min(30_000, delay * 2); }
      finally { running = false; schedule(input.visible() ? delay : Math.max(20_000, delay)); }
    };
    const unlisten = input.onVisible(() => { if (input.visible() && sent) schedule(0); });
    const deadline = setTimeout(() => finish({ status: 'unanswered' }), Math.max(0, input.deadlineInMs));
    input.signal.addEventListener('abort', onAbort, { once: true });
    if (input.signal.aborted) { onAbort(); return; }
    if (input.response) input.response.then(response => finish({ status: 'signed', response }), async error => {
      try { finish(await input.isRejection(error) ? { status: 'rejected' } : { status: 'failed', error }); }
      catch (error) { finish({ status: 'failed', error }); }
    });
    if (input.sent) input.sent.then(() => { sent = true; schedule(3_000); }, () => { /* The wallet promise owns send failures. */ });
    else schedule(3_000);
  });
}
