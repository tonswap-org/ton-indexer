import { TONSWAP_RELEASE } from '../releaseManifest';

export const RELEASE_HEADER = 'x-tonswap-release';

/** A different deployment is never an offline answer and must not enter retry or fallback paths. */
export class ReleaseMismatchError extends Error {
  readonly code = 'release_mismatch';
  constructor(readonly expected: string | null, readonly received: string | null) {
    super('The service response does not match the installed TONSwap release.');
    this.name = 'ReleaseMismatchError';
  }
}

export const isReleaseMismatchError = (error: unknown): error is ReleaseMismatchError => error instanceof ReleaseMismatchError;

export function currentReleaseHash(): string {
  const hash = TONSWAP_RELEASE?.manifestHash;
  if (typeof hash !== 'string' || !/^[0-9a-f]{64}$/.test(hash)) throw new ReleaseMismatchError(null, null);
  return hash;
}

/** Invoke immediately after fetch, before reading status or any response body. */
export function assertReleaseResponse(response: Response, expected: string): void {
  const received = response.headers.get(RELEASE_HEADER);
  if (received !== expected) throw new ReleaseMismatchError(expected, received);
}

/** The indexer's two native RPC routes and its public proxy mount; other node services have no release-header contract. */
export function isIndexerRpcEndpoint(endpoint: string): boolean {
  const configured = TONSWAP_RELEASE?.services.indexer;
  if (!configured) return false;
  try {
    const selected = new URL(endpoint), indexer = new URL(configured);
    return !selected.username && !selected.password && !selected.search && !selected.hash
      && selected.origin === indexer.origin
      && ['/jsonRPC', '/api/v2/jsonRPC', `${indexer.pathname}/jsonRPC`].includes(selected.pathname);
  } catch { return false; }
}
