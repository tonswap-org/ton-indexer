import { computed, shallowRef, type Ref } from 'vue';

export type TransportCapability = 'indexer.chain' | 'indexer.data' | 'rpc';
/** `ok`: answered. `failed`: connection error, HTTP 5xx, 408, 425, or an invalid envelope. `slow`: ran into the transport's own timeout. `limited`: HTTP 429. */
export type TransportOutcome = 'ok' | 'failed' | 'slow' | 'limited';
export type BreakerState = 'closed' | 'open' | 'half-open';

export interface TransportBreaker {
  readonly state: BreakerState;
  /** May a request be sent now? While open: false. When the open window has passed: true exactly once (the probe), and the state becomes half-open. */
  admit(): boolean;
  /** Milliseconds until `admit()` can return true again; 0 when it would now. */
  retryInMs(): number;
  record(outcome: TransportOutcome, retryAfterMs?: number | null): void;
}

/** What the whole app can say about chain reads. `fallback`: the indexer's chain reads are not admitted and the RPC is. `offline`: neither is. */
export type ChainReadMode = 'normal' | 'fallback' | 'offline';

const processEnv = typeof process !== 'undefined' && process.env ? process.env : undefined;
const importMetaEnv = (import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env;
const runtimeEnv = { ...(importMetaEnv ?? {}), ...(processEnv ?? {}) };
/** Strict mode: the public RPC is never asked, so there is nothing an indexer request could fall back to. */
export const RPC_FALLBACK_DISABLED =
  runtimeEnv.TONSWAP_DISABLE_RPC_FALLBACK === '1' ||
  runtimeEnv.VITE_TONSWAP_DISABLE_RPC_FALLBACK === '1';

/**
 * A timeout is `slow` only when the request's own time limit was at least this long. A shorter limit was the
 * caller's budget and says nothing about the transport, so the one place that records a breaker skips it.
 */
export const TRANSPORT_SLOW_THRESHOLD_MS: Readonly<Record<TransportCapability, number>> = {
  'indexer.chain': 8_000,
  'indexer.data': 4_000,
  rpc: 8_000
};

const FAILED_TO_OPEN = 2;
const SLOW_TO_OPEN = 3;
const WINDOW_BASE_MS = 2_000;
const WINDOW_MAX_MS = 30_000;
const WINDOW_JITTER = 0.2;
const LIMITED_DEFAULT_MS = 5_000;

// Windows are measured on a clock the person cannot set: a corrected device clock must not hold a breaker open.
const monotonicClock = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
let now: () => number = monotonicClock;

type Breaker = TransportBreaker & { reset(): void };

const createBreaker = (alwaysAdmit: boolean): Breaker => {
  const state = shallowRef<BreakerState>('closed');
  // Consecutive outcomes of the same kind since the last `ok`.
  let failed = 0;
  let slow = 0;
  // Windows that failures opened since the last `ok`; each one doubles the next.
  let reopened = 0;
  let windowMs = 0;
  // Open: the end of the window. Half-open: when a probe that reported nothing is given up.
  let blockedUntil = 0;

  const open = (ms: number) => {
    const until = now() + ms;
    if (state.value === 'open' && until <= blockedUntil) return;
    windowMs = ms;
    blockedUntil = until;
    state.value = 'open';
  };

  return {
    get state() {
      return state.value;
    },
    admit() {
      if (state.value === 'closed') return true;
      if (now() >= blockedUntil) {
        // This request is the probe. An abort, a 4xx or a caller's short time limit records nothing,
        // so a probe that stays silent for one more window is replaced by the next request.
        state.value = 'half-open';
        blockedUntil = now() + windowMs;
        return true;
      }
      return alwaysAdmit;
    },
    retryInMs() {
      if (state.value === 'closed' || alwaysAdmit) return 0;
      return Math.max(0, Math.ceil(blockedUntil - now()));
    },
    record(outcome, retryAfterMs) {
      if (outcome === 'ok') {
        failed = 0;
        slow = 0;
        reopened = 0;
        state.value = 'closed';
        return;
      }
      if (outcome === 'limited') {
        // The service named its own wait: it is neither doubled nor jittered.
        const asked = typeof retryAfterMs === 'number' && Number.isFinite(retryAfterMs) ? retryAfterMs : LIMITED_DEFAULT_MS;
        open(Math.min(Math.max(asked, WINDOW_BASE_MS), WINDOW_MAX_MS));
        return;
      }
      // A request that was admitted before the window opened says nothing new about it.
      if (state.value === 'open') return;
      if (state.value === 'closed') {
        if (outcome === 'failed') {
          failed += 1;
          slow = 0;
        } else {
          slow += 1;
          failed = 0;
        }
        if (failed < FAILED_TO_OPEN && slow < SLOW_TO_OPEN) return;
      }
      const base = Math.min(WINDOW_BASE_MS * 2 ** reopened, WINDOW_MAX_MS);
      reopened += 1;
      open(Math.min(WINDOW_MAX_MS, Math.round(base * (1 + WINDOW_JITTER * (2 * Math.random() - 1)))));
    },
    reset() {
      failed = 0;
      slow = 0;
      reopened = 0;
      windowMs = 0;
      blockedUntil = 0;
      state.value = 'closed';
    }
  };
};

// In strict mode the indexer breakers refuse nothing; outcomes are still recorded, so the mode below stays truthful.
const breakers: Record<TransportCapability, Breaker> = {
  'indexer.chain': createBreaker(RPC_FALLBACK_DISABLED),
  'indexer.data': createBreaker(RPC_FALLBACK_DISABLED),
  rpc: createBreaker(false)
};

/**
 * The breaker of one transport capability. Each has exactly one caller of `admit()` and `record()`, so the single
 * half-open probe cannot be spent twice: `indexerRequest` for the two indexer capabilities, `toncenterRpc` for `rpc`.
 */
export const transportBreaker = (capability: TransportCapability): TransportBreaker => breakers[capability];

export const chainReadMode: Readonly<Ref<ChainReadMode>> = computed(() =>
  breakers['indexer.chain'].state === 'closed' ? 'normal' : breakers.rpc.state === 'closed' ? 'fallback' : 'offline');

/** Tests only. */
export const resetTransportHealth = (clock?: () => number) => {
  now = clock ?? monotonicClock;
  for (const breaker of Object.values(breakers)) breaker.reset();
};
