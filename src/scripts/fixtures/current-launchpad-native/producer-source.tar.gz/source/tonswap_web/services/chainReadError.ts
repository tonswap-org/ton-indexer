import { AppError } from './appError';
import { WalletRequestNotSentError } from './walletRequestNotSent';

export type ChainReadFailure = 'unavailable' | 'busy';

export class ChainReadError extends AppError {
  readonly failure: ChainReadFailure;
  readonly retryAfterMs: number | null;
  constructor(failure: ChainReadFailure, options: { retryAfterMs?: number | null; devMessage?: string; cause?: unknown } = {}) {
    const retry = typeof options.retryAfterMs === 'number' && Number.isFinite(options.retryAfterMs)
      ? Math.max(0, options.retryAfterMs) : null;
    super(`network.read.${failure}`, { seconds: retry === null ? 5 : Math.ceil(retry / 1000) }, options);
    this.name = 'ChainReadError';
    this.failure = failure;
    this.retryAfterMs = retry;
  }
}
export const isChainReadError = (value: unknown): value is ChainReadError => value instanceof ChainReadError;

export class ChainAnswerError extends AppError {
  readonly address: string;
  readonly method: string;
  readonly exitCode: number | null;
  constructor(call: { address: string; method: string }, exitCode: number | null, devMessage?: string) {
    super('network.read.unexpected', {}, { devMessage });
    this.name = 'ChainAnswerError';
    this.address = call.address;
    this.method = call.method;
    this.exitCode = exitCode;
  }
}
export const isChainAnswerError = (value: unknown): value is ChainAnswerError => value instanceof ChainAnswerError;
export function expectStack(result: { exitCode: number; stack: [string, unknown][] }, call: { address: string; method: string }, arity?: number): [string, unknown][] {
  if (result.exitCode !== 0 || !Array.isArray(result.stack) || (arity !== undefined && result.stack.length !== arity)) {
    throw new ChainAnswerError(call, result.exitCode === 0 ? null : result.exitCode);
  }
  return result.stack;
}
export function chainReadNotSent(error: ChainReadError): WalletRequestNotSentError {
  return new WalletRequestNotSentError(error.devMessage, `network.notSent.${error.failure}`, error.params, error);
}
