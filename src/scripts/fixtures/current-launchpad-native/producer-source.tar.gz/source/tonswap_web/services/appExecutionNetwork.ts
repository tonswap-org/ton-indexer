import { TONSWAP_NETWORK } from '../constants';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { resolveExecutionNetwork } from './executionNetwork';

export const appExecutionNetwork = resolveExecutionNetwork(
  TONSWAP_RELEASE?.network, import.meta.env?.VITE_TON_NETWORK ?? TONSWAP_NETWORK,
);
