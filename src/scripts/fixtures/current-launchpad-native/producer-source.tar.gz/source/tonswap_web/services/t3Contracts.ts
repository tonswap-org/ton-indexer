import { Address, beginCell, Cell, CellType, contractAddress, Dictionary, type DictionaryValue, type Slice } from '@ton/core';
import { Buffer } from 'buffer';
import { AppError } from './appError';
import { ChainReadError } from './chainReadError';
import type { ChainCall, ChainObservation, ChainAccountResult, ChainHead, GetterArg } from './toncenter';
import { FreshStack, freshInt, freshAddressArg, type FreshChainRead } from './spotContracts';
import { decodeJettonWalletBudget, validateJettonWalletProfile, jettonTransferBody, quoteJettonTransfer,
    type JettonWalletProfile, type JettonQuotePrices } from './jettonWalletProfile';
const invalid = (devMessage: string) => new AppError('errors.unknown', {}, { devMessage });
export const T3_OP = {
    TEP74_TRANSFER: 0x0f8a7ea5, TEP74_BURN: 0x595f07bc,
    T3_MINT: 0x54334d4e, T3_PAIR: 0x5433504d, T3_SWAP: 0x54335357, T3_REDEEM: 0x54335244,
    T3_HUB_ACCEPT: 0x54334841, T3_HUB_REFUND: 0x54334846, T3_HUB_PAIR_BIND: 0x54334842,
    T3_HUB_RECEIPT: 0x5433484c, T3_HUB_MINT_RETRY: 0x5433484d, T3_HUB_PAYOUT_RETRY: 0x54334852,
    T3_WALLET_DELIVERY: 0x5433444c, T3_WALLET_BURN: 0x54335742, T3_WALLET_MINT: 0x5433574d,
    T3_WALLET_MARK: 0x5433574b, T3_WALLET_RETRY: 0x54335759, T3_WALLET_CANCEL: 0x54335758,
    T3_PROOF_STEP: 0x54335046,
} as const;
const OP = T3_OP;
function ordinary(c: Cell): Slice { if (c.isExotic) throw invalid('Expected an ordinary T3 cell'); return c.beginParse(); }
function basechain(a: Address): Address { if (a.workChain !== 0) throw invalid('Expected a basechain address'); return a; }
function slot(value: number, burn = false): number {
    if (!Number.isInteger(value) || value < 0 || value > (burn ? 3 : 2)) throw invalid('Invalid T3 receipt or reserve slot'); return value;
}
function uint(value: bigint, bits: number): bigint { if (value < 0n || value >= 1n << BigInt(bits)) throw invalid('Invalid unsigned T3 field'); return value; }
function coins(value: bigint, positive = false): bigint { uint(value,120); if (positive && value === 0n) throw invalid('A positive T3 amount is required'); return value; }

export type T3WalletDetails = {
    queryId: bigint; response: Address | null; forwardValue: bigint;
    /** Complete original Either, including the inline/reference bit. */
    forwardPayload: Cell; customPayload: Cell | null;
};
export type T3WalletAttempt = {
    id: bigint; originLt: bigint; attempt: bigint; owner: Address; recipient: Address;
    burn: boolean; amount: bigint; details: T3WalletDetails;
};
export type T3WalletRecord = { failed: boolean; cancelled: boolean; attempt: T3WalletAttempt };
export type T3WalletTransfer = {
    queryId?: bigint; amount: bigint; destination: Address; response?: Address | null;
    customPayload?: Cell | null; forwardValue?: bigint; forwardPayload?: Cell;
};
const emptyHash = () => beginCell().storeUint(0, 8).endCell().hash();
const pair = (a: Buffer, b: Buffer, domain: number) => beginCell().storeUint(domain, 8).storeBuffer(a).storeBuffer(b).endCell().hash();
export function t3WalletDetailsToCell(d: T3WalletDetails) {
    return beginCell().storeUint(d.queryId, 64).storeAddress(d.response).storeCoins(d.forwardValue)
        .storeRef(d.forwardPayload).storeMaybeRef(d.customPayload).endCell();
}
export function t3WalletAttemptToCell(a: T3WalletAttempt) {
    const terms = beginCell().storeAddress(a.owner).storeAddress(a.recipient).storeBit(a.burn).storeCoins(a.amount)
        .storeRef(t3WalletDetailsToCell(a.details)).endCell();
    return beginCell().storeUint(a.id, 64).storeUint(a.originLt, 64).storeUint(a.attempt, 64).storeRef(terms).endCell();
}
export function t3WalletAttemptFromCell(c: Cell): T3WalletAttempt {
    const a = ordinary(c); const id = a.loadUintBig(64), originLt = a.loadUintBig(64), attempt = a.loadUintBig(64), t = a.loadRef().beginParse(); a.endParse();
    const owner = t.loadAddress(), recipient = t.loadAddress(), burn = t.loadBit(), amount = t.loadCoins(), d = t.loadRef().beginParse(); t.endParse();
    const details = { queryId: d.loadUintBig(64), response: d.loadMaybeAddress(), forwardValue: d.loadCoins(),
        forwardPayload: d.loadRef(), customPayload: d.loadMaybeRef() }; d.endParse();
    return { id, originLt, attempt, owner, recipient, burn, amount, details };
}
export const t3WalletRecordToCell = (r: T3WalletRecord) => beginCell().storeBit(r.failed).storeBit(r.cancelled).storeRef(t3WalletAttemptToCell(r.attempt)).endCell();
export const t3WalletEvidence = (wallet: Address, a: T3WalletAttempt) => beginCell().storeAddress(wallet).storeRef(t3WalletAttemptToCell(a)).endCell();
export const t3WalletAttemptBody = (a: T3WalletAttempt) => beginCell().storeUint(a.burn ? OP.T3_WALLET_BURN : OP.T3_WALLET_DELIVERY, 32).storeRef(t3WalletAttemptToCell(a)).endCell();
export const t3WalletMintBody = (queryId: bigint, amount: bigint, mintIdentity: Cell, response: Address | null) => beginCell()
    .storeUint(OP.T3_WALLET_MINT, 32).storeUint(queryId, 64).storeCoins(amount).storeRef(mintIdentity).storeAddress(response).endCell();
export function t3WalletTransferBody(p: T3WalletTransfer) {
    return beginCell().storeUint(OP.TEP74_TRANSFER, 32).storeUint(p.queryId ?? 0n, 64).storeCoins(p.amount)
        .storeAddress(p.destination).storeAddress(p.response ?? null).storeMaybeRef(p.customPayload)
        .storeCoins(p.forwardValue ?? 0n).storeSlice((p.forwardPayload ?? beginCell().storeBit(false).endCell()).beginParse()).endCell();
}
export function t3WalletBurnBody(p: { queryId?: bigint; amount: bigint; response?: Address | null; customPayload?: Cell | null }) {
    return beginCell().storeUint(OP.TEP74_BURN, 32).storeUint(p.queryId ?? 0n, 64).storeCoins(p.amount)
        .storeAddress(p.response ?? null).storeMaybeRef(p.customPayload).endCell();
}

export type T3Basket = [bigint, bigint, bigint];
export type T3HubEconomy = { backing: T3Basket; pending: T3Basket; supply: bigint; feeBps: number; admitted: number; frozen: number; withdrawalsOnly: boolean; clears: T3Basket };
export type T3HubCredit = { certified: boolean; owner: Address; queryId: bigint; amount: bigint; intent: Cell; evidence: Cell | null };
export type T3HubMint = { amount: bigint; recipient: Address; attempt: bigint; sentLt: bigint; status: number };
export type T3HubLeg = { amount: bigint; attempt: bigint; sentLt: bigint; status: number; recipient: Address };
export type T3HubPayout = { owner: Address; recipient: Address; queryId: bigint; legs: [T3HubLeg, T3HubLeg, T3HubLeg] };
export type T3HubCreditRecord = { phase: number; linkedSlot: number; linkedKey: bigint; credit: T3HubCredit; mint: T3HubMint | null; payout: T3HubPayout | null; staged: Cell | null };
export type T3HubReceipt = { slot: number; key: bigint; record: Cell };
const readBasket = (s: Slice): T3Basket => [s.loadCoins(), s.loadCoins(), s.loadCoins()];
const readLeg = (s: Slice): T3HubLeg => { const leg = { amount: s.loadCoins(), attempt: s.loadUintBig(64), sentLt: s.loadUintBig(64), status: s.loadUint(1), recipient: s.loadAddress() }; s.endParse(); return leg; };
export function readT3HubEconomy(cell: Cell): T3HubEconomy {
    const s = ordinary(cell), pending = s.loadRef().beginParse(), result = { backing: readBasket(s), pending: [pending.loadUintBig(256), pending.loadUintBig(256), pending.loadUintBig(256)] as T3Basket, supply: s.loadCoins(), feeBps: s.loadUint(16),
        admitted: s.loadUint(3), frozen: s.loadUint(3), withdrawalsOnly: s.loadBit() }; const c = s.loadRef().beginParse(); const clears: T3Basket = [c.loadUintBig(64), c.loadUintBig(64), c.loadUintBig(64)]; c.endParse(); pending.endParse(); s.endParse(); return { ...result, clears };
}
export function readT3HubPayout(cell: Cell): T3HubPayout {
    const s = ordinary(cell), owner = s.loadAddress(), recipient = s.loadAddress(), queryId = s.loadUintBig(64), l = s.loadRef().beginParse();
    const legs: T3HubPayout['legs'] = [readLeg(l.loadRef().beginParse()), readLeg(l.loadRef().beginParse()), readLeg(l.loadRef().beginParse())]; s.endParse(); l.endParse(); return { owner, recipient, queryId, legs };
}
export function readT3HubCreditRecord(receipt: Cell): T3HubCreditRecord {
    const r = ordinary(receipt); r.loadUintBig(64); const s = r.loadRef().beginParse(); r.endParse();
    const phase = s.loadUint(3), linkedSlot = s.loadUint(2), linkedKey = s.loadUintBig(64), c = s.loadRef().beginParse(), m = s.loadMaybeRef(), p = s.loadMaybeRef(), staged = s.loadMaybeRef(); s.endParse();
    const credit = { certified: c.loadBit(), owner: c.loadAddress(), queryId: c.loadUintBig(64), amount: c.loadCoins(), intent: c.loadRef(), evidence: c.loadMaybeRef() }; c.endParse();
    let mint: T3HubMint | null = null;
    if (m) { const x = m.beginParse(); mint = { amount: x.loadCoins(), recipient: x.loadAddress(), attempt: x.loadUintBig(64), sentLt: x.loadUintBig(64), status: x.loadUint(1) }; x.endParse(); }
    return { phase, linkedSlot, linkedKey, credit, mint, payout: p ? readT3HubPayout(p) : null, staged };
}
export function readT3HubBurnRecord(receipt: Cell): { attempt: T3WalletAttempt; payout: T3HubPayout | null } {
    const r = ordinary(receipt); r.loadUintBig(64); const s = r.loadRef().beginParse(); r.endParse();
    const attempt = t3WalletAttemptFromCell(s.loadRef()), p = s.loadMaybeRef(); s.endParse(); return { attempt, payout: p ? readT3HubPayout(p) : null };
}

export function t3HubIntent(kind: 'mint' | 'pair' | 'swap' | 'redeem', recipient: Address, minOut = 0n, output = 0, strict = false, single = false) {
    const b = beginCell().storeUint({ mint: OP.T3_MINT, pair: OP.T3_PAIR, swap: OP.T3_SWAP, redeem: OP.T3_REDEEM }[kind], 32);
    if (kind === 'redeem') b.storeBit(single);
    if (kind === 'swap' || kind === 'redeem') b.storeUint(output, 2).storeBit(strict);
    return b.storeCoins(minOut).storeAddress(recipient).endCell();
}

export type T3ProofTarget = { hash: bigint; lt: bigint; anchor: bigint };
export type T3ProofConfig = {
    nonce: bigint; controller: Address; hub: Address; master: Address;
    request: Cell; sourceWallet: Address; targetWallet: Address;
    queryId: bigint; amount: bigint; walletCodeHash: bigint;
    source: T3ProofTarget; target: T3ProofTarget;
};
export const T3_PROOF_STEP = {
    sourceAnchor: 10, sourceAccounts: 11, sourceTransactions: 12, sourceCredit: 13,
    sourceFailure: 14, sourceHistoricalAnchor: 15, sourceNotification: 16, sourceBounce: 17,
    targetAnchor: 20, targetAccounts: 21, targetTransactions: 22, targetCredit: 23, targetFailure: 24,
    targetHistoricalAnchor: 25, certifyFailure: 30, certifyCredit: 31,
} as const;
export const t3ProofStep = (step: number) => beginCell().storeUint(OP.T3_PROOF_STEP, 32).storeUint(step, 8);
const targetCell = (t: T3ProofTarget) => beginCell().storeUint(t.hash, 256).storeUint(t.lt, 64).storeUint(t.anchor, 256).endCell();
/** Preserve only complete scalar first-release T3 deposit instructions. */
export function t3DepositIntent(payload: Cell): Cell {
    if (payload.isExotic || payload.refs.length !== 0) return Cell.EMPTY;
    try {
        const s = payload.beginParse(), op = s.loadUint(32);
        if (op === OP.T3_SWAP) { if (s.loadUint(2) > 2) return Cell.EMPTY; s.loadBit(); }
        else if (op !== OP.T3_MINT && op !== OP.T3_PAIR) return Cell.EMPTY;
        s.loadCoins(); const recipient = s.loadAddress(); s.endParse();
        return recipient.workChain === 0 ? payload : Cell.EMPTY;
    } catch { return Cell.EMPTY; }
}
export function t3RequestIntent(request: Cell): Cell {
    if (request.isExotic) throw invalid('Request root must be revealed');
    const s = request.beginParse();
    if (s.remainingBits < 32 || s.loadUint(32) !== OP.TEP74_TRANSFER) return Cell.EMPTY;
    s.loadUintBig(64); s.loadCoins(); s.loadAddress(); s.loadAddressAny(); s.loadMaybeRef(); s.loadCoins();
    const byRef = s.loadBit(), payload = byRef ? s.loadRef() : beginCell().storeSlice(s).endCell();
    if (byRef) s.endParse();
    if (payload.type === CellType.PrunedBranch) throw invalid('Deposit payload root must be revealed');
    return t3DepositIntent(payload);
}

/** A level-zero envelope transports a projected chain cell in an ordinary message. */
export function t3ProofEnvelope(tree: Cell): Cell {
    return new Cell({ exotic: true, bits: beginCell().storeUint(3, 8).storeBuffer(tree.hash(0))
        .storeUint(tree.depth(0), 16).endCell().bits, refs: [tree] });
}
/** Keep opaque roots visible but omit their children from a level-zero chain proof.
 * The on-chain verifier still requires every field it reads; this grants no authority.
 */
export function t3ProjectOpaqueChildren(root: Cell, opaqueRoots: readonly Cell[]): Cell {
    const selected = new Set(opaqueRoots.map(c => c.hash(0).toString('hex'))), cache = new Map<Cell, Cell>();
    const prune = (c: Cell, shifted: boolean) => {
        // A Merkle root hashes its children at level one. Keep both original levels;
        // the added pruned level is consumed by the outer transaction-proof envelope.
        const b = beginCell().storeUint(1, 8).storeUint(shifted ? 3 : 1, 8);
        for (let level = 0; level <= Number(shifted); level++) b.storeBuffer(c.hash(level));
        for (let level = 0; level <= Number(shifted); level++) b.storeUint(c.depth(level), 16);
        return new Cell({ exotic: true, bits: b.endCell().bits });
    };
    const walk = (c: Cell): Cell => {
        const cached = cache.get(c); if (cached) return cached;
        const picked = selected.has(c.hash(0).toString('hex'));
        if (c.isExotic && !picked) return c;
        const shifted = c.type === CellType.MerkleProof || c.type === CellType.MerkleUpdate;
        const refs = picked ? c.refs.map(ref => prune(ref, shifted)) : c.refs.map(walk);
        const result = refs.every((r, i) => r === c.refs[i]) ? c : new Cell({ exotic: c.isExotic, bits: c.bits, refs });
        if (!result.hash(0).equals(c.hash(0)) || result.depth(0) !== c.depth(0)) throw invalid('Invalid proof projection');
        cache.set(c, result); return result;
    };
    return walk(root);
}
export function t3ProofConfigToCell(c: T3ProofConfig): Cell {
    const identities = beginCell().storeAddress(c.controller).storeAddress(c.hub).storeAddress(c.master).endCell();
    const wallets = beginCell().storeAddress(c.sourceWallet).storeAddress(c.targetWallet).storeUint(c.queryId, 64).storeCoins(c.amount).endCell();
    const credit = beginCell().storeRef(identities).storeBuffer(c.request.hash(0)).storeRef(t3RequestIntent(c.request)).storeRef(wallets).storeUint(c.walletCodeHash, 256).endCell();
    return beginCell().storeUint(c.nonce, 256).storeRef(credit)
        .storeRef(beginCell().storeRef(targetCell(c.source)).storeRef(targetCell(c.target)).endCell()).endCell();
}
export function t3ProofData(config: Cell): Cell {
    const cursor = beginCell().storeUint(0, 256).storeUint(0, 256).storeUint(0, 9).storeUint(0, 64).endCell();
    return beginCell().storeRef(config).storeUint(0, 3).storeUint(0, 256).storeRef(cursor).storeUint(0,2).endCell();
}

export type T3ReceiptTree = { root: bigint; initialized: boolean; lastKey: bigint; lastLeaf: bigint; frontier: Cell | null };
export function readT3ReceiptTree(cell: Cell): T3ReceiptTree {
    const s = ordinary(cell), result = { root: s.loadUintBig(256), initialized: s.loadBit(), lastKey: s.loadUintBig(64), lastLeaf: s.loadUintBig(256), frontier: s.loadMaybeRef() };
    s.endParse(); return result;
}
export function readT3ReceiptLog(body: Cell): { slot: number; key: bigint; record: Cell } | null {
    try {
        const s = ordinary(body); if (s.loadUint(32) !== OP.T3_HUB_RECEIPT) return null;
        const selected = s.loadUint(2), record = s.loadRef(); s.endParse();
        const r = ordinary(record), key = r.loadUintBig(64); r.loadRef(); r.endParse();
        if (selected === 3) readT3HubBurnRecord(record); else readT3HubCreditRecord(record);
        return { slot: selected, key, record };
    } catch { return null; }
}

/** A log is a receipt candidate. Only membership in the current on-chain root authorizes a claim. */
export function verifyT3Witness(record: Cell, key: bigint, proof: Cell, root: bigint, leafDomain = 3): boolean {
    try {
        uint(key,64); uint(root,256); ordinary(record);
        let hash = beginCell().storeUint(leafDomain,8).storeRef(record).endCell().hash(), cursor = key, next: Cell | null = proof;
        for (let level = 0; level < 64; level++) {
            if (!next) return false;
            const s = ordinary(next), sibling = s.loadBuffer(32); next = s.loadMaybeRef(); s.endParse();
            hash = beginCell().storeUint(leafDomain + 1,8).storeBuffer(cursor & 1n ? sibling : hash).storeBuffer(cursor & 1n ? hash : sibling).endCell().hash();
            cursor >>= 1n;
        }
        return next === null && BigInt('0x' + hash.toString('hex')) === root;
    } catch { return false; }
}
export const t3HubWitness = (record: Cell, proof: Cell) => beginCell().storeRef(record).storeRef(proof).endCell();
export function readT3WalletRecord(cell: Cell): T3WalletRecord {
    const s = ordinary(cell), result = { failed: s.loadBit(), cancelled: s.loadBit(), attempt: t3WalletAttemptFromCell(s.loadRef()) }; s.endParse(); return result;
}
export function readT3Intent(cell: Cell): { kind: 'mint' | 'pair' | 'swap' | 'redeem'; recipient: Address; minimum: bigint; output: number; strict: boolean; single: boolean } {
    const s = ordinary(cell), op = s.loadUint(32);
    const kind = ({ [OP.T3_MINT]: 'mint', [OP.T3_PAIR]: 'pair', [OP.T3_SWAP]: 'swap', [OP.T3_REDEEM]: 'redeem' } as const)[op];
    if (!kind) throw invalid('Invalid fresh T3 intent');
    const single = kind === 'redeem' ? s.loadBit() : false;
    const output = kind === 'swap' || kind === 'redeem' ? slot(s.loadUint(2)) : 0;
    const strict = kind === 'swap' || kind === 'redeem' ? s.loadBit() : false;
    const minimum = s.loadCoins(), recipient = basechain(s.loadAddress()); s.endParse();
    if (kind === 'redeem' && !single && (output !== 0 || strict || minimum !== 0n)) throw invalid('A proportional exit has no aggregate minimum');
    return { kind, recipient, minimum, output, strict, single };
}
type ReservePolicy = { scale: number; codeHash: bigint; lockExit: number; balanceExit: number };
const policyValue: DictionaryValue<ReservePolicy> = { serialize() { throw invalid('Read-only reserve policy'); }, parse: s => {
    const value = { scale: s.loadUint(32), codeHash: s.loadUintBig(256), lockExit: s.loadUint(16), balanceExit: s.loadUint(16) }; s.endParse(); return value;
} };
export function readT3Config(cell: Cell) {
    const s = ordinary(cell), result = { governance: basechain(s.loadAddress()), proofCodeHash: s.loadUintBig(256), amp: s.loadUint(16), rentBits: s.loadUint(32), rentCells: s.loadUint(32),
        walletCode: s.loadRef(), metadata: s.loadRef(), policies: s.loadDict(Dictionary.Keys.Uint(8), policyValue) };
    s.endParse(); if (result.amp < 100 || result.amp > 250 || result.policies.size !== 3) throw invalid('Invalid T3 configuration'); return result;
}
export type T3ReserveSlot = JettonWalletProfile & { master: Address; wallet: Address | null; optional: boolean };
const reserveValue: DictionaryValue<T3ReserveSlot> = { serialize() { throw invalid('Read-only reserve slot'); }, parse(s) {
    const value = { master: basechain(s.loadAddress()), wallet: s.loadMaybeAddress(), walletGas: s.loadUint(32), walletGram: s.loadCoins(), optional: s.loadBit(), budget: decodeJettonWalletBudget(s.loadRef()) };
    s.endParse(); if (value.wallet) basechain(value.wallet); validateJettonWalletProfile(value); return value;
} };
export function readT3Storage(data: Cell) {
    const s = ordinary(data), config = readT3Config(s.loadRef()), ledger = ordinary(s.loadRef()), economy = readT3HubEconomy(s.loadRef()), trees = ordinary(s.loadRef()); s.endParse();
    const reserves = ledger.loadDict(Dictionary.Keys.Uint(8),reserveValue); ledger.loadMaybeRef(); ledger.endParse();
    const receipts = [0,1,2,3].map(() => readT3ReceiptTree(trees.loadRef())); trees.endParse();
    return { config, economy, reserves, receipts };
}
export type T3ReservePin = { slot: 0 | 1 | 2; master: Address; masterCodeHash: string; decimals: number; walletCodeHash: string };
export type T3ReleasePins = { codeHash: string; walletCodeHash: string; proofCodeHash: string; governance: Address; reserves: readonly T3ReservePin[] };
/** Input must first pass the application's complete current release-manifest validator. */
export function bindT3Manifest(manifest:{contracts:Partial<Record<'T3Hub'|'Governance'|'USDT'|'USDC'|'KUSD',{address:string;codeHash:string}>>;templates:{T3Wallet:string;T3RecoveryProof:string};tokens:readonly {symbol:string;root:string;decimals:number;masterCodeHash:string;walletCodeHash:string}[]}){
    const hub=manifest.contracts.T3Hub,governance=manifest.contracts.Governance,t3=manifest.tokens.filter(t=>t.symbol==='T3');
    if(!hub||!governance||t3.length!==1||t3[0].root!==hub.address||t3[0].decimals!==9||t3[0].masterCodeHash!==hub.codeHash||t3[0].walletCodeHash!==manifest.templates.T3Wallet)throw invalid('T3 master/manifest binding is invalid');
    const reserves=(['USDT','USDC','KUSD'] as const).map((symbol,index)=>{
        const matches=manifest.tokens.filter(t=>t.symbol===symbol),contract=manifest.contracts[symbol];
        if(matches.length!==1||!contract||matches[0].root!==contract.address||matches[0].masterCodeHash!==contract.codeHash)throw invalid('Missing exact reserve manifest binding');
        const token=matches[0];return{slot:index as 0|1|2,master:basechain(Address.parse(token.root)),masterCodeHash:token.masterCodeHash,walletCodeHash:token.walletCodeHash,decimals:token.decimals};
    });
    return{address:basechain(Address.parse(hub.address)),pins:{codeHash:hub.codeHash,walletCodeHash:manifest.templates.T3Wallet,proofCodeHash:manifest.templates.T3RecoveryProof,governance:basechain(Address.parse(governance.address)),reserves} satisfies T3ReleasePins};
}
export type T3TransactionPlan = { address: Address; value: bigint; body: Cell; bounce: boolean; head: ChainHead };
const hashPattern = /^[0-9a-f]{64}$/;
function checkPins(state: ReturnType<typeof readT3Storage>, pins: T3ReleasePins) {
    if (![pins.codeHash,pins.walletCodeHash,pins.proofCodeHash].every(h => hashPattern.test(h)) || !state.config.governance.equals(pins.governance)
        || state.config.walletCode.hash().toString('hex') !== pins.walletCodeHash || state.config.proofCodeHash !== BigInt('0x' + pins.proofCodeHash)
        || pins.reserves.length !== state.reserves.size || pins.reserves.length < 2 || new Set(pins.reserves.map(p => p.slot)).size !== pins.reserves.length) throw invalid('T3 configuration differs from the release');
    for (const pin of pins.reserves) {
        slot(pin.slot); const actual = state.reserves.get(pin.slot), policy = state.config.policies.get(pin.slot);
        if (!actual || !policy || !hashPattern.test(pin.walletCodeHash) || !hashPattern.test(pin.masterCodeHash) || !Number.isInteger(pin.decimals) || pin.decimals < 0 || pin.decimals > 9
            || !actual.master.equals(pin.master) || actual.optional !== (pin.slot === 2)
            || policy.scale !== 10 ** (9-pin.decimals) || policy.codeHash !== BigInt('0x' + pin.walletCodeHash)) throw invalid('T3 reserve differs from its qualified release identity');
    }
    if (!state.reserves.has(0) || !state.reserves.has(1)) throw invalid('Missing core T3 reserves');
}
function checkObservation(observation: ChainObservation, count: number): ChainHead {
    if (!observation.head || !Number.isSafeInteger(observation.head.seqno) || observation.head.seqno <= 0 || observation.results.length !== count) throw new ChainReadError('unavailable', { devMessage: 'Missing anchored T3 observation' });
    return observation.head;
}
function activeAccount(result: ChainObservation['results'][number], expectedHash: string): ChainAccountResult {
    if (result?.kind !== 'account' || result.state !== 'active' || !result.code || !result.data || result.code.hash().toString('hex') !== expectedHash) throw invalid('T3 account code differs from release or is not active'); return result;
}
const getter = (address: Address, method: string, args: readonly GetterArg[] = []): ChainCall => ({ kind: 'getter', address: address.toRawString(), method, args });
const cellArg = (cell: Cell): GetterArg => ({ type: 'cell', cell });
// The readChain codec encodes absent cell payloads as TVM null.
const optionalAddress = (a: Address | null): GetterArg => a ? freshAddressArg(basechain(a)) : { type: 'cell' };
function resultStack(result: ChainObservation['results'][number]): FreshStack {
    if (result?.kind !== 'getter' || result.exitCode !== 0) throw invalid('T3 getter failed'); return new FreshStack(result.stack);
}
function quoteStack(s: FreshStack) {
    const quote = { status: s.number(8), detail: s.number(32), minted: s.uint(), payout: [s.uint(),s.uint(),s.uint()] as T3Basket, feeBps: s.number(16) }; s.end(); return quote;
}
function quoteArgs(intent: Cell, input: number, amount: bigint, staged: bigint, burn: boolean): GetterArg[] {
    readT3Intent(intent); slot(input); coins(amount,true); coins(staged);
    return [cellArg(intent),freshInt(input),freshInt(amount),freshInt(staged),freshInt(burn ? -1 : 0)];
}

/** The master is the hub. Every getter batch checks its code and immutable configuration at the same block. */
export function createT3Hub(read: FreshChainRead, address: Address, pins: T3ReleasePins) {
    basechain(address);
    const batch = async (calls: readonly ChainCall[] = []) => {
        const all: ChainCall[] = [{ kind: 'account', address: address.toRawString() }, ...calls];
        const observation = await read(all,{ anchored:true,lane:'user' }), head = checkObservation(observation,all.length);
        const account = activeAccount(observation.results[0],pins.codeHash), state = readT3Storage(account.data!); checkPins(state,pins);
        return { head, account, state, results: observation.results.slice(1) };
    };
    const get = async (method: string,args: readonly GetterArg[] = []) => { const result = await batch([getter(address,method,args)]); return { ...result, stack: resultStack(result.results[0]) }; };
    const min = async (method: string,args: readonly GetterArg[] = []) => { const { stack, head } = await get(method,args); const value = stack.uint(); stack.end(); return { value,head }; };
    return { address, pins, batch,
        getSnapshot: () => batch(),
        async getWalletAddress(owner: Address) { const { stack,head } = await get('get_wallet_address',[freshAddressArg(basechain(owner))]); const wallet = stack.address()!; stack.end(); return { wallet,head }; },
        async getJettonData() { const { stack:s,head } = await get('get_jetton_data'); const value = { supply:s.uint(),mintable:s.bool(),admin:s.address(true),metadata:s.cell()!,walletCode:s.cell()!,head }; s.end(); return value; },
        async getQuote(intent: Cell,input: number,amount: bigint,staged=0n,burn=false) { const { stack,head } = await get('get_quote',quoteArgs(intent,input,amount,staged,burn)); return { ...quoteStack(stack),head }; },
        getMinExecute: (intent: Cell,input: number,amount: bigint,staged: bigint,burn: boolean,owner: Address) => min('get_min_execute',[...quoteArgs(intent,input,amount,staged,burn),freshAddressArg(basechain(owner))]),
        getMinValue: (op: number) => min('get_min_value',[freshInt(op)]),
        getMinRefund: (selected: number,record: Cell,recipient: Address | null = null) => min('get_min_refund',[freshInt(slot(selected)),cellArg(record),optionalAddress(recipient)]),
        getMinMintRetry: (selected: number,record: Cell) => min('get_min_mint_retry',[freshInt(slot(selected)),cellArg(record)]),
        getMinPayoutRetry: (selected: number,output: number,record: Cell) => min('get_min_payout_retry',[freshInt(slot(selected,true)),freshInt(slot(output)),cellArg(record)]),
    };
}
export type T3HubReader = ReturnType<typeof createT3Hub>;
export type T3Operation = { kind:'mint'|'pair'|'swap'|'redeem'; owner:Address; recipient:Address; input:0|1|2; amount:bigint; staged?:bigint; output?:0|1|2; single?:boolean; slippageBps?:number };
export async function planT3Operation(hub:T3HubReader, operation:T3Operation) {
    const { kind,owner,recipient,input,amount,staged=0n,output=0,single=false,slippageBps=50 } = operation;
    basechain(owner); basechain(recipient); slot(input); slot(output); coins(amount,true); coins(staged);
    if ((kind!=='pair' && staged!==0n) || (kind!=='redeem' && single) || (kind==='redeem' && !single && output!==0)
        || !Number.isInteger(slippageBps) || slippageBps<0 || slippageBps>10000) throw invalid('Invalid T3 operation');
    const burn=kind==='redeem', probe=t3HubIntent(kind,recipient,0n,output,false,single);
    const initial=await hub.getQuote(probe,input,amount,staged,burn);
    if (initial.status!==0) throw invalid(`T3 quote refused: ${initial.status}/${initial.detail}`);
    const raw=kind==='mint'||kind==='pair'?initial.minted:initial.payout[output];
    const minimum=burn&&!single?0n:raw*BigInt(10000-slippageBps)/10000n;
    const intent=t3HubIntent(kind,recipient,minimum,output,false,single), args=quoteArgs(intent,input,amount,staged,burn);
    const current=await hub.batch([getter(hub.address,'get_quote',args),getter(hub.address,'get_min_execute',[...args,freshAddressArg(owner)])]);
    const quote=quoteStack(resultStack(current.results[0])), funding=resultStack(current.results[1]), hubValue=funding.uint(); funding.end();
    if (quote.status!==0) throw invalid(`T3 quote changed or refused: ${quote.status}/${quote.detail}`);
    return { intent,minimum,hubValue,quote,head:current.head };
}

export type T3ReceiptWitness = { slot:number; record:Cell; proof:Cell };
function requireReceipt(state:ReturnType<typeof readT3Storage>, witness:T3ReceiptWitness):bigint {
    slot(witness.slot,true); const s=ordinary(witness.record), key=s.loadUintBig(64); s.loadRef(); s.endParse();
    if (!verifyT3Witness(witness.record,key,witness.proof,state.receipts[witness.slot].root)) throw invalid('Stale or invalid T3 receipt witness'); return key;
}
export type T3ClaimAction = { kind:'accept'|'refund'|'mintRetry'|'payoutRetry'; witness:T3ReceiptWitness; caller:Address; recipient?:Address|null; output?:0|1|2 };
/** Hub claims retain their exact physical identity; they are never generic CLMJ/CLMA owed claims. */
export async function prepareT3Claim(hub:T3HubReader, action:T3ClaimAction):Promise<T3TransactionPlan> {
    const {kind,witness,caller,recipient=null,output=0}=action; basechain(caller); if(recipient)basechain(recipient); slot(witness.slot,true); slot(output);
    if(!['accept','refund','mintRetry','payoutRetry'].includes(kind))throw invalid('Unknown T3 claim action');
    const credit=witness.slot<3?readT3HubCreditRecord(witness.record):null, burn=witness.slot===3?readT3HubBurnRecord(witness.record):null;
    const owner=credit?.credit.owner??burn!.attempt.owner;
    if (kind!=='payoutRetry' && !credit) throw invalid('This action requires a reserve credit receipt');
    let method:string,args:GetterArg[],body:Cell,acceptQuote:ChainCall|null=null;
    const w=t3HubWitness(witness.record,witness.proof);
    if(kind==='accept') {
        if(recipient || ![0,4].includes(credit!.phase))throw invalid('Credit is not pending or sealed');
        let intent=credit!.credit.intent, staged=0n;
        if(credit!.phase===4){
            if(!credit!.staged)throw invalid('Missing sealed pair credit');
            const c=ordinary(credit!.staged); c.loadBit(); const a=c.loadAddress(); c.loadUintBig(64); staged=c.loadCoins(); const first=readT3Intent(c.loadRef()); c.loadMaybeRef(); c.endParse();
            const second=readT3Intent(intent); if(!a.equals(owner)||first.kind!=='pair'||second.kind!=='pair'||!first.recipient.equals(second.recipient))throw invalid('Invalid sealed pair');
            intent=t3HubIntent('pair',second.recipient,first.minimum>second.minimum?first.minimum:second.minimum);
        }
        if(credit!.phase===0&&readT3Intent(intent).kind==='pair')throw invalid('A pair credit must be bound and sealed before acceptance');
        method='get_min_execute'; args=[...quoteArgs(intent,witness.slot,credit!.credit.amount,staged,false),freshAddressArg(owner)];
        acceptQuote=getter(hub.address,'get_quote',args.slice(0,-1));
        body=beginCell().storeUint(OP.T3_HUB_ACCEPT,32).storeUint(witness.slot,2).storeRef(w).endCell();
    }else if(kind==='refund'){
        if(!caller.equals(owner)||![0,4].includes(credit!.phase))throw invalid('Only the owner may refund a pending credit');
        method='get_min_refund';args=[freshInt(witness.slot),cellArg(witness.record),optionalAddress(recipient)];
        body=beginCell().storeUint(OP.T3_HUB_REFUND,32).storeUint(witness.slot,2).storeAddress(recipient).storeRef(w).endCell();
    }else if(kind==='mintRetry'){
        if(credit!.phase!==2||credit!.mint?.status!==1||credit!.mint.attempt===(1n<<64n)-1n)throw invalid('Mint retry requires a verified current failure');
        if(recipient&&!recipient.equals(credit!.mint.recipient)&&!caller.equals(owner))throw invalid('Only the credit owner may redirect');
        method='get_min_mint_retry';args=[freshInt(witness.slot),cellArg(witness.record)];
        body=beginCell().storeUint(OP.T3_HUB_MINT_RETRY,32).storeUint(witness.slot,2).storeAddress(recipient).storeRef(w).endCell();
    }else{
        const leg=(credit?.payout??burn?.payout)?.legs[output];
        if(!leg||leg.amount===0n||leg.status!==1||leg.attempt===(1n<<64n)-1n)throw invalid('Payout retry requires a verified current failure');
        if(recipient&&!recipient.equals(leg.recipient)&&!caller.equals(owner))throw invalid('Only the claim owner may redirect');
        method='get_min_payout_retry';args=[freshInt(witness.slot),freshInt(output),cellArg(witness.record)];
        body=beginCell().storeUint(OP.T3_HUB_PAYOUT_RETRY,32).storeUint(witness.slot,2).storeUint(output,2).storeAddress(recipient).storeRef(w).endCell();
    }
    const current=await hub.batch([getter(hub.address,method,args),...(acceptQuote?[acceptQuote]:[])]); requireReceipt(current.state,witness);
    if(acceptQuote&&quoteStack(resultStack(current.results[1])).status!==0)throw invalid('Pending T3 credit quote refused');
    const s=resultStack(current.results[0]),value=s.uint();s.end();return{address:hub.address,value,body,bounce:true,head:current.head};
}
export async function prepareT3Pair(hub:T3HubReader,caller:Address,mode:0|1|2,first:T3ReceiptWitness,second:T3ReceiptWitness):Promise<T3TransactionPlan>{
    if(![0,1,2].includes(mode)||first.slot>1||second.slot!==1-first.slot)throw invalid('Invalid T3 pair binding');
    const a=readT3HubCreditRecord(first.record),b=readT3HubCreditRecord(second.record),ai=readT3Intent(a.credit.intent),bi=readT3Intent(b.credit.intent);
    if(!a.credit.owner.equals(caller)||!b.credit.owner.equals(caller))throw invalid('Only the common credit owner may bind pairs');
    if(ai.kind!=='pair'||bi.kind!=='pair'||!ai.recipient.equals(bi.recipient))throw invalid('Pair recipients or intents differ');
    const current=await hub.batch([getter(hub.address,'get_min_value',[freshInt(OP.T3_HUB_PAIR_BIND)])]),aKey=requireReceipt(current.state,first),bKey=requireReceipt(current.state,second);
    if(mode===0){if(a.phase!==0||b.phase!==0)throw invalid('Pair binding requires two pending credits');}
    else if(a.phase!==1||a.linkedSlot!==second.slot||a.linkedKey!==bKey||mode===2&&b.phase!==0
        ||mode===1&&[2,4].includes(b.phase)&&b.linkedSlot===first.slot&&b.linkedKey===aKey)throw invalid('Pair link or phase forbids this transition');
    const s=resultStack(current.results[0]),value=s.uint();s.end();
    return{address:hub.address,value,body:beginCell().storeUint(OP.T3_HUB_PAIR_BIND,32).storeUint(mode,2).storeUint(first.slot,2).storeRef(t3HubWitness(first.record,first.proof)).storeRef(t3HubWitness(second.record,second.proof)).endCell(),bounce:true,head:current.head};
}

/** Prices must be authenticated for the same block as the final hub/wallet read. */
export async function prepareT3Deposit(hub:T3HubReader,request:{owner:Address;input:0|1|2;amount:bigint;intent:Cell;queryId:bigint;sourceWallet:Address;prices:JettonQuotePrices;masterchainSeqno:number}) {
    const { owner,input,amount,intent,queryId,sourceWallet,prices,masterchainSeqno }=request;
    basechain(owner);basechain(sourceWallet);coins(amount,true);uint(queryId,64);slot(input);
    const decoded=readT3Intent(intent);if(decoded.kind==='redeem')throw invalid('Redemption uses a T3 burn');
    const pin=hub.pins.reserves.find(p=>p.slot===input);if(!pin)throw invalid('Reserve is not configured');
    const args=quoteArgs(intent,input,amount,0n,false),pairDeposit=decoded.kind==='pair';
    const calls=[getter(pin.master,'get_wallet_address',[freshAddressArg(owner)]),{kind:'account' as const,address:sourceWallet.toRawString()},getter(sourceWallet,'get_wallet_data'),
        getter(hub.address,'get_quote',args),pairDeposit?getter(hub.address,'get_min_value',[freshInt(OP.T3_HUB_ACCEPT)]):getter(hub.address,'get_min_execute',[...args,freshAddressArg(owner)])];
    calls.push({kind:'account',address:pin.master.toRawString()},getter(pin.master,'get_wallet_address',[freshAddressArg(hub.address)]));
    const current=await hub.batch(calls),[addressResult,account,walletResult,quoteResult,valueResult]=current.results;
    if(current.head.seqno!==masterchainSeqno)throw new ChainReadError('unavailable',{devMessage:'Refresh T3 funding prices for the current block'});
    const canonical=resultStack(addressResult),wallet=canonical.address()!;canonical.end();
    if(!wallet.equals(sourceWallet))throw invalid('Source wallet is not the master-selected owner wallet');
    activeAccount(account,pin.walletCodeHash);
    const w=resultStack(walletResult),balance=w.uint(),walletOwner=w.address()!,master=w.address()!,code=w.cell()!;w.end();
    if(!walletOwner.equals(owner)||!master.equals(pin.master)||code.hash().toString('hex')!==pin.walletCodeHash||balance<amount)throw invalid('Source wallet binding or balance is invalid');
    const reserve=current.state.reserves.get(input)!;if(!reserve.wallet)throw invalid('Hub reserve wallet discovery is incomplete');
    activeAccount(current.results[5],pin.masterCodeHash);
    const destination=resultStack(current.results[6]),reserveWallet=destination.address()!;destination.end();
    if(!reserveWallet.equals(reserve.wallet))throw invalid('Hub reserve wallet differs from the pinned master binding');
    const quote=quoteStack(resultStack(quoteResult));if(!pairDeposit&&quote.status!==0)throw invalid(`T3 quote refused: ${quote.status}/${quote.detail}`);
    const v=resultStack(valueResult),hubValue=v.uint();v.end();
    const transfer={queryId,amount,destination:hub.address,responseDestination:owner,forwardGram:hubValue,forwardPayload:intent,either:'ref' as const};
    const value=quoteJettonTransfer(prices,reserve,transfer);
    return{address:sourceWallet,value,body:jettonTransferBody(transfer),bounce:true,head:current.head,hubValue,quote,
        // Pair collateral is registered separately, then bound/sealed/accepted with current witnesses.
        requiresPairBinding:pairDeposit,sourceNativeBalance:(account as ChainAccountResult).balance};
}
export function t3WalletInitialData(owner:Address,master:Address,proofCodeHash:bigint):Cell{
    basechain(owner);basechain(master);uint(proofCodeHash,256);
    let empty=emptyHash();for(let i=0;i<64;i++)empty=pair(empty,empty,4);
    return beginCell().storeRef(beginCell().storeAddress(owner).storeAddress(master).storeUint(proofCodeHash,256).endCell())
        .storeCoins(0n).storeUint(0n,65).storeBuffer(empty).storeRef(beginCell().storeUint(0n,64).storeUint(0n,256).storeDict(null).endCell())
        .storeDict(null).storeUint(0n,256).storeUint(0n,256).endCell();
}
export function readT3WalletStorage(data:Cell){
    const s=ordinary(data),cfg=ordinary(s.loadRef()),owner=basechain(cfg.loadAddress()),master=basechain(cfg.loadAddress()),proofCodeHash=cfg.loadUintBig(256);cfg.endParse();
    const balance=s.loadCoins(),count=s.loadUintBig(65),root=s.loadUintBig(256),journal=ordinary(s.loadRef());
    const failures=journal.loadUintBig(64),failureRoot=journal.loadUintBig(256);journal.loadDict(Dictionary.Keys.Uint(8),Dictionary.Values.BigUint(256));journal.endParse();
    s.loadDict(Dictionary.Keys.Uint(8),Dictionary.Values.BigUint(256));const protectedCredits=s.loadUintBig(256),acceptedTransfers=s.loadUintBig(256);s.endParse();
    return{owner,master,proofCodeHash,balance,count,root,failures,failureRoot,protectedCredits,acceptedTransfers};
}
export function createT3Wallet(read:FreshChainRead,owner:Address,hub:T3HubReader,walletCode:Cell){
    if(walletCode.hash().toString('hex')!==hub.pins.walletCodeHash)throw invalid('T3 wallet code differs from release');
    const proofCodeHash=BigInt('0x'+hub.pins.proofCodeHash),init={code:walletCode,data:t3WalletInitialData(owner,hub.address,proofCodeHash)},address=contractAddress(0,init);
    const batch=async(calls:readonly ChainCall[]=[])=>{
        const result=await hub.batch([{kind:'account',address:address.toRawString()},...calls]);
        const account=activeAccount(result.results[0],hub.pins.walletCodeHash),state=readT3WalletStorage(account.data!);
        if(!state.owner.equals(owner)||!state.master.equals(hub.address)||state.proofCodeHash!==proofCodeHash)throw invalid('T3 wallet state differs from its derived identity');
        return{head:result.head,account,state,results:result.results.slice(1),hubState:result.state};
    };
    return{address,owner,init,hub,batch,getSnapshot:()=>batch()};
}
export type T3WalletReader=ReturnType<typeof createT3Wallet>;
export async function prepareT3Redemption(hub:T3HubReader,wallet:T3WalletReader,request:Omit<T3Operation,'kind'|'owner'> & {queryId:bigint}):Promise<T3TransactionPlan & {hubValue:bigint;walletValue:bigint;minimum:bigint}> {
    if(!wallet.hub.address.equals(hub.address)||wallet.hub.pins.codeHash!==hub.pins.codeHash||wallet.hub.pins.walletCodeHash!==hub.pins.walletCodeHash||wallet.hub.pins.proofCodeHash!==hub.pins.proofCodeHash)throw invalid('Redemption wallet belongs to another release hub');
    uint(request.queryId,64);const plan=await planT3Operation(hub,{...request,kind:'redeem',owner:wallet.owner});
    const attempt:T3WalletAttempt={id:0n,originLt:0n,attempt:0n,owner:wallet.owner,recipient:wallet.owner,burn:true,amount:request.amount,
        details:{queryId:request.queryId,response:wallet.owner,forwardValue:0n,forwardPayload:beginCell().storeBit(false).endCell(),customPayload:plan.intent}};
    const args=quoteArgs(plan.intent,request.input,request.amount,0n,true);
    const current=await wallet.batch([getter(hub.address,'get_quote',args),getter(hub.address,'get_min_execute',[...args,freshAddressArg(wallet.owner)]),getter(wallet.address,'outgoing_value',[cellArg(t3WalletAttemptToCell(attempt))])]);
    if(current.state.balance<request.amount||current.state.count>=1n<<64n)throw invalid('Insufficient T3 balance or exhausted wallet sequence');
    const quote=quoteStack(resultStack(current.results[0]));if(quote.status!==0)throw invalid('T3 redemption quote changed or refused');
    const h=resultStack(current.results[1]),w=resultStack(current.results[2]),hubValue=h.uint(),walletValue=w.uint();h.end();w.end();
    // outgoing_value includes source storage debt/cold transport. Burn redemption separately funds the hub.
    return{address:wallet.address,value:hubValue+walletValue,body:t3WalletBurnBody({queryId:request.queryId,amount:request.amount,response:wallet.owner,customPayload:plan.intent}),
        bounce:true,head:current.head,hubValue,walletValue,minimum:plan.minimum};
}
export async function prepareT3WalletRecovery(wallet:T3WalletReader,request:{kind:'retry'|'cancelBurn'|'mark';record:Cell;proof:Cell;caller:Address;recipient?:Address;evidenceIndex?:bigint;evidenceProof?:Cell}):Promise<T3TransactionPlan>{
    if(!['retry','cancelBurn','mark'].includes(request.kind))throw invalid('Unknown T3 wallet recovery action');
    const r=readT3WalletRecord(request.record),a=r.attempt,recipient=request.recipient??a.recipient;basechain(request.caller);basechain(recipient);
    if(r.cancelled||!a.owner.equals(wallet.owner))throw invalid('Wallet claim is cancelled or belongs to another owner');
    let body:Cell,quote:ChainCall;
    if(request.kind==='retry'){
        if(!r.failed||a.attempt===(1n<<64n)-1n)throw invalid('Retry requires a verified current failure');
        if(!recipient.equals(a.recipient)&&(a.burn||!request.caller.equals(wallet.owner)))throw invalid('This wallet claim cannot be redirected');
        const next={...a,attempt:a.attempt+1n,recipient};
        body=beginCell().storeUint(OP.T3_WALLET_RETRY,32).storeRef(request.record).storeRef(request.proof).storeAddress(recipient).endCell();
        quote=getter(wallet.address,'outgoing_value',[cellArg(t3WalletAttemptToCell(next))]);
    }else if(request.kind==='cancelBurn'){
        if(!r.failed||!a.burn||!request.caller.equals(wallet.owner))throw invalid('Only the owner may cancel a verified failed burn');
        body=beginCell().storeUint(OP.T3_WALLET_CANCEL,32).storeRef(request.record).storeRef(request.proof).endCell();quote=getter(wallet.address,'recovery_value');
    }else{
        if(r.failed||request.evidenceIndex===undefined||!request.evidenceProof)throw invalid('Marking requires exact wallet failure evidence');
        body=beginCell().storeUint(OP.T3_WALLET_MARK,32).storeRef(request.record).storeRef(request.proof).storeUint(request.evidenceIndex,64).storeRef(request.evidenceProof).endCell();quote=getter(wallet.address,'recovery_value');
    }
    const calls=[quote];
    if(request.kind==='retry'&&a.burn){
        if(a.details.customPayload){
            if(readT3Intent(a.details.customPayload).kind!=='redeem')throw invalid('Burn recovery has an invalid redemption intent');
            const args=quoteArgs(a.details.customPayload,0,a.amount,0n,true);
            calls.push(getter(wallet.hub.address,'get_quote',args),getter(wallet.hub.address,'get_min_execute',[...args,freshAddressArg(wallet.owner)]));
        }else calls.push(getter(wallet.hub.address,'get_min_value',[freshInt(OP.T3_WALLET_BURN)]));
    }
    const current=await wallet.batch(calls);
    if(a.id>=current.state.count||!verifyT3Witness(request.record,a.id,request.proof,current.state.root))throw invalid('Stale or invalid wallet claim witness');
    if(request.kind==='mark'&&(request.evidenceIndex!>=current.state.failures||!verifyT3Witness(t3WalletEvidence(wallet.address,a),request.evidenceIndex!,request.evidenceProof!,current.state.failureRoot,1)))throw invalid('Invalid authenticated failure journal evidence');
    const s=resultStack(current.results[0]);let value=s.uint();s.end();
    if(request.kind==='retry'&&a.burn){
        if(a.details.customPayload&&quoteStack(resultStack(current.results[1])).status!==0)throw invalid('Recovered redemption quote refused');
        const funding=resultStack(current.results[a.details.customPayload?2:1]);value+=funding.uint();funding.end();
    }
    return{address:wallet.address,value,body,bounce:true,head:current.head};
}

export function buildT3ProofStep(step:number,fields:{proof?:Cell;states?:Cell;history?:Cell;seqno?:number;receiver?:Cell;value?:bigint}):Cell{
    const b=t3ProofStep(step);
    if([10,11,12,14,17,20,21,22,24].includes(step)){if(!fields.proof)throw invalid('Missing proof step evidence');b.storeRef(fields.proof);}
    else if([13,16,23].includes(step)){if(!fields.proof||!fields.states)throw invalid('Missing transaction/account evidence');b.storeRef(fields.proof).storeRef(fields.states);}
    else if(step===15||step===25){if(!fields.proof||!fields.history||!Number.isInteger(fields.seqno)||fields.seqno!<0||fields.seqno!>=2**32)throw invalid('Missing historical anchor');b.storeUint(fields.seqno!,32).storeRef(fields.proof).storeRef(fields.history);}
    else if(step===30||step===31){if(!fields.receiver||fields.value===undefined)throw invalid('Missing certificate receiver/value');b.storeRef(fields.receiver).storeCoins(coins(fields.value));}
    else throw invalid('Unknown T3 proof step');return b.endCell();
}
/** Derives only the pristine session. Completed verifier state cannot replace its deployment data.
 * stepValue is the compute floor; certificate sends additionally fund receiver value and actual forwarding.
 * Original authenticated chain proofs/current witnesses and eventual funded execution remain caller inputs.
 */
export function createT3RecoverySession(read:FreshChainRead,config:T3ProofConfig,code:Cell,expectedCodeHash:string){
    if(!hashPattern.test(expectedCodeHash)||code.hash().toString('hex')!==expectedCodeHash)throw invalid('Proof code differs from the receiver pin');
    [config.controller,config.hub,config.master,config.sourceWallet,config.targetWallet].forEach(basechain);
    const configCell=t3ProofConfigToCell(config),init={code,data:t3ProofData(configCell)},address=contractAddress(0,init);
    return{address,init,config:configCell,
        async getSnapshot(){
            const calls:ChainCall[]=[{kind:'account',address:address.toRawString()},getter(address,'proofConfig'),getter(address,'stage'),getter(address,'proofValue')];
            const observation=await read(calls,{anchored:true,lane:'user'}),head=checkObservation(observation,calls.length);activeAccount(observation.results[0],expectedCodeHash);
            const c=resultStack(observation.results[1]),actual=c.cell()!;c.end();if(!actual.equals(configCell))throw invalid('Proof session configuration changed');
            const s=resultStack(observation.results[2]),stage={phase:s.number(3),messageHash:s.uint(256),cursor:{hash:s.uint(256),key:s.uint(256),bits:s.number(9),lt:s.uint(64)}};s.end();
            const v=resultStack(observation.results[3]),stepValue=v.uint();v.end();return{head,stage,stepValue};
        },
    };
}
export function t3HubFailurePayload(kind:0|1,selected:number,output:number,witness:T3ReceiptWitness):Cell{
    if(![0,1].includes(kind)||selected!==witness.slot||(kind===0&&output!==0))throw invalid('Invalid hub failure receiver payload');
    return beginCell().storeUint(kind,2).storeUint(slot(selected,true),2).storeUint(slot(output),2).storeRef(t3HubWitness(witness.record,witness.proof)).endCell();
}
export const t3HubCreditPayload=(selected:number,historicalPath:Cell|null)=>beginCell().storeUint(slot(selected),2).storeMaybeRef(historicalPath).endCell();
