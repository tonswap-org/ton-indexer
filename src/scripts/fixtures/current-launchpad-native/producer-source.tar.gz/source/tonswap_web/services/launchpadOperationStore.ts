import { Address, Cell } from '@ton/core';
import { CHAIN, type SendTransactionRequest } from '@tonconnect/sdk';
import type { ReviewWalletAction, SendWalletTransaction } from './walletAction';
import { isWalletRequestNotSentError, WalletRequestNotSentError } from './walletRequestNotSent';
import { isWalletRequestTicket, isWalletRequestAnswer, walletAnswer, resolveWalletRequest, readFirstHop,
  walletMessageExpired, readWalletRequestRecord, walletRequestRecordKey,
  type WalletRequestTicket, type WalletRequestAnswer, type WalletRequestOutcome, type WalletRequestChain, type FirstHop } from './walletRequest';
import { AppError } from './appError';
import { sameWalletTransaction } from './exactWalletTransaction';
import { launchpadHolderProofPending } from './launchpadHolderProofStore';
import { T3_OP, readT3WalletRecord } from './t3Contracts';
import { LAUNCH_OP,readLaunchpadRecoveryReceipt } from './launchpadContracts';
import { decodeSpotTokenTransfer } from './spotSwapChainProof';
const journalError=(code:string,message:string)=>new AppError('launchCreate.error.progress.invalid',{}, {devMessage:`${code}: ${message}`});

/** Fresh release operation history. Retired keys are never read or modified. */
export type LaunchpadScope={network:'testnet'|'mainnet'|'localnet';releaseId:string;manifestHash:string;wallet:string;factory:string};
export type LaunchpadOperation='create'|'contribute'|'supply'|'vest-supply'|'claim'|'finalize'|'cancel'|'discover'|'lp-seed'|'lp-release'|'vest-claim'|'vest-return'|'owed'|'wallet-retry'|'wallet-mark'|'holder-claim'|'archive-claim';
export type LaunchpadAsset={root:string;masterCodeHash:string;walletCodeHash:string;amountRaw:string;recipient:string};
export type LaunchpadRequest=LaunchpadScope&{kind:LaunchpadOperation;sale:string;target:string;creator:string;nonce:string;model:0|1|2;queryId:string;tokenRoot:string|null;amountRaw:string;minTokensRaw:string|null;sourceWallet:string|null;assets:LaunchpadAsset[];
 destination:string;valueNano:string;bodyBoc:string;bodyHash:string;createdAt:number;validUntil:number};
export type LaunchpadAttempt = { request: LaunchpadRequest; ticket: WalletRequestTicket|null; answer: WalletRequestAnswer|null;
  state: 'requesting'|'pending'|'accepted'|'confirmed'|'refunded'|'not-sent'; walletClosed: boolean;
  receipt: { transactionHash: string; amountRaw: string }|null };
export type LaunchpadJournal = { version: 1; scope: LaunchpadScope; attempts: LaunchpadAttempt[] };
export function launchpadQueryId(){const words=crypto.getRandomValues(new Uint32Array(2));return (BigInt(words[0])<<32n|BigInt(words[1]))||1n;}
export type LaunchpadStorage = Pick<Storage,'getItem'|'setItem'>;
export type LaunchpadLock = <T>(name: string, run: () => Promise<T>) => Promise<T>;
type Dependencies = { storage?: LaunchpadStorage; lock?: LaunchpadLock };
const clone = <T>(value: T): T => structuredClone(value);
const exact = (v: unknown, fields: string[]) => !!v && typeof v==='object' && !Array.isArray(v) && Object.keys(v).sort().join(',')===[...fields].sort().join(',');
const uint = (v: unknown, bits: number, positive=false): v is string => typeof v==='string' && /^(0|[1-9]\d{0,36})$/.test(v) && BigInt(v)<1n<<BigInt(bits) && (!positive||BigInt(v)>0n);
const hex = (v: unknown) => typeof v==='string' && /^[0-9a-f]{64}$/.test(v);
const address = (v: unknown): v is string => { try { const a=Address.parse(v as string); return a.workChain===0 && a.toRawString()===v; } catch { return false; } };
const SCOPE_FIELDS=['network','releaseId','manifestHash','wallet','factory'];
export function validLaunchpadScope(v: unknown): v is LaunchpadScope {
  const s=v as LaunchpadScope;
  return exact(s,SCOPE_FIELDS) && ['testnet','mainnet','localnet'].includes(s.network) && typeof s.releaseId==='string' && s.releaseId.length>0
    && hex(s.manifestHash) && [s.wallet,s.factory].every(address);
}
export const launchpadScopeOf=(r:LaunchpadScope):LaunchpadScope=>Object.fromEntries(SCOPE_FIELDS.map(k=>[k,r[k as keyof LaunchpadScope]])) as LaunchpadScope;
const sameScope=(a:LaunchpadScope,b:LaunchpadScope)=>JSON.stringify(launchpadScopeOf(a))===JSON.stringify(launchpadScopeOf(b));
export function launchpadJournalKey(scope:LaunchpadScope) {
  if(!validLaunchpadScope(scope))throw journalError('savedInvalid','Invalid release-bound Launchpad scope');
  return `tonswap:launchpad:current-v1:${scope.network}:${scope.manifestHash}:${scope.wallet}:${scope.factory}`;
}
export function validLaunchpadRequest(v:unknown):v is LaunchpadRequest {
 try{const r=v as LaunchpadRequest;
  if(!exact(r,[...SCOPE_FIELDS,'kind','sale','target','creator','nonce','model','queryId','tokenRoot','amountRaw','minTokensRaw','sourceWallet','assets','destination','valueNano','bodyBoc','bodyHash','createdAt','validUntil'])
   ||!validLaunchpadScope(launchpadScopeOf(r))||!['create','contribute','supply','vest-supply','claim','finalize','cancel','discover','lp-seed','lp-release','vest-claim','vest-return','owed','wallet-retry','wallet-mark','holder-claim','archive-claim'].includes(r.kind)
   ||![r.sale,r.target,r.creator,r.destination].every(address)||![0,1,2].includes(r.model)||!uint(r.nonce,64)||!uint(r.queryId,64,true)||!uint(r.amountRaw,120)||!uint(r.valueNano,120,true)
   ||r.tokenRoot!==null&&!address(r.tokenRoot)||r.sourceWallet!==null&&!address(r.sourceWallet)||r.minTokensRaw!==null&&!uint(r.minTokensRaw,120,true)
   ||!Array.isArray(r.assets)||r.assets.length>8||r.assets.some(a=>!exact(a,['root','masterCodeHash','walletCodeHash','amountRaw','recipient'])||![a.root,a.recipient].every(address)||![a.masterCodeHash,a.walletCodeHash].every(hex)||!uint(a.amountRaw,120,true))
   ||!hex(r.bodyHash)||typeof r.bodyBoc!=='string'||r.bodyBoc.length>1000000||!Number.isSafeInteger(r.createdAt)||r.createdAt<=0||!Number.isSafeInteger(r.validUntil)||r.validUntil<=0||r.validUntil>0xffffffff)return false;
  const c=Cell.fromBase64(r.bodyBoc);if(c.isExotic||c.hash().toString('hex')!==r.bodyHash)return false;
  if(['contribute','supply','vest-supply'].includes(r.kind)){
   const t=decodeSpotTokenTransfer(c);if(t.query!==BigInt(r.queryId)||t.amount!==BigInt(r.amountRaw)||t.owner!==r.target||t.response!==r.wallet||t.custom!==null||r.sourceWallet!==r.destination||r.tokenRoot===null)return false;
   const p=t.payload.beginParse();if(r.kind==='contribute'){if(p.loadUint(32)!==LAUNCH_OP.CONTRIBUTE||p.loadCoins().toString()!==r.minTokensRaw)return false;}p.endParse();
  }else if(r.kind==='wallet-retry'||r.kind==='wallet-mark'){
   const s=c.beginParse();if(s.loadUint(32)!==(r.kind==='wallet-retry'?T3_OP.T3_WALLET_RETRY:T3_OP.T3_WALLET_MARK))return false;
   const record=readT3WalletRecord(s.loadRef());s.loadRef();const a=record.attempt;
   if(a.burn||record.cancelled||a.owner.toRawString()!==r.target||a.amount.toString()!==r.amountRaw||r.destination!==r.sourceWallet||r.assets.length!==1||r.assets[0].recipient!==a.recipient.toRawString()||r.assets[0].amountRaw!==r.amountRaw||r.assets[0].root!==r.tokenRoot)return false;
   if(r.kind==='wallet-retry'){if(!record.failed||!s.loadAddress().equals(a.recipient))return false;}else{if(record.failed)return false;s.loadUintBig(64);s.loadRef();}s.endParse();
  }else if(r.kind==='holder-claim'){
   const s=c.beginParse();if(s.loadUint(32)!==0x4a52434d||r.destination!==r.target||r.sourceWallet!==null)return false;const receipt=readLaunchpadRecoveryReceipt(s.loadRef());s.loadRef();s.endParse();if(receipt.claimed||receipt.amount.toString()!==r.amountRaw||r.assets.length!==1||r.assets[0].amountRaw!==r.amountRaw)return false;
  }else if(r.kind==='archive-claim'){
   const s=c.beginParse();if(s.loadUint(32)!==0x434c4d41||s.loadUintBig(64).toString()!==r.queryId||s.loadUint(8)>1||r.destination!==r.target||r.sourceWallet!==null)return false;s.loadUintBig(64);if(s.loadAddress().toRawString()!==r.wallet||s.loadCoins().toString()!==r.amountRaw)return false;s.loadRef();s.endParse();if(r.assets.length!==1||r.assets[0].amountRaw!==r.amountRaw||r.assets[0].recipient!==r.wallet)return false;
  }else{
   const ops={create:LAUNCH_OP.CREATE,claim:LAUNCH_OP.CLAIM,finalize:LAUNCH_OP.FINALIZE,cancel:LAUNCH_OP.CANCEL,discover:LAUNCH_OP.DISCOVER,'lp-seed':LAUNCH_OP.LP_SEED,'lp-release':LAUNCH_OP.LP_RELEASE,'vest-claim':LAUNCH_OP.VEST_CLAIM,'vest-return':LAUNCH_OP.VEST_RETURN,owed:LAUNCH_OP.OWED};
   const p=c.beginParse();if(p.loadUint(32)!==ops[r.kind as keyof typeof ops]||p.loadUintBig(64).toString()!==r.queryId||r.destination!==r.target)return false;
   if(r.kind==='create'){if(p.loadUintBig(64).toString()!==r.nonce||p.loadUint(8)!==r.model)return false;p.loadRef();}
   if(r.kind==='lp-seed'){p.loadCoins();p.loadCoins();}if(r.kind==='lp-release'){p.loadCoins();p.loadCoins();p.loadBit();}
   if(r.kind==='owed'){if(p.loadUint(8)>1||p.loadAddress().toRawString()!==r.wallet)return false;}p.endParse();
  }
  return true;
 }catch{return false;}
}
export function launchpadTicketMatches(r:LaunchpadRequest,t:WalletRequestTicket) {
  return isWalletRequestTicket(t)&&t.network===r.network&&t.owner===r.wallet&&t.validUntil===r.validUntil&&t.messages.length===1
    &&t.messages[0].destination===r.destination&&t.messages[0].amount===r.valueNano&&t.messages[0].bodyHash===r.bodyHash&&!t.messages[0].init;
}
export function validLaunchpadJournal(v:unknown):v is LaunchpadJournal {
  const j=v as LaunchpadJournal;
  if(!exact(j,['version','scope','attempts'])||j.version!==1||!validLaunchpadScope(j.scope)||!Array.isArray(j.attempts))return false;
  const ids=new Set<string>();
  return j.attempts.every(a=>{
    if(!exact(a,['request','ticket','answer','state','walletClosed','receipt'])||!validLaunchpadRequest(a.request)||!sameScope(a.request,j.scope)||ids.has(a.request.queryId)
      ||!['requesting','pending','accepted','confirmed','refunded','not-sent'].includes(a.state)||typeof a.walletClosed!=='boolean'
      ||a.ticket!==null&&!launchpadTicketMatches(a.request,a.ticket)||a.answer!==null&&(!a.ticket||!isWalletRequestAnswer(a.answer))
      ||['confirmed','refunded','not-sent'].includes(a.state)&&!a.walletClosed
      ||['confirmed','refunded','accepted'].includes(a.state)&&(!a.ticket||!a.receipt)
      ||a.receipt!==null&&(!exact(a.receipt,['transactionHash','amountRaw'])||!hex(a.receipt.transactionHash)||!uint(a.receipt.amountRaw,120)))return false;
    ids.add(a.request.queryId);return true;
  });
}
const storage=():LaunchpadStorage=>{try{if(globalThis.localStorage)return globalThis.localStorage;}catch{}throw journalError('storageBlocked','Launchpad storage unavailable');};
export const launchpadLock:LaunchpadLock=async(key,run)=>{
  if(typeof navigator==='undefined'||!navigator.locks?.request)throw journalError('lockUnavailable','Launchpad request lock unavailable');
  return navigator.locks.request(key,{mode:'exclusive',ifAvailable:true},held=>{if(!held)throw journalError('openInAnotherTab','Launchpad operation is open in another tab');return run();});
};
export function readLaunchpadJournal(scope:LaunchpadScope,target:LaunchpadStorage=storage()):LaunchpadJournal {
  const key=launchpadJournalKey(scope);let bytes:string|null;
  try{bytes=target.getItem(key);}catch{throw journalError('savedUnreadable','Launchpad journal cannot be read');}
  if(bytes===null)return{version:1,scope:clone(scope),attempts:[]};
  let v:unknown;try{v=JSON.parse(bytes);}catch{throw journalError('savedInvalid','Malformed Launchpad journal retained');}
  if(!validLaunchpadJournal(v)||!sameScope(v.scope,scope))throw journalError('savedInvalid','Invalid Launchpad journal retained');return clone(v);
}
export function saveLaunchpadJournal(j:LaunchpadJournal,target:LaunchpadStorage=storage()) {
  if(!validLaunchpadJournal(j))throw journalError('savedInvalid','Invalid Launchpad operation');
  const key=launchpadJournalKey(j.scope),bytes=JSON.stringify(j);target.setItem(key,bytes);
  if(target.getItem(key)!==bytes)throw journalError('saveFailed','Launchpad operation was not durably saved');
  if(typeof window!=='undefined')window.dispatchEvent(new Event('tonswap-launchpad-journal'));
}
export function sameLaunchCreationIntent(a:LaunchpadRequest,b:LaunchpadRequest){try{if(a.kind!=='create'||b.kind!=='create'||!sameScope(a,b)||a.sale!==b.sale||a.creator!==b.creator||a.nonce!==b.nonce||a.model!==b.model||a.target!==b.target)return false;const x=Cell.fromBase64(a.bodyBoc).beginParse(),y=Cell.fromBase64(b.bodyBoc).beginParse();x.skip(96);y.skip(96);return x.asCell().equals(y.asCell());}catch{return false;}}
export const launchpadAttemptOpen=(a:LaunchpadAttempt)=>!['confirmed','refunded','not-sent'].includes(a.state);
export function launchpadTransaction(r:LaunchpadRequest):SendTransactionRequest {
  if(!validLaunchpadRequest(r))throw journalError('requestMismatch','Invalid Launchpad request');
  return{from:r.wallet,network:r.network==='mainnet'?CHAIN.MAINNET:CHAIN.TESTNET,validUntil:r.validUntil,messages:[{address:r.destination,amount:r.valueNano,payload:r.bodyBoc}]};
}
export function verifyLaunchpadTransaction(r:LaunchpadRequest,t:Readonly<SendTransactionRequest>) {
  const e=launchpadTransaction(r);
  if(!sameWalletTransaction(t,e))
    throw new WalletRequestNotSentError('Launchpad transaction differs from the saved request');
}
/** Every direct operation and recovery gets a new retained attempt. Withdrawal is never resent. */
export async function sendLaunchpadRequest(input:Dependencies&{request:LaunchpadRequest;action:ReviewWalletAction;current:()=>boolean;revalidate:()=>Promise<void>;send:SendWalletTransaction}):Promise<LaunchpadAttempt> {
  const target=input.storage??storage(),r=clone(input.request),scope=launchpadScopeOf(r),lock=input.lock??launchpadLock;
  return lock(launchpadJournalKey(scope),async()=>{
    const j=readLaunchpadJournal(scope,target);
    if(launchpadHolderProofPending(scope,target))throw journalError('proofUnresolved','Resolve the proof step first');
    if(j.attempts.some(a=>a.request.queryId===r.queryId))throw journalError('originalUnresolved','A Launchpad query cannot be reused');
    const open=j.attempts.filter(a=>launchpadAttemptOpen(a)),recovery=['discover','owed','wallet-retry','wallet-mark','holder-claim','archive-claim'].includes(r.kind);
    if(open.some(a=>!a.walletClosed)||!recovery&&open.some(a=>a.request.target===r.target&&a.request.kind===r.kind&&!(a.state==='accepted'&&a.request.kind==='create'&&r.kind==='create'&&(sameLaunchCreationIntent(a.request,r)||a.request.sale!==r.sale&&a.request.nonce!==r.nonce&&a.request.creator===r.creator))))throw journalError('originalUnresolved','Resolve the original Launchpad request first');
    if(!input.current())throw journalError('contextChanged','Launchpad context changed');
    const a:LaunchpadAttempt={request:r,ticket:null,answer:null,state:'requesting',walletClosed:false,receipt:null};j.attempts.push(a);saveLaunchpadJournal(j,target);
    let expected=JSON.stringify(j);
    const checkJournal=()=>{if(JSON.stringify(readLaunchpadJournal(scope,target))!==expected)throw new WalletRequestNotSentError('Launchpad journal changed during review');};
    const unchanged=()=>{checkJournal();if(!input.current())throw new WalletRequestNotSentError('Launchpad context changed during review');};
    const persist=()=>{saveLaunchpadJournal(j,target);expected=JSON.stringify(j);};
    try {
      const response=await input.send(launchpadTransaction(r),input.action,{verify:t=>{unchanged();verifyLaunchpadTransaction(r,t);},beforeDispatch:async ticket=>{
        unchanged();await input.revalidate();unchanged();
        if(a.ticket||!launchpadTicketMatches(r,ticket))throw new WalletRequestNotSentError('Launchpad ticket differs from reviewed request');
        a.ticket=clone(ticket);a.state='pending';persist();
      }});
      checkJournal();
      if(response===null&&!a.ticket){a.state='not-sent';a.walletClosed=true;persist();}
      else if(response!==null){if(!a.ticket)throw journalError('saveFailed','Wallet answer has no durable Launchpad ticket');a.answer=walletAnswer(a.ticket,response)??a.answer;a.state='pending';persist();}
      return clone(a);
    }catch(error){if(!a.ticket&&isWalletRequestNotSentError(error)){checkJournal();a.state='not-sent';a.walletClosed=true;persist();}throw error;}
  });
}
export type LaunchpadEffect={requestBodyHash:string;transactionHash:string;amountRaw:string;status:'accepted'|'delivered'|'refunded'};
/** Effects must come from an independent verifier, never a wallet answer or accounting event. */
export async function reconcileLaunchpadAttempt(scope:LaunchpadScope,queryId:string,effect:LaunchpadEffect|null,
  input:Dependencies&{current?:()=>boolean;chain?:WalletRequestChain;signal?:AbortSignal}={}) {
  const target=input.storage??storage(),lock=input.lock??launchpadLock,j=readLaunchpadJournal(scope,target),original=j.attempts.find(a=>a.request.queryId===queryId);
  if(!original||!launchpadAttemptOpen(original))return{attempt:original??null,outcome:null,firstHop:null};
  const ticket=original.ticket,shared=()=>ticket?JSON.stringify(readWalletRequestRecord(ticket.network,ticket.owner,target).entries.find(e=>e.ticket.id===ticket.id)??null):null;
  const before=shared(),options={answer:original.answer,storage:target,chain:input.chain,signal:input.signal};
  const outcome:WalletRequestOutcome|null=ticket?await resolveWalletRequest(ticket,options):null;
  const firstHop:FirstHop|null=ticket&&outcome?.status==='observed'&&outcome.final?await readFirstHop(ticket,0,options):null;
  return lock(launchpadJournalKey(scope),async()=>{
    const apply=async()=>{
      input.signal?.throwIfAborted();const next=readLaunchpadJournal(scope,target),a=next.attempts.find(v=>v.request.queryId===queryId);
      if(!a||input.current&&!input.current()||JSON.stringify(a)!==JSON.stringify(original)||before!==shared())return{attempt:a??null,outcome,firstHop};
      const rejected=firstHop?.status==='rejected'&&outcome?.status==='observed'&&outcome.final;
      a.walletClosed ||= !ticket||!!outcome&&walletMessageExpired(outcome,0)||outcome?.status==='observed'&&outcome.final;
      if(!ticket||rejected||outcome&&walletMessageExpired(outcome,0))a.state='not-sent';
      if(effect&&ticket&&outcome?.status==='observed'&&outcome.final&&firstHop?.status==='executed'){
        if(rejected||outcome&&walletMessageExpired(outcome,0))throw journalError('claimOnchainMismatch','Launchpad evidence conflicts with original request closure');
        if(effect.requestBodyHash!==a.request.bodyHash||!hex(effect.transactionHash)||!uint(effect.amountRaw,120))throw journalError('claimOnchainMismatch','Launchpad evidence identity differs');
        const financial=!['discover','wallet-retry','wallet-mark','holder-claim'].includes(a.request.kind);
        if(financial&&['contribute','supply','vest-supply','claim','vest-claim','vest-return','owed','archive-claim'].includes(a.request.kind)&&(['owed','vest-claim','vest-return'].includes(a.request.kind)?BigInt(effect.amountRaw)<BigInt(a.request.amountRaw):effect.amountRaw!==a.request.amountRaw))throw journalError('claimOnchainMismatch','Launchpad physical amount differs');
        a.receipt={transactionHash:effect.transactionHash,amountRaw:effect.amountRaw};
        a.state=a.walletClosed&&(effect.status!=='accepted'||!financial)?effect.status==='refunded'?'refunded':'confirmed':'accepted';
      }
      saveLaunchpadJournal(next,target);return{attempt:clone(a),outcome,firstHop};
    };
    return ticket?lock(walletRequestRecordKey(ticket.network,ticket.owner),apply):apply();
  });
}
