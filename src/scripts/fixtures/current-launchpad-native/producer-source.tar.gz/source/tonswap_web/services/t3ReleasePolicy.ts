import { Address } from '@ton/core';
import { TESTNET_ADDRESSES } from '../constants';
import { AppError } from './appError';

export const FIRST_RELEASE_T3_RESERVES = ['USDT', 'USDC'] as const;

export const FIRST_RELEASE_KUSD_BINDING_NOTICE =
  'KUSD minting, public pools, liquidity deposits, and swaps require a qualified KUSD/T3 relative-peg binding. KUSD redemption remains available.';

/**
 * Why a pair cannot be traded in this release, as data. The screen says its own plain sentence for the
 * code and keeps `statement` verbatim under a Details disclosure; `redemptionAvailable` lets it offer
 * the one thing a person can still do with KUSD.
 */
export type FirstReleaseTradingGate = {
  readonly code: 'kusd-peg-unqualified';
  readonly statement: string;
  readonly redemptionAvailable: true;
};

export const FIRST_RELEASE_KUSD_GATE: FirstReleaseTradingGate = Object.freeze({
  code: 'kusd-peg-unqualified',
  statement: FIRST_RELEASE_KUSD_BINDING_NOTICE,
  redemptionAvailable: true
});

/** The error services throw when KUSD would be traded. Its code is the catalog sentence a screen shows. */
export const firstReleaseKusdError = () =>
  new AppError('release.kusd.closed', {}, { devMessage: FIRST_RELEASE_KUSD_BINDING_NOTICE });

export const isFirstReleaseT3MintCollateral = (symbol: string): boolean =>
  (FIRST_RELEASE_T3_RESERVES as readonly string[]).includes(symbol.trim().toUpperCase());

export const FIRST_RELEASE_T3_MAX_RESERVE_SKEW_BPS = 500n;

/** Mirrors the Hub's two-reserve post-mint bound for launch-state guidance. */
export const wouldExceedFirstReleaseT3ReserveCap = (
  balances: { usdt: bigint; usdc: bigint; kusd: bigint },
  deposit: { usdt: bigint; usdc: bigint; kusd: bigint }
): boolean => {
  if (balances.kusd !== 0n || deposit.kusd !== 0n) return false;
  const usdt = balances.usdt + deposit.usdt;
  const usdc = balances.usdc + deposit.usdc;
  if (usdt <= 0n || usdc <= 0n) return false;
  const difference = usdt > usdc ? usdt - usdc : usdc - usdt;
  return difference * 10_000n > (usdt + usdc) * FIRST_RELEASE_T3_MAX_RESERVE_SKEW_BPS;
};

export const isFirstReleaseT3StableSwapAllowed = (
  poolType: string | null | undefined,
  paySymbol: string,
  receiveSymbol: string
): boolean => poolType !== 'Stableswap'
  || ![paySymbol, receiveSymbol].some((symbol) => symbol.trim().toUpperCase() === 'KUSD');

const sameRoot = (a: string | null | undefined, b: string | null | undefined): boolean => {
  if (!a || !b) return false;
  try { return Address.parse(a).equals(Address.parse(b)); } catch { return false; }
};

/** Identity comes from jetton roots, never a pool label, symbol, or selected route. */
export const isFirstReleaseKusdT3Pair = (
  rootA: string | null | undefined,
  rootB: string | null | undefined,
  t3Hub = TESTNET_ADDRESSES.t3Hub,
  kusdRoot = TESTNET_ADDRESSES.kusdRoot
): boolean =>
  sameRoot(rootA, t3Hub) && sameRoot(rootB, kusdRoot)
  || sameRoot(rootA, kusdRoot) && sameRoot(rootB, t3Hub);

/** KUSD has no qualified trading peg in this release, regardless of venue. */
export const isFirstReleaseKusdTradingPair = (
  rootA: string | null | undefined,
  rootB: string | null | undefined,
  kusdRoot = TESTNET_ADDRESSES.kusdRoot
): boolean => sameRoot(rootA, kusdRoot) || sameRoot(rootB, kusdRoot);

export const assertFirstReleaseKusdTradingAllowed = (
  rootA: string | null | undefined,
  rootB: string | null | undefined
): void => {
  if (isFirstReleaseKusdTradingPair(rootA, rootB)) throw firstReleaseKusdError();
};

export const isFirstReleaseT3SpotSwapAllowed = (
  poolType: string | null | undefined,
  paySymbol: string,
  receiveSymbol: string,
  payRoot: string | null | undefined,
  receiveRoot: string | null | undefined
): boolean => isFirstReleaseT3StableSwapAllowed(poolType, paySymbol, receiveSymbol)
  && !isFirstReleaseKusdTradingPair(payRoot, receiveRoot);

/** The gate on a spot pair, or null when the pair may be traded. */
export const firstReleaseSpotGate = (
  poolType: string | null | undefined,
  paySymbol: string,
  receiveSymbol: string,
  payRoot: string | null | undefined,
  receiveRoot: string | null | undefined
): FirstReleaseTradingGate | null =>
  isFirstReleaseT3SpotSwapAllowed(poolType, paySymbol, receiveSymbol, payRoot, receiveRoot) ? null : FIRST_RELEASE_KUSD_GATE;

export const assertFirstReleaseT3SpotSwapAllowed = (
  poolType: string | null | undefined,
  paySymbol: string,
  receiveSymbol: string,
  payRoot: string | null | undefined,
  receiveRoot: string | null | undefined
): void => {
  if (!isFirstReleaseT3SpotSwapAllowed(poolType, paySymbol, receiveSymbol, payRoot, receiveRoot))
    throw firstReleaseKusdError();
};
