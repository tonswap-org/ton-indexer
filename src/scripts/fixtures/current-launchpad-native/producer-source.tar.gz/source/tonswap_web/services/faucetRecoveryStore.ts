import { sameWalletTransaction } from './exactWalletTransaction';
import { Cell, beginCell } from '@ton/core';
import { Buffer } from 'buffer';
import { CHAIN, type SendTransactionRequest } from '@tonconnect/sdk';
import { AppError } from './appError';
import type { ReviewWalletAction, SendWalletTransaction } from './walletAction';
import { isWalletRequestTicket, isWalletRequestAnswer, resolveWalletRequest, readFirstHop, walletMessageExpired, walletAnswer,
  readWalletRequestRecord, walletRequestRecordKey, type WalletRequestTicket, type WalletRequestAnswer, type WalletRequestChain } from './walletRequest';
import { WalletRequestNotSentError, isWalletRequestNotSentError } from './walletRequestNotSent';
import { faucetBrowserStorage, faucetBrowserLock, faucetJournalKey, faucetScopeOf, validFaucetScope, readFaucetJournal, faucetEvidenceRequest,
  type FaucetScope, type FaucetStorage, type FaucetLock } from './faucetStore';
import { faucetClaimBody, faucetRecoveryBody } from './faucetContracts';
import { readFaucetRecoveryReceipt, type FaucetRecoveryReady, type FaucetRecoveryState, type FaucetRecoveryPlan } from './faucetRecovery';
import type { FaucetEvidenceRequest } from './faucetEvidence';

export type FaucetRecoveryRequest = { id:string; original:FaucetEvidenceRequest; kind:'claim-receipt'|'restore-cooldown';
  sourceLt:string; sourceHash:string; wire:string; amountRaw:string; receiptBoc:string; proofBoc:string;
  bodyBoc:string; bodyHash:string; valueNano:string; createdAt:number; validUntil:number };
export type FaucetRecoveryResolution = { phase:'restore-cooldown'|'retry-ready'|'superseded'; sourceLt:string; sourceHash:string; root:string; seqno:number; blockRootHash:string };
export type FaucetRecoveryAttempt = { request:FaucetRecoveryRequest; ticket:WalletRequestTicket|null; answer:WalletRequestAnswer|null;
  walletClosed:boolean; state:'requesting'|'pending'|'not-sent'|'confirmed'; resolution:FaucetRecoveryResolution|null };
type Journal={version:1;scope:FaucetScope;attempts:FaucetRecoveryAttempt[]};
const fail=(devMessage:string)=>new AppError('wallet.faucet.error.saved',{}, {devMessage});
const exact=(v:unknown,keys:string[]):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const hash=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const uint=(v:unknown,bits=120):v is string=>typeof v==='string'&&/^(0|[1-9]\d{0,36})$/.test(v)&&BigInt(v)<1n<<BigInt(bits);
const clone=<T>(v:T):T=>structuredClone(v);
const same=(a:unknown,b:unknown)=>JSON.stringify(a)===JSON.stringify(b);
export function validFaucetEvidenceRequest(p:unknown):p is FaucetEvidenceRequest{
 try{return exact(p,['network','releaseId','manifestHash','owner','faucet','kind','asset','queryId','bodyBoc','bodyHash','valueNano','createdAt','dispatch'])
  &&validFaucetScope(faucetScopeOf(p as FaucetEvidenceRequest))&&p.kind==='claim'&&p.asset===0&&uint(p.queryId,64)&&uint(p.valueNano)&&p.valueNano!=='0'
  &&Number.isSafeInteger(p.createdAt)&&p.createdAt>0&&typeof p.bodyBoc==='string'&&p.bodyBoc.length<1000&&hash(p.bodyHash)
  &&Cell.fromBase64(p.bodyBoc).equals(faucetClaimBody(0,BigInt(p.queryId)))&&Cell.fromBase64(p.bodyBoc).hash().toString('hex')===p.bodyHash
  &&exact(p.dispatch,['lt','hash','valueNano'])&&uint(p.dispatch.lt,64)&&p.dispatch.lt!=='0'&&hash(p.dispatch.hash)&&uint(p.dispatch.valueNano)&&p.dispatch.valueNano!=='0';}catch{return false;}
}
export function validFaucetRecoveryRequest(r:unknown):r is FaucetRecoveryRequest{
 try{if(!exact(r,['id','original','kind','sourceLt','sourceHash','wire','amountRaw','receiptBoc','proofBoc','bodyBoc','bodyHash','valueNano','createdAt','validUntil'])
  ||!validFaucetEvidenceRequest(r.original)||!['claim-receipt','restore-cooldown'].includes(r.kind)||!hash(r.id)||!uint(r.sourceLt,64)||r.sourceLt==='0'||!hash(r.sourceHash)
  ||!uint(r.wire,64)||r.wire==='0'||!uint(r.amountRaw)||r.amountRaw==='0'||!uint(r.valueNano)||r.valueNano==='0'||!hash(r.bodyHash)
  ||!Number.isSafeInteger(r.createdAt)||r.createdAt<=0||!Number.isSafeInteger(r.validUntil)||r.validUntil<=0||r.validUntil>0xffffffff
  ||![r.receiptBoc,r.proofBoc,r.bodyBoc].every(v=>typeof v==='string'&&v.length<65536))return false;
  const receipt=Cell.fromBase64(r.receiptBoc),proof=Cell.fromBase64(r.proofBoc),rec=readFaucetRecoveryReceipt(receipt),body=faucetRecoveryBody(receipt,proof,r.kind==='restore-cooldown');
  const command=rec.body.beginParse();if(command.loadUint(32)!==0x0f8a7ea5||command.loadUintBig(64).toString()!==r.wire||command.loadCoins().toString()!==r.amountRaw
    ||command.loadAddress().toRawString()!==r.original.owner||command.loadMaybeAddress()?.toRawString()!==r.original.owner)return false;
  return rec.key.toString()===r.sourceLt&&rec.amount.toString()===r.amountRaw&&rec.claimed===(r.kind==='restore-cooldown')&&body.equals(Cell.fromBase64(r.bodyBoc))&&body.hash().toString('hex')===r.bodyHash;
 }catch{return false;}
}
export function faucetRecoveryTransaction(r:FaucetRecoveryRequest):SendTransactionRequest{
 if(!validFaucetRecoveryRequest(r))throw fail('Invalid faucet recovery request');return{from:r.original.owner,network:CHAIN.TESTNET,validUntil:r.validUntil,messages:[{address:r.original.faucet,amount:r.valueNano,payload:r.bodyBoc}]};
}
export function faucetRecoveryTicketMatches(r:FaucetRecoveryRequest,t:WalletRequestTicket){return isWalletRequestTicket(t)&&t.network===r.original.network&&t.owner===r.original.owner&&t.validUntil===r.validUntil&&t.messages.length===1
 &&t.messages[0].destination===r.original.faucet&&t.messages[0].bodyHash===r.bodyHash&&t.messages[0].amount===r.valueNano&&!t.messages[0].init;}
export function faucetRecoveryJournalKey(scope:FaucetScope){if(!validFaucetScope(scope))throw fail('Invalid faucet scope');return `${faucetJournalKey(scope)}:recovery`;}
export const faucetRecoveryOpen=(a:FaucetRecoveryAttempt)=>!['confirmed','not-sent'].includes(a.state);
function validResolution(v:unknown,r:FaucetRecoveryRequest):v is FaucetRecoveryResolution{return exact(v,['phase','sourceLt','sourceHash','root','seqno','blockRootHash'])
 &&['restore-cooldown','retry-ready','superseded'].includes(v.phase)&&(r.kind==='claim-receipt'||v.phase!=='restore-cooldown')&&v.sourceLt===r.sourceLt&&v.sourceHash===r.sourceHash&&hash(v.root)&&hash(v.blockRootHash)&&Number.isSafeInteger(v.seqno)&&v.seqno>0;}
function validJournal(v:unknown,scope:FaucetScope):v is Journal{
 if(!exact(v,['version','scope','attempts'])||v.version!==1||!validFaucetScope(v.scope)||!same(v.scope,scope)||!Array.isArray(v.attempts))return false;
 const ids=new Set<string>();return v.attempts.every(a=>{
  if(!exact(a,['request','ticket','answer','walletClosed','state','resolution'])||!validFaucetRecoveryRequest(a.request)||!same(faucetScopeOf(a.request.original),scope)||ids.has(a.request.id)
   ||!['requesting','pending','not-sent','confirmed'].includes(a.state)||typeof a.walletClosed!=='boolean'||a.ticket!==null&&!faucetRecoveryTicketMatches(a.request,a.ticket)
   ||a.answer!==null&&(!a.ticket||!isWalletRequestAnswer(a.answer))||a.resolution!==null&&!validResolution(a.resolution,a.request)
   ||a.state==='confirmed'&&(!a.ticket||!a.walletClosed||!a.resolution)||a.state==='not-sent'&&!a.walletClosed||a.state!=='confirmed'&&a.resolution!==null)return false;
  ids.add(a.request.id);return true;
 });
}
export function readFaucetRecoveryJournal(scope:FaucetScope,target:FaucetStorage=faucetBrowserStorage()):Journal{
 const bytes=target.getItem(faucetRecoveryJournalKey(scope));if(bytes===null)return{version:1,scope:clone(scope),attempts:[]};try{const j=JSON.parse(bytes);if(!validJournal(j,scope))throw Error();return j;}catch{throw fail('Invalid recovery journal retained');}
}
function save(j:Journal,target:FaucetStorage){if(!validJournal(j,j.scope))throw fail('Invalid recovery journal');const key=faucetRecoveryJournalKey(j.scope),bytes=JSON.stringify(j);target.setItem(key,bytes);if(target.getItem(key)!==bytes)throw fail('Recovery save failed');}
export function makeFaucetRecoveryRequest(state:FaucetRecoveryReady,plan:FaucetRecoveryPlan,validUntil:number,now=Date.now()):FaucetRecoveryRequest{
 if(plan.kind!==state.status||plan.originalBodyHash!==state.request.bodyHash||plan.sourceLt!==state.sourceFailure.sourceLt||plan.sourceHash!==state.sourceFailure.sourceHash||plan.wire!==state.wire||plan.amountRaw!==state.amountRaw||plan.address.toRawString()!==state.request.faucet)throw fail('Recovery plan changed');
 const bodyHash=plan.body.hash().toString('hex'),id=beginCell().storeBuffer(Buffer.from(bodyHash,'hex')).storeUint(now,64).endCell().hash().toString('hex');
 const r:FaucetRecoveryRequest={id,original:clone(state.request),kind:plan.kind,sourceLt:plan.sourceLt,sourceHash:plan.sourceHash,wire:plan.wire,amountRaw:plan.amountRaw,receiptBoc:plan.receiptBoc,proofBoc:plan.proofBoc,
  bodyBoc:plan.body.toBoc().toString('base64'),bodyHash,valueNano:plan.value.toString(),validUntil,createdAt:now};if(!validFaucetRecoveryRequest(r))throw fail('Invalid recovery plan');return r;
}
export async function sendFaucetRecoveryRequest(input:{request:FaucetRecoveryRequest;action:ReviewWalletAction;send:SendWalletTransaction;current:()=>boolean;revalidate:()=>Promise<void>;storage?:FaucetStorage;lock?:FaucetLock}):Promise<FaucetRecoveryAttempt>{
 const target=input.storage??faucetBrowserStorage(),lock=input.lock??faucetBrowserLock,r=clone(input.request),scope=faucetScopeOf(r.original);
 return lock(faucetJournalKey(scope),async()=>{
  if(!validFaucetRecoveryRequest(r)||!input.current())throw fail('Recovery context changed');const claims=readFaucetJournal(scope,target),claim=claims.attempts.find(a=>a.request.bodyHash===r.original.bodyHash);
  if(!claim||!claim.walletClosed||!same(faucetEvidenceRequest(claim),r.original)||claims.attempts.some(a=>!a.walletClosed))throw fail('Original claim has not resolved');
  const proof=await import('./faucetProofStore');if(proof.faucetProofPending(scope,target))throw fail('Faucet proof unresolved');
  const j=readFaucetRecoveryJournal(scope,target);if(j.attempts.some(a=>faucetRecoveryOpen(a)||a.request.id===r.id))throw fail('Earlier recovery unresolved');
  const a:FaucetRecoveryAttempt={request:r,ticket:null,answer:null,walletClosed:false,state:'requesting',resolution:null};j.attempts.push(a);save(j,target);let expected=JSON.stringify(j);
  const unchanged=()=>{if(!input.current()||JSON.stringify(readFaucetRecoveryJournal(scope,target))!==expected)throw new WalletRequestNotSentError('Recovery changed');};
  const persist=()=>{save(j,target);expected=JSON.stringify(j);};
  try{const tx=faucetRecoveryTransaction(r),answer=await input.send(tx,input.action,{verify:t=>{unchanged();if(!sameWalletTransaction(t,tx))throw new WalletRequestNotSentError('Recovery payload changed');},beforeDispatch:async ticket=>{
   unchanged();await input.revalidate();unchanged();if(a.ticket||!faucetRecoveryTicketMatches(r,ticket))throw new WalletRequestNotSentError('Recovery ticket changed');a.ticket=clone(ticket);a.state='pending';persist();
  }});
   if(JSON.stringify(readFaucetRecoveryJournal(scope,target))!==expected)throw fail('Recovery changed before wallet answer');
   if(answer===null&&!a.ticket){a.state='not-sent';a.walletClosed=true;persist();}else if(answer!==null){if(!a.ticket)throw fail('Recovery answer has no ticket');a.answer=walletAnswer(a.ticket,answer)??a.answer;a.state='pending';persist();}return clone(a);
  }catch(error){if(!a.ticket&&isWalletRequestNotSentError(error)&&JSON.stringify(readFaucetRecoveryJournal(scope,target))===expected){a.state='not-sent';a.walletClosed=true;persist();}throw error;}
 });
}
export function recoveryResolution(state:FaucetRecoveryState,r:FaucetRecoveryRequest):FaucetRecoveryResolution|null{
 if(state.status==='unavailable'||!same(state.request,r.original)||state.sourceFailure.sourceLt!==r.sourceLt||state.sourceFailure.sourceHash!==r.sourceHash||state.amountRaw!==r.amountRaw||state.wire!==r.wire)return null;
 const v={phase:state.status,sourceLt:r.sourceLt,sourceHash:r.sourceHash,root:state.root,seqno:state.head.seqno,blockRootHash:state.head.rootHashHex};return validResolution(v,r)?v:null;
}
export async function reconcileFaucetRecovery(scope:FaucetScope,id:string,input:{readRecovery:(request:FaucetEvidenceRequest)=>Promise<FaucetRecoveryState>;storage?:FaucetStorage;lock?:FaucetLock;chain?:WalletRequestChain;signal?:AbortSignal;current?:()=>boolean}):Promise<FaucetRecoveryAttempt|null>{
 const target=input.storage??faucetBrowserStorage(),lock=input.lock??faucetBrowserLock,original=readFaucetRecoveryJournal(scope,target).attempts.find(a=>a.request.id===id);if(!original||!faucetRecoveryOpen(original))return original??null;
 const a=clone(original),ticket=a.ticket,shared=()=>ticket?JSON.stringify(readWalletRequestRecord(ticket.network,ticket.owner,target)):null,before=shared();
 if(ticket){const options={storage:target,chain:input.chain,signal:input.signal,answer:a.answer},outcome=await resolveWalletRequest(ticket,options);
  if(walletMessageExpired(outcome,0)){a.walletClosed=true;a.state='not-sent';}
  else if(outcome.status==='observed'&&outcome.final){a.walletClosed=true;const hop=await readFirstHop(ticket,0,options);if(hop.status==='rejected')a.state='not-sent';
   else if(hop.status==='executed'){const resolution=recoveryResolution(await input.readRecovery(a.request.original),a.request);if(resolution){a.state='confirmed';a.resolution=resolution;}}
  }
 }
 return lock(faucetJournalKey(scope),async()=>{const publish=async()=>{input.signal?.throwIfAborted();const j=readFaucetRecoveryJournal(scope,target),latest=j.attempts.find(v=>v.request.id===id);
   if(input.current&&!input.current()||!latest||!same(latest,original)||before!==shared())return latest??null;
   if(!ticket){a.walletClosed=true;a.state='not-sent';}j.attempts[j.attempts.indexOf(latest)]=a;save(j,target);return clone(a);};return ticket?lock(walletRequestRecordKey(ticket.network,ticket.owner),publish):publish();});
}
