import { Address, Cell } from '@ton/core';
import type { SendTransactionRequest } from '@tonconnect/sdk';
import { NATIVE_ASSET_SYMBOL } from '../constants';
import { has } from '../i18n';
import type { WalletProvability } from './walletRequest';
import type { ReviewRow, ReviewWalletAction, ReviewValue, WalletActionDetails, WalletDispatchOptions, WalletTransferWalletAction } from './walletAction';

/* -------------------------------------------------------------------------------------------------
 * "Not sent" failures
 * ----------------------------------------------------------------------------------------------- */

import { WalletRequestNotSentError, notSent, notSentFrom, type NotSentReason } from './walletRequestNotSent';

export const WALLET_APPROVAL_MIN_SECONDS = 60;
export const walletRequestSecondsRemaining = (validUntil: number, now = Date.now()) =>
  Math.max(0, validUntil - Math.floor(now / 1000));

/* -------------------------------------------------------------------------------------------------
 * The review controller
 * ----------------------------------------------------------------------------------------------- */

export type WalletRequestContext = { owner: string; network: string; route: string; generation: number };
export type WalletRequestAdmission = { provability: WalletProvability; keep: { neededNano: string; leftNano: string } | null };
export type WalletRequestReview = {
  id: number;
  context: Readonly<WalletRequestContext>;
  transaction: SendTransactionRequest;
  totalNano: string;
  action: WalletActionDetails;
  provability?: WalletProvability;
  keep?: { neededNano: string; leftNano: string } | null;
};
const freeze = <T>(value: T): T => {
  if (value && typeof value === 'object') {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
};
export const sameWalletRequestContext = (a: WalletRequestContext, b: WalletRequestContext) =>
  a.owner === b.owner && a.network === b.network && a.route === b.route && a.generation === b.generation;

const SYMBOL = /^[A-Za-z0-9][A-Za-z0-9._-]{0,19}$/;
const DECIMAL = /^(0|[1-9]\d*)(\.\d{1,36})?$/;
const record = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value);
const canonicalAddress = (value: unknown) => { try { return typeof value === 'string' && Address.parse(value).toRawString() !== ''; } catch { return false; } };
const knownKey = (value: unknown): value is string => typeof value === 'string' && has(value);
const messageParams = (value: unknown) => value === undefined || (record(value) && Object.values(value).every(item =>
  typeof item === 'string' || (typeof item === 'number' && Number.isFinite(item))));

/* -------------------------------------------------------------------------------------------------
 * The signed payload, decoded
 * ----------------------------------------------------------------------------------------------- */

/** TEP-74 `transfer#0f8a7ea5`: the operation code of a jetton transfer message body. */
const JETTON_TRANSFER_OP = 0x0f8a7ea5;
/** The only message fields the dialog can account for. Anything else would be signed unseen. */
const MESSAGE_FIELDS = new Set(['address', 'amount', 'payload', 'stateInit']);

/** What a message body does, read from the bytes that will be signed. */
export type DecodedBody =
  /** No body: a plain GRAM transfer. */
  | { kind: 'none' }
  /** A text comment (operation code 0). The text is shown with control and direction marks replaced. */
  | { kind: 'comment'; text: string }
  /** A TEP-74 token transfer: `amount` is in the token's smallest units, `destination` is the recipient's OWNER wallet. */
  | { kind: 'jetton-transfer'; queryId: bigint; amount: bigint; destination: string; responseDestination: string | null; forwardAmount: bigint }
  /** Anything else: a call to a contract. `op` is its 32-bit operation code, or null when the body has none or cannot be read. */
  | { kind: 'call'; op: number | null };

export type DecodedMessage = {
  /** Position in the request, from 0. */
  index: number;
  /** The destination in raw form (`0:` and 64 hex digits). */
  destination: string;
  bounceable: boolean;
  /** The exact GRAM in nanograms. */
  value: bigint;
  /** True when the message carries contract code and data (a deployment). */
  deploys: boolean;
  body: DecodedBody;
};

type BodySlice = ReturnType<Cell['beginParse']>;

/**
 * What follows `response_destination` in a transfer, read as the forward amount in nanograms, or null when
 * the rest does not have that exact shape. Two layouts exist, and a body is accepted only if exactly one of
 * them reads it cleanly:
 *  - canonical TEP-74: `custom_payload:(Maybe ^Cell) forward_ton_amount forward_payload:(Either Cell ^Cell)`;
 *  - the reference layout the app writes today (services/tonPayloads.ts): a bare custom-payload reference,
 *    the forward amount, a bare forward-payload reference, and nothing else. It goes away when that builder
 *    writes the canonical layout.
 */
function transferTrailer(rest: BodySlice): bigint | null {
  const canonical = (): bigint | null => {
    try {
      const cursor = rest.clone();
      if (cursor.loadBit()) cursor.loadRef();
      const forward = cursor.loadCoins();
      if (cursor.loadBit()) { cursor.loadRef(); if (cursor.remainingBits !== 0 || cursor.remainingRefs !== 0) return null; }
      return forward;
    } catch { return null; }
  };
  const reference = (): bigint | null => {
    try {
      const cursor = rest.clone();
      cursor.loadRef();
      const forward = cursor.loadCoins();
      cursor.loadRef();
      return cursor.remainingBits === 0 && cursor.remainingRefs === 0 ? forward : null;
    } catch { return null; }
  };
  const first = canonical(), second = reference();
  if (first !== null && second !== null) return first === second ? first : null;
  return first ?? second;
}

function decodeBody(payload: unknown): DecodedBody {
  if (payload === undefined) return { kind: 'none' };
  if (typeof payload !== 'string') return { kind: 'call', op: null };
  let slice: BodySlice;
  try { slice = Cell.fromBase64(payload).beginParse(); } catch { return { kind: 'call', op: null }; }
  if (slice.remainingBits === 0 && slice.remainingRefs === 0) return { kind: 'none' };
  if (slice.remainingBits < 32) return { kind: 'call', op: null };
  const op = slice.loadUint(32);
  try {
    if (op === 0) return { kind: 'comment', text: slice.loadStringTail().replace(/[\p{Cc}\p{Cf}]/gu, '\ufffd') };
    if (op === JETTON_TRANSFER_OP) {
      const queryId = slice.loadUintBig(64);
      const amount = slice.loadCoins();
      const destination = slice.loadAddress().toRawString();
      const response = slice.loadMaybeAddress();
      const forwardAmount = transferTrailer(slice);
      // A transfer whose tail cannot be read is shown as the call it is, never as a partial transfer.
      if (forwardAmount !== null) return { kind: 'jetton-transfer', queryId, amount, destination, responseDestination: response ? response.toRawString() : null, forwardAmount };
    }
  } catch { /* A truncated or malformed body is shown as the call it is. */ }
  return { kind: 'call', op };
}

/**
 * Reads every message of a request exactly as it will be signed: where it goes, how many nanograms it
 * carries, and what its body does. Throws when a destination or an amount cannot be read, because a
 * request that cannot be shown in full must not be signed.
 */
export function decodeRequestMessages(request: Pick<SendTransactionRequest, 'messages'>): DecodedMessage[] {
  if (!Array.isArray(request.messages) || request.messages.length === 0) throw new Error('A request needs at least one message.');
  return request.messages.map((message, index) => {
    if (typeof message.address !== 'string' || typeof message.amount !== 'string' || !/^(0|[1-9]\d*)$/.test(message.amount)) throw new Error('Unreadable message.');
    const raw = Address.isRaw(message.address);
    const friendly = raw ? null : Address.parseFriendly(message.address);
    const address = raw ? Address.parseRaw(message.address) : friendly!.address;
    return { index, destination: address.toRawString(), bounceable: friendly?.isBounceable ?? true, value: BigInt(message.amount),
      deploys: message.stateInit !== undefined, body: decodeBody(message.payload) };
  });
}

/** An amount row's canonical decimal text, in the token's smallest units; null when it has more places than `decimals`. */
function decimalToRaw(text: string, decimals: number): bigint | null {
  const [whole, fraction = ''] = text.split('.');
  return fraction.length > decimals ? null : BigInt(whole + fraction.padEnd(decimals, '0'));
}
const SAFE_DECIMALS = (value: unknown): value is number => Number.isSafeInteger(value) && (value as number) >= 0 && (value as number) <= 36;

/**
 * Compares one bound row with the decoded message. A descriptor arrives from a caller, so it is read as
 * untrusted data: anything that cannot be proven equal to the signed message is a mismatch.
 */
function bindingHolds(row: ReviewRow, descriptor: unknown, messages: DecodedMessage[]): boolean {
  if (!record(descriptor)) return false;
  const { kind, field, messageIndex, decimals } = descriptor;
  if (!Number.isSafeInteger(messageIndex) || (messageIndex as number) < 0) return false;
  const message = messages[messageIndex as number], value = row.value;
  if (!message) return false;
  const address = (expected: string | null) => value.type === 'address' && expected !== null && Address.parse(value.address).toRawString() === expected;
  const amount = (expected: bigint, places: number, symbol: string | null) =>
    value.type === 'amount' && (symbol === null || value.symbol === symbol) && decimalToRaw(value.amount, places) === expected;
  const body = message.body;
  if (kind === 'native-transfer') {
    if (body.kind !== 'none' && body.kind !== 'comment') return false;
    return field === 'destination' ? address(message.destination) : field === 'value' ? amount(message.value, 9, NATIVE_ASSET_SYMBOL) : false;
  }
  if (kind === 'jetton-transfer' && body.kind === 'jetton-transfer') {
    switch (field) {
      case 'recipient': return address(body.destination);
      case 'responseDestination': return address(body.responseDestination);
      case 'forwardAmount': return amount(body.forwardAmount, 9, NATIVE_ASSET_SYMBOL);
      // The token's symbol is not in the message (it addresses a token wallet), so only the amount is compared.
      case 'amount': return SAFE_DECIMALS(decimals) && amount(body.amount, decimals, null);
      default: return false;
    }
  }
  return false;
}

/* -------------------------------------------------------------------------------------------------
 * Validation
 * ----------------------------------------------------------------------------------------------- */

function validReviewValue(value: unknown): value is ReviewValue {
  if (!record(value)) return false;
  switch (value.type) {
    case 'amount': return typeof value.amount === 'string' && DECIMAL.test(value.amount) && typeof value.symbol === 'string' && SYMBOL.test(value.symbol);
    case 'address': return canonicalAddress(value.address);
    case 'text': return typeof value.text === 'string' && value.text.length > 0 && value.text.length <= 512;
    case 'date': return Number.isSafeInteger(value.seconds) && (value.seconds as number) > 0;
    default: return false;
  }
}
function requireReview(action: ReviewWalletAction, messages: DecodedMessage[]): void {
  if (!knownKey(action.titleKey) || (action.summaryKey !== undefined && !knownKey(action.summaryKey)) || (action.noteKey !== undefined && !knownKey(action.noteKey)) ||
    (action.fundingLabelKey !== undefined && !knownKey(action.fundingLabelKey)) ||
    !messageParams(action.params) || !Array.isArray(action.rows) || action.rows.length === 0 ||
    !action.rows.every(row => record(row) && knownKey(row.labelKey) && messageParams(row.labelParams) && validReviewValue(row.value))) throw new Error('Invalid review');
  const step = action.step;
  if (step && (!Number.isSafeInteger(step.current) || !Number.isSafeInteger(step.total) || step.current < 1 || step.current > step.total)) throw new Error('Invalid approval sequence');
  // A bound row must say what the signed message says; a descriptor that cannot be proven is a mismatch.
  if (action.rows.some(row => row.bind !== undefined && !bindingHolds(row, row.bind, messages))) throw notSent('rowMismatch');
}
function requireTransfer(action: WalletTransferWalletAction, options: WalletDispatchOptions): void {
  const canonicalAmount = (value: unknown): value is string => typeof value === 'string' && DECIMAL.test(value);
  if (action.step !== 'transfer' || typeof action.symbol !== 'string' || !SYMBOL.test(action.symbol) || !canonicalAmount(action.amount) ||
    Number(action.amount) <= 0 || !canonicalAddress(action.recipient) ||
    !(action.memo === null || (typeof action.memo === 'string' && new TextEncoder().encode(action.memo).length <= 512)) ||
    !record(action.fee) || !canonicalAmount(action.fee.amount) || !['reserve', 'attached'].includes(action.fee.mode)) throw new Error('Invalid transfer review');
  // A transfer cannot be rebuilt from this description alone: the saved record must vouch for the request.
  if (typeof options.verify !== 'function') throw new Error('A transfer review needs its saved record');
}

/** Rebuild-and-compare for every typed kind. A kind that is not listed here cannot be reviewed. */
function validateWalletAction(request: SendTransactionRequest, action: WalletActionDetails, options: WalletDispatchOptions, messages: DecodedMessage[]): void {
  if (!action || typeof action !== 'object') throw new Error('Missing wallet action');
  switch (action.kind) {
    case 'review': requireReview(action, messages); break;
    case 'wallet-transfer': requireTransfer(action, options); break;
    default: { const unknown: never = action; throw new Error(`Unknown wallet action ${String((unknown as { kind?: unknown }).kind)}`); }
  }
}

/** How long a caller's `verify` may take. A verifier that is still working then has not vouched for the request. */
export const WALLET_VERIFY_TIMEOUT_MS = 10_000;
const isThenable = (value: unknown): value is PromiseLike<unknown> =>
  (typeof value === 'object' || typeof value === 'function') && value !== null && typeof (value as { then?: unknown }).then === 'function';
/** A verifier vouches by returning or resolving without `false`; `false` refuses. A throw or rejection refuses too. */
function acceptVerdict(verdict: unknown): void {
  if (verdict === false) throw notSent('verifyFailed');
}
/** The longest delay setTimeout keeps; a longer one fires at once. */
const MAX_TIMER_MS = 2_147_483_647;

/**
 * A prepared request needs its own explicit review; elapsed RPC time is not user intent.
 *
 * What the person approves is what the wallet receives. `request` therefore works in one fixed order:
 * copy the request and the action, stamp the sender, check the network, run the typed validator, freeze
 * both deeply, and only then run the caller's `verify` on the frozen request. `verify` can read and
 * refuse, never change. A throw, a `false`, a rejection or a timeout refuses the request, and no review
 * is shown. A synchronous `verify` decides before `request` returns; an asynchronous one decides
 * before the review opens, and `result` rejects when it refuses.
 */
export function createWalletRequestReviewController(
  changed: (review: WalletRequestReview | null) => void,
  now = () => Math.floor(Date.now() / 1000)
) {
  let nextId = 0;
  let activeId: number | null = null;
  let expiryTimer: ReturnType<typeof setTimeout> | null = null;
  let pending: {
    review: WalletRequestReview;
    resolve: (request: SendTransactionRequest | null) => void;
    reject: (error: WalletRequestNotSentError) => void;
  } | null = null;
  // A request whose asynchronous verifier has not answered yet: no review is open, but it is in flight.
  let verifying: { fail: (error: WalletRequestNotSentError) => void } | null = null;
  const clear = () => {
    if (expiryTimer) clearTimeout(expiryTimer);
    expiryTimer = null; pending = null; changed(null);
  };
  const invalidate = (reason: NotSentReason) => {
    if (verifying) { verifying.fail(notSent(reason)); return; }
    if (!pending) return;
    const original = pending;
    clear();
    original.reject(notSent(reason));
  };

  /** Everything that must hold before a review may exist. Returns the frozen request and action. */
  function prepare(transaction: SendTransactionRequest, context: WalletRequestContext, action: WalletActionDetails, options: WalletDispatchOptions) {
    try {
      const request: SendTransactionRequest = JSON.parse(JSON.stringify(transaction));
      const reviewed: WalletActionDetails = JSON.parse(JSON.stringify(action));
      const owner = Address.parse(context.owner).toRawString();
      if (request.from && Address.parse(request.from).toRawString() !== owner) throw new Error('Sender differs');
      request.from = owner;
      if (!request.network || String(request.network) !== context.network) throw new Error('Network differs');
      if (!Number.isSafeInteger(request.validUntil) || request.validUntil <= now()) throw new Error('Request expired');
      if (!Array.isArray(request.messages) || !request.messages.length || request.messages.some(message => typeof message.amount !== 'string' || !/^(0|[1-9]\d*)$/.test(message.amount))) throw new Error('Invalid messages');
      // The dialog can show a destination, an amount, a body and a deployment flag. A currency or field it cannot show is not signed.
      if (request.messages.some(message => !record(message) || message.extraCurrency !== undefined)) throw notSent('extraCurrency');
      if (request.messages.some(message => Object.keys(message).some(key => !MESSAGE_FIELDS.has(key)) ||
        (message.payload !== undefined && typeof message.payload !== 'string') || (message.stateInit !== undefined && typeof message.stateInit !== 'string'))) throw new Error('Unsupported message field');
      const messages = decodeRequestMessages(request);
      const before = JSON.stringify([request, reviewed]);
      validateWalletAction(request, reviewed, options, messages);
      if (JSON.stringify([request, reviewed]) !== before) throw new Error('A validator changed the request');
      return { request: freeze(request), reviewed: freeze(reviewed) };
    } catch (cause) {
      throw notSentFrom(cause, 'invalid');
    }
  }

  return {
    request(transaction: SendTransactionRequest, context: WalletRequestContext, action: WalletActionDetails,
      options: WalletDispatchOptions & { admit?: (request: Readonly<SendTransactionRequest>) => WalletRequestAdmission | Promise<WalletRequestAdmission> } = {}) {
      if (activeId !== null) throw notSent('busy');
      const { request, reviewed } = prepare(transaction, context, action, options);
      let verdict: unknown;
      try { verdict = options.verify?.(request); if (!isThenable(verdict)) acceptVerdict(verdict); }
      catch (cause) { throw notSentFrom(cause, 'verifyFailed'); }
      const id = ++nextId;
      activeId = id;
      const result = new Promise<SendTransactionRequest | null>((resolve, reject) => {
        let settled = false, timer: ReturnType<typeof setTimeout> | undefined;
        const fail = (error: WalletRequestNotSentError) => {
          if (settled) return;
          settled = true; clearTimeout(timer); verifying = null; activeId = null; reject(error);
        };
        const open = (admission: WalletRequestAdmission = { provability: 'provable', keep: null }) => {
          if (settled) return;
          if (request.validUntil <= now()) { fail(notSent('reviewExpired')); return; }
          clearTimeout(timer); verifying = null;
          const review: WalletRequestReview = freeze({ id, context: { ...context }, transaction: request, action: reviewed,
            totalNano: request.messages.reduce((sum, message) => sum + BigInt(message.amount), 0n).toString(), ...admission });
          pending = { review, resolve, reject };
          expiryTimer = setTimeout(() => { if (pending?.review.id === id) invalidate('reviewExpired'); },
            Math.min(MAX_TIMER_MS, Math.max(0, (request.validUntil - now()) * 1000)));
          changed(review);
        };
        const admit = () => {
          if (settled) return;
          clearTimeout(timer);
          if (!options.admit) { open(); return; }
          let admission: WalletRequestAdmission | Promise<WalletRequestAdmission>;
          try { admission = options.admit(request); } catch (cause) { fail(notSentFrom(cause, 'walletUnverified')); return; }
          if (!isThenable(admission)) { open(admission); return; }
          verifying = { fail };
          timer = setTimeout(() => fail(notSent('walletUnverified')), 12_000);
          Promise.resolve(admission).then(open, cause => fail(notSentFrom(cause, 'walletUnverified')));
        };
        if (!isThenable(verdict)) { admit(); return; }
        verifying = { fail };
        timer = setTimeout(() => fail(notSent('verifyTimeout')), WALLET_VERIFY_TIMEOUT_MS);
        Promise.resolve(verdict).then(value => {
          if (settled) return;
          try { acceptVerdict(value); } catch (cause) { fail(notSentFrom(cause, 'verifyFailed')); return; }
          admit();
        }, cause => fail(notSentFrom(cause, 'verifyFailed')));
      });
      return { id, result };
    },
    approve(id: number, context: WalletRequestContext, trusted: boolean) {
      if (!trusted || !pending || pending.review.id !== id) return false;
      if (!sameWalletRequestContext(pending.review.context, context)) {
        invalidate('contextChanged');
        return false;
      }
      if (pending.review.transaction.validUntil - now() < WALLET_APPROVAL_MIN_SECONDS) {
        invalidate('tooLate');
        return false;
      }
      const original = pending;
      clear();
      // The SDK receives an independent copy of exactly the reviewed fields.
      original.resolve(JSON.parse(JSON.stringify(original.review.transaction)));
      return true;
    },
    cancel(id: number, trusted: boolean) {
      if (!trusted || !pending || pending.review.id !== id) return;
      const original = pending;
      clear();
      original.resolve(null);
    },
    invalidate,
    finish(id: number) { if (activeId === id && !pending && !verifying) activeId = null; }
  };
}
