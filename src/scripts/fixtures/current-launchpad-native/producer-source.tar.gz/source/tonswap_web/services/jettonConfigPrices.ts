import { TONSWAP_RELEASE } from '../releaseManifest';
import { ChainReadError, isChainReadError } from './chainReadError';
import { indexerRequest, IndexerRequestError } from './indexer';
import { isReleaseMismatchError, ReleaseMismatchError } from './releaseTransport';
import type { JettonQuotePrices } from './jettonWalletProfile';
import type { ChainHead } from './toncenter';

export type JettonPriceHead = ChainHead & { utime: number; rootHashHex: string };
export class ConfigHeadMismatchError extends ChainReadError {
  readonly reason = 'head_mismatch';
  constructor() { super('unavailable', { devMessage: 'Refresh the operation: chain funding prices moved to another block.' }); }
}
const failure = () => new ChainReadError('unavailable', { devMessage: 'The authenticated chain funding prices are unavailable.' });
const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
const exact = (value: unknown, keys: readonly string[]): value is Record<string, unknown> => object(value)
  && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
const digest = (value: unknown): value is string => typeof value === 'string' && /^[0-9a-f]{64}$/.test(value) && !/^0+$/.test(value);
const uint64 = (value: unknown): bigint => {
  if (typeof value !== 'string' || !/^(0|[1-9][0-9]{0,19})$/.test(value)) throw failure();
  const result = BigInt(value);
  if (result >= 1n << 64n) throw failure();
  return result;
};
const checkedHead = (head: ChainHead): JettonPriceHead => {
  if (!Number.isSafeInteger(head.seqno) || head.seqno <= 0 || !Number.isSafeInteger(head.utime)
    || head.utime! <= 0 || head.utime! > 0xffffffff || !digest(head.rootHashHex)) throw failure();
  return { ...head, utime: head.utime!, rootHashHex: head.rootHashHex };
};

/** Parse the selected basechain prices without accepting numeric rounding or a different block. */
export function decodeJettonQuotePrices(value: unknown, expected: JettonPriceHead): { head: JettonPriceHead; prices: JettonQuotePrices } {
  const release = TONSWAP_RELEASE;
  if (!release) throw failure();
  if (!exact(value, ['schema', 'releaseId', 'manifestHash', 'asOf', 'basechain']) || value.schema !== 'tonswap-config-prices-v1') throw failure();
  if (value.manifestHash !== release.manifestHash || value.releaseId !== release.releaseId)
    throw new ReleaseMismatchError(release.manifestHash, typeof value.manifestHash === 'string' ? value.manifestHash : null);
  if (!exact(value.asOf, ['masterchainSeqno', 'unixTime', 'blockRootHash'])) throw failure();
  if (value.asOf.masterchainSeqno !== expected.seqno || value.asOf.unixTime !== expected.utime || value.asOf.blockRootHash !== expected.rootHashHex)
    throw new ConfigHeadMismatchError();
  const p = value.basechain;
  if (!exact(p, ['gas', 'forward', 'storage']) || !exact(p.gas, ['flatGasPrice', 'flatLimit', 'other'])
    || !exact(p.gas.other, ['gasPrice']) || !exact(p.forward, ['lumpPrice', 'bitPrice', 'cellPrice'])
    || !exact(p.storage, ['bit_price_ps', 'cell_price_ps'])) throw failure();
  const prices: JettonQuotePrices = {
    gas: Object.freeze({ flatGasPrice: uint64(p.gas.flatGasPrice), flatLimit: uint64(p.gas.flatLimit),
      other: Object.freeze({ gasPrice: uint64(p.gas.other.gasPrice) }) }),
    forward: Object.freeze({ lumpPrice: uint64(p.forward.lumpPrice), bitPrice: uint64(p.forward.bitPrice), cellPrice: uint64(p.forward.cellPrice) }),
    storage: Object.freeze({ bit_price_ps: uint64(p.storage.bit_price_ps), cell_price_ps: uint64(p.storage.cell_price_ps) }),
  };
  return { head: Object.freeze({ ...expected }), prices: Object.freeze(prices) };
}

/** A single release-bound current read. A moved head requires a fresh operation review; there is no cached price or RPC substitution. */
export async function readJettonQuotePrices(head: ChainHead, signal?: AbortSignal): Promise<{ head: JettonPriceHead; prices: JettonQuotePrices }> {
  signal?.throwIfAborted();
  const expected = checkedHead(head);
  try {
    const value = await indexerRequest<unknown>('/v1/config-prices', {
      params: { masterchainSeqno: expected.seqno, blockRootHash: expected.rootHashHex },
      timeoutMs: 10_000, maxAttempts: 1, health: 'chain', cache: 'no-store', signal,
    });
    signal?.throwIfAborted();
    return decodeJettonQuotePrices(value, expected);
  } catch (error) {
    if (signal?.aborted) throw signal.reason;
    if (isReleaseMismatchError(error) || isChainReadError(error)) throw error;
    if (error instanceof IndexerRequestError && error.status === 409 && error.code === 'head_mismatch') throw new ConfigHeadMismatchError();
    throw new ChainReadError('unavailable', { cause: error, devMessage: 'The authenticated chain funding prices are unavailable.' });
  }
}
