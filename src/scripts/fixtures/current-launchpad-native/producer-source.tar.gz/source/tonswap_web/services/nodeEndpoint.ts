import { TESTNET_CONFIG } from '../constants';
import { isLoopbackHostname, isToncenterHostname } from '../urlSecurity';

/*
 * The TON node the app reads from. This module is the only place that knows the storage key, decides
 * which addresses are acceptable, and says which one is in use.
 *
 *  - The default is the endpoint the build was configured with. It is never written to storage, so a
 *    new default reaches every returning visitor.
 *  - A custom endpoint is an explicit choice: it is validated, stored under one key, and removed when
 *    the person goes back to the default or enters the default's own address.
 *  - Nothing measures or switches nodes by itself. A connection test is a request the person makes,
 *    and it changes nothing.
 *
 * An endpoint is acceptable when it is a TON Center address (https), a loopback address, or an
 * address on the page's own origin. Anything else could send the person's balance and quote reads
 * to a server nobody reviewed.
 */

export const NODE_ENDPOINT_STORAGE_KEY = 'ton-node-url';
export const NODE_TEST_TIMEOUT_MS = 5000;

/** Where an acceptable endpoint lives. */
export type NodeEndpointKind = 'toncenter' | 'loopback' | 'same-origin';

/** Why an endpoint was refused: blank, not an address, or an address outside the allow-list. */
export type NodeEndpointRefusal = 'empty' | 'invalid' | 'notAllowed';

// Every variant declares every field: this project does not narrow on `ok` (no strictNullChecks), so a
// caller reads `check.url` or `check.reason` after testing `check.ok` without a cast.
export type NodeEndpointCheck =
  | { ok: true; url: string; kind: NodeEndpointKind; reason?: never }
  | { ok: false; reason: NodeEndpointRefusal; url?: never; kind?: never };

/** The page the app runs in, when there is one: relative endpoints and "same origin" are measured against it. */
export type NodePage = { href: string; origin: string };

const currentPage = (): NodePage | null => {
  if (typeof window === 'undefined') return null;
  const href = window.location?.href;
  if (!href) return null;
  try {
    return { href, origin: window.location.origin || new URL(href).origin };
  } catch {
    return null;
  }
};

const parse = (value: string, page: NodePage | null): URL | null => {
  try {
    return page ? new URL(value, page.href) : new URL(value);
  } catch {
    return null;
  }
};

/**
 * Where an endpoint lives, or null when it is outside the allow-list. The answer comes from the
 * resolved address, so `//elsewhere.example/rpc` is judged by `elsewhere.example`, not by the slash it
 * starts with. Without a page (a test or a server) a path starting with one slash counts as local.
 */
export function classifyNodeEndpoint(value: string, page: NodePage | null = currentPage()): NodeEndpointKind | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (!page && /^\/(?!\/)/.test(trimmed)) return 'same-origin';
  const url = parse(trimmed, page);
  if (!url) return null;
  if (isToncenterHostname(url.hostname)) return 'toncenter';
  if (isLoopbackHostname(url.hostname)) return 'loopback';
  return page && url.origin === page.origin ? 'same-origin' : null;
}

/** True for an endpoint served by this machine or this origin: the only kind a strict build may use. */
export function isLocalNodeEndpoint(value: string | null | undefined, page: NodePage | null = currentPage()): boolean {
  if (!value) return false;
  const kind = classifyNodeEndpoint(value, page);
  return kind === 'loopback' || kind === 'same-origin';
}

/** Checks an address a person typed: resolves it, applies the allow-list, and returns the address to store. */
export function checkNodeEndpoint(value: string | null | undefined, page: NodePage | null = currentPage()): NodeEndpointCheck {
  const trimmed = value?.trim();
  if (!trimmed) return { ok: false, reason: 'empty' };
  // Text without a scheme or a leading slash ("testnet.toncenter.com/api") would silently resolve to a
  // path on this page, so it is not an address.
  if (!/^(?:[a-z][a-z0-9+.-]*:|\/)/i.test(trimmed)) return { ok: false, reason: 'invalid' };
  const url = parse(trimmed, page);
  if (!url || (url.protocol !== 'https:' && url.protocol !== 'http:') || url.username || url.password) {
    return { ok: false, reason: 'invalid' };
  }
  const kind = classifyNodeEndpoint(trimmed, page);
  if (!kind) return { ok: false, reason: 'notAllowed' };
  // Plain http is for this machine or this page's own origin; a hosted node must use https.
  if (url.protocol === 'http:' && kind === 'toncenter') return { ok: false, reason: 'notAllowed' };
  return { ok: true, url: url.toString(), kind };
}

/**
 * A configured address as an absolute URL, or the text unchanged when it cannot be resolved. The build
 * configuration is trusted, so it is not held to the allow-list.
 */
export function resolveConfiguredEndpoint(value: string, page: NodePage | null = currentPage()): string {
  const trimmed = value.trim();
  if (!trimmed) return value;
  return parse(trimmed, page)?.toString() ?? value;
}

const storage = (): Storage | null => {
  if (typeof window === 'undefined') return null;
  try {
    return window.localStorage ?? null;
  } catch {
    return null;
  }
};

/** The endpoint the build was configured with. */
export function defaultNodeEndpoint(): string {
  return resolveConfiguredEndpoint(TESTNET_CONFIG.toncenterEndpoint);
}

/**
 * The custom endpoint the person chose, or null. A stored value that is no longer acceptable, or that
 * only repeats the default, is removed instead of being used.
 */
export function getCustomNodeEndpoint(): string | null {
  const store = storage();
  if (!store) return null;
  try {
    const stored = store.getItem(NODE_ENDPOINT_STORAGE_KEY);
    if (stored === null) return null;
    const check = checkNodeEndpoint(stored);
    if (check.ok && check.url !== defaultNodeEndpoint()) return check.url;
    store.removeItem(NODE_ENDPOINT_STORAGE_KEY);
  } catch {
    // Storage is unavailable (private mode): the default is used.
  }
  return null;
}

/** The endpoint requests go to right now. */
export function getNodeEndpoint(): string {
  return getCustomNodeEndpoint() ?? defaultNodeEndpoint();
}

export type SetNodeEndpointResult =
  | { ok: true; custom: string | null; reason?: never }
  | { ok: false; reason: NodeEndpointRefusal | 'storage'; custom?: never };

/**
 * Chooses the endpoint. A blank value or the default's own address returns to the default and stores
 * nothing; anything else is stored only if it passes the allow-list.
 */
export function setCustomNodeEndpoint(value: string | null | undefined): SetNodeEndpointResult {
  const store = storage();
  const blank = !value?.trim();
  const check = blank ? null : checkNodeEndpoint(value);
  if (check && !check.ok) return { ok: false, reason: check.reason };
  const custom = check && check.url !== defaultNodeEndpoint() ? check.url : null;
  if (!store) return custom === null ? { ok: true, custom: null } : { ok: false, reason: 'storage' };
  try {
    if (custom === null) store.removeItem(NODE_ENDPOINT_STORAGE_KEY);
    else store.setItem(NODE_ENDPOINT_STORAGE_KEY, custom);
    return { ok: true, custom };
  } catch {
    return { ok: false, reason: 'storage' };
  }
}

export type NodeConnectionResult =
  | { ok: true; latencyMs: number; reason?: never }
  | { ok: false; reason: NodeEndpointRefusal | 'timeout' | 'unreachable' | 'rejected'; latencyMs?: never };

export type NodeConnectionOptions = {
  timeoutMs?: number;
  fetch?: typeof fetch;
  now?: () => number;
};

/**
 * One request to the node, on demand: does it answer? With no address it tests the endpoint in use; with
 * one it tests that address (after the same allow-list check) so a person can try before saving. It never
 * stores or switches anything.
 */
export async function testNodeConnection(candidate?: string, options: NodeConnectionOptions = {}): Promise<NodeConnectionResult> {
  let url = getNodeEndpoint();
  if (candidate !== undefined) {
    const check = checkNodeEndpoint(candidate);
    if (!check.ok) return { ok: false, reason: check.reason };
    url = check.url;
  }
  const send = options.fetch ?? fetch;
  const now = options.now ?? (() => performance.now());
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs ?? NODE_TEST_TIMEOUT_MS);
  const headers: Record<string, string> = { 'content-type': 'application/json' };
  // The API key goes to TON Center only, never to a custom host.
  if (TESTNET_CONFIG.toncenterApiKey && classifyNodeEndpoint(url) === 'toncenter') {
    headers['X-API-Key'] = TESTNET_CONFIG.toncenterApiKey;
  }
  const started = now();
  try {
    const response = await send(url, {
      method: 'POST',
      headers,
      cache: 'no-store',
      signal: controller.signal,
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'getMasterchainInfo', params: {} })
    });
    if (!response.ok) return { ok: false, reason: 'rejected' };
    const body: unknown = await response.json().catch(() => null);
    // Only a JSON-RPC style object is a node. A page, an array or an empty object that answered 200 is
    // some other server, and saving it would break every balance and quote read.
    if (!body || typeof body !== 'object' || Array.isArray(body)) return { ok: false, reason: 'rejected' };
    const { ok, error, result } = body as { ok?: unknown; error?: unknown; result?: unknown };
    if (ok === false || (error !== undefined && error !== null)) return { ok: false, reason: 'rejected' };
    if (ok !== true && (result === undefined || result === null)) return { ok: false, reason: 'rejected' };
    return { ok: true, latencyMs: Math.max(0, Math.round(now() - started)) };
  } catch {
    return { ok: false, reason: controller.signal.aborted ? 'timeout' : 'unreachable' };
  } finally {
    clearTimeout(timer);
  }
}
