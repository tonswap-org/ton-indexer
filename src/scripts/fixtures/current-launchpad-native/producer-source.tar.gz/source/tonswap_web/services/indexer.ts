import { Address, Cell } from '@ton/core';
import { Buffer } from 'buffer';
import { TESTNET_CONFIG, TONSWAP_RELEASE } from '../constants';
import { RPC_FALLBACK_DISABLED, TRANSPORT_SLOW_THRESHOLD_MS, transportBreaker, type TransportOutcome } from './transportHealth';
import { RELEASE_HEADER, assertReleaseResponse, currentReleaseHash, isReleaseMismatchError } from './releaseTransport';

export const toIndexerAssetSymbol = (symbol: string) => symbol.trim();

export const toIndexerMarketKey = (marketKey: string) => {
  const spotMatch = marketKey.match(/^spot:([^-]+)-([^-]+)$/i);
  if (spotMatch) {
    return `spot:${toIndexerAssetSymbol(spotMatch[1])}-${toIndexerAssetSymbol(spotMatch[2])}`;
  }
  const perpsLinearMatch = marketKey.match(/^perps:linear:([^:]+)$/i);
  if (perpsLinearMatch) {
    return `perps:linear:${toIndexerAssetSymbol(perpsLinearMatch[1])}`;
  }
  const optionsMatch = marketKey.match(/^options:([^:]+):([^:]+)$/i);
  if (optionsMatch) {
    return `options:${toIndexerAssetSymbol(optionsMatch[1])}:${optionsMatch[2]}`;
  }
  return marketKey;
};

type IndexerStatus = 'success' | 'failed' | 'pending';

type IndexerDetail =
  | {
      kind: 'swap';
      payToken?: string;
      receiveToken?: string;
      payAmount?: string;
      receiveAmount?: string;
      queryId?: string;
      executionType?: string;
      twapSlice?: number;
      twapTotal?: number;
      querySequence?: number;
      queryNonce?: number;
    }
  | {
      kind: 'lp';
      pair?: string;
      tokenA?: string;
      tokenB?: string;
      amountA?: string;
      amountB?: string;
    }
  | {
      kind: 'mint';
      mode?: string;
      inputToken?: string;
      outputToken?: string;
      inputAmount?: string;
      outputAmount?: string;
    }
  | {
      kind: 'transfer';
      asset?: string;
      amount?: string;
    }
  | { kind: 'unknown' };

export type IndexerTxEntry = {
  txId: string;
  utime: number;
  status: IndexerStatus;
  reason?: string;
  txType: string;
  inSource?: string;
  inValue?: string;
  outCount: number;
  detail?: IndexerDetail;
  kind: string;
  actions: unknown[];
  lt: string;
  hash: string;
  inMessage?: {
    source?: string;
    destination?: string;
    value?: string;
    op?: number;
    body?: string;
  } | null;
  outMessages?: Array<{
    source?: string;
    destination?: string;
    value?: string;
    op?: number;
    body?: string;
  }> | null;
};

export type IndexerTxResponse = {
  page: number;
  page_size: number;
  total_txs: number;
  total_pages: number | null;
  total_pages_min: number;
  history_complete: boolean;
  txs: IndexerTxEntry[];
  network: string;
};

export type IndexerAccountStateResponse = {
  address: string;
  last_tx_lt: string | null;
  last_tx_hash: string | null;
  last_seen_utime: number | null;
  last_confirmed_seqno: number | null;
  account_state: 'active' | 'uninitialized' | 'frozen' | null;
  code_boc: string | null;
  data_boc: string | null;
  network: string | null;
};

type IndexerBigIntString = string | null;

export type IndexerVolIndexConfig = {
  seriesManager: string | null;
  oracle: string | null;
  automation: string | null;
  coverManager: string | null;
  minLiquidityBps: IndexerBigIntString;
  staleSeconds: IndexerBigIntString;
  emaAlphaBps: IndexerBigIntString;
};

export type IndexerVolIndexState = {
  impliedVolBps: IndexerBigIntString;
  realizedVolBps: IndexerBigIntString;
  varianceSpeedBps: IndexerBigIntString;
  sampleCount: IndexerBigIntString;
  eligibleSeries: IndexerBigIntString;
  lastPremiumTs: IndexerBigIntString;
  lastRealizedTs: IndexerBigIntString;
  lastPublishTs: IndexerBigIntString;
  lastSamplePrice: IndexerBigIntString;
  lastSampleTs: IndexerBigIntString;
};

export type IndexerVolIndexRoute = {
  exists: boolean;
  sourcePool: string | null;
  coverPolicyId: IndexerBigIntString;
};

export type IndexerVolIndexSnapshotResponse = {
  vol_index: string;
  config: IndexerVolIndexConfig | null;
  state: IndexerVolIndexState | null;
  pool: string | null;
  pool_state: IndexerVolIndexState | null;
  route_ids: number[];
  routes: Record<string, IndexerVolIndexRoute>;
  source: string;
  network: string;
  updated_at: number;
};

export type IndexerGovernanceLock = {
  amount: IndexerBigIntString;
  unlockTime: IndexerBigIntString;
  tier: IndexerBigIntString;
  activatedAt: IndexerBigIntString;
  weight: IndexerBigIntString;
};

export type IndexerGovernanceProposal = {
  id: string;
  status: IndexerBigIntString;
  passed: IndexerBigIntString;
  yesWeight: IndexerBigIntString;
  noWeight: IndexerBigIntString;
  abstainWeight: IndexerBigIntString;
  quorumWeight: IndexerBigIntString;
  totalWeightSnapshot: IndexerBigIntString;
  startTime: IndexerBigIntString;
  minCloseTime: IndexerBigIntString;
  maxCloseTime: IndexerBigIntString;
  cooldownEnd: IndexerBigIntString;
  target: string | null;
  value: IndexerBigIntString;
  descriptionHash: IndexerBigIntString;
};

export type IndexerGovernanceSnapshotResponse = {
  voting: string;
  owner: string | null;
  lock: IndexerGovernanceLock | null;
  proposal_count: number;
  scanned: number;
  proposals: IndexerGovernanceProposal[];
  source: string;
  network: string;
  updated_at: number;
};

export type IndexerCoverState = {
  totalPolicies: IndexerBigIntString;
  activePolicies: IndexerBigIntString;
  breachingPolicies: IndexerBigIntString;
  claimablePolicies: IndexerBigIntString;
  claimedPolicies: IndexerBigIntString;
  nextWakeTimestamp: IndexerBigIntString;
  lastSender: string | null;
  lastJobId: IndexerBigIntString;
  lastWork: IndexerBigIntString;
  lastTimestamp: IndexerBigIntString;
  lastProcessed: IndexerBigIntString;
  lastRemaining: IndexerBigIntString;
  vault: string | null;
  governance: string | null;
  riskVault: string | null;
  riskBucketId: IndexerBigIntString;
};

export type IndexerCoverPolicy = {
  id: string;
  owner: string | null;
  pool: string | null;
  lowerBound: IndexerBigIntString;
  upperBound: IndexerBigIntString;
  payout: IndexerBigIntString;
  coveredNotional: IndexerBigIntString;
  windowSeconds: IndexerBigIntString;
  requiredObservations: IndexerBigIntString;
  breachStart: IndexerBigIntString;
  breachSeconds: IndexerBigIntString;
  lastObservation: IndexerBigIntString;
  lastHealthyObservation: IndexerBigIntString;
  breachObservations: IndexerBigIntString;
  lastVolatilityTimestamp: IndexerBigIntString;
  lastVolatilityRequestHash: IndexerBigIntString;
  startsAt: IndexerBigIntString;
  expiresAt: IndexerBigIntString;
  graceEndsAt: IndexerBigIntString;
  riskPositionKey: IndexerBigIntString;
  closeReason: IndexerBigIntString;
  closeQueryId: IndexerBigIntString;
  closeRequester: string | null;
  premiumFinal: boolean;
  exitNativeEscrow: IndexerBigIntString;
  status: IndexerBigIntString;
  riskVault: string | null;
  riskBucketId: IndexerBigIntString;
};

export type IndexerCoverSnapshotResponse = {
  manager: string;
  owner: string | null;
  enabled: boolean | null;
  state: IndexerCoverState | null;
  policy_count: number;
  scanned: number;
  live_revision: string;
  next_after_slot: number | null;
  page_complete: true;
  policies: IndexerCoverPolicy[];
  source: string;
  network: string;
  updated_at: number;
};

export type IndexerBalanceStreamState = 'connecting' | 'open' | 'reconnecting' | 'degraded' | 'closed';

export type IndexerBalanceStreamEvent =
  | {
      type: 'balances_changed';
      address: string | null;
      seq: number | null;
      ts: number | null;
      hints: { ton: boolean; jettons: string[] | null } | null;
      payload: unknown;
    }
  | {
      type: 'balances_snapshot';
      address: string | null;
      seq: number | null;
      ts: number | null;
      balances: IndexerBalances;
      payload: unknown;
    }
  | {
      type: 'subscribed' | 'error';
      address: string | null;
      seq: number | null;
      ts: number | null;
      payload: unknown;
    };

export type IndexerBalanceStreamHandlers = {
  onEvent?: (event: IndexerBalanceStreamEvent) => void;
  onStateChange?: (state: IndexerBalanceStreamState, detail?: string) => void;
  onError?: (error: Error) => void;
};

export type IndexerBalanceStreamConnection = {
  subscribe: (addresses: string[]) => void;
  unsubscribe: (addresses: string[]) => void;
  close: () => void;
};

/** An indexer request that produced no answer. The status and `retryAfterMs` say what kind; nothing compares the message. */
export class IndexerRequestError extends Error {
  readonly path: string;
  /** HTTP status, or undefined for a connection error or timeout. */
  readonly status: number | undefined;
  /** The top-level `code` of the indexer's flat error body, or null when the body has none. For logs only. */
  readonly code: string | null;
  readonly retryAfterMs: number | null;
  readonly timedOut: boolean;
  /** True when no request was sent because the breaker did not admit it. */
  readonly refused: boolean;

  constructor(
    message: string,
    path: string,
    detail: { status?: number; code?: string | null; retryAfterMs?: number | null; timedOut?: boolean; refused?: boolean; cause?: unknown } = {}
  ) {
    super(message, detail.cause === undefined ? undefined : { cause: detail.cause });
    this.name = 'IndexerRequestError';
    this.path = path;
    this.status = detail.status;
    this.code = detail.code ?? null;
    this.retryAfterMs = detail.retryAfterMs ?? null;
    this.timedOut = detail.timedOut === true;
    this.refused = detail.refused === true;
  }
}

const INDEXER_MAX_ATTEMPTS = 3;
const INDEXER_RETRY_BASE_MS = 300;
const INDEXER_REQUEST_TIMEOUT_MS = RPC_FALLBACK_DISABLED ? 20_000 : 10_000;
const INDEXER_STREAM_RECONNECT_BASE_MS = 800;
const INDEXER_STREAM_RECONNECT_MAX_MS = 12_000;
const INDEXER_STREAM_DEGRADE_AFTER_ATTEMPTS = 4;
const createAbortError = () => {
  const error = new Error('Indexer request aborted.');
  error.name = 'AbortError';
  return error;
};

/** A caller that aborts gets its own reason back. */
const abortReason = (signal: AbortSignal) => (signal.reason instanceof Error ? signal.reason : createAbortError());

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortReason(signal));
      return;
    }
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortReason(signal!));
    };
    signal?.addEventListener('abort', onAbort, { once: true });
    if (signal?.aborted) onAbort();
  });

// The manifest's service mount is the only transport; API paths are relative to it.
const getBaseUrl = () => {
  const base = TESTNET_CONFIG.indexerEndpoint?.trim();
  if (!base) return null;
  return base.endsWith('/') ? base.slice(0, -1) : base;
};

// The service mount is part of release-readiness identity.
export const getIndexerRequestScope = () => getBaseUrl() ?? '';

/**
 * Is indexed product data (ledger, transactions, candles, snapshots) usable now? It has its own breaker:
 * a failing chain read does not turn it off, and it comes back by itself when the open window has passed.
 */
export const isIndexerEnabled = () => {
  if (!getBaseUrl()) return false;
  const breaker = transportBreaker('indexer.data');
  return breaker.state !== 'open' || breaker.retryInMs() === 0;
};

/** Chain reads through the indexer need only the service mount; their breaker is consulted by the request itself. */
export const isFreshIndexerConfigured = () => getBaseUrl() !== null;

const asRecord = (value: unknown): Record<string, unknown> | null => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
};

const readString = (value: unknown): string | null => {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : null;
  }
  return null;
};

const readNumber = (value: unknown): number | null => {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string') {
    const parsed = Number(value.trim());
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
};

const readBoolean = (value: unknown): boolean | null => {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value === 1;
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    if (normalized === 'true' || normalized === '1') return true;
    if (normalized === 'false' || normalized === '0') return false;
  }
  return null;
};

const readValueFromKeys = (record: Record<string, unknown> | null, keys: string[]) => {
  if (!record) return null;
  for (const key of keys) {
    if (!(key in record)) continue;
    const value = record[key];
    if (value === null || value === undefined) continue;
    return value;
  }
  return null;
};

const shouldRetryStatus = (status?: number) =>
  status === 408 || status === 425 || status === 429 || status === 500 || status === 502 || status === 503 || status === 504;

const buildIndexerUrl = (base: string, path: string, params?: Record<string, string | number | undefined>) => {
  const url = new URL(`${base}${path}`);
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      if (value === undefined || value === null || value === '') continue;
      url.searchParams.set(key, String(value));
    }
  }
  return url;
};

type IndexerRequestOptions = {
  method?: 'GET' | 'POST';
  params?: Record<string, string | number | undefined>;
  body?: unknown;
  timeoutMs?: number;
  maxAttempts?: number;
  signal?: AbortSignal;
  credentials?: RequestCredentials;
  cache?: RequestCache;
  /** Which breaker this request consults and feeds. `none`: neither. Default `data`. */
  health?: 'chain' | 'data' | 'none';
};

/** `Retry-After` in seconds; the date form is not used by the service. */
const readRetryAfterMs = (header: string | null): number | null => {
  const seconds = header?.trim() ?? '';
  return /^\d{1,9}$/.test(seconds) ? Number(seconds) * 1_000 : null;
};

/**
 * One decoder for the one error shape, the flat `{ error, code }`. The sentence becomes the developer message
 * and the code goes to logs; the request is classified by the status and `Retry-After` alone.
 */
const errorFromResponse = async (response: Response, path: string): Promise<IndexerRequestError> => {
  const body = asRecord(await response.json().catch(() => null));
  return new IndexerRequestError(
    typeof body?.error === 'string' && body.error ? body.error : `Indexer request failed (${response.status})`,
    path,
    {
      status: response.status,
      code: typeof body?.code === 'string' && body.code ? body.code : null,
      retryAfterMs: readRetryAfterMs(response.headers.get('retry-after'))
    }
  );
};

/** One attempt. Rejects with an `IndexerRequestError`, or with the caller's own reason when the caller aborted. */
const sendIndexerRequest = async (
  url: string,
  path: string,
  options: Pick<IndexerRequestOptions, 'method' | 'body' | 'signal' | 'credentials' | 'cache'>,
  timeoutMs: number
): Promise<unknown> => {
  const { signal } = options;
  const method = options.method ?? 'GET';
  const controller = new AbortController();
  const abortFromCaller = () => controller.abort(signal?.reason);
  signal?.addEventListener('abort', abortFromCaller, { once: true });
  if (signal?.aborted) abortFromCaller();
  const timeout = new IndexerRequestError('The network request timed out. Retry when the connection is available.', path, { timedOut: true });
  // The limit covers the body as well as the headers.
  const timer = setTimeout(() => controller.abort(timeout), timeoutMs);
  try {
    const releaseHash = currentReleaseHash();
    const init: RequestInit = { method, ...(options.cache ? { cache: options.cache } : {}), headers: { accept: 'application/json', [RELEASE_HEADER]: releaseHash }, signal: controller.signal, ...(options.credentials ? { credentials: options.credentials } : {}) };
    if (method === 'POST') {
      (init.headers as Record<string, string>)['Content-Type'] = 'application/json';
      init.body = JSON.stringify(options.body ?? {});
    }
    const response = await fetch(url, init);
    assertReleaseResponse(response, releaseHash);
    if (!response.ok) throw await errorFromResponse(response, path);
    try {
      return await response.json();
    } catch (cause) {
      if (controller.signal.aborted) throw cause;
      throw new IndexerRequestError('Indexer answer is not JSON.', path, { status: response.status, cause });
    }
  } catch (error) {
    if (isReleaseMismatchError(error)) throw error;
    if (signal?.aborted) throw abortReason(signal);
    if (controller.signal.aborted) throw timeout;
    if (error instanceof IndexerRequestError) throw error;
    const blocked = typeof window !== 'undefined' && window.location?.protocol === 'https:' && url.startsWith('http://');
    throw new IndexerRequestError(
      blocked
        ? 'Indexer request blocked from secure page. The release must name an HTTPS indexer endpoint.'
        : (error instanceof Error && error.message) || 'Indexer request failed.',
      path,
      { cause: error }
    );
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', abortFromCaller);
  }
};

/** What a failed attempt says about the transport, or null when it says nothing (a 4xx, a caller's short time limit). */
const transportOutcome = (error: IndexerRequestError, slowCounts: boolean): TransportOutcome | null => {
  if (error.timedOut) return slowCounts ? 'slow' : null;
  if (error.status === undefined) return 'failed';
  if (error.status === 429) return 'limited';
  // Below 400 the status was fine and the body was not an answer.
  return error.status >= 500 || error.status === 408 || error.status === 425 || error.status < 400 ? 'failed' : null;
};

/**
 * Every request to the indexer passes here. It is the one place that consults and records the two indexer
 * breakers: it refuses at once when its breaker does not admit, and what it records follows the status alone.
 * `decode` checks the answer before it counts as one: a throw is an invalid envelope, recorded as `failed`
 * and returned as an IndexerRequestError with the decoder failure as its cause.
 */
const requestIndexer = async <T>(path: string, options: IndexerRequestOptions, decode?: (payload: unknown) => T): Promise<T> => {
  if (options.signal?.aborted) throw abortReason(options.signal);
  const base = getBaseUrl();
  if (!base) throw new IndexerRequestError('Indexer endpoint not configured.', path);
  const capability = options.health === 'none' ? null : options.health === 'chain' ? 'indexer.chain' : 'indexer.data';
  const breaker = capability && transportBreaker(capability);
  const timeoutMs =
    typeof options.timeoutMs === 'number' && Number.isFinite(options.timeoutMs) && options.timeoutMs > 0
      ? Math.trunc(options.timeoutMs)
      : INDEXER_REQUEST_TIMEOUT_MS;
  const maxAttempts =
    typeof options.maxAttempts === 'number' && Number.isFinite(options.maxAttempts) && options.maxAttempts > 0
      ? Math.max(1, Math.trunc(options.maxAttempts))
      : INDEXER_MAX_ATTEMPTS;
  const url = buildIndexerUrl(base, path, options.params).toString();
  let lastError: IndexerRequestError | null = null;
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    if (attempt > 0) await sleep(INDEXER_RETRY_BASE_MS * attempt, options.signal);
    if (breaker && !breaker.admit()) {
      // A window that an earlier attempt of this call opened: that attempt's failure is the answer.
      if (lastError) break;
      const retryAfterMs = breaker.retryInMs();
      throw new IndexerRequestError(
        `Indexer requests are paused after repeated failures. Retry in ${Math.ceil(retryAfterMs / 1_000)}s.`,
        path,
        { refused: true, retryAfterMs }
      );
    }
    let payload: unknown;
    try {
      payload = await sendIndexerRequest(url, path, options, timeoutMs);
    } catch (error) {
      if (options.signal?.aborted || !(error instanceof IndexerRequestError)) throw error;
      const outcome = capability && transportOutcome(error, timeoutMs >= TRANSPORT_SLOW_THRESHOLD_MS[capability]);
      if (outcome) breaker!.record(outcome, error.retryAfterMs);
      lastError = error;
      if (error.status === undefined || error.status < 400 || shouldRetryStatus(error.status)) continue;
      break;
    }
    if (!decode) {
      breaker?.record('ok');
      return payload as T;
    }
    let value: T;
    try {
      value = decode(payload);
    } catch (error) {
      breaker?.record('failed');
      throw new IndexerRequestError(
        error instanceof Error ? error.message : 'Invalid indexer answer.', path,
        { status: 200, cause: error }
      );
    }
    breaker?.record('ok');
    return value;
  }
  throw lastError ?? new IndexerRequestError('Indexer request failed after retries.', path);
};

export const indexerRequest = async <T>(path: string, options: IndexerRequestOptions = {}): Promise<T> =>
  requestIndexer<T>(path, options);

type IndexerReadOptions = Pick<IndexerRequestOptions, 'timeoutMs' | 'maxAttempts' | 'signal' | 'health'>;

const indexerFetch = async <T>(
  path: string,
  params?: Record<string, string | number | undefined>,
  options: IndexerReadOptions = {}
): Promise<T> => indexerRequest<T>(path, { method: 'GET', params, ...options });

const indexerPost = async <T>(path: string, body: unknown, options: IndexerReadOptions = {}): Promise<T> =>
  indexerRequest<T>(path, { method: 'POST', body, ...options });

const uniqueStrings = (values: Array<string | null | undefined>) => {
  const seen = new Set<string>();
  const output: string[] = [];
  for (const value of values) {
    const trimmed = value?.trim();
    if (!trimmed) continue;
    if (seen.has(trimmed)) continue;
    seen.add(trimmed);
    output.push(trimmed);
  }
  return output;
};

const parseIndexerBalanceStreamEvent = (payload: unknown): IndexerBalanceStreamEvent | null => {
  const root = asRecord(payload);
  if (!root || !Number.isSafeInteger(root.seq) || Number(root.seq) < 0 ||
      !Number.isSafeInteger(root.ts) || Number(root.ts) <= 0) return null;
  const seq = root.seq as number, ts = root.ts as number;
  if (root.type === 'subscribed' || root.type === 'error') {
    return { type: root.type, address: null, seq, ts, payload };
  }
  const address = rawAddressOrNull(root.address);
  if (!address) return null;
  if (root.type === 'balances_snapshot') {
    return { type: root.type, address, seq, ts, balances: decodeIndexerBalances(root.balances, address), payload };
  }
  if (root.type === 'balances_changed') {
    const hints = asRecord(root.hints);
    if (!hints || typeof hints.ton !== 'boolean' ||
        (hints.jettons !== null && (!Array.isArray(hints.jettons) || hints.jettons.some(value => !rawAddressOrNull(value))))) return null;
    const jettons = hints.jettons === null ? null : (hints.jettons as string[]).map(value => Address.parse(value).toRawString());
    return { type: root.type, address, seq, ts, hints: { ton: hints.ton, jettons }, payload };
  }
  return null;
};

const INDEXER_STREAM_MAX_EVENT_CHARS = 256 * 1024;

/** One verified fetch SSE connection; only an owned reader can deliver events or schedule a reconnect. */
export const connectIndexerBalanceStream = (
  handlers: IndexerBalanceStreamHandlers = {}
): IndexerBalanceStreamConnection => {
  const onEvent = handlers.onEvent ?? (() => {});
  const onStateChange = handlers.onStateChange ?? (() => {});
  const onError = handlers.onError ?? (() => {});
  const subscriptions = new Set<string>();
  let active: { controller: AbortController; reader: ReadableStreamDefaultReader<Uint8Array> | null } | null = null;
  let closed = false;
  let fatal = false;
  let reconnectAttempt = 0;
  let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

  const clearReconnectTimer = () => {
    if (reconnectTimer !== null) clearTimeout(reconnectTimer);
    reconnectTimer = null;
  };
  const closeStream = () => {
    const previous = active;
    active = null;
    if (!previous) return;
    previous.controller.abort();
    void previous.reader?.cancel().catch(() => {});
  };
  const scheduleReconnect = (reason: string) => {
    closeStream();
    clearReconnectTimer();
    if (closed || fatal || !subscriptions.size) return;
    reconnectAttempt += 1;
    const delay = Math.min(INDEXER_STREAM_RECONNECT_BASE_MS * 2 ** Math.min(reconnectAttempt - 1, 5), INDEXER_STREAM_RECONNECT_MAX_MS);
    onStateChange(reconnectAttempt >= INDEXER_STREAM_DEGRADE_AFTER_ATTEMPTS ? 'degraded' : 'reconnecting', `${reason} Retrying in ${delay} ms.`);
    reconnectTimer = setTimeout(() => { reconnectTimer = null; connect(); }, delay);
  };
  const connect = () => {
    if (closed || fatal || !subscriptions.size || active) return;
    if (typeof fetch === 'undefined' || typeof TextDecoder === 'undefined') {
      onStateChange('degraded', 'Streaming fetch is unavailable in this runtime.');
      onError(new Error('Streaming fetch is unavailable in this runtime.'));
      return;
    }
    const base = getBaseUrl();
    if (!base) { onStateChange('degraded', 'Indexer stream endpoint is not configured.'); return; }
    const url = buildIndexerUrl(base, '/v1/stream/balances', { addresses: [...subscriptions].join(',') }).toString();
    onStateChange(reconnectAttempt > 0 ? 'reconnecting' : 'connecting');
    const connection = { controller: new AbortController(), reader: null as ReadableStreamDefaultReader<Uint8Array> | null };
    active = connection;
    const owned = () => active === connection && !closed;
    void (async () => {
      try {
        const releaseHash = currentReleaseHash();
        const response = await fetch(url, { headers: { accept: 'text/event-stream', [RELEASE_HEADER]: releaseHash },
          cache: 'no-store', signal: connection.controller.signal });
        // A replaced subscription cannot validate or consume a response on behalf of its successor.
        if (!owned()) { await response.body?.cancel(); return; }
        assertReleaseResponse(response, releaseHash);
        if (!response.ok) throw await errorFromResponse(response, '/v1/stream/balances');
        if (response.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'text/event-stream' || !response.body)
          throw new Error('Indexer balance stream is not an event stream.');
        const reader = response.body.getReader(); connection.reader = reader;
        reconnectAttempt = 0;
        onStateChange('open', url);
        const decoder = new TextDecoder('utf-8', { fatal: true });
        let line = '', data = '', eventName = '', skipLf = false;
        const acceptLine = () => {
          if (!line) {
            if (data && (!eventName || eventName === 'message')) {
              let parsed: IndexerBalanceStreamEvent | null = null;
              try { parsed = parseIndexerBalanceStreamEvent(JSON.parse(data.slice(0, -1))); }
              catch { /* A malformed event cannot replace a verified balance. */ }
              if (parsed && owned()) onEvent(parsed);
            }
            data = ''; eventName = '';
          } else if (!line.startsWith(':')) {
            const colon = line.indexOf(':');
            const field = colon < 0 ? line : line.slice(0, colon);
            let value = colon < 0 ? '' : line.slice(colon + 1);
            if (value.startsWith(' ')) value = value.slice(1);
            if (field === 'data') data += `${value}\n`;
            else if (field === 'event') eventName = value;
          }
          line = '';
          if (data.length + eventName.length > INDEXER_STREAM_MAX_EVENT_CHARS) throw new Error('Indexer balance event exceeds its buffer limit.');
        };
        while (owned()) {
          const { value, done } = await reader.read();
          if (!owned()) return;
          if (done) { decoder.decode(); throw new Error('Event stream disconnected.'); }
          // Process each bounded slice without retaining an arbitrarily large network chunk.
          for (let offset = 0; offset < value.length && owned(); offset += 16 * 1024) {
            const text = decoder.decode(value.subarray(offset, offset + 16 * 1024), { stream: true });
            for (const char of text) {
              if (!owned()) return;
              if (skipLf) { skipLf = false; if (char === '\n') continue; }
              if (char === '\r' || char === '\n') { acceptLine(); skipLf = char === '\r'; }
              else {
                line += char;
                if (line.length + data.length + eventName.length > INDEXER_STREAM_MAX_EVENT_CHARS) throw new Error('Indexer balance event exceeds its buffer limit.');
              }
            }
          }
        }
      } catch (error) {
        if (!owned()) return;
        const failure = error instanceof Error ? error : new Error('Indexer balance stream failed.');
        if (isReleaseMismatchError(error)) {
          fatal = true;
          closeStream(); clearReconnectTimer();
          onError(failure); onStateChange('degraded', error.code);
          return;
        }
        onError(failure); scheduleReconnect(failure.message);
      } finally {
        try { connection.reader?.releaseLock(); } catch { /* A canceled read releases on settlement. */ }
      }
    })();
  };
  const restart = () => { clearReconnectTimer(); closeStream(); connect(); };
  return {
    subscribe: addresses => {
      if (closed) return;
      const before = subscriptions.size;
      for (const address of canonicalAccountAddresses(addresses)) subscriptions.add(address);
      if (subscriptions.size !== before) restart();
      else if (!active && reconnectTimer === null) connect();
    },
    unsubscribe: addresses => {
      if (closed) return;
      const before = subscriptions.size;
      for (const address of canonicalAccountAddresses(addresses)) subscriptions.delete(address);
      if (subscriptions.size === before) return;
      restart();
      if (!subscriptions.size) onStateChange('closed', 'No addresses subscribed.');
    },
    close: () => {
      closed = true;
      subscriptions.clear();
      clearReconnectTimer();
      closeStream();
      onStateChange('closed');
    }
  };
};

const accountPath = (address: string, suffix?: string) => {
  let canonical = address;
  try { canonical = Address.parse(address).toRawString(); } catch { /* Server validates malformed addresses. */ }
  const encoded = encodeURIComponent(canonical);
  if (!suffix) return `/v1/accounts/${encoded}`;
  return `/v1/accounts/${encoded}/${suffix}`;
};

const volIndexSnapshotPath = (volIndexAddress: string) =>
  `/v1/vol-index/${encodeURIComponent(volIndexAddress)}/snapshot`;
const governanceSnapshotPath = (votingAddress: string) =>
  `/v1/governance/${encodeURIComponent(votingAddress)}/snapshot`;
const coverSnapshotPath = (managerAddress: string) =>
  `/v1/cover/${encodeURIComponent(managerAddress)}/snapshot`;
const dlmmPoolsSnapshotPath = () => `/v1/dlmm/pools/snapshot`;

export const getIndexerVolIndexSnapshot = async (
  volIndexAddress: string,
  options: { pool?: string | null; routeIds?: number[] } = {}
): Promise<IndexerVolIndexSnapshotResponse> => {
  const params: Record<string, string | number | undefined> = {};
  if (options.pool?.trim()) {
    params.pool = options.pool.trim();
  }
  if (options.routeIds?.length) {
    const ids = options.routeIds
      .filter((value) => Number.isFinite(value) && value > 0)
      .map((value) => Math.trunc(value));
    if (ids.length) {
      params.route_ids = ids.join(',');
    }
  }
  const requestedRoutes = options.routeIds?.length ?? 0;
  const timeoutMs = Math.min(12_000, 3_000 + requestedRoutes * 180);
  return indexerFetch<IndexerVolIndexSnapshotResponse>(volIndexSnapshotPath(volIndexAddress), params, {
    timeoutMs,
    maxAttempts: 1
  });
};

export const getIndexerGovernanceSnapshot = async (
  votingAddress: string,
  options: { owner?: string | null; maxScan?: number; maxConsecutiveMisses?: number } = {}
): Promise<IndexerGovernanceSnapshotResponse> => {
  const params: Record<string, string | number | undefined> = {};
  if (options.owner?.trim()) {
    params.owner = options.owner.trim();
  }
  if (typeof options.maxScan === 'number' && Number.isFinite(options.maxScan) && options.maxScan > 0) {
    params.max_scan = Math.trunc(options.maxScan);
  }
  if (
    typeof options.maxConsecutiveMisses === 'number' &&
    Number.isFinite(options.maxConsecutiveMisses) &&
    options.maxConsecutiveMisses > 0
  ) {
    params.max_misses = Math.trunc(options.maxConsecutiveMisses);
  }
  const maxScan = typeof options.maxScan === 'number' && Number.isFinite(options.maxScan) ? Math.max(1, Math.trunc(options.maxScan)) : 20;
  const timeoutMs = Math.min(12_000, 2_500 + maxScan * 200);
  return indexerFetch<IndexerGovernanceSnapshotResponse>(governanceSnapshotPath(votingAddress), params, { timeoutMs, maxAttempts: 1 });
};

/** Read all bounded live slots; a partial page is never a complete wallet portfolio. */
export const getIndexerCoverSnapshot = async (
  managerAddress: string,
  options: { owner?: string | null; limit?: number } = {}
): Promise<IndexerCoverSnapshotResponse> => {
  const limit = options.limit ?? 40;
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 40) throw new Error('Cover page size must be between 1 and 40.');
  let afterSlot = 0, revision: string | undefined, snapshot: IndexerCoverSnapshotResponse | undefined;
  const seen = new Set<string>();
  for (let pageNumber = 0; pageNumber < Math.ceil(1024 / limit); pageNumber++) {
    const page = await indexerFetch<IndexerCoverSnapshotResponse>(coverSnapshotPath(managerAddress),
      { owner: options.owner?.trim() || undefined, limit, after_slot: afterSlot, revision },
      { timeoutMs: 12_000, maxAttempts: 1 });
    if (page.page_complete !== true || !/^(0|[1-9][0-9]{0,19})$/.test(page.live_revision) ||
        BigInt(page.live_revision) >= (1n << 64n) || (revision !== undefined && page.live_revision !== revision) ||
        !Array.isArray(page.policies) || !Number.isSafeInteger(page.scanned) || page.scanned < page.policies.length || page.scanned > limit ||
        (page.next_after_slot !== null && (page.scanned !== limit || !Number.isSafeInteger(page.next_after_slot) || page.next_after_slot <= afterSlot || page.next_after_slot >= 1024))) {
      throw new Error('Cover policy page is incomplete or changed. Refresh to try again.');
    }
    for (const policy of page.policies) {
      if (!/^[1-9][0-9]{0,19}$/.test(policy.id) || BigInt(policy.id) >= (1n << 64n) || seen.has(policy.id)) throw new Error('Cover policy list contains invalid or repeated identities.');
      seen.add(policy.id);
    }
    if (!snapshot) snapshot = { ...page, policies: [...page.policies] };
    else { snapshot.policies.push(...page.policies); snapshot.scanned += page.scanned; }
    revision = page.live_revision;
    if (page.next_after_slot === null) {
      snapshot.next_after_slot = null;
      snapshot.policy_count = snapshot.policies.length;
      return snapshot;
    }
    afterSlot = page.next_after_slot;
  }
  throw new Error('Cover policy list exceeds its on-chain capacity.');
};

export type IndexerDlmmPoolsSnapshotRequest = {
  t3Root: string;
  dlmmRegistry?: string | null;
  dlmmFactory?: string | null;
  tokens: string[];
};

export type IndexerDlmmPoolsSnapshotEntry = {
  token: string;
  pool: string | null;
  kind: number | null;
  status: number | null;
  activeBinId: number | null;
  walletCodeHash: IndexerBigIntString;
  binReserves: { reserveT: IndexerBigIntString; reserveX: IndexerBigIntString } | null;
};

export type IndexerDlmmPoolsSnapshotResponse = {
  t3Root: string;
  registry: string | null;
  factory: string | null;
  pools: IndexerDlmmPoolsSnapshotEntry[];
  network: string;
  updated_at: number;
};

export const getIndexerDlmmPoolsSnapshot = async (
  body: IndexerDlmmPoolsSnapshotRequest,
  options: { timeoutMs?: number } = {}
): Promise<IndexerDlmmPoolsSnapshotResponse> => {
  const tokenCount = Array.isArray(body.tokens) ? body.tokens.length : 0;
  const timeoutMs =
    typeof options.timeoutMs === 'number' && Number.isFinite(options.timeoutMs) && options.timeoutMs > 0
      ? Math.trunc(options.timeoutMs)
      : Math.min(12_000, 3_000 + tokenCount * 400);
  return indexerPost<IndexerDlmmPoolsSnapshotResponse>(dlmmPoolsSnapshotPath(), body, {
    timeoutMs,
    maxAttempts: 1
  });
};

export type IndexerGetMethodResponse = {
  stack: [string, unknown][];
  exit_code: number;
  gas_used: number | null;
};

export type IndexerFreshCall =
  | { kind: 'account'; address: string }
  | { kind: 'getter'; address: string; method: string; stack: [string, unknown][] };

export type IndexerFreshAccount = {
  kind: 'account';
  address: string;
  balance_raw: string;
  account_state: 'active' | 'uninitialized' | 'frozen';
  code_boc: string | null;
  data_boc: string | null;
  last_tx_lt: string | null;
  last_tx_hash: string | null;
};

export type IndexerFreshGetter = IndexerGetMethodResponse & { kind: 'getter'; address: string };
export type IndexerFreshResponse = {
  network: 'testnet' | 'mainnet' | 'localnet';
  release: { releaseId: string; manifestHash: string };
  readContext: {
    source: 'lite';
    /** `utime` is the block's own time. The deployed service does not send it yet. */
    head: { workchain: -1; shard: '-9223372036854775808'; seqno: number; rootHashHex: string; fileHashHex: string; utime?: number };
    queriedAt: number;
  };
  results: Array<IndexerFreshAccount | IndexerFreshGetter>;
};

const freshReadError = () => new Error('The current release chain state could not be verified.');
const isDigest = (value: unknown) => typeof value === 'string' && /^[0-9a-f]{64}$/.test(value);
const isAtomicAmount = (value: unknown): value is string => typeof value === 'string' && /^(0|[1-9][0-9]*)$/.test(value);
const isNullableBoc = (value: unknown) => {
  if (value === null) return true;
  if (typeof value !== 'string' || !value) return false;
  try { return Cell.fromBoc(Buffer.from(value, 'base64')).length === 1; }
  catch { return false; }
};

/**
 * A live read is accepted only with the current release and an explicitly queried chain head.
 * The device clock is not consulted: the answer is fresh because the request was just made.
 */
export const readIndexerFresh = async (
  calls: IndexerFreshCall[],
  options: { timeoutMs?: number; signal?: AbortSignal } = {}
): Promise<IndexerFreshResponse> => {
  const release = TONSWAP_RELEASE;
  if (!release || calls.length < 1 || calls.length > 32) throw freshReadError();
  const normalized = calls.map(call => ({ ...call, address: Address.parse(call.address).toRawString() }));
  const decode = (payload: unknown): IndexerFreshResponse => {
    const response = asRecord(payload);
    const identity = asRecord(response?.release);
    const context = asRecord(response?.readContext);
    const head = asRecord(context?.head);
    if (!response || response.network !== release.network.slice(4) ||
      identity?.releaseId !== release.releaseId || identity?.manifestHash !== release.manifestHash ||
      TONSWAP_RELEASE?.manifestHash !== release.manifestHash ||
      context?.source !== 'lite' ||
      head?.workchain !== -1 || head.shard !== '-9223372036854775808' ||
      !Number.isSafeInteger(head.seqno) || Number(head.seqno) < 0 ||
      !isDigest(head.rootHashHex) || !isDigest(head.fileHashHex) ||
      !Number.isSafeInteger(context?.queriedAt) ||
      !Array.isArray(response.results) || response.results.length !== normalized.length) throw freshReadError();
    response.results.forEach((value, i) => {
      const result = asRecord(value);
      const call = normalized[i];
      if (!result || result.kind !== call.kind || result.address !== call.address) throw freshReadError();
      if (call.kind === 'getter') {
        if (!Number.isSafeInteger(result.exit_code) || !Array.isArray(result.stack) ||
          !result.stack.every(entry => Array.isArray(entry) && entry.length === 2 && typeof entry[0] === 'string') ||
          result.gas_used !== null) throw freshReadError();
      } else if (!isAtomicAmount(result.balance_raw) ||
        !['active', 'uninitialized', 'frozen'].includes(String(result.account_state)) ||
        !isNullableBoc(result.code_boc) || !isNullableBoc(result.data_boc) ||
        (result.account_state === 'active' && (!result.code_boc || !result.data_boc)) ||
        (result.last_tx_lt !== null && !isAtomicAmount(result.last_tx_lt)) ||
        ((result.last_tx_lt === null) !== (result.last_tx_hash === null)) ||
        (result.last_tx_hash !== null && typeof result.last_tx_hash !== 'string')) throw freshReadError();
    });
    return payload as IndexerFreshResponse;
  };
  return requestIndexer('/v1/readFresh', {
    method: 'POST', body: { calls: normalized }, cache: 'no-store',
    timeoutMs: options.timeoutMs, maxAttempts: 1, signal: options.signal, health: 'chain'
  }, decode);
};

export const getIndexerRunGetMethod = async (
  address: string,
  method: string,
  stack: [string, unknown][] = [],
  options: { signal?: AbortSignal } = {}
): Promise<IndexerGetMethodResponse> => {
  return requestIndexer<IndexerGetMethodResponse>('/v1/runGetMethod', {
    method: 'POST', body: { address, method, stack }, maxAttempts: 1, signal: options.signal,
    timeoutMs: 8_000, health: 'chain'
  }, payload => {
    const answer = asRecord(payload);
    if (!answer || !Number.isSafeInteger(answer.exit_code) || !Array.isArray(answer.stack) ||
      !answer.stack.every(entry => Array.isArray(entry) && entry.length === 2 && typeof entry[0] === 'string') ||
      (answer.gas_used !== null && !Number.isSafeInteger(answer.gas_used))) {
      throw new Error('Invalid indexer getter answer.');
    }
    return payload as IndexerGetMethodResponse;
  });
};

const readLtString = (value: unknown): string | null => {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return null;
    return /^\d+$/.test(trimmed) ? trimmed : null;
  }
  if (typeof value === 'number' && Number.isFinite(value) && Number.isSafeInteger(value) && value >= 0) {
    return String(Math.trunc(value));
  }
  return null;
};

const parseIndexerAccountStatePayload = (payload: unknown): IndexerAccountStateResponse => {
  const record = asRecord(payload);
  if (!record) {
    throw new Error('Invalid indexer account state payload.');
  }

  const address = readString(record.address) ?? '';
  const last_tx_lt = readLtString(record.last_tx_lt);
  const last_tx_hash = readString(record.last_tx_hash);
  const last_seen_utime = readNumber(record.last_seen_utime);
  const last_confirmed_seqno_raw = readNumber(record.last_confirmed_seqno);
  const last_confirmed_seqno =
    last_confirmed_seqno_raw === null ? null : Math.trunc(last_confirmed_seqno_raw);
  const accountStateRaw = readString(record.account_state);
  const account_state =
    accountStateRaw === 'active' || accountStateRaw === 'uninitialized' || accountStateRaw === 'frozen'
      ? accountStateRaw
      : null;
  const codeBoc = readString(record.code_boc);
  const dataBoc = readString(record.data_boc);
  const network = readString(record.network);

  return {
    address,
    last_tx_lt,
    last_tx_hash,
    last_seen_utime,
    last_confirmed_seqno,
    account_state,
    code_boc: codeBoc,
    data_boc: dataBoc,
    network
  };
};

export const getIndexerAccountState = async (
  address: string,
  options: { timeoutMs?: number; maxAttempts?: number } = {}
): Promise<IndexerAccountStateResponse> => {
  const timeoutMs =
    typeof options.timeoutMs === 'number' && Number.isFinite(options.timeoutMs) && options.timeoutMs > 0
      ? Math.trunc(options.timeoutMs)
      : 3_000;
  const maxAttempts =
    typeof options.maxAttempts === 'number' && Number.isFinite(options.maxAttempts) && options.maxAttempts > 0
      ? Math.max(1, Math.trunc(options.maxAttempts))
      : 1;
  const payload = await indexerFetch<unknown>(`${accountPath(address, 'state')}`, undefined, { timeoutMs, maxAttempts, health: 'chain' });
  return parseIndexerAccountStatePayload(payload);
};

export const getIndexerTransactions = async (
  address: string,
  options: { cursor?: { lt: string; hash: string }; page?: number; timeoutMs?: number; maxAttempts?: number } = {}
): Promise<IndexerTxResponse> => {
  const params: Record<string, string | number | undefined> = {};
  if (options.page) params.page = options.page;
  if (options.cursor) {
    params.cursor_lt = options.cursor.lt;
    params.cursor_hash = options.cursor.hash;
  }
  const timeoutMs =
    typeof options.timeoutMs === 'number' && Number.isFinite(options.timeoutMs) && options.timeoutMs > 0
      ? Math.trunc(options.timeoutMs)
      : 8_000;
  const maxAttempts =
    typeof options.maxAttempts === 'number' && Number.isFinite(options.maxAttempts) && options.maxAttempts > 0
      ? Math.max(1, Math.trunc(options.maxAttempts))
      : 1;
  return indexerFetch<IndexerTxResponse>(`${accountPath(address, 'txs')}`, params, { timeoutMs, maxAttempts });
};

export const getIndexerTransactionsForAddresses = async (
  addresses: string[],
  options: { cursor?: { lt: string; hash: string }; page?: number; timeoutMs?: number; maxAttempts?: number } = {}
): Promise<IndexerTxResponse> => {
  const candidates = canonicalAccountAddresses(addresses);
  if (!candidates.length) {
    throw new Error('Missing address for indexer transaction lookup.');
  }
  let lastError: unknown;
  for (const candidate of candidates) {
    try {
      return await getIndexerTransactions(candidate, options);
    } catch (error) {
      if (isReleaseMismatchError(error)) throw error;
      lastError = error;
    }
  }
  throw lastError;
};

export type IndexerSwapExecutionType = 'market' | 'limit' | 'twap' | 'unknown';

export type IndexerMarketCandleInterval = '1m' | '5m' | '15m' | '1h' | '4h' | '1d';

export type IndexerMarketCandle = {
  ts: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volumeBase: number;
  volumeQuote: number;
  tradeCount: number;
  sourceTxIds: string[];
};

export type IndexerMarketCandlesResponse = {
  market_key: string;
  market_address: string;
  interval: IndexerMarketCandleInterval;
  from_utime: number | null;
  to_utime: number | null;
  candle_count: number;
  history_complete: boolean;
  synced_at: number;
  network: string;
  candles: IndexerMarketCandle[];
};

const MARKET_CANDLE_INTERVALS = new Set<IndexerMarketCandleInterval>([
  '1m',
  '5m',
  '15m',
  '1h',
  '4h',
  '1d'
]);

export const normalizeIndexerMarketCandlesResponse = (
  input: unknown,
  fallback: {
    marketKey: string;
    marketAddress: string;
    interval: IndexerMarketCandleInterval;
  }
): IndexerMarketCandlesResponse => {
  const record = asRecord(input);
  if (!record) throw new Error('Indexer candles response must be an object.');
  const rawCandles = Array.isArray(record.candles) ? record.candles : [];
  const candlesByTimestamp = new Map<number, IndexerMarketCandle>();
  for (const rawCandle of rawCandles) {
    const candle = asRecord(rawCandle);
    if (!candle) continue;
    let ts = readNumber(readValueFromKeys(candle, ['ts', 'timestamp', 'utime', 'time']));
    const open = readNumber(readValueFromKeys(candle, ['open', 'open_price']));
    const high = readNumber(readValueFromKeys(candle, ['high', 'high_price']));
    const low = readNumber(readValueFromKeys(candle, ['low', 'low_price']));
    const close = readNumber(readValueFromKeys(candle, ['close', 'close_price']));
    if (
      ts === null ||
      open === null ||
      high === null ||
      low === null ||
      close === null ||
      open <= 0 ||
      high <= 0 ||
      low <= 0 ||
      close <= 0
    ) {
      continue;
    }
    if (ts > 10_000_000_000) ts /= 1000;
    ts = Math.trunc(ts);
    if (
      ts <= 0 ||
      high < Math.max(open, close, low) ||
      low > Math.min(open, close, high)
    ) {
      continue;
    }
    const volumeBase =
      readNumber(readValueFromKeys(candle, ['volumeBase', 'volume_base'])) ?? 0;
    const volumeQuote =
      readNumber(readValueFromKeys(candle, ['volumeQuote', 'volume_quote'])) ?? 0;
    const tradeCount =
      readNumber(readValueFromKeys(candle, ['tradeCount', 'trade_count', 'trades'])) ?? 0;
    if (volumeBase < 0 || volumeQuote < 0 || tradeCount < 0) continue;
    const sourceTxIdsRaw = readValueFromKeys(candle, ['sourceTxIds', 'source_tx_ids']);
    const sourceTxIds = Array.isArray(sourceTxIdsRaw)
      ? Array.from(
          new Set(
            sourceTxIdsRaw
              .map((value) => (typeof value === 'string' ? value.trim() : ''))
              .filter(Boolean)
          )
        )
      : [];
    candlesByTimestamp.set(ts, {
      ts,
      open,
      high,
      low,
      close,
      volumeBase,
      volumeQuote,
      tradeCount: Math.trunc(tradeCount),
      sourceTxIds
    });
  }
  const candles = Array.from(candlesByTimestamp.values()).sort((left, right) => left.ts - right.ts);
  const intervalValue = readString(record.interval);
  const interval =
    intervalValue && MARKET_CANDLE_INTERVALS.has(intervalValue as IndexerMarketCandleInterval)
      ? (intervalValue as IndexerMarketCandleInterval)
      : fallback.interval;
  const fromUtime =
    readNumber(readValueFromKeys(record, ['from_utime', 'fromUtime'])) ??
    candles[0]?.ts ??
    null;
  const toUtime =
    readNumber(readValueFromKeys(record, ['to_utime', 'toUtime'])) ??
    candles[candles.length - 1]?.ts ??
    null;
  return {
    market_key:
      readString(readValueFromKeys(record, ['market_key', 'marketKey'])) ?? fallback.marketKey,
    market_address:
      readString(readValueFromKeys(record, ['market_address', 'marketAddress'])) ??
      fallback.marketAddress,
    interval,
    from_utime: fromUtime === null ? null : Math.trunc(fromUtime),
    to_utime: toUtime === null ? null : Math.trunc(toUtime),
    candle_count: candles.length,
    history_complete:
      readBoolean(readValueFromKeys(record, ['history_complete', 'historyComplete'])) ?? false,
    synced_at: Math.trunc(
      readNumber(readValueFromKeys(record, ['synced_at', 'syncedAt'])) ??
        candles[candles.length - 1]?.ts ??
        0
    ),
    network: readString(record.network) ?? TESTNET_CONFIG.network,
    candles
  };
};

const marketPath = (marketKey: string, suffix?: string) => {
  const encoded = encodeURIComponent(marketKey);
  if (!suffix) return `/v1/markets/${encoded}`;
  return `/v1/markets/${encoded}/${suffix}`;
};

export const getIndexerMarketCandles = async (
  marketKey: string,
  options: {
    marketAddress: string;
    assetSymbol: string;
    quoteSymbol: string;
    interval?: IndexerMarketCandleInterval;
    fromUtime?: number;
    toUtime?: number;
    limit?: number;
    timeoutMs?: number;
    maxAttempts?: number;
    signal?: AbortSignal;
  }
): Promise<IndexerMarketCandlesResponse> => {
  const params: Record<string, string | number | undefined> = {
    market_address: options.marketAddress,
    asset_symbol: toIndexerAssetSymbol(options.assetSymbol),
    quote_symbol: toIndexerAssetSymbol(options.quoteSymbol)
  };
  if (options.interval) params.interval = options.interval;
  if (options.fromUtime) params.from_utime = Math.max(1, Math.trunc(options.fromUtime));
  if (options.toUtime) params.to_utime = Math.max(1, Math.trunc(options.toUtime));
  if (options.limit) params.limit = Math.max(1, Math.trunc(options.limit));
  const timeoutMs =
    typeof options.timeoutMs === 'number' && Number.isFinite(options.timeoutMs) && options.timeoutMs > 0
      ? Math.trunc(options.timeoutMs)
      : 8_000;
  const maxAttempts =
    typeof options.maxAttempts === 'number' && Number.isFinite(options.maxAttempts) && options.maxAttempts > 0
      ? Math.max(1, Math.trunc(options.maxAttempts))
      : 1;
  const normalizedMarketKey = toIndexerMarketKey(marketKey);
  const response = await indexerFetch<unknown>(
    marketPath(normalizedMarketKey, 'candles'),
    params,
    { timeoutMs, maxAttempts, signal: options.signal }
  );
  return normalizeIndexerMarketCandlesResponse(response, {
    marketKey: normalizedMarketKey,
    marketAddress: options.marketAddress,
    interval: options.interval ?? '1m'
  });
};

type SharedRequest<T> = {
  controller: AbortController;
  promise: Promise<T>;
  waiters: number;
};

/** Callers with one key share the request in flight. It is aborted only when every one of them has aborted. */
const joinSharedRequest = <T>(
  pending: Map<string, SharedRequest<T>>,
  key: string,
  start: (signal: AbortSignal) => Promise<T>,
  signal?: AbortSignal
): Promise<T> => {
  let shared = pending.get(key);
  if (!shared) {
    const controller = new AbortController();
    const created: SharedRequest<T> = { controller, waiters: 0, promise: undefined! };
    created.promise = start(controller.signal).finally(() => {
      if (pending.get(key) === created) pending.delete(key);
      controller.abort();
    });
    pending.set(key, created);
    shared = created;
  }
  const request = shared;
  request.waiters += 1;
  return new Promise<T>((resolve, reject) => {
    let settled = false;
    const release = () => {
      if (settled) return false;
      settled = true;
      signal?.removeEventListener('abort', onAbort);
      request.waiters -= 1;
      return true;
    };
    const onAbort = () => {
      if (!release()) return;
      reject(signal?.reason ?? createAbortError());
      if (request.waiters === 0) {
        if (pending.get(key) === request) pending.delete(key);
        request.controller.abort();
      }
    };
    signal?.addEventListener('abort', onAbort, { once: true });
    if (signal?.aborted) onAbort();
    request.promise.then(
      (result) => { if (release()) resolve(result); },
      (error) => { if (release()) reject(error); }
    );
  });
};

function canonicalAccountAddresses(addresses: string[]): string[] {
  return uniqueStrings(addresses.map(address => {
    try { return Address.parse(address).toRawString(); }
    catch { return address; } // Malformed identifiers are rejected by the endpoint.
  }));
}

export type IndexerBalanceStatus = 'ok' | 'not_deployed' | 'unavailable';
export type IndexerBalanceRow = {
  kind: 'native' | 'jetton';
  /** Raw jetton root; null for native. */
  root: string | null;
  wallet: string | null;
  symbol: string | null;
  status: IndexerBalanceStatus;
  /** Atomic units as a decimal string; null exactly when status is `unavailable`. */
  raw: string | null;
};
export type IndexerBalances = { owner: string; headSeqno: number | null; complete: boolean; rows: IndexerBalanceRow[] };

const rawAddressOrNull = (value: unknown): string | null => {
  if (typeof value !== 'string') return null;
  try { return Address.parse(value).toRawString(); }
  catch { return null; }
};

/**
 * The one shape of a balances answer. A row without a valid `status` is `unavailable`, and `unavailable` is
 * never a zero: the caller reads that asset from the chain. Only `assets`, `complete`, `head_seqno` and a row's
 * `kind`, `root`, `wallet`, `symbol`, `status` and `balance_raw` are read; nothing is matched by symbol.
 * Pure. Throws when `payload.assets` is not an array (the response is then a failed request, not an empty wallet).
 */
export const decodeIndexerBalances = (payload: unknown, owner: string): IndexerBalances => {
  const body = asRecord(payload);
  if (!body || !Array.isArray(body.assets)) throw new Error('Indexer balances answer has no asset list.');
  const rows: IndexerBalanceRow[] = [];
  for (const element of body.assets) {
    const asset = asRecord(element);
    if (!asset || (asset.kind !== 'native' && asset.kind !== 'jetton')) continue;
    const root = asset.kind === 'jetton' ? rawAddressOrNull(asset.root) : null;
    // A jetton element that does not name its root is not a row.
    if (asset.kind === 'jetton' && !root) continue;
    let status: IndexerBalanceStatus =
      asset.status === 'ok' || asset.status === 'not_deployed' ? asset.status : 'unavailable';
    let raw: string | null = null;
    if (status === 'ok' && isAtomicAmount(asset.balance_raw)) raw = asset.balance_raw;
    else if (status === 'not_deployed' && asset.balance_raw === '0') raw = '0';
    else status = 'unavailable';
    rows.push({
      kind: asset.kind,
      root,
      wallet: asset.kind === 'jetton' ? rawAddressOrNull(asset.wallet) : null,
      symbol: readString(asset.symbol),
      status,
      raw
    });
  }
  const headSeqno = body.head_seqno;
  return {
    owner: Address.parse(owner).toRawString(),
    headSeqno: typeof headSeqno === 'number' && Number.isSafeInteger(headSeqno) && headSeqno >= 0 ? headSeqno : null,
    complete: body.complete === true && rows.every(row => row.status !== 'unavailable'),
    rows
  };
};

const BALANCES_TIMEOUT_MS = 6_000;
const BALANCES_REUSE_MS = 2_000;
// How long ago an answer arrived is measured on a clock the person cannot set.
const monotonicNow = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
const balanceReads = new Map<string, SharedRequest<IndexerBalances>>();
const recentBalances = new Map<string, { balances: IndexerBalances; at: number }>();

/**
 * GET /v1/accounts/{owner}/balances, 6 s, one attempt, `health: 'chain'`. Callers for one owner share
 * the request in flight (it is aborted only when all of them aborted) and an answer is reused for 2 s.
 */
export const readIndexerBalances = async (owner: string, options: { signal?: AbortSignal } = {}): Promise<IndexerBalances> => {
  if (options.signal?.aborted) throw abortReason(options.signal);
  const account = Address.parse(owner).toRawString();
  const key = JSON.stringify([getBaseUrl(), account]);
  const recent = recentBalances.get(key);
  if (recent && monotonicNow() - recent.at < BALANCES_REUSE_MS) return recent.balances;
  return joinSharedRequest(balanceReads, key, async signal => {
    const balances = await requestIndexer(
      accountPath(account, 'balances'),
      { timeoutMs: BALANCES_TIMEOUT_MS, maxAttempts: 1, signal, health: 'chain' },
      payload => decodeIndexerBalances(payload, account)
    );
    for (const [other, entry] of recentBalances) {
      if (monotonicNow() - entry.at >= BALANCES_REUSE_MS) recentBalances.delete(other);
    }
    recentBalances.set(key, { balances, at: monotonicNow() });
    return balances;
  }, options.signal);
};
