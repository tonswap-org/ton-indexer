/**
 * The one grammar for user-entered amounts: ASCII digits with at most one
 * decimal separator. A lone ',' is the decimal separator ("1,5" is 1.5),
 * except where it reads as a thousands group ("1,000" could be 1 or 1000),
 * which is rejected as ambiguous. Grouping, repeated separators, signs,
 * exponents, inner spaces and non-ASCII digits are rejected, never stripped or
 * converted, so an amount is never silently rescaled. The grammar does not
 * depend on the display language; `i18n/decimal.ts` delegates to it.
 */
export type AmountInputError = 'empty' | 'format' | 'ambiguous' | 'precision' | 'decimals';
/**
 * The two ways a thousands-group-shaped number ("1,234", "01,234", "1.234") can be read, as canonical
 * strings: `larger` is the whole number ("1234") and always exists; `smaller` is the decimal ("1.234")
 * and exists only when the token has enough decimals for it.
 */
export interface AmountReadings {
  readonly larger: string;
  readonly smaller?: string;
}
/**
 * Both variants declare every field so `result.error` and `result.raw` type-check with or without
 * narrowing (the project does not enable `strictNullChecks`, where `!result.ok` alone does not narrow).
 * An `ambiguous` failure carries both readings, so the caller can let the person choose one.
 */
export type AmountInput =
  | { ok: true; raw: bigint; error?: undefined; readings?: undefined }
  | { ok: false; raw?: undefined; error: AmountInputError; readings?: AmountReadings };

/** The largest token precision the parser accepts. */
export const MAX_AMOUNT_DECIMALS = 255;
const MAX_AMOUNT_INPUT_LENGTH = 128;
const AMOUNT_GRAMMAR = /^(\d*)(?:([.,])(\d*))?$/;
// "1,000" / "12,500" / "999,999" / "01,234": a 1-3 digit non-zero whole part (leading zeros do not
// count: "001,234" is a group as much as "1,234") and exactly three digits after the separator.
const THOUSANDS_GROUP_SHAPE = /^0*[1-9]\d{0,2}$/;
const THOUSANDS_GROUP_DIGITS = 3;

/**
 * Both readings of `input` when it has the shape of a thousands group around `separator`, else null.
 * The grammar itself only treats the comma shape as ambiguous (a point is a decimal point); a screen
 * that knows more (a language that groups with a point, pasted text) asks for the point shape too, so
 * the two shapes are judged by the same rule and give the same readings.
 */
export const groupShapeReadings = (input: string, decimals: number, separator: '.' | ','): AmountReadings | null => {
  const match = AMOUNT_GRAMMAR.exec(input.trim());
  if (!match || match[2] !== separator) return null;
  const [, whole, , fraction] = match;
  if (fraction.length !== THOUSANDS_GROUP_DIGITS || !THOUSANDS_GROUP_SHAPE.test(whole)) return null;
  const digits = whole.replace(/^0+/, '');
  return decimals >= THOUSANDS_GROUP_DIGITS ? { larger: digits + fraction, smaller: `${digits}.${fraction}` } : { larger: digits + fraction };
};

type AmountParts = { whole: string; fraction: string } | { error: 'empty' | 'format'; readings?: undefined } | { error: 'ambiguous'; readings: AmountReadings };

const splitAmountInput = (input: string | number | null | undefined, decimals = MAX_AMOUNT_DECIMALS): AmountParts => {
  if (typeof input === 'number' && !Number.isFinite(input)) return { error: 'format' };
  const text = String(input ?? '').trim();
  if (!text) return { error: 'empty' };
  const match = text.length <= MAX_AMOUNT_INPUT_LENGTH ? AMOUNT_GRAMMAR.exec(text) : null;
  if (!match || !(match[1] || match[3])) return { error: 'format' };
  const [, whole, separator, fraction = ''] = match;
  const readings = separator === ',' ? groupShapeReadings(text, decimals, ',') : null;
  if (readings) return { error: 'ambiguous', readings };
  return { whole: whole.replace(/^0+(?=\d)/, '') || '0', fraction };
};

/** Parse a user amount into atomic units; more fractional digits than `decimals` is an error. */
export const parseAmountInput = (input: string | number | null | undefined, decimals: number): AmountInput => {
  if (!Number.isSafeInteger(decimals) || decimals < 0 || decimals > MAX_AMOUNT_DECIMALS) return { ok: false, error: 'decimals' };
  const parts = splitAmountInput(input, decimals);
  if ('error' in parts) return { ok: false, ...parts };
  if (parts.fraction.length > decimals) return { ok: false, error: 'precision' };
  return { ok: true, raw: BigInt(parts.whole + parts.fraction.padEnd(decimals, '0')) };
};

export const parseAmountToNano = (input: string | number | null | undefined, decimals: number): bigint | null => {
  const parsed = parseAmountInput(input, decimals);
  return parsed.ok ? parsed.raw : null;
};

/**
 * Canonical "whole.fraction" text of a user amount for display arithmetic, or null when invalid:
 * no redundant leading zero, no trailing separator, fraction digits kept as typed.
 */
export const amountInputText = (input: string | number | null | undefined): string | null => {
  const parts = splitAmountInput(input);
  if ('error' in parts) return null;
  return parts.fraction ? `${parts.whole}.${parts.fraction}` : parts.whole;
};

export const toNanoString = (value: bigint) => value.toString(10);
