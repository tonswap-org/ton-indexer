import { AppError, isAppError } from './appError';
import englishReview from '../i18n/locales/en/review.ts';
import type { MessageParams } from '../i18n/message.ts';

/** Why a request definitely never reached the wallet. Each reason has a catalog message `review.notSent.<reason>`. */
export type NotSentReason =
  | 'generic' | 'busy' | 'invalid' | 'reviewExpired' | 'contextChanged' | 'tooLate' | 'pageClosed' | 'sessionChanged'
  | 'notConfigured' | 'notConnected' | 'networkUnverified' | 'tradingChanged' | 'tradingUnverified' | 'tradingExpired'
  | 'reviewChanged' | 'connectionChanged' | 'handoffChanged' | 'handoff'
  | 'verifyFailed' | 'verifyTimeout' | 'rowMismatch' | 'extraCurrency'
  | 'otherTab' | 'locksUnavailable' | 'walletUnverified' | 'needGram' | 'requestPending' | 'requestSigned' | 'clockSkew' | 'recordUnsaved';

/** The English sentence of a catalog key: the one source for developer messages and logs. */
function english(key: string): string {
  let node: unknown = englishReview;
  for (const part of key.split('.').slice(1)) node = (node as Record<string, unknown> | undefined)?.[part];
  if (typeof node !== 'string') throw new Error(`The review catalog has no English text for ${key}.`);
  return node;
}

/**
 * This error proves that the request was never handed to the wallet. It is an `AppError`, so a screen shows
 * `messageFor(error, useI18n())` and never `error.message`; `message` is the English developer sentence.
 */
export class WalletRequestNotSentError extends AppError {
  readonly phase = 'before-wallet';
  constructor(message: string, code: string = 'review.notSent.generic', params: MessageParams = {}, cause?: unknown) {
    super(code, params, { devMessage: message, cause });
    this.name = 'WalletRequestNotSentError';
  }
}
export const isWalletRequestNotSentError = (error: unknown): error is WalletRequestNotSentError =>
  error instanceof WalletRequestNotSentError;

/** A not-sent error with the catalog sentence for `reason`; `cause` keeps the underlying failure for logs. */
export function notSent(reason: NotSentReason, cause?: unknown, params: MessageParams = {}): WalletRequestNotSentError {
  const code = `review.notSent.${reason}`;
  return new WalletRequestNotSentError(english(code), code, params, cause);
}

/**
 * Wraps a failure from before the handoff. A typed failure keeps its own code and message; anything else
 * becomes the `reason` message, with the original text kept for developers.
 */
export function notSentFrom(error: unknown, reason: NotSentReason): WalletRequestNotSentError {
  if (isWalletRequestNotSentError(error)) return error;
  if (isAppError(error)) return new WalletRequestNotSentError(error.devMessage, error.code, error.params, error);
  if (error instanceof Error && error.message) return new WalletRequestNotSentError(`${error.message} ${english('review.notSent.generic')}`, `review.notSent.${reason}`, {}, error);
  return notSent(reason, error);
}

export const formatWalletRequestTon = (nano: string) => {
  const amount = BigInt(nano), decimals = (amount % 1_000_000_000n).toString().padStart(9, '0').replace(/0+$/, '');
  return `${amount / 1_000_000_000n}${decimals ? '.' + decimals : ''}`;
};
