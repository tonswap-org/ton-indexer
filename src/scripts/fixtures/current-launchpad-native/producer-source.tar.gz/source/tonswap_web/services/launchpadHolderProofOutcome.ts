import { Address, beginCell, Cell, loadTransaction, storeMessage, type Transaction } from '@ton/core';
import artifact from './artifacts/t3RecoveryProof.json';
import type { LaunchpadHolderProofRequest } from './launchpadHolderProofStore';
import type { LaunchpadProofBinding } from './launchpadOperationSettlement';
import type { TransactionRef, WalletRequestChain } from './walletRequest';
import { walletRequestChain } from './walletRequestChain';
import { createTransactionProofReader, decodeLinkedPage } from './transactionProofHistory';

export type LaunchpadHolderProofFailure={verifierTransactionBoc:string;holderTransactionBoc:string;dispatch:Pick<TransactionRef,'lt'|'hash'>};
const sameMessage=(a:NonNullable<Transaction['inMessage']>,b:NonNullable<Transaction['inMessage']>)=>beginCell().store(storeMessage(a)).endCell().equals(beginCell().store(storeMessage(b)).endCell());
function transaction(raw:string,address:string){
 if(typeof raw!=='string'||raw.length>1024*1024)throw Error('Certificate transaction exceeds limit');
 const c=Cell.fromBase64(raw);if(c.isExotic)throw Error('Exotic certificate transaction');
 const s=c.beginParse(),t=loadTransaction(s);s.endParse();if(t.address!==BigInt('0x'+Address.parse(address).hash.toString('hex'))||t.lt<=0n||t.prevTransactionLt>=t.lt)throw Error('Certificate transaction identity differs');return t;
}
/** Only an original, causally linked aborted receiver transaction releases a
 * failed certificate attempt. Absence of a receipt or an unchanged phase does not. */
export function validateLaunchpadHolderProofFailure(value:unknown,r:LaunchpadHolderProofRequest,binding:LaunchpadProofBinding):value is LaunchpadHolderProofFailure{
 try{
  if(r.step!==30||!value||typeof value!=='object'||Object.keys(value).sort().join()!=='dispatch,holderTransactionBoc,verifierTransactionBoc')return false;
  const v=value as LaunchpadHolderProofFailure;if(!v.dispatch||Object.keys(v.dispatch).sort().join()!=='hash,lt'||!/^([1-9][0-9]*)$/.test(v.dispatch.lt)||!/^[a-f0-9]{64}$/.test(v.dispatch.hash))return false;
  const source=transaction(v.verifierTransactionBoc,r.address),target=transaction(v.holderTransactionBoc,r.session.candidate.holder);
  if(source.lt.toString()!==v.dispatch.lt||Cell.fromBase64(v.verifierTransactionBoc).hash().toString('hex')!==v.dispatch.hash)return false;
  if(source.description.type!=='generic'||source.description.aborted||target.description.type!=='generic'||!target.description.aborted||target.lt<=source.lt)return false;
  const incoming=source.inMessage;if(incoming?.info.type!=='internal'||incoming.info.bounced||incoming.info.bounce!==r.bounce||incoming.info.value.coins!==BigInt(r.valueNano)||incoming.info.src.toRawString()!==r.session.original.owner||incoming.info.dest.toRawString()!==r.address||incoming.body.hash().toString('hex')!==r.bodyHash)return false;
  const code=Cell.fromBase64(artifact.codeBoc);if(code.hash().toString('hex')!==binding.proofCodeHash)return false;
  const body=Cell.fromBase64(r.bodyBoc).beginParse();if(body.loadUint(32)!==0x54335046||body.loadUint(8)!==30)return false;const receiver=body.loadRef(),amount=body.loadCoins();body.endParse();
  const certificate=beginCell().storeUint(r.session.candidate.kind==='notification'?0x54334e43:0x54334643,32).storeRef(Cell.fromBase64(r.session.configBoc)).storeRef(receiver).storeRef(code);if(r.session.candidate.kind==='notification')certificate.storeUint(BigInt(r.expectedStage.messageHash),256);const expected=certificate.endCell();
  const sent=[...source.outMessages.values()].filter(m=>m.info.type==='internal'&&!m.info.bounced&&m.info.src.toRawString()===r.address&&m.info.dest.toRawString()===r.session.candidate.holder&&m.body.equals(expected)&&m.info.value.coins===amount);
  const received=target.inMessage;return sent.length===1&&!!received&&received.info.type==='internal'&&!received.info.bounced&&sameMessage(sent[0],received);
 }catch{return false;}
}
const readers=new WeakMap<WalletRequestChain,ReturnType<typeof createTransactionProofReader>>();
export async function readLaunchpadHolderProofFailure(r:LaunchpadHolderProofRequest,binding:LaunchpadProofBinding,origin:TransactionRef,options:{chain?:WalletRequestChain;signal?:AbortSignal}={}):Promise<LaunchpadHolderProofFailure|null>{
 if(r.step!==30)return null;const chain=options.chain??walletRequestChain;
 try{
  const rows=await chain.readTransactions(r.address,origin,1,options.signal),source=decodeLinkedPage(r.address,rows,origin)[0];if(!source)return null;
  let read=readers.get(chain);if(!read){read=createTransactionProofReader(async(account,cursor,limit,signal)=>{const tip=cursor??await chain.readAccountTip(account,signal);return tip.lt==='0'?[]:chain.readTransactions(account,tip,limit??32,signal);});readers.set(chain,read);}
  const history=await read(`${r.id}:${origin.lt}:${origin.hash}`,[r.session.candidate.holder],Math.max(0,source.now-1),4,options.signal);if(!history)return null;
  const verified=(history.get(r.session.candidate.holder)??[]).map(row=>({verifierTransactionBoc:(rows[0] as {data:string}).data,holderTransactionBoc:(row as {data:string}).data,dispatch:{lt:origin.lt,hash:origin.hash}})).filter(v=>validateLaunchpadHolderProofFailure(v,r,binding));
  return verified.length===1?verified[0]:null;
 }catch(error){if(options.signal?.aborted)throw options.signal.reason;return null;}
}
