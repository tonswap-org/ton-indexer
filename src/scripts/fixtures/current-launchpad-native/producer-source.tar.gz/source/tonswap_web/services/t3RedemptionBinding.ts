import { validateReleaseManifest } from '../releaseManifestCodec.mjs';
import type { ExecutionNetwork } from './executionNetwork';

export type T3ReserveBinding = {
  slot: 0 | 1 | 2; symbol: 'USDT' | 'USDC' | 'KUSD'; master: string;
  masterCodeHash: string; walletCodeHash: string; decimals: number;
};
export type T3RedemptionBinding = {
  network: ExecutionNetwork; releaseId: string; manifestHash: string;
  hub: string; governance: string; hubCodeHash: string; walletCodeHash: string;
  recoveryProofCodeHash: string; reserves: T3ReserveBinding[];
};

/** Identity pins shared by browser flows and read-only observers. The hub is the
 * T3 master. Each reserve master supplies its own custody-wallet identity. */
export function deriveT3RedemptionBinding(input: unknown): T3RedemptionBinding | undefined {
  const validated = validateReleaseManifest(input);
  if (validated.ok === false) throw new Error(`Invalid current native manifest: ${validated.errors.join(', ')}`);
  const m = validated.m, hub = m.contracts.T3Hub, governance = m.contracts.Governance;
  if (!hub || !governance) return undefined;
  const reserves: T3ReserveBinding[] = [];
  for (const [slot, symbol] of (['USDT', 'USDC', 'KUSD'] as const).entries()) {
    const token = m.tokens.find(t => t.symbol === symbol);
    if (!token) {
      if (slot < 2) return undefined;
      continue;
    }
    // T3 uses at most nine decimal places even though unrelated jettons may use eighteen.
    if (token.decimals > 9) throw new Error(`T3 reserve ${symbol} precision exceeds the hub scale`);
    reserves.push({ slot: slot as 0 | 1 | 2, symbol, master: token.root,
      masterCodeHash: token.masterCodeHash, walletCodeHash: token.walletCodeHash, decimals: token.decimals });
  }
  return {
    network: m.network.slice(4) as ExecutionNetwork, releaseId: m.releaseId, manifestHash: m.manifestHash,
    hub: hub.address, governance: governance.address, hubCodeHash: hub.codeHash,
    walletCodeHash: m.templates.T3Wallet, recoveryProofCodeHash: m.templates.T3RecoveryProof, reserves,
  };
}
