import { Address, beginCell } from '@ton/core';
import type { StandardWalletKind, WalletRequestTicket, WalletRequestAnswer } from './walletRequest';

const hex = (value: unknown, length: number): value is string => typeof value === 'string' && new RegExp(`^[0-9a-f]{${length}}$`).test(value);
const integer = (value: unknown): value is number => Number.isSafeInteger(value) && Number(value) >= 0;
const coins = (value: unknown): value is string => typeof value === 'string' && /^(0|[1-9][0-9]*)$/.test(value);
const canonical = (value: unknown): value is string => { try { return typeof value === 'string' && Address.parse(value).toRawString() === value; } catch { return false; } };
const walletKind = (value: unknown): value is StandardWalletKind | null => value === null || ['v3r1', 'v3r2', 'v4r2', 'v5r1'].includes(String(value));
const positionValid = (position: { lt: string; hash: string }) => coins(position?.lt) && hex(position?.hash, 64)
  && (position.lt === '0') === (position.hash === '0'.repeat(64));
const ticketFields = (ticket: Omit<WalletRequestTicket, 'id'>) => ({ version: ticket.version, network: ticket.network,
  owner: ticket.owner, validUntil: ticket.validUntil, messages: ticket.messages.map(m => ({ destination: m.destination,
    amount: m.amount, bodyHash: m.bodyHash, init: m.init })), baseline: { lt: ticket.baseline.lt, hash: ticket.baseline.hash }, wallet: ticket.wallet });
export const ticketId = (ticket: Omit<WalletRequestTicket, 'id'>) => beginCell().storeStringTail(JSON.stringify(ticketFields(ticket)))
  .endCell().hash().toString('hex').slice(0, 32);


export function isWalletRequestTicket(value: unknown): value is WalletRequestTicket {
  try {
    const t = value as WalletRequestTicket;
    return !!t && t.version === 1 && hex(t.id, 32) && ['mainnet', 'testnet', 'localnet'].includes(t.network)
      && canonical(t.owner) && integer(t.validUntil) && t.validUntil > 0 && t.validUntil <= 0xffffffff
      && positionValid(t.baseline) && walletKind(t.wallet) && Array.isArray(t.messages) && t.messages.length > 0 && t.messages.length <= 255
      && t.messages.every(m => canonical(m.destination) && coins(m.amount) && hex(m.bodyHash, 64) && typeof m.init === 'boolean')
      && ticketId(t) === t.id;
  } catch { return false; }
}
export function isWalletRequestAnswer(value: unknown): value is WalletRequestAnswer {
  const a = value as WalletRequestAnswer;
  return !!a && (a.bodyHash === null || hex(a.bodyHash, 64)) && (a.signedValidUntil === 'none' || a.signedValidUntil === 'unreadable'
    || integer(a.signedValidUntil) && a.signedValidUntil <= 0xffffffff);
}
