import { Address, beginCell, Cell } from '@ton/core';
import { TONSWAP_RELEASE } from '../releaseManifest';
import type { LaunchpadRequest } from './launchpadOperationStore';
import type { FreshJettonSlot } from './spotContracts';
import { jettonWalletBudgetToCell, standardJettonWalletProfile, type JettonWalletProfile } from './jettonWalletProfile';
import { LAUNCH_OP, decodeLaunchChild, decodeLaunchFactory, decodeLaunchTerms, launchChildAddress, launchChildren,
  launchContractError, launchpadReleaseBinding, readLaunchpadState, type LaunchReadOptions, type LaunchpadBinding } from './launchpadContracts';

const requireMatch = (condition: unknown, reason: string): void => { if (!condition) throw launchContractError(`Creation state: ${reason}`); };
const profileMatches = (actual: JettonWalletProfile, expected: JettonWalletProfile) => actual.walletGas === expected.walletGas
  && actual.walletGram === expected.walletGram && jettonWalletBudgetToCell(actual.budget).equals(jettonWalletBudgetToCell(expected.budget));
const slotMatches = (slot: FreshJettonSlot | undefined, master: Address, optional: boolean, profile: JettonWalletProfile) =>
  !!slot && slot.master.equals(master) && slot.optional === optional && profileMatches(slot, profile);

function originalCreation(request: LaunchpadRequest, factoryBeforeDataBoc: string, binding = launchpadReleaseBinding()) {
  const release = TONSWAP_RELEASE;
  requireMatch(release && request.releaseId === release.releaseId && request.manifestHash === release.manifestHash
    && `ton:${request.network}` === release.network, 'release changed');
  requireMatch(request.kind === 'create' && request.wallet === request.creator && request.factory === binding.factory.toRawString()
    && request.target === request.factory && request.destination === request.factory && request.amountRaw === '0'
    && request.tokenRoot === null && request.sourceWallet === null && request.minTokensRaw === null && request.assets.length === 0,
  'original request identity differs');
  const body = Cell.fromBase64(request.bodyBoc);
  requireMatch(!body.isExotic && body.hash().toString('hex') === request.bodyHash, 'original body hash differs');
  const s = body.beginParse();
  requireMatch(s.loadUint(32) === LAUNCH_OP.CREATE && s.loadUintBig(64).toString() === request.queryId
    && s.loadUintBig(64).toString() === request.nonce && s.loadUint(8) === request.model && [0, 1, 2].includes(request.model), 'original CREATE differs');
  const termsCell = s.loadRef(); s.endParse();
  const terms = decodeLaunchTerms(termsCell), factory = decodeLaunchFactory(Cell.fromBase64(factoryBeforeDataBoc));
  requireMatch(!factory.closed && factory.feeBps <= 500 && factory.codes.size === 5
    && factory.governance.equals(binding.governance) && factory.t3Master.equals(binding.t3Root)
    && factory.feeSink.equals(binding.feeSink) && factory.dlmmFactory.equals(binding.dlmmFactory)
    && binding.templateHashes.every((hash, index) => factory.codes.get(index)?.code.hash().toString('hex') === hash), 'original factory peers or code pins differ');
  const creator = Address.parse(request.creator), children = launchChildren({ binding, factory }, creator, BigInt(request.nonce), request.model);
  requireMatch(children.sale.toRawString() === request.sale, 'original sale address differs');
  const expectedSale = beginCell().storeUint(factory.feeBps, 16)
    .storeRef(beginCell().storeAddress(factory.feeSink).storeAddress(children.lp).storeAddress(terms.vesting ? children.vesting : null).endCell())
    .storeRef(termsCell).endCell();
  const projectProfile = standardJettonWalletProfile(30_000);
  const poolId = beginCell().storeAddress(terms.projectMaster).storeUint(2500, 16).storeUint(3000, 32).storeUint(terms.xDecimals, 8)
    .storeUint(projectProfile.walletGas, 32).storeCoins(projectProfile.walletGram).storeRef(jettonWalletBudgetToCell(projectProfile.budget)).endCell();
  const expectedLp = beginCell().storeRef(beginCell().storeAddress(children.sale).storeAddress(terms.lpRecipient).storeAddress(factory.dlmmFactory).endCell())
    .storeInt(terms.seedBin, 32).storeRef(poolId).endCell();
  const vest = terms.vesting;
  const expectedVest = vest ? beginCell().storeAddress(children.sale).storeRef(beginCell().storeAddress(vest.beneficiary).storeCoins(vest.amount)
    .storeUint(vest.cliff, 32).storeUint(vest.duration, 32).storeUint(vest.period, 32).endCell()).endCell() : null;
  const roles = [
    { role: 0 as const, address: children.sale, config: expectedSale },
    { role: 1 as const, address: children.lp, config: expectedLp },
    ...(expectedVest ? [{ role: 2 as const, address: children.vesting, config: expectedVest }] : [])
  ];
  return { binding, factory, creator, children, terms, projectProfile, roles };
}
type OriginalCreation = ReturnType<typeof originalCreation>;
function checkChild(original: OriginalCreation, request: LaunchpadRequest, address: Address, code: Cell, data: Cell) {
  const { factory, binding, creator, terms, projectProfile, roles } = original;
  const expected = roles.find(child => child.address.equals(address));
  requireMatch(expected, 'unexpected child address');
  const pinnedCode = factory.codes.get(expected!.role === 0 ? request.model : expected!.role + 2)!.code;
  requireMatch(code.equals(pinnedCode), 'canonical child code differs');
  const child = decodeLaunchChild(data), id = child.identity;
  requireMatch(id.factory.equals(binding.factory) && id.creator.equals(creator) && id.nonce === BigInt(request.nonce)
    && id.kind === request.model && id.role === expected!.role && launchChildAddress(id, code).equals(address), 'canonical child identity differs');
  if (!child.config) { requireMatch(child.slots.size === 0, 'unconfigured child has token slots'); return false; }
  requireMatch(child.config.equals(expected!.config), 'immutable child configuration differs from original CREATE');
  const project = child.slots.get(expected!.role === 2 ? 0 : 1);
  requireMatch(child.slots.size === (expected!.role === 2 ? 1 : 2)
    && slotMatches(project, terms.projectMaster, true, projectProfile)
    && (expected!.role === 2 || slotMatches(child.slots.get(0), factory.t3Master, false, factory.t3Profile)),
  'immutable child token profile differs from original CREATE');
  return true;
}

/** Validate a configured native child against the verified original factory CREATE before-state. */
export function assertLaunchpadCreatedChild(request: LaunchpadRequest, factoryBeforeDataBoc: string,
  address: Address, code: Cell, data: Cell, binding: LaunchpadBinding = launchpadReleaseBinding()): void {
  requireMatch(checkChild(originalCreation(request, factoryBeforeDataBoc, binding), request, address, code, data), 'child is not configured');
}

/**
 * The caller must obtain factoryBeforeDataBoc from the authenticated before-state of
 * the original, successfully executed factory CREATE transaction. A bare historical
 * data cell cannot authenticate its own origin. This check proves configuration,
 * never delivery of funds, and does not replace the original dispatch anchor.
 * Retrying is a separate decision: the caller must compare currentFactoryDataHash
 * with the reviewed plan and require chainNow <= retryUntil. A creation that
 * completed earlier stays fulfilled after the retry window or a fee change.
 */
export async function verifyLaunchpadCreationState(request: LaunchpadRequest, factoryBeforeDataBoc: string,
  options: Omit<LaunchReadOptions, 'calls'> = {}) {
  options.signal?.throwIfAborted();
  const release = TONSWAP_RELEASE, requestSnapshot = JSON.stringify(request);
  const original = originalCreation(request, factoryBeforeDataBoc, options.binding), { binding, children, terms, roles } = original;
  // One observation prevents an apparent completion assembled from different heads.
  const current = await readLaunchpadState(null, { ...options, binding,
    calls: roles.map(child => ({ kind: 'account' as const, address: child.address.toRawString() })) });
  options.signal?.throwIfAborted();
  requireMatch(release === TONSWAP_RELEASE && JSON.stringify(request) === requestSnapshot, 'original request changed during read');
  let complete = true;
  for (const [index, expected] of roles.entries()) {
    const a = current.result(index);
    requireMatch(a.kind === 'account', 'child response kind differs');
    if (a.kind !== 'account') throw launchContractError('Creation state: child response missing');
    if (a.state !== 'active') { complete = false; continue; }
    requireMatch(a.code && a.data, 'active child code or data missing');
    if (!checkChild(original, request, expected.address, a.code!, a.data!)) complete = false;
  }
  const factoryAccount = current.observation.results[0];
  requireMatch(factoryAccount.kind === 'account' && factoryAccount.data, 'current factory data missing');
  if (factoryAccount.kind !== 'account' || !factoryAccount.data) throw launchContractError('Creation state: current factory data missing');
  return { state: complete ? 'fulfilled' as const : 'incomplete' as const, head: current.head,
    chainNow: current.chainNow, retryUntil: terms.startTime - 300,
    currentFactoryDataHash: factoryAccount.data.hash().toString('hex'),
    children: { sale: children.sale.toRawString(), lp: children.lp.toRawString(), vesting: terms.vesting ? children.vesting.toRawString() : null } };
}
