import { Address, beginCell, Cell, CellType, Dictionary, type DictionaryValue } from '@ton/core';
import type { ReleaseManifestV1 } from '../releaseManifest';
import { AppError } from './appError';
import { ChainReadError } from './chainReadError';
import type { ChainCall, ChainObservation, ChainHead, GetterArg } from './toncenter';
import { FreshStack, freshInt, freshAddressArg, type FreshChainRead, type FreshJettonSlot } from './spotContracts';
import { decodeJettonWalletBudget, validateJettonWalletProfile } from './jettonWalletProfile';
import { readT3ReceiptTree, verifyT3Witness } from './t3Contracts';

export const FAUCET_OP = { claim: 0x46434c4d, prune: 0x4650524e, restoreCooldown: 0x46435253, recoveryClaim: 0x4a52434d } as const;
export type FaucetAsset = 0 | 1 | 2;
export const FAUCET_SYMBOLS = ['T3', 'USDT', 'TS'] as const;
const invalid = (devMessage: string) => new AppError('wallet.faucet.error.verifyFaucet', {}, { devMessage });
const basechain = (address: Address) => { if (address.workChain !== 0) throw invalid('Expected a basechain address'); return address; };
const assetId = (asset: number): FaucetAsset => { if (![0, 1, 2].includes(asset)) throw invalid('Unknown faucet asset'); return asset as FaucetAsset; };
const query = (id: bigint) => { if (id < 0n || id >= 1n << 64n) throw invalid('Invalid faucet query id'); return id; };
export const faucetClaimBody = (asset: FaucetAsset, queryId = 0n) => beginCell().storeUint(FAUCET_OP.claim, 32).storeUint(query(queryId), 64).storeUint(assetId(asset), 8).endCell();
export const faucetPruneBody = (owner: Address, queryId = 0n) => beginCell().storeUint(FAUCET_OP.prune, 32).storeUint(query(queryId), 64).storeAddress(basechain(owner)).endCell();

export const faucetRecoveryBody = (receipt: Cell, proof: Cell, restoreCooldown: boolean) => beginCell().storeUint(restoreCooldown ? FAUCET_OP.restoreCooldown : FAUCET_OP.recoveryClaim, 32).storeRef(receipt).storeRef(proof).endCell();

export type FaucetClaimer = { last: [number, number, number]; wire: [bigint, bigint, bigint] };
const claimerCodec: DictionaryValue<FaucetClaimer> = {
  serialize(value, builder) { value.last.forEach(n => builder.storeUint(n, 32)); value.wire.forEach(n => builder.storeUint(n, 64)); },
  parse(s) { return { last: [s.loadUint(32), s.loadUint(32), s.loadUint(32)], wire: [s.loadUintBig(64), s.loadUintBig(64), s.loadUintBig(64)] }; }
};
const slotCodec: DictionaryValue<FreshJettonSlot> = {
  serialize() { throw invalid('Read-only faucet slot'); },
  parse(s) {
    const slot = { master: s.loadAddress(), wallet: s.loadMaybeAddress(), walletGas: s.loadUint(32), walletGram: s.loadCoins(), optional: s.loadBit(), budget: decodeJettonWalletBudget(s.loadRef()) };
    s.endParse(); validateJettonWalletProfile(slot); basechain(slot.master); if (slot.wallet) basechain(slot.wallet); return slot;
  }
};
export type FaucetRecovery = { dispatched: bigint; handled: bigint; pending: bigint; tree: Cell | null; restored: bigint };
export function readFaucetRecovery(cell: Cell): FaucetRecovery {
  const s = cell.beginParse(), value = { dispatched: s.loadUintBig(256), handled: s.loadUintBig(256), pending: s.loadCoins(), tree: s.loadMaybeRef(), restored: s.loadUintBig(256) };
  s.endParse(); return value;
}
export function readFaucetState(cell: Cell) {
  const s = cell.beginParse(), cfg = s.loadRef().beginParse();
  const cooldown = cfg.loadUint(32), grants = [cfg.loadCoins(), cfg.loadCoins(), cfg.loadCoins()] as const;
  const supplyBase = cfg.loadUintBig(120), tsLifetimeCap = cfg.loadCoins(); cfg.endParse();
  const managed = s.loadRef().beginParse(), slots = managed.loadDict(Dictionary.Keys.Uint(8), slotCodec);
  const refundContext = managed.loadMaybeRef(), recoveries = managed.loadDict(Dictionary.Keys.Uint(8), Dictionary.Values.Cell()); managed.endParse();
  const available = [s.loadCoins(), s.loadCoins(), s.loadCoins()] as const, tsGranted = s.loadCoins(), nextWire = s.loadUintBig(65), count = s.loadUint(16);
  const claimers = s.loadDict(Dictionary.Keys.Address(), claimerCodec); s.endParse();
  if (count !== claimers.size || count > 16384 || cooldown === 0 || grants.some(n => n <= 0n) || slots.size !== 3 || nextWire < 1n || nextWire > 1n << 64n
      || supplyBase <= 0n || tsLifetimeCap < grants[2] || tsLifetimeCap >= (supplyBase * 200n + 9999n) / 10000n || tsGranted > tsLifetimeCap) throw invalid('Invalid current faucet state');
  return { cooldown, grants, supplyBase, tsLifetimeCap, slots, refundContext, recoveries, available, tsGranted, nextWire, count, claimers };
}
export type FaucetPins = { address: Address; codeHash: string; supplyBase: bigint; tokens: Array<{ master: Address; masterCodeHash: string; walletCodeHash: string; decimals: number }> };
export function bindFaucetManifest(manifest: ReleaseManifestV1): FaucetPins {
  const contract = manifest.contracts.TestnetFaucet;
  if (!contract || manifest.network === 'ton:mainnet') throw invalid('The current testnet faucet is not deployed');
  const tokens = FAUCET_SYMBOLS.map(symbol => {
    const token = manifest.tokens.find(t => t.symbol === symbol);
    if (!token || !/^[0-9a-f]{64}$/.test(token.masterCodeHash) || !/^[0-9a-f]{64}$/.test(token.walletCodeHash)) throw invalid('Missing faucet token identity');
    return { master: basechain(Address.parse(token.root)), masterCodeHash: token.masterCodeHash, walletCodeHash: token.walletCodeHash, decimals: token.decimals };
  });
  return { address: basechain(Address.parse(contract.address)), codeHash: contract.codeHash, supplyBase: BigInt(manifest.supplyBase), tokens };
}
function stack(result: ChainObservation['results'][number]) {
  if (result?.kind !== 'getter' || result.exitCode !== 0) throw invalid('Faucet getter refused'); return new FreshStack(result.stack);
}
function active(result: ChainObservation['results'][number], codeHash: string) {
  if (result?.kind !== 'account' || result.state !== 'active' || !result.code || !result.data || !faucetCodeMatches(result.code, codeHash)) throw invalid('Faucet account identity differs');
  return result;
}
/** TON library references must name the exact release-pinned executable code. */
export function faucetCodeMatches(code:Cell,codeHash:string):boolean{
  if(code.hash().toString('hex')===codeHash)return !code.isExotic||code.type===CellType.Library;
  if(!code.isExotic)return false;
  if(code.type!==CellType.Library||code.bits.length!==264||code.refs.length!==0)return false;
  const s=code.beginParse(true);return s.loadUint(8)===2&&s.loadBuffer(32).toString('hex')===codeHash;
}
const account = (address: Address): ChainCall => ({ kind: 'account', address: address.toRawString() });
const getter = (address: Address, method: string, args: readonly GetterArg[] = []): ChainCall => ({ kind: 'getter', address: address.toRawString(), method, args });
function anchored(result: ChainObservation) {
  const head = result.head;
  if (!head || !Number.isSafeInteger(head.seqno) || head.seqno <= 0 || !head.rootHashHex || !/^[0-9a-f]{64}$/.test(head.rootHashHex)
      || /^0+$/.test(head.rootHashHex) || head.utime === null || !Number.isSafeInteger(head.utime) || head.utime <= 0 || head.utime > 0xffffffff) throw new ChainReadError('unavailable');
  return head;
}
export type FaucetTransactionPlan = { address: Address; body: Cell; value: bigint; bounce: true; head: ChainHead };
export function createFaucet(read: FreshChainRead, pins: FaucetPins) {
  const stateOf = (result: ChainObservation['results'][number]) => {
    const state = readFaucetState(active(result, pins.codeHash).data!);
    if (state.supplyBase !== pins.supplyBase || pins.tokens.length !== 3) throw invalid('Faucet supply differs from release');
    pins.tokens.forEach((token, i) => { const slot = state.slots.get(i); if (!slot || slot.optional || !slot.master.equals(token.master)) throw invalid('Faucet token differs from release'); });
    return state;
  };
  const snapshot = async (owner: Address | null = null, extra: readonly ChainCall[] = []) => {
    if (owner) basechain(owner);
    const first = await read([account(pins.address)], { anchored: true, lane: 'user' }); anchored(first);
    const initial = stateOf(first.results[0]);
    const calls: ChainCall[] = [account(pins.address), getter(pins.address, 'get_faucet'),
      ...FAUCET_SYMBOLS.map((_, i) => getter(pins.address, 'get_min_value', [freshInt(FAUCET_OP.claim), freshInt(i)])),
      ...pins.tokens.flatMap((token, i) => { const wallet = initial.slots.get(i)?.wallet; if (!wallet) throw invalid('Faucet wallets are not discovered'); return [
        account(token.master), getter(token.master, 'get_wallet_address', [freshAddressArg(pins.address)]), account(wallet), getter(wallet, 'get_wallet_data')]; }),
      ...(owner ? [getter(pins.address, 'get_claimer', [freshAddressArg(owner)])] : []), ...extra];
    const observation = await read(calls, { anchored: true, lane: 'user' }), head = anchored(observation);
    if (observation.results.length !== calls.length) throw invalid('Incomplete faucet observation');
    const state = stateOf(observation.results[0]), s = stack(observation.results[1]);
    const values = [s.uint(), s.uint(), s.uint(), s.uint(), s.uint(), s.uint(), s.uint(), s.uint(), s.uint(), s.uint(), s.uint(), s.uint(65)]; s.end();
    const expected = [BigInt(state.cooldown), ...state.grants, state.supplyBase, state.tsLifetimeCap, ...state.available, state.tsGranted, BigInt(state.count), state.nextWire];
    if (values.some((n, i) => n !== expected[i])) throw invalid('Faucet getter differs from account state');
    const claimValues = observation.results.slice(2, 5).map(result => { const s = stack(result), value = s.uint(); s.end(); if (value <= 0n) throw invalid('Missing faucet funding'); return value; });
    const balances = pins.tokens.map((token, i) => {
      const offset = 5 + i * 4, slot = state.slots.get(i)!, wallet = initial.slots.get(i)!.wallet!;
      active(observation.results[offset], token.masterCodeHash);
      const selected = stack(observation.results[offset + 1]), address = selected.address(); selected.end();
      if (!address?.equals(wallet) || !slot.wallet?.equals(wallet)) throw invalid('Faucet wallet selection changed');
      active(observation.results[offset + 2], token.walletCodeHash);
      const walletResult=observation.results[offset+3];
      if(walletResult?.kind!=='getter'||walletResult.exitCode!==0||walletResult.stack.length!==4)throw invalid('Incomplete wallet getter');
      const w=new FreshStack(walletResult.stack.slice(0,3)),balance=w.uint(),walletOwner=w.address(),master=w.address();w.end();
      const [codeType,codeBytes]=walletResult.stack[3],encoded=typeof codeBytes==='string'?codeBytes:codeBytes&&typeof codeBytes==='object'&&'bytes' in codeBytes?(codeBytes as {bytes:unknown}).bytes:null;
      if(!['cell','tvm.Cell'].includes(codeType)||typeof encoded!=='string')throw invalid('Missing wallet code getter');
      const code=Cell.fromBase64(encoded);
      if (!walletOwner?.equals(pins.address) || !master?.equals(token.master) || !code || !faucetCodeMatches(code, token.walletCodeHash)) throw invalid('Faucet wallet owner/master differs');
      return balance;
    });
    const claimer = owner ? state.claimers.get(owner) ?? null : null;
    if (owner) {
      const s = stack(observation.results[17]);
      // Tolk 1.5 nullable structs expose six fields and their union discriminator.
      if (!claimer) { for(let i=0;i<6;i++)if(s.cell(true)!==null)throw invalid('Faucet claimer differs from state');if(s.int()!==0n)throw invalid('Invalid empty claimer tag'); }
      else { const values = [s.uint(), s.uint(), s.uint(), s.uint(), s.uint(), s.uint()]; if (values.some((n, i) => n !== (i < 3 ? BigInt(claimer.last[i]) : claimer.wire[i - 3]))||s.int()!==139n) throw invalid('Faucet claimer differs from state'); }
      s.end();
    }
    return { state, head, balances, claimValues, claimer, results: observation.results.slice(owner ? 18 : 17) };
  };
  return { pins, snapshot,
    async prepareClaim(owner: Address, asset: FaucetAsset, queryId = 0n) {
      assetId(asset); const r = await snapshot(owner), now = r.head.utime!, last = r.claimer?.last[asset] ?? 0, amount = r.state.grants[asset];
      if (owner.equals(pins.address) || pins.tokens.some((t, i) => owner.equals(t.master) || owner.equals(r.state.slots.get(i)!.wallet!))
          || r.state.nextWire >= 1n << 64n || (!r.claimer && r.state.count >= 16384) || last > 0 && now < last + r.state.cooldown
          || r.state.available[asset] < amount || r.balances[asset] < amount || asset === 2 && r.state.tsGranted + amount > r.state.tsLifetimeCap) throw invalid('Faucet claim is unavailable');
      return { address: pins.address, body: faucetClaimBody(asset, queryId), value: r.claimValues[asset], bounce: true as const, head: r.head,
        owner, asset, amount, sourceWallet: r.state.slots.get(asset)!.wallet!, priorWire: r.claimer?.wire[asset] ?? 0n };
    },
    async prepareRecovery(owner: Address, receipt: Cell, proof: Cell, restoreCooldown: boolean): Promise<FaucetTransactionPlan> {
      const rec = receipt.beginParse(), key = rec.loadUintBig(64), item = rec.loadRef().beginParse(); rec.endParse();
      const incoming = item.loadBit(), asset = assetId(item.loadUint(8)), amount = item.loadCoins(), claimed = item.loadBit(), body = item.loadRef().beginParse(); item.endParse();
      if (incoming || claimed !== restoreCooldown || amount <= 0n || body.loadUint(32) !== 0x0f8a7ea5) throw invalid('Expected a current source failure receipt');
      const wire = body.loadUintBig(64), sent = body.loadCoins(), destination = body.loadAddress(), excess = body.loadMaybeAddress(), custom = body.loadMaybeRef(), forward = body.loadCoins();
      const payload = body.loadBit() ? body.loadRef().beginParse() : body; payload.endParse(); if (payload !== body) body.endParse();
      if (sent !== amount || !destination.equals(owner) || !excess?.equals(owner) || custom || forward !== 0n) throw invalid('Faucet failure belongs to another command');
      const method = restoreCooldown ? 'get_min_cooldown_restore' : 'get_min_recovery_claim';
      const r = await snapshot(owner, [getter(pins.address, method, restoreCooldown ? [] : [{ type: 'cell', cell: receipt }])]);
      const cell = r.state.recoveries.get(asset), recovery = cell ? readFaucetRecovery(cell) : null;
      if (!recovery?.tree || r.state.grants[asset] !== amount || (restoreCooldown && r.claimer?.wire[asset] !== wire) || !verifyT3Witness(receipt, key, proof, readT3ReceiptTree(recovery.tree).root)) throw invalid('Faucet recovery witness is stale or unrelated');
      const s = stack(r.results[0]), value = s.uint(); s.end(); if (value <= 0n) throw invalid('Missing recovery funding');
      return { address: pins.address, body: faucetRecoveryBody(receipt, proof, restoreCooldown), value, bounce: true, head: r.head };
    }
  };
}
