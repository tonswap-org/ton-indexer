import { sameWalletTransaction } from './exactWalletTransaction';
import { Address, Cell } from '@ton/core';
import { CHAIN, type SendTransactionRequest } from '@tonconnect/sdk';
import type { SendWalletTransaction, ReviewWalletAction } from './walletAction';
import { isWalletRequestTicket, isWalletRequestAnswer, walletAnswer, walletMessageExpired, resolveWalletRequest, readFirstHop,
  readWalletRequestRecord, walletRequestRecordKey, type WalletRequestTicket, type WalletRequestAnswer, type WalletRequestChain } from './walletRequest';
import { isWalletRequestNotSentError, WalletRequestNotSentError } from './walletRequestNotSent';
import { AppError } from './appError';
import { walletRequestChain } from './walletRequestChain';
import { decodeLinkedPage } from './transactionProofHistory';
import type { FaucetRecoveryState } from './faucetRecovery';
import { faucetClaimBody, type FaucetAsset } from './faucetContracts';
import type { FaucetEvidenceRequest, FaucetEvidence, FaucetDelivery, FaucetRestored } from './faucetEvidence';

export type FaucetScope={network:'testnet'|'localnet';releaseId:string;manifestHash:string;owner:string;faucet:string};
export type FaucetRequest=FaucetScope&{kind:'claim';asset:FaucetAsset;queryId:string;bodyBoc:string;bodyHash:string;valueNano:string;amountRaw:string;createdAt:number;validUntil:number};
export type FaucetAttempt={request:FaucetRequest;ticket:WalletRequestTicket|null;answer:WalletRequestAnswer|null;walletClosed:boolean;
  state:'requesting'|'pending'|'not-sent'|'delivered'|'restored'|'recovered';dispatch:FaucetEvidenceRequest['dispatch']|null;delivery:FaucetDelivery|FaucetRestored|null;recovery:{phase:'retry-ready'|'superseded';sourceLt:string;sourceHash:string;root:string;blockRootHash:string;seqno:number}|null};
export type FaucetJournal={version:1;scope:FaucetScope;attempts:FaucetAttempt[]};
export type FaucetStorage=Pick<Storage,'getItem'|'setItem'>;
export type FaucetLock=<T>(key:string,run:()=>Promise<T>)=>Promise<T>;
const fail=(message:string)=>new AppError('wallet.faucet.error.saved',{}, {devMessage:message});
const clone=<T>(v:T):T=>structuredClone(v);
const exact=(v:unknown,keys:string[]):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const hash=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const uint=(v:unknown,bits=120):v is string=>typeof v==='string'&&/^(0|[1-9]\d{0,36})$/.test(v)&&BigInt(v)<1n<<BigInt(bits);
const address=(v:unknown):v is string=>{try{const a=Address.parse(v as string);return a.workChain===0&&a.toRawString()===v;}catch{return false;}};
const scopeKeys=['network','releaseId','manifestHash','owner','faucet'];
export const faucetScopeOf=(r:FaucetScope):FaucetScope=>Object.fromEntries(scopeKeys.map(k=>[k,r[k as keyof FaucetScope]])) as FaucetScope;
const sameScope=(a:FaucetScope,b:FaucetScope)=>JSON.stringify(faucetScopeOf(a))===JSON.stringify(faucetScopeOf(b));
export function validFaucetScope(v:unknown):v is FaucetScope{return exact(v,scopeKeys)&&['testnet','localnet'].includes(v.network)&&typeof v.releaseId==='string'&&v.releaseId.length>0&&hash(v.manifestHash)&&address(v.owner)&&address(v.faucet);}
export function validFaucetRequest(v:unknown):v is FaucetRequest{
 try{if(!exact(v,[...scopeKeys,'kind','asset','queryId','bodyBoc','bodyHash','valueNano','amountRaw','createdAt','validUntil'])||!validFaucetScope(faucetScopeOf(v as FaucetRequest))
    ||v.kind!=='claim'||![0,1,2].includes(v.asset)||!uint(v.queryId,64)||!uint(v.valueNano)||v.valueNano==='0'||!uint(v.amountRaw)||v.amountRaw==='0'
    ||!hash(v.bodyHash)||typeof v.bodyBoc!=='string'||v.bodyBoc.length>1000||!Number.isSafeInteger(v.createdAt)||v.createdAt<=0||!Number.isSafeInteger(v.validUntil)||v.validUntil<=0||v.validUntil>0xffffffff)return false;
  const body=faucetClaimBody(v.asset,BigInt(v.queryId));return body.hash().toString('hex')===v.bodyHash&&body.equals(Cell.fromBase64(v.bodyBoc));
 }catch{return false;}
}
export function faucetTicketMatches(r:FaucetRequest,t:WalletRequestTicket){return isWalletRequestTicket(t)&&t.network===r.network&&t.owner===r.owner&&t.validUntil===r.validUntil&&t.messages.length===1
  &&t.messages[0].destination===r.faucet&&t.messages[0].amount===r.valueNano&&t.messages[0].bodyHash===r.bodyHash&&!t.messages[0].init;}
export function validFaucetJournal(v:unknown):v is FaucetJournal{
 if(!exact(v,['version','scope','attempts'])||v.version!==1||!validFaucetScope(v.scope)||!Array.isArray(v.attempts))return false;
 const queries=new Set<string>();return v.attempts.every(a=>{
  if(!exact(a,['request','ticket','answer','walletClosed','state','dispatch','delivery','recovery'])||!validFaucetRequest(a.request)||!sameScope(a.request,v.scope)||queries.has(a.request.queryId)
    ||!['requesting','pending','not-sent','delivered','restored','recovered'].includes(a.state)||typeof a.walletClosed!=='boolean'||a.ticket!==null&&!faucetTicketMatches(a.request,a.ticket)
    ||a.answer!==null&&(!a.ticket||!isWalletRequestAnswer(a.answer))||['not-sent','delivered','restored','recovered'].includes(a.state)&&!a.walletClosed)return false;
  if(a.dispatch!==null&&(!a.ticket||!a.walletClosed||!exact(a.dispatch,['lt','hash','valueNano'])||!uint(a.dispatch.lt,64)||a.dispatch.lt==='0'||!hash(a.dispatch.hash)||!uint(a.dispatch.valueNano)))return false;
  if(a.delivery!==null&&(!exact(a.delivery,['status','transactionHash','faucetTransactionHash','sourceTransactionHash','amountRaw','wire'])||!['delivered','restored'].includes(a.delivery.status)
    ||!hash(a.delivery.transactionHash)||!hash(a.delivery.faucetTransactionHash)||!hash(a.delivery.sourceTransactionHash)||a.delivery.amountRaw!==a.request.amountRaw||!uint(a.delivery.wire,64)||a.delivery.wire==='0'||!a.dispatch||a.state!==a.delivery.status))return false;
  if(['delivered','restored'].includes(a.state)&&!a.delivery)return false;
  if(a.recovery!==null&&(!exact(a.recovery,['phase','sourceLt','sourceHash','root','blockRootHash','seqno'])||!['retry-ready','superseded'].includes(a.recovery.phase)||!uint(a.recovery.sourceLt,64)||a.recovery.sourceLt==='0'||!hash(a.recovery.sourceHash)||!hash(a.recovery.root)||!hash(a.recovery.blockRootHash)||!Number.isSafeInteger(a.recovery.seqno)||a.recovery.seqno<=0||a.state!=='recovered'||!a.dispatch||a.delivery))return false;
  if(a.state==='recovered'&&!a.recovery)return false;queries.add(a.request.queryId);return true;
 });
}
export function faucetJournalKey(scope:FaucetScope){if(!validFaucetScope(scope))throw fail('Invalid faucet scope');return `tonswap:faucet:current-v1:${scope.network}:${scope.manifestHash}:${scope.owner}:${scope.faucet}`;}
export function faucetBrowserStorage():FaucetStorage{try{if(globalThis.localStorage)return globalThis.localStorage;}catch{}throw fail('Faucet durable storage unavailable');}
export const faucetBrowserLock:FaucetLock=async(key,run)=>{if(typeof navigator==='undefined'||!navigator.locks?.request)throw fail('Faucet Web Locks unavailable');return navigator.locks.request(key,{mode:'exclusive',ifAvailable:true},held=>{if(!held)throw fail('Faucet request open in another tab');return run();});};
export function readFaucetJournal(scope:FaucetScope,target:FaucetStorage=faucetBrowserStorage()):FaucetJournal{
 try{const bytes=target.getItem(faucetJournalKey(scope));if(bytes===null)return{version:1,scope:clone(scope),attempts:[]};const j=JSON.parse(bytes);if(!validFaucetJournal(j)||!sameScope(j.scope,scope))throw fail('Invalid faucet journal retained');return clone(j);}catch{throw fail('Unreadable faucet journal retained');}
}
export function saveFaucetJournal(j:FaucetJournal,target:FaucetStorage=faucetBrowserStorage()){
 if(!validFaucetJournal(j))throw fail('Invalid faucet journal');const key=faucetJournalKey(j.scope),bytes=JSON.stringify(j);target.setItem(key,bytes);if(target.getItem(key)!==bytes)throw fail('Faucet journal was not durably saved');
}
export const faucetAttemptOpen=(a:FaucetAttempt)=>!['not-sent','delivered','restored','recovered'].includes(a.state);
export function faucetTransaction(r:FaucetRequest):SendTransactionRequest{
 if(!validFaucetRequest(r))throw fail('Invalid faucet request');return{from:r.owner,network:CHAIN.TESTNET,validUntil:r.validUntil,messages:[{address:r.faucet,amount:r.valueNano,payload:r.bodyBoc}]};
}
export async function sendFaucetRequest(input:{request:FaucetRequest;action:ReviewWalletAction;send:SendWalletTransaction;current:()=>boolean;revalidate:()=>Promise<void>;storage?:FaucetStorage;lock?:FaucetLock}):Promise<FaucetAttempt>{
 const target=input.storage??faucetBrowserStorage(),lock=input.lock??faucetBrowserLock,r=clone(input.request),scope=faucetScopeOf(r);
 return lock(faucetJournalKey(scope),async()=>{
  const recovery=await import('./faucetRecoveryStore');if(recovery.readFaucetRecoveryJournal(scope,target).attempts.some(recovery.faucetRecoveryOpen))throw fail('Faucet recovery unresolved');
  const proof=await import('./faucetProofStore');if(proof.faucetProofPending(scope,target))throw fail('Faucet proof unresolved');
  const j=readFaucetJournal(scope,target);if(j.attempts.some(a=>a.request.queryId===r.queryId||faucetAttemptOpen(a)&&(a.request.asset===r.asset||!a.walletClosed)))throw fail('Original faucet request unresolved');
  if(!input.current())throw fail('Faucet context changed');const a:FaucetAttempt={request:r,ticket:null,answer:null,walletClosed:false,state:'requesting',dispatch:null,delivery:null,recovery:null};j.attempts.push(a);saveFaucetJournal(j,target);
  let expected=JSON.stringify(j);const unchanged=()=>{if(!input.current()||JSON.stringify(readFaucetJournal(scope,target))!==expected)throw new WalletRequestNotSentError('Faucet request/context changed');};
  const persist=()=>{saveFaucetJournal(j,target);expected=JSON.stringify(j);};
  try{const tx=faucetTransaction(r),answer=await input.send(tx,input.action,{verify:t=>{unchanged();if(!sameWalletTransaction(t,tx))throw new WalletRequestNotSentError('Faucet transaction differs');},beforeDispatch:async ticket=>{
    unchanged();await input.revalidate();unchanged();if(a.ticket||!faucetTicketMatches(r,ticket))throw new WalletRequestNotSentError('Faucet ticket differs');a.ticket=clone(ticket);a.state='pending';persist();
  }});
  // A late wallet answer belongs to the original owner even if the visible wallet changed.
  if(JSON.stringify(readFaucetJournal(scope,target))!==expected)throw fail('Faucet journal changed before wallet answer');
  if(answer===null&&!a.ticket){a.state='not-sent';a.walletClosed=true;persist();}
  else if(answer!==null){if(!a.ticket)throw fail('Faucet wallet answer has no saved ticket');a.answer=walletAnswer(a.ticket,answer)??a.answer;a.state='pending';persist();}
  return clone(a);
  }catch(error){if(!a.ticket&&isWalletRequestNotSentError(error)&&JSON.stringify(readFaucetJournal(scope,target))===expected){a.state='not-sent';a.walletClosed=true;persist();}throw error;}
 });
}
export function faucetEvidenceRequest(a:FaucetAttempt):FaucetEvidenceRequest|null{
 if(!a.dispatch)return null;const {amountRaw:_amount,validUntil:_until,...request}=a.request;return{...request,dispatch:a.dispatch};
}
export async function reconcileFaucetAttempt(scope:FaucetScope,queryId:string,input:{storage?:FaucetStorage;lock?:FaucetLock;chain?:WalletRequestChain;signal?:AbortSignal;current?:()=>boolean;readEvidence?:(p:FaucetEvidenceRequest)=>Promise<FaucetEvidence>;readRecovery?:(p:FaucetEvidenceRequest)=>Promise<FaucetRecoveryState>}={}):Promise<FaucetAttempt|null>{
 const target=input.storage??faucetBrowserStorage(),lock=input.lock??faucetBrowserLock,j=readFaucetJournal(scope,target),original=j.attempts.find(a=>a.request.queryId===queryId);
 if(!original||!faucetAttemptOpen(original))return original??null;
 const a=clone(original),ticket=a.ticket,shared=()=>ticket?JSON.stringify(readWalletRequestRecord(ticket.network,ticket.owner,target)):null,before=shared();
 if(ticket){const options={storage:target,answer:a.answer,chain:input.chain,signal:input.signal},outcome=await resolveWalletRequest(ticket,options);
   if(walletMessageExpired(outcome,0)){a.walletClosed=true;a.state='not-sent';}
   else if(outcome.status==='observed'&&outcome.final){a.walletClosed=true;const hop=await readFirstHop(ticket,0,options);
    if(hop.status==='rejected')a.state='not-sent';
    else if(hop.status==='executed'){const cursor=outcome.transaction,rows=await(input.chain??walletRequestChain).readTransactions(a.request.owner,cursor,1,input.signal);
     const tx=decodeLinkedPage(a.request.owner,rows,cursor)[0];if(!tx)throw fail('Original owner transaction unavailable');
     const outgoing=tx.outMessages.values().filter(m=>m.info.type==='internal'&&!m.info.bounced&&m.info.dest.toRawString()===a.request.faucet&&m.body.hash().toString('hex')===a.request.bodyHash);
     if(outgoing.length===1&&outgoing[0].info.type==='internal')a.dispatch={lt:outcome.transaction.lt,hash:outcome.transaction.hash,valueNano:outgoing[0].info.value.coins.toString()};
    }
   }
 }
 const request=faucetEvidenceRequest(a);if(a.state!=='not-sent'&&request&&input.readEvidence){const evidence=await input.readEvidence(request);if(evidence.status==='delivered'||evidence.status==='restored'){
   if(evidence.amountRaw!==a.request.amountRaw)throw fail('Faucet settled amount differs');a.delivery=evidence;a.state=evidence.status;
 }}
 if(a.state==='pending'&&request&&a.walletClosed&&input.readRecovery){const recovered=await input.readRecovery(request);
  if((recovered.status==='retry-ready'||recovered.status==='superseded')&&JSON.stringify(recovered.request)===JSON.stringify(request)&&recovered.amountRaw===a.request.amountRaw){
   a.state='recovered';a.recovery={phase:recovered.status,sourceLt:recovered.sourceFailure.sourceLt,sourceHash:recovered.sourceFailure.sourceHash,root:recovered.root,seqno:recovered.head.seqno,blockRootHash:recovered.head.rootHashHex};
  }
 }
 return lock(faucetJournalKey(scope),async()=>{const publish=async()=>{input.signal?.throwIfAborted();const next=readFaucetJournal(scope,target),latest=next.attempts.find(v=>v.request.queryId===queryId);
   if(input.current&&!input.current()||!latest||JSON.stringify(latest)!==JSON.stringify(original)||before!==shared())return latest??null;
   // Acquiring the operation lock proves no review still owns this ticketless
   // attempt. A dispatch could not occur without the durable ticket.
   if(!ticket){a.walletClosed=true;a.state='not-sent';}
   next.attempts[next.attempts.indexOf(latest)]=a;saveFaucetJournal(next,target);return clone(a);};return ticket?lock(walletRequestRecordKey(ticket.network,ticket.owner),publish):publish();});
}
