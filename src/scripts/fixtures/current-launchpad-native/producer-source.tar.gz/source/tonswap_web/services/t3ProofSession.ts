import { Address, beginCell, Cell, contractAddress, Dictionary, loadMessage, loadShardAccount, loadShardIdent, type StateInit } from '@ton/core';
import { Buffer } from 'buffer';
import artifact from './artifacts/t3RecoveryProof.json';
import type { FaucetEvidenceBinding, FaucetEvidenceRequest } from './faucetEvidence';
import { decodeFaucetRecovery, type FaucetRecoveryReady } from './faucetRecovery';
import { validFaucetEvidenceRequest } from './faucetRecoveryStore';
import { indexerRequest } from './indexer';
import { currentT3ActiveState, currentT3Cell } from './t3CurrentEvidence';
import { buildT3ProofStep, t3ProofConfigToCell, t3ProofData, type T3ProofConfig } from './t3Contracts';
import { validateRecoveryProofAnchor, validateRecoveryProofHistory, recoveryAccountPath, recoveryTransactionChunk, type ProofHead, type RecoveryProofAnchor, type RecoveryProofHistory } from './t3ProofBundle';
import { FreshStack, type FreshChainRead } from './spotContracts';
import { readJettonQuotePrices } from './jettonConfigPrices';
import { jettonGasValue, jettonForwardValue, jettonRentValue, payloadGeometry } from './jettonWalletProfile';
import type { ChainHead } from './toncenter';

export type T3ProofStage = { phase:number; messageHash:string; cursor:{hash:string;key:string;bits:number;lt:string}; evidence:number };
export type T3ProofSessionRecord = {version:1;original:FaucetEvidenceRequest;nonce:string;anchor:ProofHead;configBoc:string;address:string};
export type T3ProofSnapshot = {head:ChainHead;deployed:boolean;stage:T3ProofStage};
export type T3ProofStepPlan = {address:Address;body:Cell;value:bigint;bounce:boolean;init?:StateInit;head:ChainHead;step:number;expectedStage:T3ProofStage;nextStage:T3ProofStage};
export type FaucetProofStepResult = {status:'ready';session:T3ProofSessionRecord;plan:T3ProofStepPlan}|{status:'recovered';recovery:FaucetRecoveryReady}|{status:'unavailable'};
function check(ok:unknown):asserts ok {if(!ok)throw Error('Unverified current recovery proof session');}
const exact=(v:unknown,keys:string[]):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const canonical=(v:unknown):unknown=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b)).map(([k,n])=>[k,canonical(n)])):v;
const same=(a:unknown,b:unknown)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
const digest=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const toDecimal=(v:bigint)=>v.toString();
const cursor=(s:T3ProofStage)=>({hash:BigInt(s.cursor.hash),key:BigInt(s.cursor.key),bits:s.cursor.bits,lt:BigInt(s.cursor.lt)});
const storedCursor=(c:ReturnType<typeof cursor>)=>({hash:toDecimal(c.hash),key:toDecimal(c.key),bits:c.bits,lt:toDecimal(c.lt)});
function code(binding:FaucetEvidenceBinding){const c=Cell.fromBase64(artifact.codeBoc);check(c.hash().toString('hex')===artifact.codeHash&&artifact.codeHash===binding.release.templates.T3RecoveryProof);return c;}
export function readT3ProofStage(data:Cell,config:Cell):T3ProofStage{
 const s=data.beginParse();check(s.loadRef().equals(config));const phase=s.loadUint(3),messageHash=s.loadUintBig(256).toString(),c=s.loadRef().beginParse();
 const value={hash:c.loadUintBig(256).toString(),key:c.loadUintBig(256).toString(),bits:c.loadUint(9),lt:c.loadUintBig(64).toString()};c.endParse();const evidence=s.loadUint(2);s.endParse();check(value.bits<=256&&evidence<=2);return{phase,messageHash,cursor:value,evidence};
}
export function validateT3ProofSessionRecord(v:unknown,binding:FaucetEvidenceBinding):v is T3ProofSessionRecord{
 try{if(!exact(v,['version','original','nonce','anchor','configBoc','address'])||v.version!==1||!validFaucetEvidenceRequest(v.original)||!digest(v.nonce)
  ||v.original.releaseId!==binding.release.releaseId||v.original.manifestHash!==binding.release.manifestHash||v.original.faucet!==binding.pins.address.toRawString()
  ||!exact(v.anchor,['seqno','workchain','shard','rootHashHex','fileHashHex','utime'])||v.anchor.workchain!==-1||v.anchor.shard!=='-9223372036854775808'
  ||![v.anchor.seqno,v.anchor.utime].every(n=>Number.isSafeInteger(n)&&n>0&&n<=0xffffffff)||!digest(v.anchor.rootHashHex)||!digest(v.anchor.fileHashHex))return false;
  const cfg=currentT3Cell(v.configBoc),s=cfg.beginParse();if(s.loadBuffer(32).toString('hex')!==v.nonce)return false;
  const credit=s.loadRef().beginParse(),targets=s.loadRef().beginParse();s.endParse();
  const ids=credit.loadRef().beginParse();if(!ids.loadAddress().equals(binding.pins.address)||!ids.loadAddress().equals(binding.pins.address)||!ids.loadAddress().equals(binding.pins.tokens[0].master))return false;ids.endParse();
  if(credit.loadUintBig(256)===0n||!credit.loadRef().equals(Cell.EMPTY))return false;
  const wallets=credit.loadRef().beginParse(),source=wallets.loadAddress(),target=wallets.loadAddress();wallets.loadUintBig(64);if(source.workChain!==0||(!target.equals(source)&&!target.equals(binding.pins.address))||wallets.loadCoins()===0n)return false;wallets.endParse();
  if(credit.loadBuffer(32).toString('hex')!==binding.pins.tokens[0].walletCodeHash)return false;credit.endParse();
  const from=targets.loadRef(),to=targets.loadRef();targets.endParse();
  const point=(c:Cell)=>{const p=c.beginParse();check(p.loadUintBig(256)>0n);const lt=p.loadUintBig(64);check(lt>0n&&p.loadBuffer(32).toString('hex')===v.anchor.rootHashHex);p.endParse();return lt;};
  const fromLt=point(from),toLt=point(to);if(target.equals(source)?!from.equals(to):toLt<=fromLt)return false;
  return contractAddress(0,{code:code(binding),data:t3ProofData(cfg)}).toRawString()===v.address;
 }catch{return false;}
}
/** The journal retains attempts; current pinned storage determines progress. */
export async function readT3ProofSession(record:T3ProofSessionRecord,binding:FaucetEvidenceBinding,read:FreshChainRead):Promise<T3ProofSnapshot>{
 check(validateT3ProofSessionRecord(record,binding));const r=await read([{kind:'account',address:record.address}],{anchored:true,lane:'user'}),a=r.results[0],h=r.head;
 check(h&&Number.isSafeInteger(h.seqno)&&h.seqno>=record.anchor.seqno&&digest(h.rootHashHex)&&h.utime&&r.results.length===1&&a?.kind==='account');
 if(a.state==='uninitialized'){check(!a.code&&!a.data);return{head:h,deployed:false,stage:readT3ProofStage(t3ProofData(currentT3Cell(record.configBoc)),currentT3Cell(record.configBoc))};}
 check(a.state==='active'&&a.code&&a.data&&a.code.hash().toString('hex')===artifact.codeHash);
 return{head:h,deployed:true,stage:readT3ProofStage(a.data,currentT3Cell(record.configBoc))};
}
/** A repeated phase is not progress: chunk acknowledgement includes the exact
 * native hash/key/bits/LT cursor. Certificate sends leave verifier state intact. */
export function isT3ProofStepApplied(plan:Pick<T3ProofStepPlan,'step'|'nextStage'>,current:T3ProofSnapshot):boolean{
 return plan.step!==30&&current.deployed&&same(plan.nextStage,current.stage);
}
function anchorParts(body:Cell){
 const s=body.beginParse();check(s.loadUint(32)===0x54335046);const step=s.loadUint(8);check([10,15,20,25].includes(step));
 if(step===15||step===25)s.loadUint(32);const proof=s.loadRef(),history=step===15||step===25?s.loadRef():null;s.endParse();
 const envelope=history??proof;check(envelope.type===3&&envelope.refs.length===1);const block=envelope.refs[0].beginParse().loadRef(),b=block.beginParse();
 check(b.loadUint(32)===0x11ef55aa);b.loadInt(32);const h=b.loadRef().beginParse();check(h.loadUint(32)===0x9bc7a987);h.skip(32+8+8);const seqno=h.loadUint(32);h.loadUint(32);
 const shard=loadShardIdent(h);check(shard.workchainId===-1&&shard.shardPrefixBits===0&&shard.shardPrefix===0n);const utime=h.loadUint(32);
 return{proof,seqno,utime};
}
/** Refresh authority/cursor/funding without needlessly replacing a reviewed
 * historical proof every block. Only its already verified recent anchor body
 * may remain stable; certificates always require the exact fresh witness. */
export async function revalidateFaucetProofStep(original:FaucetEvidenceRequest,binding:FaucetEvidenceBinding,read:FreshChainRead,session:T3ProofSessionRecord,plan:T3ProofStepPlan,signal?:AbortSignal):Promise<void>{
 const next=await prepareFaucetProofStep(original,binding,read,session,signal);check(next.status==='ready'&&same(next.session,session));
 const p=next.plan;check(p.address.equals(plan.address)&&p.value<=plan.value&&p.bounce===plan.bounce&&!!p.init===!!plan.init&&same(p.expectedStage,plan.expectedStage)&&same(p.nextStage,plan.nextStage));
 if(p.step===plan.step&&p.body.equals(plan.body)){
  if([10,15,20,25].includes(plan.step)){const old=anchorParts(plan.body);check(p.head.seqno>=old.seqno&&p.head.seqno-old.seqno<=8);}
  return;
 }
 check(([10,15].includes(p.step)&&[10,15].includes(plan.step))||([20,25].includes(p.step)&&[20,25].includes(plan.step)));
 const old=anchorParts(plan.body),fresh=anchorParts(p.body);check(old.proof.equals(fresh.proof)&&p.head.seqno>=old.seqno&&p.head.seqno-old.seqno<=8&&old.utime<=p.head.utime!);
}
function configOf(state:FaucetRecoveryReady,binding:FaucetEvidenceBinding,nonce:string,anchor:ProofHead):T3ProofConfig{
 const f=state.sourceFailure,point=(hash:string,lt:string)=>({hash:BigInt('0x'+hash),lt:BigInt(lt),anchor:BigInt('0x'+anchor.rootHashHex)});
 return{nonce:BigInt('0x'+nonce),controller:binding.pins.address,hub:binding.pins.address,master:binding.pins.tokens[0].master,
  request:currentT3Cell(f.commandBoc),sourceWallet:Address.parse(state.sourceWallet),targetWallet:Address.parse(f.targetWallet),queryId:BigInt(f.wire),amount:BigInt(f.amountRaw),
  walletCodeHash:BigInt('0x'+binding.pins.tokens[0].walletCodeHash),source:point(f.sourceHash,f.sourceLt),target:point(f.targetHash,f.targetLt)};
}
function rawMessages(tx:Cell){const s=tx.beginParse();s.skip(4+256+64+256+64+32+15+4);const m=s.loadRef().beginParse(),incoming=m.loadMaybeRef(),out=m.loadDict(Dictionary.Keys.Uint(15),Dictionary.Values.Cell());m.endParse();return{incoming,out};}
function moneyHead(h:ChainHead,minimum:ChainHead){check(h.seqno>=minimum.seqno&&(h.seqno!==minimum.seqno||h.rootHashHex===minimum.rootHashHex)&&h.utime);return h;}

export async function prepareFaucetProofStep(original:FaucetEvidenceRequest,binding:FaucetEvidenceBinding,read:FreshChainRead,session?:T3ProofSessionRecord,signal?:AbortSignal):Promise<FaucetProofStepResult>{
 try{
  const originalIdentity=JSON.stringify(original),savedSession=session&&JSON.stringify(session);
  signal?.throwIfAborted();check(validFaucetEvidenceRequest(original));if(session)check(validateT3ProofSessionRecord(session,binding)&&same(original,session.original));
  const proofCode=code(binding),nonce=session?.nonce??Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('hex');
  const value=await indexerRequest<unknown>('/v1/t3/faucet-proof-session',{method:'POST',body:{original,nonce,anchor:session?.anchor??null,proofCodeBoc:artifact.codeBoc},signal,timeoutMs:20_000,maxAttempts:1,health:'chain',cache:'no-store'});
  signal?.throwIfAborted();check(Buffer.byteLength(JSON.stringify(value))<=8*1024*1024&&exact(value,['schema','releaseId','manifestHash','asOf','recovery','anchor','address','configBoc','source','target','history','sessionShardAccountBoc','transactionBocs'])
   &&exact(value.asOf,['seqno','workchain','shard','rootHashHex','fileHashHex','utime'])&&value.asOf.workchain===-1&&value.asOf.shard==='-9223372036854775808'&&[value.asOf.seqno,value.asOf.utime].every(n=>Number.isSafeInteger(n)&&n>0&&n<=0xffffffff)&&digest(value.asOf.rootHashHex)&&digest(value.asOf.fileHashHex)
   &&value.schema==='tonswap-faucet-proof-session-v1'&&value.releaseId===original.releaseId&&value.manifestHash===original.manifestHash);
  const recovery=decodeFaucetRecovery(value.recovery,original,binding);check(recovery.status!=='unavailable');
  if(recovery.status!=='certificate-required')return{status:'recovered',recovery};
  const anchor=value.anchor as ProofHead,cfg=t3ProofConfigToCell(configOf(recovery,binding,nonce,anchor)),record:T3ProofSessionRecord={version:1,original:structuredClone(original),nonce,anchor:structuredClone(anchor),configBoc:cfg.toBoc().toString('base64'),address:contractAddress(0,{code:proofCode,data:t3ProofData(cfg)}).toRawString()};
  check(validateT3ProofSessionRecord(record,binding)&&currentT3Cell(value.configBoc).equals(cfg)&&value.address===record.address&&(!session||same(session,record)));
  const source=value.source as RecoveryProofAnchor,target=value.target as RecoveryProofAnchor|null;
  check(source.account===recovery.sourceWallet&&same(source.head,anchor));validateRecoveryProofAnchor(source);
  const current=await readT3ProofSession(record,binding,read);moneyHead(value.asOf as ProofHead,recovery.head);moneyHead(current.head,value.asOf as ProofHead);
  if(value.sessionShardAccountBoc!==null){const shard=loadShardAccount(currentT3Cell(value.sessionShardAccountBoc).beginParse());check(shard.account?.addr.toRawString()===record.address);
   if(current.deployed)check(same(readT3ProofStage(currentT3ActiveState(shard,artifact.codeHash).data,cfg),current.stage));else check(shard.account?.storage.state.type==='uninit');}
  else check(!current.deployed);
  const stage=current.stage,next=structuredClone(stage),isTarget=stage.phase>=3&&stage.phase<=5,f=recovery.sourceFailure;
  if(isTarget){check(target&&target.account===f.targetWallet&&same(target.head,anchor));validateRecoveryProofAnchor(target!);}else check(target===null);
  const branch=target??source,point={lt:BigInt(isTarget?f.targetLt:f.sourceLt),hash:BigInt('0x'+(isTarget?f.targetHash:f.sourceHash))};
  let step:number,fields:Parameters<typeof buildT3ProofStep>[1]={},receiverValue=0n,certificate:Cell|null=null;
  if(stage.phase===0||stage.phase===3){const a=validateRecoveryProofAnchor(branch);step=isTarget?20:10;fields.proof=a.bundle;
   if(value.history!==null){const hist=value.history as RecoveryProofHistory;check(same(hist.anchor,anchor)&&hist.head.seqno<=current.head.seqno);fields.history=validateRecoveryProofHistory(hist);fields.seqno=anchor.seqno;step+=5;}
   next.phase=stage.phase+1;next.cursor={hash:BigInt('0x'+a.root.hash(0).toString('hex')).toString(),key:a.key.toString(),bits:256,lt:'0'};
  }else if(stage.phase===1||stage.phase===4){const a=recoveryAccountPath(branch,cursor(stage));step=isTarget?21:11;fields.proof=a.proof;next.cursor=storedCursor(a.next);if(a.done)next.phase++;}
  else if(stage.phase===2||stage.phase===5){check(Array.isArray(value.transactionBocs)&&value.transactionBocs.length<=4);const a=recoveryTransactionChunk(branch.account,value.transactionBocs,cursor(stage),point);fields.proof=a.proof;
   if(!a.done){step=isTarget?22:12;next.cursor=storedCursor(a.next);}
   else if(isTarget){step=24;next.phase=7;next.cursor.bits=1;}
   else{const messages=rawMessages(currentT3Cell(value.transactionBocs.at(-1)));check(messages.incoming);
    if(f.targetWallet===recovery.sourceWallet){step=14;next.phase=7;next.messageHash=BigInt('0x'+messages.incoming!.hash(0).toString('hex')).toString();next.cursor.bits=0;}
    else{step=17;const outgoing=messages.out.values().filter(c=>{const m=loadMessage(c.beginParse());return m.info.type==='internal'&&m.info.bounced&&m.info.dest.toRawString()===f.targetWallet;});check(outgoing.length===1);next.phase=3;next.evidence=2;next.messageHash=BigInt('0x'+outgoing[0].hash(0).toString('hex')).toString();}
   }
  }else{check(stage.phase===7);step=30;
   const sourceShard=loadShardAccount(currentT3Cell(value.recovery.sourceWallet.shardAccountBoc).beginParse()),walletCode=currentT3ActiveState(sourceShard,binding.pins.tokens[0].walletCodeHash).code;
   const receiver=beginCell().storeRef(currentT3Cell(f.commandBoc)).storeRef(walletCode).storeRef(currentT3Cell(recovery.proofBoc)).endCell();
   certificate=beginCell().storeUint(0x54334643,32).storeRef(cfg).storeRef(receiver).storeRef(proofCode).endCell();
   const r=await read([{kind:'getter',address:original.faucet,method:'get_min_recovery',args:[{type:'cell',cell:certificate}]}],{anchored:true,lane:'user'});moneyHead(r.head!,current.head);
   const result=r.results[0];check(result?.kind==='getter'&&result.exitCode===0);const s=new FreshStack(result.stack);receiverValue=s.uint();s.end();check(receiverValue>0n);fields={receiver,value:receiverValue};
   current.head=r.head!;
  }
  const body=buildT3ProofStep(step!,fields),{prices}=await readJettonQuotePrices(current.head,signal),floor=jettonGasValue(prices,250000);
  // Fund retained verifier state explicitly. This reserve is never a token claim.
  const init={code:proofCode,data:t3ProofData(cfg)},geometry=payloadGeometry(beginCell().storeRef(proofCode).storeRef(init.data).endCell());
  let attachment=floor+jettonRentValue(prices,7*24*60*60,geometry.bits,geometry.cells);
  if(certificate){const g=payloadGeometry(certificate);attachment+=receiverValue+jettonForwardValue(prices,g.bits+1024,g.cells+1);}
  signal?.throwIfAborted();check(JSON.stringify(original)===originalIdentity&&(!session||JSON.stringify(session)===savedSession&&same(session,record)));
  return{status:'ready',session:record,plan:{address:Address.parse(record.address),body,value:attachment,bounce:current.deployed,...(!current.deployed?{init}:{}),head:current.head,step:step!,expectedStage:stage,nextStage:next}};
 }catch(e){if(signal?.aborted)throw signal.reason;return{status:'unavailable'};}
}
