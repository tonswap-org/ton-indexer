import { Address, beginCell, Cell, Dictionary, type DictionaryValue } from '@ton/core';
import { sha256_sync } from '@ton/crypto';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { readChain, type ChainCall, type ReadChainOptions } from './toncenter';
import { decodeFreshPoolId, freshAddressArg, freshInt, FreshStack, type FreshChainRead } from './spotContracts';
import { readSpotPool, spotGetter, spotPoolIdentity, type SpotPoolIdentity } from './spotPoolRead';
import { readSpotWallets, verifySpotPoolInputWallet, verifySpotSlots, verifySpotWallet, verifySpotWalletPlan } from './spotPoolWallets';
import { jettonRentValue, jettonTransferBody, quoteJettonTransfer, standardJettonWalletProfile, jettonWalletBudgetToCell } from './jettonWalletProfile';
import { readJettonQuotePrices } from './jettonConfigPrices';
import { t3WalletAttemptToCell } from './t3Contracts';
import {firstReleaseKusdError,isFirstReleaseKusdTradingPair} from './t3ReleasePolicy';
import { liquidityError } from './liquidityError';

export const POOL_OP={add:0x4c514133,remove:0x4c515233,outcome:0x4c514f33,event:0x4c514533,farmCreate:0x464d4333,farmAction:0x464d4133,farmEvent:0x464d4533,payout:0x50504f33,create:0x50435233} as const;
const fail=(detail:string)=>liquidityError('poolNotVerified',detail);
export type NativePoolBin={t:bigint;x:bigint;shares:bigint;pq:bigint};
export type NativePoolPosition={shares:bigint;farmId:bigint;accSnap:bigint;rewardCarry:bigint};
export type NativeFarm={id:bigint;end:number;lastTs:number;acc:bigint;weight:bigint;paid:bigint;binId:number;side:0|1;sponsor:string;total:bigint;start:number;duration:number};
export const poolBinValue:DictionaryValue<NativePoolBin>={serialize(){throw fail('Read-only bin codec');},parse(s){const r={t:s.loadCoins(),x:s.loadCoins(),shares:s.loadUintBig(256),pq:s.loadUintBig(128)};s.endParse();if(r.pq<1n<<32n)throw fail('Invalid bin price');return r;}};
export const poolPositionValue:DictionaryValue<NativePoolPosition>={serialize(){throw fail('Read-only position codec');},parse(s){const r={shares:s.loadUintBig(256),farmId:s.loadUintBig(64),accSnap:s.loadUintBig(256),rewardCarry:0n},carry=s.loadMaybeRef();s.endParse();if(carry){const p=carry.beginParse();r.rewardCarry=p.loadUintBig(128);p.endParse();}return r;}};
export function decodeNativeFarm(id:bigint,cell:Cell|null):NativeFarm|null{if(!cell)return null;const s=cell.beginParse(),r={id,end:s.loadUint(32),lastTs:s.loadUint(32),acc:s.loadUintBig(256),weight:s.loadUintBig(128),paid:s.loadCoins()},p=s.loadRef().beginParse();s.endParse();const terms={binId:p.loadInt(32),side:p.loadUint(8),sponsor:p.loadAddress().toRawString(),total:p.loadCoins(),start:p.loadUint(32),duration:p.loadUint(32)};p.endParse();if(terms.side>1||terms.duration<3600||terms.duration>7776000||r.end<terms.start||r.end>terms.start+terms.duration||r.paid>terms.total)throw fail('Invalid native farm terms');return{...r,...terms,side:terms.side as 0|1};}
const derivedPools=new Map<string,SpotPoolIdentity>();
const qualifiedTokens=new Map<string,SpotPoolIdentity['x']>();
export async function readPoolToken(root:string,read:FreshChainRead=readChain){
 const r=TONSWAP_RELEASE;if(!r)throw fail('Release unavailable');const canonical=Address.parse(root).toRawString(),known=r.tokens.find(t=>t.root===canonical);if(known)return known;
 const observed=await read([{kind:'account',address:canonical},{kind:'getter',address:canonical,method:'get_jetton_data'}],{anchored:true,lane:'user'}),account=observed.results[0],getter=observed.results[1];
 if(!observed.head?.seqno||!observed.head.utime||!observed.head.rootHashHex||account.kind!=='account'||account.state!=='active'||account.code?.hash().toString('hex')!==r.templates.JettonV21Minter||getter.kind!=='getter'||getter.exitCode!==0)throw fail('Project master is not current native V21');
 const data=new FreshStack(getter.stack);data.uint();data.bool();data.cell(true);const content=data.cell()!,wallet=data.cell()!;data.end();if(wallet.hash().toString('hex')!==r.templates.JettonV21Wallet)throw fail('Project wallet differs from current V21');
 const c=content.beginParse();if(c.loadUint(8)!==0)throw fail('Project decimals require on-chain metadata');const fields=c.loadDict(Dictionary.Keys.BigUint(256),Dictionary.Values.Cell());c.endParse();
 const field=(name:string)=>{const cell=fields.get(BigInt('0x'+sha256_sync(name).toString('hex')));if(!cell)return null;const p=cell.beginParse();if(p.loadUint(8)!==0)return null;const value=p.loadStringTail();return value.includes('\0')?null:value;},decimals=field('decimals');
 if(decimals===null||!/^(0|[1-9]\d?)$/.test(decimals)||Number(decimals)>18||TONSWAP_RELEASE!==r)throw fail('Project decimals are unavailable');
 const value={symbol:field('symbol')??canonical,root:canonical,decimals:Number(decimals),masterCodeHash:account.code!.hash().toString('hex'),walletCodeHash:wallet.hash().toString('hex')} as SpotPoolIdentity['x'];qualifiedTokens.set(`${r.manifestHash}:${canonical}`,value);return value;
}
export function nativePoolIdentity(pool:string){const r=TONSWAP_RELEASE,m=r?.spotMarkets.find(v=>Address.parse(v.pool).toRawString()===Address.parse(pool).toRawString()),t=r?.tokens.find(v=>v.symbol==='T3'),x=r?.tokens.find(v=>v.symbol===m?.symbol);if(r&&m&&t&&x)return spotPoolIdentity(pool,t.root,x.root);const derived=derivedPools.get(`${r?.manifestHash}:${pool}`);if(derived&&derived.release===r)return derived;throw fail('Pool is not bound to the current release');}
export function publicPoolId(root:string){const release=TONSWAP_RELEASE;if(isFirstReleaseKusdTradingPair(root,release?.contracts.T3Hub.address,release?.contracts.KUSD.address))throw firstReleaseKusdError();const token=release?.tokens.find(t=>t.root===Address.parse(root).toRawString())??qualifiedTokens.get(`${release?.manifestHash}:${Address.parse(root).toRawString()}`),profile=standardJettonWalletProfile(30000);if(!token||token.symbol==='T3'||token.root===release?.contracts.DlmmPoolFactory?.address)throw fail('Token is not approved by the current release');return{token,cell:beginCell().storeAddress(Address.parse(token.root)).storeUint(2500,16).storeUint(3000,32).storeUint(token.decimals,8).storeUint(30000,32).storeCoins(0).storeRef(jettonWalletBudgetToCell(profile.budget)).endCell(),profile};}
export async function readPublicPoolFactory(read:FreshChainRead=readChain){
 const r=TONSWAP_RELEASE,f=r?.contracts.DlmmPoolFactory;if(!r||!f)throw fail('Pool factory unavailable');
 const o=await read([{kind:'account',address:f.address},{kind:'getter',address:f.address,method:'get_factory_info'},{kind:'getter',address:f.address,method:'get_public_tier'},{kind:'getter',address:f.address,method:'get_create_min_value'}],{anchored:true,lane:'user'}),a=o.results[0];
 if(!o.head?.seqno||!o.head.rootHashHex||!o.head.utime||a.kind!=='account'||a.state!=='active'||a.code?.hash().toString('hex')!==f.codeHash)throw fail('Factory identity is unverified');
 const stack=(i:number)=>{const v=o.results[i];if(v.kind!=='getter'||v.exitCode!==0)throw fail('Factory getter unavailable');return new FreshStack(v.stack);},s=stack(1),governance=s.address()!,feeSink=s.address()!,treasury=s.address()!,t3=s.address()!,blockedCell=s.cell(true),blocked=blockedCell?blockedCell.beginParse().loadMaybeAddress():null;s.uint(32);s.uint(16);const code=s.cell()!;s.uint(32);s.uint();s.cell();s.end();
 if(governance.toRawString()!==r.contracts.Governance?.address||feeSink.toRawString()!==r.contracts.FeeRouter?.address||treasury.toRawString()!==r.contracts.Treasury?.address||t3.toRawString()!==r.contracts.T3Hub?.address||code.hash().toString('hex')!==r.templates.DlmmPool)throw fail('Factory peers differ from release');
 const tier=stack(2);if(tier.uint(16)!==2500n||tier.uint(32)!==3000n||tier.uint(32)!==30000n||tier.uint()!==0n)throw fail('Unsupported public pool tier');tier.end();const value=stack(3),minValue=value.uint();value.end();if(minValue<=0n)throw fail('Factory funding unavailable');return{release:r,factory:f.address,t3:t3.toRawString(),treasury:treasury.toRawString(),blocked:blocked?.toRawString()??null,minValue,head:o.head};
}
export async function readPublicPoolAddress(root:string,read:FreshChainRead=readChain){
 await readPoolToken(root,read);const f=await readPublicPoolFactory(read),id=publicPoolId(root);if(id.token.root===f.blocked)throw fail('Pool token is blocked');const o=await read([{kind:'account',address:f.factory},{kind:'getter',address:f.factory,method:'get_pool_address',args:[{type:'cell',cell:id.cell}]},{kind:'getter',address:f.factory,method:'get_create_min_value_for',args:[{type:'cell',cell:id.cell}]}],{anchored:true,notBefore:f.head.seqno,lane:'user'}),a=o.results[0],g=o.results[1],v=o.results[2];
 if(!o.head?.rootHashHex||a.kind!=='account'||a.code?.hash().toString('hex')!==f.release.contracts.DlmmPoolFactory.codeHash||g.kind!=='getter'||g.exitCode!==0||v.kind!=='getter'||v.exitCode!==0)throw fail('Canonical pool address unavailable');const s=new FreshStack(g.stack),address=s.address()!.toRawString();s.end();const q=new FreshStack(v.stack),value=q.uint();q.end();
 const market={pool:address,symbol:id.token.symbol,binSpacing:2500,feePips:3000,xDecimals:id.token.decimals,walletGasX:30000,walletGramX:'0',walletBudgetX:id.profile.budget},t3=f.release.tokens.find(t=>t.symbol==='T3')!;
 derivedPools.set(`${f.release.manifestHash}:${address}`,{release:f.release,market,t3,x:id.token,pool:address,inSide:0});return{...f,address,value,id:id.cell};
}
export async function resolveNativePoolIdentity(pool:string,read:FreshChainRead=readChain):Promise<SpotPoolIdentity>{
 try{return nativePoolIdentity(pool);}catch{}
 const r=TONSWAP_RELEASE,address=Address.parse(pool).toRawString();if(!r)throw fail('Release unavailable');
 const observed=await read([{kind:'account',address},{kind:'getter',address,method:'get_pool_info'}],{anchored:true,lane:'user'}),a=observed.results[0],g=observed.results[1];
 if(a.kind!=='account'||a.state!=='active'||a.code?.hash().toString('hex')!==r.templates.DlmmPool||g.kind!=='getter'||g.exitCode!==0)throw fail('Unknown pool identity');
 const s=new FreshStack(g.stack),id=decodeFreshPoolId(s.cell()!),canonical=await readPublicPoolAddress(id.xMaster.toRawString(),read);
 if(canonical.address!==address)throw fail('Pool is not the canonical current public pool');return nativePoolIdentity(address);
}
export const poolGetter=(pool:string,method:string,...args:bigint[]):ChainCall=>({kind:'getter',address:pool,method,args:args.map(freshInt)});
export async function readNativePool(pool:string,calls:readonly ChainCall[]=[],options:ReadChainOptions&{read?:FreshChainRead}={}){
 const {read=readChain,...opts}=options,identity=await resolveNativePoolIdentity(pool,read),state=await readSpotPool(read,identity,calls,opts),h=state.head;
 if(!/^[0-9a-f]{64}$/.test(h.rootHashHex??'')||!Number.isSafeInteger(h.utime)||h.utime!<=0)throw fail('Pool read lacks an exact masterchain root and time');
 return{...state,identity,chainNow:h.utime!,extra:(i:number)=>spotGetter(state.observation,i+2)};
}
export async function readNativePoolBins(pool:string,owner:string,bins:readonly number[],options:ReadChainOptions&{read?:FreshChainRead}={}){
 const calls=bins.flatMap(bin=>[poolGetter(pool,'get_bin',BigInt(bin)),{kind:'getter' as const,address:pool,method:'get_position',args:[freshAddressArg(Address.parse(owner)),freshInt(bin)]}]);
 const state=await readNativePool(pool,calls,options);return{...state,bins:new Map(bins.map((bin,i)=>{const s=state.extra(i*2),cell=s.cell(true);s.end();const p=state.extra(i*2+1),position={shares:p.uint(256),farmId:p.uint(64),valueT3:p.uint(256),minimum:p.uint()};p.end();return[bin,{bin:cell?poolBinValue.parse(cell.beginParse()):null,position}];}))};
}
export async function readNativePoolPositions(pool:string,owner:string,from=-200000,limit=64,options:ReadChainOptions&{read?:FreshChainRead}={}){
 if(!Number.isInteger(from)||from< -200000||from>200000||!Number.isInteger(limit)||limit<1||limit>64)throw fail('Invalid position page');
 const state=await readNativePool(pool,[{kind:'getter',address:pool,method:'get_positions',args:[freshAddressArg(Address.parse(owner)),freshInt(from),freshInt(limit)]}],options),s=state.extra(0),root=s.cell(true);s.end();return{...state,positions:Dictionary.loadDirect(Dictionary.Keys.Int(32),poolPositionValue,root)};
}
export function nativeLiqAddBody(owner:string,binId:number,amount:bigint,minShares:bigint){if(!Number.isInteger(binId)||Math.abs(binId)>200000||amount<=0n||minShares<=0n||minShares>=1n<<256n)throw fail('Invalid liquidity terms');return beginCell().storeUint(POOL_OP.add,32).storeAddress(Address.parse(owner)).storeBit(true).storeUint(1,3).storeRef(beginCell().storeInt(binId,32).storeCoins(amount).storeUint(minShares,256).storeBit(false).endCell()).endCell();}
export function decodeNativeLiqAdd(body:Cell){const s=body.beginParse();if(s.loadUint(32)!==POOL_OP.add)throw fail('Wrong liquidity opcode');const owner=s.loadAddress().toRawString(),notify=s.loadBit(),count=s.loadUint(3),r=s.loadRef().beginParse();s.endParse();const row={binId:r.loadInt(32),amount:r.loadCoins(),minShares:r.loadUintBig(256)};if(r.loadMaybeRef()||count!==1)throw fail('Wrong liquidity row count');r.endParse();return{owner,notify,...row};}
export function nativeLiqRemoveBody(owner:string,rows:readonly {binId:number;shares:bigint}[],queryId:bigint,deadline:number,minT3:bigint,minX:bigint){
 if(rows.length<1||rows.length>2||!Number.isInteger(deadline)||deadline<=0||deadline>0xffffffff||queryId<=0n||queryId>=1n<<64n||minT3<0n||minX<0n)throw fail('Invalid liquidity removal');let next:Cell|null=null;
 const sorted=[...rows].sort((a,b)=>a.binId-b.binId);for(let i=sorted.length-1;i>=0;i--){const row=sorted[i];if(!Number.isInteger(row.binId)||Math.abs(row.binId)>200000||row.shares<=0n||row.shares>=1n<<256n||i>0&&row.binId===sorted[i-1].binId)throw fail('Invalid removal row');next=beginCell().storeInt(row.binId,32).storeUint(row.shares,256).storeMaybeRef(next).endCell();}
 return beginCell().storeUint(POOL_OP.remove,32).storeUint(queryId,64).storeAddress(Address.parse(owner)).storeUint(deadline,32).storeCoins(minT3).storeCoins(minX).storeUint(sorted.length,3).storeRef(next!).endCell();
}
export function decodeNativeLiqRemove(body:Cell){const s=body.beginParse();if(s.loadUint(32)!==POOL_OP.remove)throw fail('Wrong removal opcode');const queryId=s.loadUintBig(64),owner=s.loadAddress().toRawString(),deadline=s.loadUint(32),minT3=s.loadCoins(),minX=s.loadCoins(),count=s.loadUint(3);let next:Cell|null=s.loadRef();s.endParse();const rows:{binId:number;shares:bigint}[]=[];for(let i=0;i<count;i++){if(!next)throw fail('Truncated removal');const v:ReturnType<Cell['beginParse']>=next.beginParse();rows.push({binId:v.loadInt(32),shares:v.loadUintBig(256)});next=v.loadMaybeRef();v.endParse();}if(next||!body.equals(nativeLiqRemoveBody(owner,rows,queryId,deadline,minT3,minX)))throw fail('Invalid removal body');return{owner,queryId,deadline,minT3,minX,rows};}
export const nativeFarmCreateBody=(binId:number,duration:number)=>beginCell().storeUint(POOL_OP.farmCreate,32).storeInt(binId,32).storeUint(duration,32).endCell();
export function nativeFarmActionBody(action:number,id:bigint,owner:string,queryId:bigint){if(action<1||action>5)throw fail('Invalid farm action');return beginCell().storeUint(POOL_OP.farmAction,32).storeUint(queryId,64).storeUint(action,8).storeUint(id,64).storeAddress(Address.parse(owner)).endCell();}

export type PoolTransferRequest={pool:string;owner:string;side:0|1;amount:bigint;queryId:bigint;payload:Cell;opcode:typeof POOL_OP.add|typeof POOL_OP.farmCreate};
/** Pool funding, master-selected wallets, source funds and exact config prices are
 * verified at one final head. No shared external-wallet template is assumed. */
export async function preparePoolTokenTransfer(r:PoolTransferRequest,options:{read?:FreshChainRead;prices?:typeof readJettonQuotePrices;signal?:AbortSignal}={}){
 if(r.amount<=0n||r.amount>=1n<<120n||r.queryId<=0n||r.queryId>=1n<<64n||r.payload.beginParse().preloadUint(32)!==r.opcode)throw fail('Invalid pool transfer');
 const read=options.read??readChain,base=await resolveNativePoolIdentity(r.pool,read),identity={...base,inSide:r.side},wallets=await readSpotWallets(read,identity,r.owner,{signal:options.signal});
 for(let attempt=0;attempt<3;attempt++){
  const q=await readSpotPool(read,identity,[poolGetter(r.pool,'get_min_forward',BigInt(r.opcode),BigInt(r.side))],{signal:options.signal}),v=spotGetter(q.observation,2),forward=v.uint();v.end();if(forward<=0n)throw fail('Pool funding is unavailable');
  const transfer={queryId:r.queryId,amount:r.amount,destination:Address.parse(r.pool),responseDestination:Address.parse(r.owner),forwardGram:forward,forwardPayload:r.payload,either:'ref' as const};
  const calls:ChainCall[]=[...wallets.plan.calls];
  const entries=[wallets.pay,wallets.poolPay,wallets.poolReceive].map(wallet=>{const index=calls.length+2;calls.push({kind:'account',address:wallet.address},{kind:'getter',address:wallet.address,method:'get_wallet_data'});return{wallet,index};});
  const slotsIndex=calls.length+2;calls.push({kind:'getter',address:r.pool,method:'get_jetton_slots'});
  const minIndex=calls.length+2;calls.push(poolGetter(r.pool,'get_min_forward',BigInt(r.opcode),BigInt(r.side)));
  const valueIndex=calls.length+2;
  if(r.side===0){const cell=t3WalletAttemptToCell({id:0n,originLt:0n,attempt:0n,owner:Address.parse(r.owner),recipient:Address.parse(r.pool),burn:false,amount:r.amount,details:{queryId:r.queryId,response:Address.parse(r.owner),forwardValue:forward,forwardPayload:beginCell().storeBit(true).storeRef(r.payload).endCell(),customPayload:null}});calls.push({kind:'getter',address:wallets.pay.address,method:'outgoing_value',args:[{type:'cell',cell}]});}
  const ownerIndex=calls.length+2;calls.push({kind:'account',address:r.owner});
  const final=await readSpotPool(read,identity,calls,{signal:options.signal,notBefore:q.head.seqno});
  if(!/^[0-9a-f]{64}$/.test(final.head.rootHashHex??'')||!final.head.utime||!final.ready||final.flags&2)throw fail('Pool is unavailable for new funding');
  const min=spotGetter(final.observation,minIndex),required=min.uint();min.end();if(required!==forward)continue;
  const bound=verifySpotWalletPlan(wallets.plan,final.observation);for(const name of ['pay','receive','poolPay','poolReceive'] as const)if(bound[name].address!==wallets[name].address)throw fail('Canonical wallet changed');
  const source=verifySpotWallet(final.observation.results[entries[0].index],final.observation.results[entries[0].index+1],wallets.pay);
  for(const e of entries.slice(1))verifySpotPoolInputWallet(final.observation.results[e.index],final.observation.results[e.index+1],e.wallet);
  if(source.balance<r.amount)throw fail('Insufficient source token balance');
  const profile=verifySpotSlots(spotGetter(final.observation,slotsIndex),identity,wallets);
  let value:bigint;if(r.side===0){const s=spotGetter(final.observation,valueIndex);value=s.uint();s.end();}else{const {prices}=await(options.prices??readJettonQuotePrices)(final.head,options.signal);value=quoteJettonTransfer(prices,profile,transfer)+jettonRentValue(prices,profile.budget.rentSeconds,profile.budget.rentBits,profile.budget.rentCells);}
  const account=final.observation.results[ownerIndex];if(value<=forward||account.kind!=='account'||account.balance<value)throw fail('Insufficient native funding');
  return{...final,wallets,sourceBalance:source.balance,forward,value,body:jettonTransferBody(transfer),message:{address:wallets.pay.address,amount:value.toString(),payload:jettonTransferBody(transfer).toBoc().toString('base64')}};
 }
 throw fail('Pool funding changed during preparation');
}
