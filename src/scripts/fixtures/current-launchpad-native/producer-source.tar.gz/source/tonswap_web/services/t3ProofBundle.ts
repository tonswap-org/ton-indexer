/** Original lite proof and native cursor verification. Keep these commitment rules aligned with the indexer t3ProofBundle/liteProof modules. */
import { Address, Cell, CellType, type Slice, beginCell, loadAccount, loadDepthBalanceInfo, loadShardIdent, loadShardAccount, loadTransaction } from '@ton/core';
import { Buffer } from 'buffer';
export type ProofHead = {seqno:number;workchain:number;shard:string;rootHashHex:string;fileHashHex:string;utime:number};
type ChainHead = ProofHead;

export type ProofBlockId = { workchain: number; shard: string; seqno: number; rootHash: Buffer; fileHash: Buffer };
export const sameProofBlock = (a: ProofBlockId, b: ProofBlockId) => a.workchain === b.workchain && a.shard === b.shard
  && a.seqno === b.seqno && a.rootHash.equals(b.rootHash) && a.fileHash.equals(b.fileHash);
export const headProofBlock = (head: ChainHead): ProofBlockId => ({ ...head,
  rootHash: Buffer.from(head.rootHashHex, 'hex'), fileHash: Buffer.from(head.fileHashHex, 'hex') });

export function proofRoots(bytes: Buffer, count: number): Cell[] {
  const roots = Cell.fromBoc(bytes);
  if (roots.length !== count || roots.some(root => root.type !== CellType.MerkleProof || root.refs.length !== 1)) {
    throw new Error('Invalid lite Merkle proof roots.');
  }
  return roots.map(root => root.refs[0]);
}

/** Follow only the requested dictionary path. A pruned path is unavailable,
 * never evidence that the key is absent (Dictionary.load skips pruned branches). */
export function provenDictionaryValue(root: Cell, key: bigint, width: number): Slice | null {
  let cell = root, remaining = width;
  for (;;) {
    if (cell.type !== CellType.Ordinary) throw new Error('Requested dictionary path is pruned.');
    const slice = cell.beginParse();
    let length = 0, label = 0n;
    const sizeBits = Math.ceil(Math.log2(remaining + 1));
    if (!slice.loadBit()) {
      while (slice.loadBit()) { if (++length > remaining) throw new Error('Invalid dictionary label.'); }
      label = length ? slice.loadUintBig(length) : 0n;
    } else if (!slice.loadBit()) {
      length = sizeBits ? slice.loadUint(sizeBits) : 0;
      if (length > remaining) throw new Error('Invalid dictionary label.');
      label = length ? slice.loadUintBig(length) : 0n;
    } else {
      const bit = slice.loadBit();
      length = sizeBits ? slice.loadUint(sizeBits) : 0;
      if (length > remaining) throw new Error('Invalid dictionary label.');
      label = bit ? (1n << BigInt(length)) - 1n : 0n;
    }
    if ((key >> BigInt(remaining - length)) !== label) return null;
    remaining -= length;
    key &= (1n << BigInt(remaining)) - 1n;
    if (!remaining) return slice;
    const left = slice.loadRef(), right = slice.loadRef();
    remaining--;
    cell = (key >> BigInt(remaining)) === 0n ? left : right;
    key &= (1n << BigInt(remaining)) - 1n;
  }
}

function stateParts(root: Cell, expected: ProofBlockId) {
  const s = root.beginParse();
  if (s.loadUint(32) !== 0x9023afe2) throw new Error('Invalid proven shard state.');
  s.loadInt(32);
  const shard = loadShardIdent(s), seqno = s.loadUint(32);
  if (shard.shardPrefixBits > 60 || shard.workchainId !== expected.workchain || seqno !== expected.seqno
    || BigInt.asIntN(64, shard.shardPrefix | (1n << BigInt(63 - shard.shardPrefixBits))).toString() !== expected.shard) {
    throw new Error('Proven shard state identity mismatch.');
  }
  s.loadUint(32); const utime = s.loadUint(32);
  s.loadUintBig(64); s.loadUint(32); s.loadRef(); s.loadBit();
  const accounts = s.loadRef(); s.loadRef();
  const extras = s.loadBit() ? s.loadRef() : null;
  s.endParse();
  return { utime, accounts, extras };
}

export function boundState(block: Cell, state: Cell, expected: ProofBlockId) {
  const utime = blockHeaderTime(block, expected), update = block.refs[2];
  if (update?.type !== CellType.MerkleUpdate || !update.refs[1]?.hash(0).equals(state.hash(0))
    || update.refs[1].depth(0) !== state.depth(0)) throw new Error('State is not committed by the requested block.');
  const parts = stateParts(state, expected);
  if (parts.utime !== utime) throw new Error('Proven block/state time mismatch.');
  return parts;
}

function masterExtra(state: ReturnType<typeof stateParts>) {
  if (!state.extras) throw new Error('Masterchain state extra is unavailable.');
  const extra = state.extras.beginParse();
  if (extra.loadUint(16) !== 0xcc26) throw new Error('Invalid masterchain state extra.');
  return extra;
}

function bindShardToMasterchain(shard: ProofBlockId, proof: Buffer, head: ChainHead) {
  const master = headProofBlock(head);
  if (master.workchain !== -1 || master.shard !== '-9223372036854775808') throw new Error('Account requires a masterchain head.');
  if (sameProofBlock(shard, master)) return;
  const [block, state] = proofRoots(proof, 2);
  const parts = boundState(block, state, master);
  if (parts.utime !== head.utime) throw new Error('Masterchain proof time mismatch.');
  const extra = masterExtra(parts);
  if (!extra.loadBit()) throw new Error('Masterchain has no shard hashes.');
  const wc = provenDictionaryValue(extra.loadRef(), BigInt.asUintN(32, BigInt(shard.workchain)), 32);
  if (!wc) throw new Error('Workchain is absent from the selected masterchain state.');
  let tree = wc.loadRef(); wc.endParse();
  const tagged = BigInt.asUintN(64, BigInt(shard.shard));
  let prefix = 0n, depth = 0;
  for (;;) {
    const branch = tree.beginParse();
    if (!branch.loadBit()) {
      if ((prefix | (1n << BigInt(63 - depth))) !== tagged) throw new Error('Shard prefix differs from the selected masterchain state.');
      const tag = branch.loadUint(4);
      if (tag !== 0xa && tag !== 0xb) throw new Error('Unsupported shard descriptor.');
      const seqno = branch.loadUint(32); branch.loadUint(32); branch.skip(128);
      if (seqno !== shard.seqno || !branch.loadBuffer(32).equals(shard.rootHash)
        || !branch.loadBuffer(32).equals(shard.fileHash)) throw new Error('Shard block is not selected by the requested masterchain state.');
      return;
    }
    if (depth >= 60) throw new Error('Invalid shard tree depth.');
    const rightward = (tagged & (1n << BigInt(63 - depth))) !== 0n;
    const left = branch.loadRef(), right = branch.loadRef(); branch.endParse();
    if (rightward) prefix |= 1n << BigInt(63 - depth);
    tree = rightward ? right : left; depth++;
  }
}

export function provenShardAccount(response: { block: ProofBlockId; shardBlock: ProofBlockId; proof: Buffer; shardProof: Buffer; raw: Buffer },
  head: ChainHead, address: Address): Cell | null {
  if (!sameProofBlock(response.block, headProofBlock(head))) throw new Error('Account masterchain head mismatch.');
  if (response.shardBlock.workchain !== address.workChain) throw new Error('Account proof workchain mismatch.');
  const tagged = BigInt.asUintN(64, BigInt(response.shardBlock.shard));
  if (!tagged) throw new Error('Invalid shard identifier.');
  const mask = BigInt.asUintN(64, -((tagged & -tagged) << 1n));
  if ((address.hash.readBigUInt64BE() & mask) !== (tagged & mask)) throw new Error('Account is outside the proven shard.');
  bindShardToMasterchain(response.shardBlock, response.shardProof, head);
  const [block, root] = proofRoots(response.proof, 2);
  const { accounts, utime } = boundState(block, root, response.shardBlock);
  if (utime > head.utime || (address.workChain === -1 && utime !== head.utime)) throw new Error('Account proof time mismatch.');
  const map = accounts.beginParse();
  const leaf = map.loadBit() ? provenDictionaryValue(map.loadRef(), BigInt(`0x${address.hash.toString('hex')}`), 256) : null;
  if (!leaf) {
    if (response.raw.length) throw new Error('Account bytes supplied for a proven absent account.');
    return null;
  }
  loadDepthBalanceInfo(leaf);
  const original = leaf.asCell();
  if (original.bits.length !== 320 || original.refs.length !== 1) throw new Error('Invalid original ShardAccount envelope.');
  const roots = Cell.fromBoc(response.raw);
  if (roots.length !== 1 || roots[0].type !== CellType.Ordinary) throw new Error('Invalid original Account bytes.');
  const account = roots[0], reference = original.refs[0];
  if (!account.hash(0).equals(reference.hash(0)) || account.depth(0) !== reference.depth(0)) throw new Error('Account bytes differ from their proven hash/depth.');
  const pending = [account], seen = new Set<Cell>();
  while (pending.length) {
    const cell = pending.pop()!;
    if (seen.has(cell)) continue;
    seen.add(cell);
    if (cell.type !== CellType.Ordinary && cell.type !== CellType.Library) throw new Error('Original Account bytes contain an unresolved proof branch.');
    pending.push(...cell.refs);
  }
  const data = account.beginParse();
  if (!data.loadBit() || !loadAccount(data).addr.equals(address)) throw new Error('Proven account address mismatch.');
  data.endParse();
  // Retain the dictionary's exact 320 pointer bits. Expand only the already
  // committed Account reference; never rebuild ShardAccount from SDK summaries.
  const expanded = new Cell({ bits: original.bits, refs: [account] });
  if (!expanded.hash(0).equals(original.hash(0)) || expanded.depth(0) !== original.depth(0)) throw new Error('Account expansion changed its proven envelope.');
  return expanded;
}

function identity(shard: ReturnType<typeof loadShardIdent>, seqno: number, expected: ProofBlockId): void {
  if (shard.shardPrefixBits > 60) throw new Error('Invalid shard prefix');
  const id = BigInt.asIntN(64, shard.shardPrefix | (1n << BigInt(63 - shard.shardPrefixBits))).toString();
  if (shard.workchainId !== expected.workchain || seqno !== expected.seqno || id !== expected.shard)
    throw new Error('Anchor shard identity mismatch');
}
export function blockHeaderTime(block: Cell, expected: ProofBlockId): number {
  if (!block.hash(0).equals(expected.rootHash)) throw new Error('Anchor block hash mismatch');
  const root = block.beginParse();
  if (root.loadUint(32) !== 0x11ef55aa) throw new Error('Invalid anchor block');
  root.loadInt(32);
  const info = root.loadRef().beginParse();
  if (info.loadUint(32) !== 0x9bc7a987) throw new Error('Invalid anchor block info');
  info.loadUint(32); info.loadUint(8); info.loadUint(8);
  const seqno = info.loadUint(32); info.loadUint(32);
  identity(loadShardIdent(info), seqno, expected);
  return info.loadUint(32);
}


export type RecoveryProofAnchor = {account:string;head:ProofHead;shardBlock:Omit<ProofHead,'utime'>;masterchainProofBoc:string;accountProofBoc:string;accountBoc:string;shardAccountBoc:string};
export type RecoveryProofHistory = {head:ProofHead;anchor:ProofHead;blockBoc:string;stateBoc:string};
const ensure = (ok: unknown, text = 'Invalid original recovery proof.') => { if (!ok) throw new Error(text); };
export function recoveryEnvelope(tree: Cell): Cell {
  return beginCell().storeUint(3, 8).storeBuffer(tree.hash(0)).storeUint(tree.depth(0), 16).storeRef(tree).endCell({ exotic: true });
}
export function validateRecoveryProofAnchor(a: RecoveryProofAnchor) {
  ensure(a && Object.keys(a).sort().join() === ['account','head','shardBlock','masterchainProofBoc','accountProofBoc','accountBoc','shardAccountBoc'].sort().join());
  const address = Address.parse(a.account); ensure(address.workChain === 0);
  const raw = { block: headProofBlock(a.head), shardBlock: headProofBlock({ ...a.shardBlock, utime: 0 }),
    shardProof: Buffer.from(a.masterchainProofBoc, 'base64'), proof: Buffer.from(a.accountProofBoc, 'base64'), raw: Buffer.from(a.accountBoc, 'base64') };
  const exact = provenShardAccount(raw, a.head, address);
  ensure(exact && exact.equals(Cell.fromBase64(a.shardAccountBoc)));
  const [masterBlock, masterState] = proofRoots(raw.shardProof, 2), [shardBlock, shardState] = proofRoots(raw.proof, 2);
  const { accounts } = boundState(shardBlock, shardState, raw.shardBlock), s = accounts.beginParse();
  ensure(s.loadBit()); const root = s.loadRef();
  const shard = loadShardAccount(exact!.beginParse()); ensure(shard.lastTransactionLt > 0n && shard.lastTransactionHash > 0n);
  return { bundle: recoveryEnvelope(beginCell().storeRef(masterBlock).storeRef(masterState).storeRef(shardBlock).storeRef(shardState).endCell()),
    root, key: BigInt('0x' + address.hash.toString('hex')), lt: shard.lastTransactionLt, hash: shard.lastTransactionHash };
}
/** The exact native prev_blocks path, including its augmented leaf. No list of
 * remembered block hashes substitutes for this original state commitment. */
export function validateRecoveryProofHistory(h: RecoveryProofHistory): Cell {
  ensure(h && Object.keys(h).sort().join() === ['head','anchor','blockBoc','stateBoc'].sort().join());
  ensure(h.anchor.seqno < h.head.seqno && h.anchor.workchain === -1 && h.head.workchain === -1);
  const block = Cell.fromBase64(h.blockBoc), state = Cell.fromBase64(h.stateBoc);
  const { extras } = boundState(block, state, headProofBlock(h.head)); ensure(extras);
  const e = extras!.beginParse(); ensure(e.loadUint(16) === 0xcc26);
  e.loadMaybeRef(); e.skip(256); e.loadRef();
  const info = e.loadRef().beginParse(); ensure(info.loadUint(16) <= 1); info.skip(32 + 32 + 1); ensure(info.loadBit());
  const leaf = provenDictionaryValue(info.loadRef(), BigInt(h.anchor.seqno), 32); ensure(leaf);
  leaf!.skip(1 + 64); leaf!.loadBit(); leaf!.skip(64);
  ensure(leaf!.loadUint(32) === h.anchor.seqno && leaf!.loadBuffer(32).toString('hex') === h.anchor.rootHashHex
    && leaf!.loadBuffer(32).toString('hex') === h.anchor.fileHashHex); leaf!.endParse();
  return recoveryEnvelope(beginCell().storeRef(block).storeRef(state).endCell());
}
export type RecoveryCursor = { hash: bigint; key: bigint; bits: number; lt: bigint };
/** Native dictionaryWalk advances at most 64 original edges per transaction. */
export function recoveryAccountChunk(root: Cell, key: bigint, bits: number) {
  let node = root, n = bits, selected = key;
  ensure(n > 0 && n <= 256);
  for (let i = 0; i < 64; i++) {
    ensure(node.type === CellType.Ordinary, 'Recovery account path is pruned.');
    const s = node.beginParse(), width = Math.ceil(Math.log2(n + 1)); let length = 0, prefix = 0n;
    if (!s.loadBit()) { while (s.loadBit()) { ensure(++length <= n); } prefix = length ? s.loadUintBig(length) : 0n; }
    else if (!s.loadBit()) { length = width ? s.loadUint(width) : 0; ensure(length <= n); prefix = length ? s.loadUintBig(length) : 0n; }
    else { const bit = s.loadBit(); length = width ? s.loadUint(width) : 0; ensure(length <= n); prefix = bit ? (1n << BigInt(length)) - 1n : 0n; }
    ensure(prefix === selected >> BigInt(n - length)); n -= length;
    if (!n) {
      loadDepthBalanceInfo(s); s.loadRef(); const hash = s.loadUintBig(256), lt = s.loadUintBig(64); s.endParse();
      return { proof: recoveryEnvelope(root), next: { hash, lt, key: 0n, bits: 0 }, done: true };
    }
    selected &= (1n << BigInt(n)) - 1n;
    const left = s.loadRef(), right = s.loadRef(); n--; node = (selected >> BigInt(n)) === 0n ? left : right;
    selected &= (1n << BigInt(n)) - 1n;
  }
  return { proof: recoveryEnvelope(root), next: { hash: BigInt('0x' + node.hash(0).toString('hex')), key: selected, bits: n, lt: 0n }, done: false };
}
/** Find a persisted native cursor only along the same authenticated account path. */
export function recoveryAccountPath(anchor: RecoveryProofAnchor, cursor: RecoveryCursor) {
  const p = validateRecoveryProofAnchor(anchor); let node = p.root, key = p.key, bits = 256;
  for (let chunk = 0; chunk < 5; chunk++) {
    if (BigInt('0x' + node.hash(0).toString('hex')) === cursor.hash && key === cursor.key && bits === cursor.bits && cursor.lt === 0n) return recoveryAccountChunk(node, key, bits);
    const result = recoveryAccountChunk(node, key, bits); ensure(!result.done, 'Recovery account cursor is not on the committed path.');
    const wanted = result.next.hash; let found: Cell | undefined;
    const queue = [node], seen = new Set<Cell>();
    while (queue.length) { const c = queue.pop()!; if (seen.has(c)) continue; seen.add(c); if (BigInt('0x' + c.hash(0).toString('hex')) === wanted) { found = c; break; } if (!c.isExotic) queue.push(...c.refs); }
    ensure(found); node = found!; key = result.next.key; bits = result.next.bits;
  }
  throw new Error('Recovery account cursor exceeds the native path bound.');
}
export function recoveryTransactionChunk(account: string, originals: readonly string[], cursor: RecoveryCursor, target: { lt: bigint; hash: bigint }) {
  ensure(originals.length > 0 && originals.length <= 4 && cursor.bits === 0 && cursor.key === 0n && target.lt > 0n);
  const address = Address.parse(account); let hash = cursor.hash, lt = cursor.lt;
  const cells: Cell[] = []; let final: ReturnType<typeof loadTransaction> | undefined;
  for (const boc of originals) {
    const cell = Cell.fromBase64(boc); ensure(!cell.isExotic);
    const tx = loadTransaction(cell.beginParse()); ensure(tx.address === BigInt('0x' + address.hash.toString('hex'))
      && tx.lt === lt && BigInt('0x' + cell.hash().toString('hex')) === hash && lt >= target.lt);
    cells.push(cell); final = tx; hash = tx.prevTransactionHash; lt = tx.prevTransactionLt;
  }
  ensure(final); const done = final!.lt === target.lt;
  ensure(done ? BigInt('0x' + cells.at(-1)!.hash().toString('hex')) === target.hash : lt >= target.lt && (lt !== target.lt || hash === target.hash));
  let suffix: Cell | null = null;
  for (let i = cells.length - 1; i >= 0; i--) suffix = beginCell().storeRef(recoveryEnvelope(cells[i])).storeMaybeRef(suffix).endCell();
  return { proof: suffix!, done, next: { hash, lt, key: 0n, bits: 0 } };
}
