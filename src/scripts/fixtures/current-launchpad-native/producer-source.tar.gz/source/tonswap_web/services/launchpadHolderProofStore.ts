import { sameWalletTransaction } from './exactWalletTransaction';
import { Address, beginCell, Cell, storeStateInit, loadStateInit, contractAddress } from '@ton/core';
import { Buffer } from 'buffer';
import { CHAIN, type SendTransactionRequest } from '@tonconnect/sdk';
import { AppError } from './appError';
import { readLaunchpadHolderProofFailure, validateLaunchpadHolderProofFailure, type LaunchpadHolderProofFailure } from './launchpadHolderProofOutcome';
import { T3_OP, t3ProofData } from './t3Contracts';
import { launchpadScopeOf,launchpadJournalKey,launchpadLock,readLaunchpadJournal,validLaunchpadScope,type LaunchpadScope,type LaunchpadStorage,type LaunchpadLock } from './launchpadOperationStore';
import { launchpadEvidenceRequest } from './launchpadOperationSettlement';
import { isT3ProofStepApplied,type T3ProofStepPlan,type T3ProofSnapshot,type T3ProofStage } from './t3ProofSession';
import { validateLaunchpadHolderProofSession,type LaunchpadHolderProofSession } from './launchpadHolderProofSession';
import type { LaunchpadProofBinding, LaunchpadEvidenceRequest } from './launchpadOperationSettlement';
import type { LaunchpadHolderRecoveries } from './launchpadHolderRecoveryEvidence';
import { walletAnswer, isWalletRequestTicket, isWalletRequestAnswer, walletMessageExpired, resolveWalletRequest, readFirstHop, readWalletRequestRecord, walletRequestRecordKey, type WalletRequestTicket, type WalletRequestAnswer, type WalletRequestChain } from './walletRequest';
import { isWalletRequestNotSentError, WalletRequestNotSentError } from './walletRequestNotSent';
import type { SendWalletTransaction, ReviewWalletAction } from './walletAction';

export type LaunchpadHolderProofRequest = {id:string;session:LaunchpadHolderProofSession;step:number;expectedStage:T3ProofStage;nextStage:T3ProofStage;
 address:string;bounce:boolean;bodyBoc:string;bodyHash:string;initBoc:string|null;valueNano:string;createdAt:number;validUntil:number};
export type LaunchpadHolderProofAttempt = {request:LaunchpadHolderProofRequest;ticket:WalletRequestTicket|null;answer:WalletRequestAnswer|null;walletClosed:boolean;failure:LaunchpadHolderProofFailure|null;state:'requesting'|'pending'|'not-sent'|'confirmed'|'rejected'};
const originalScope=(p:LaunchpadEvidenceRequest)=>launchpadScopeOf({...p,wallet:p.owner});
const proofStorage=():LaunchpadStorage=>{try{if(globalThis.localStorage)return globalThis.localStorage;}catch{}throw fail('Proof storage unavailable');};
type Journal={version:1;scope:LaunchpadScope;sessions:LaunchpadHolderProofSession[];attempts:LaunchpadHolderProofAttempt[]};
const fail=(devMessage:string)=>new AppError('launchCreate.error.progress.invalid',{}, {devMessage});
const canonical=(v:unknown):unknown=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b)).map(([k,x])=>[k,canonical(x)])):v;
const same=(a:unknown,b:unknown)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
const clone=<T>(v:T):T=>structuredClone(v);
const exact=(v:unknown,keys:string[]):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const hash=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const uint=(v:unknown,bits=256):v is string=>typeof v==='string'&&/^(0|[1-9]\d{0,77})$/.test(v)&&BigInt(v)<1n<<BigInt(bits);
const stage=(v:unknown):v is T3ProofStage=>exact(v,['phase','messageHash','cursor','evidence'])&&Number.isInteger(v.phase)&&v.phase>=0&&v.phase<=7&&uint(v.messageHash)&&Number.isInteger(v.evidence)&&v.evidence>=0&&v.evidence<=2
 &&exact(v.cursor,['hash','key','bits','lt'])&&uint(v.cursor.hash)&&uint(v.cursor.key)&&Number.isInteger(v.cursor.bits)&&v.cursor.bits>=0&&v.cursor.bits<=256&&uint(v.cursor.lt,64);
export const launchpadHolderProofOpen=(a:LaunchpadHolderProofAttempt)=>a.state==='pending'||a.state==='requesting';
export function launchpadHolderProofJournalKey(scope:LaunchpadScope){return `${launchpadJournalKey(scope)}:proof`;}
function rawJournal(scope:LaunchpadScope,target:LaunchpadStorage):Journal{
 const bytes=target.getItem(launchpadHolderProofJournalKey(scope));if(bytes===null)return{version:1,scope:clone(scope),sessions:[],attempts:[]};
 try{const j=JSON.parse(bytes);if(!exact(j,['version','scope','sessions','attempts'])||j.version!==1||!validLaunchpadScope(j.scope)||!same(j.scope,scope)||!Array.isArray(j.sessions)||!Array.isArray(j.attempts)
  ||j.attempts.some((a:any)=>!exact(a,['request','ticket','answer','walletClosed','failure','state'])||!['requesting','pending','not-sent','confirmed','rejected'].includes(a.state)))throw Error();return j as Journal;}catch{throw fail('Saved proof journal invalid; retained');}
}
/** Other Launchpad actions use the same lock and cannot overtake a proof handoff. */
export function launchpadHolderProofPending(scope:LaunchpadScope,target:LaunchpadStorage=proofStorage()){return rawJournal(scope,target).attempts.some(launchpadHolderProofOpen);}
function validRequest(r:unknown,binding:LaunchpadProofBinding):r is LaunchpadHolderProofRequest{
 try{if(!exact(r,['id','session','step','expectedStage','nextStage','address','bounce','bodyBoc','bodyHash','initBoc','valueNano','createdAt','validUntil'])||!hash(r.id)||!validateLaunchpadHolderProofSession(r.session,binding)
  ||r.address!==r.session.address||typeof r.bounce!=='boolean'||![10,11,12,14,15,16,17,20,21,22,24,25,30].includes(r.step)||!stage(r.expectedStage)||!stage(r.nextStage)
  ||!hash(r.bodyHash)||!uint(r.valueNano,120)||r.valueNano==='0'||!Number.isSafeInteger(r.createdAt)||r.createdAt<=0||!Number.isSafeInteger(r.validUntil)||r.validUntil<=0||r.validUntil>0xffffffff
  ||typeof r.bodyBoc!=='string'||r.bodyBoc.length>1024*1024||r.initBoc!==null&&(typeof r.initBoc!=='string'||r.initBoc.length>1024*1024))return false;
  const body=Cell.fromBase64(r.bodyBoc),b=body.beginParse();
  if(body.hash().toString('hex')!==r.bodyHash||b.loadUint(32)!==T3_OP.T3_PROOF_STEP||b.loadUint(8)!==r.step)return false;
  if(r.step===15||r.step===25){b.loadUint(32);b.loadRef();b.loadRef();}
  else if(r.step===16){b.loadRef();b.loadRef();}
  else if(r.step===30){b.loadRef();if(b.loadCoins()===0n)return false;}
  else b.loadRef();b.endParse();
  if(r.initBoc!==null){const i=Cell.fromBase64(r.initBoc).beginParse(),init=loadStateInit(i);i.endParse();
    if(r.bounce||init.splitDepth!==undefined||init.special||init.libraries?.size||!init.code||!init.data||init.code.hash().toString('hex')!==binding.proofCodeHash||!init.data.equals(t3ProofData(Cell.fromBase64(r.session.configBoc)))||contractAddress(0,init).toRawString()!==r.address)return false;}
  else if(!r.bounce)return false;return true;
 }catch{return false;}
}
export function launchpadHolderProofTransaction(r:LaunchpadHolderProofRequest):SendTransactionRequest{return{from:r.session.original.owner,network:r.session.original.network==='mainnet'?CHAIN.MAINNET:CHAIN.TESTNET,validUntil:r.validUntil,messages:[{
 address:Address.parse(r.address).toString({bounceable:r.bounce,testOnly:r.session.original.network!=='mainnet'}),amount:r.valueNano,payload:r.bodyBoc,...(r.initBoc?{stateInit:r.initBoc}:{})}]};}
function ticketMatches(r:LaunchpadHolderProofRequest,t:WalletRequestTicket){return isWalletRequestTicket(t)&&t.network===r.session.original.network&&t.owner===r.session.original.owner&&t.validUntil===r.validUntil&&t.messages.length===1
 &&t.messages[0].destination===r.address&&t.messages[0].bodyHash===r.bodyHash&&t.messages[0].amount===r.valueNano&&t.messages[0].init===(r.initBoc!==null);}
export function readLaunchpadHolderProofJournal(scope:LaunchpadScope,binding:LaunchpadProofBinding,target:LaunchpadStorage=proofStorage()):Journal{
 const j=rawJournal(scope,target),ids=new Set<string>(),addresses=new Set<string>();
 for(const s of j.sessions){if(!validateLaunchpadHolderProofSession(s,binding)||!same(originalScope(s.original),scope)||addresses.has(s.address))throw fail('Saved proof session invalid; retained');addresses.add(s.address);}
 for(const a of j.attempts){if(!validRequest(a.request,binding)||!j.sessions.some(s=>same(s,a.request.session))||ids.has(a.request.id)||typeof a.walletClosed!=='boolean'
  ||a.ticket!==null&&!ticketMatches(a.request,a.ticket)||a.answer!==null&&(!a.ticket||!isWalletRequestAnswer(a.answer))||['confirmed','not-sent','rejected'].includes(a.state)&&!a.walletClosed||['confirmed','rejected'].includes(a.state)&&!a.ticket
  ||(a.state==='rejected'?(a.failure===null||!validateLaunchpadHolderProofFailure(a.failure,a.request,binding)):a.failure!==null))throw fail('Saved proof attempt invalid; retained');ids.add(a.request.id);}
 return j;
}
function save(j:Journal,binding:LaunchpadProofBinding,target:LaunchpadStorage){const key=launchpadHolderProofJournalKey(j.scope),bytes=JSON.stringify(j);readLaunchpadHolderProofJournal(j.scope,binding,{getItem:()=>bytes,setItem:()=>{}});target.setItem(key,bytes);if(target.getItem(key)!==bytes)throw fail('Proof save failed');readLaunchpadHolderProofJournal(j.scope,binding,target);}
export function makeLaunchpadHolderProofRequest(session:LaunchpadHolderProofSession,plan:T3ProofStepPlan,binding:LaunchpadProofBinding,validUntil:number,now=Date.now()):LaunchpadHolderProofRequest{
 const bodyHash=plan.body.hash().toString('hex'),r:LaunchpadHolderProofRequest={id:beginCell().storeAddress(plan.address).storeBuffer(Buffer.from(bodyHash,'hex')).storeUint(now,64).endCell().hash().toString('hex'),session:clone(session),step:plan.step,expectedStage:clone(plan.expectedStage),nextStage:clone(plan.nextStage),address:plan.address.toRawString(),bounce:plan.bounce,
  bodyBoc:plan.body.toBoc().toString('base64'),bodyHash,initBoc:plan.init?beginCell().store(storeStateInit(plan.init)).endCell().toBoc().toString('base64'):null,valueNano:plan.value.toString(),createdAt:now,validUntil};
 if(!validRequest(r,binding))throw fail('Invalid native proof plan');return r;
}
export async function sendLaunchpadHolderProofRequest(input:{request:LaunchpadHolderProofRequest;binding:LaunchpadProofBinding;action:ReviewWalletAction;send:SendWalletTransaction;current:()=>boolean;revalidate:()=>Promise<void>;storage?:LaunchpadStorage;lock?:LaunchpadLock}):Promise<LaunchpadHolderProofAttempt>{
 const target=input.storage??proofStorage(),lock=input.lock??launchpadLock,r=clone(input.request),scope=originalScope(r.session.original);
 return lock(launchpadJournalKey(scope),async()=>{
  if(!input.current()||!validRequest(r,input.binding))throw fail('Proof context changed');const claims=readLaunchpadJournal(scope,target),claim=claims.attempts.find(a=>a.request.bodyHash===r.session.original.bodyHash);
  if(!claim?.walletClosed||!same(launchpadEvidenceRequest(claim.request,r.session.original.dispatch),r.session.original)||claims.attempts.some(a=>!a.walletClosed))throw fail('Original Launchpad handoff unresolved');
  const j=readLaunchpadHolderProofJournal(scope,input.binding,target);if(j.attempts.some(a=>launchpadHolderProofOpen(a)||a.request.id===r.id))throw fail('Earlier proof step unresolved');
  const saved=j.sessions.find(s=>s.address===r.session.address||same(s.original,r.session.original)&&s.candidate.key===r.session.candidate.key);if(saved&&!same(saved,r.session))throw fail('Immutable proof session changed');if(!saved)j.sessions.push(clone(r.session));
  const a:LaunchpadHolderProofAttempt={request:r,ticket:null,answer:null,walletClosed:false,failure:null,state:'requesting'};j.attempts.push(a);save(j,input.binding,target);let expected=JSON.stringify(j);
  const originalClaims=JSON.stringify(claims);const unchanged=()=>{if(!input.current()||JSON.stringify(readLaunchpadJournal(scope,target))!==originalClaims||JSON.stringify(readLaunchpadHolderProofJournal(scope,input.binding,target))!==expected)throw new WalletRequestNotSentError('Proof context changed');};const persist=()=>{save(j,input.binding,target);expected=JSON.stringify(j);};
  try{const tx=launchpadHolderProofTransaction(r),answer=await input.send(tx,input.action,{verify:t=>{unchanged();if(!sameWalletTransaction(t,tx))throw new WalletRequestNotSentError('Proof payload changed');},beforeDispatch:async ticket=>{
   unchanged();await input.revalidate();unchanged();if(a.ticket||!ticketMatches(r,ticket))throw new WalletRequestNotSentError('Proof ticket changed');a.ticket=clone(ticket);a.state='pending';persist();
  }});
   if(JSON.stringify(readLaunchpadHolderProofJournal(scope,input.binding,target))!==expected)throw fail('Proof journal changed before wallet answer');
   if(answer===null&&!a.ticket){a.walletClosed=true;a.state='not-sent';persist();}else if(answer!==null){if(!a.ticket)throw fail('Proof answer has no ticket');a.answer=walletAnswer(a.ticket,answer)??a.answer;a.state='pending';persist();}return clone(a);
  }catch(error){if(!a.ticket&&isWalletRequestNotSentError(error)&&JSON.stringify(readLaunchpadHolderProofJournal(scope,input.binding,target))===expected){a.walletClosed=true;a.state='not-sent';persist();}throw error;}
 });
}
export async function reconcileLaunchpadHolderProof(scope:LaunchpadScope,id:string,input:{binding:LaunchpadProofBinding;readSession:(session:LaunchpadHolderProofSession)=>Promise<T3ProofSnapshot>;readRecovery:(request:LaunchpadEvidenceRequest)=>Promise<LaunchpadHolderRecoveries>;
 storage?:LaunchpadStorage;lock?:LaunchpadLock;chain?:WalletRequestChain;signal?:AbortSignal;current?:()=>boolean}):Promise<LaunchpadHolderProofAttempt|null>{
 const target=input.storage??proofStorage(),lock=input.lock??launchpadLock,original=readLaunchpadHolderProofJournal(scope,input.binding,target).attempts.find(a=>a.request.id===id);if(!original||!launchpadHolderProofOpen(original))return original??null;
 const a=clone(original),ticket=a.ticket,shared=()=>ticket?JSON.stringify(readWalletRequestRecord(ticket.network,ticket.owner,target)):null,before=shared();
 if(ticket){const options={storage:target,chain:input.chain,signal:input.signal,answer:a.answer},outcome=await resolveWalletRequest(ticket,options);
  if(walletMessageExpired(outcome,0)){a.walletClosed=true;a.state='not-sent';}
  else if(outcome.status==='observed'&&outcome.final){a.walletClosed=true;const hop=await readFirstHop(ticket,0,options);if(hop.status==='rejected')a.state='not-sent';
   else if(hop.status==='executed'){const recovery=await input.readRecovery(a.request.session.original);
    const certified=recovery.status==='ready'&&recovery.candidates.some(c=>c.key===a.request.session.candidate.key&&c.status!=='certificate-required');
    if(certified||a.request.step!==30&&isT3ProofStepApplied(a.request,await input.readSession(a.request.session)))a.state='confirmed';
    else if(a.request.step===30){const failure=await readLaunchpadHolderProofFailure(a.request,input.binding,hop.transaction,{chain:input.chain,signal:input.signal});if(failure){a.failure=failure;a.state='rejected';}}
   }
  }
 }
 return lock(launchpadJournalKey(scope),async()=>{const publish=async()=>{input.signal?.throwIfAborted();const j=readLaunchpadHolderProofJournal(scope,input.binding,target),latest=j.attempts.find(v=>v.request.id===id);
  if(input.current&&!input.current()||!latest||!same(latest,original)||before!==shared())return latest??null;if(!ticket){a.walletClosed=true;a.state='not-sent';}j.attempts[j.attempts.indexOf(latest)]=a;save(j,input.binding,target);return clone(a);};return ticket?lock(walletRequestRecordKey(ticket.network,ticket.owner),publish):publish();});
}
