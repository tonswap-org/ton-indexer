import { TONSWAP_RELEASE } from '../releaseManifest';

export const platformApiBase = (TONSWAP_RELEASE?.services.platform ?? '').replace(/\/$/, '');

export class PlatformError extends Error {
  constructor(message: string, public status: number, public code: string | null = null) { super(message); this.name = 'PlatformError'; }
}

export type PlatformSessionScope = { walletAddress: string; network: 'mainnet' | 'testnet'; csrfToken: string };
let sessionScope: PlatformSessionScope | null = null;
export function setPlatformSession(value: PlatformSessionScope | null) { sessionScope = value ? { ...value } : null; }
export function capturePlatformSession(): PlatformSessionScope | null { return sessionScope ? { ...sessionScope } : null; }
export type PlatformRequestOptions = RequestInit & { sessionScope?: PlatformSessionScope | null };

export async function platformRequest<T>(path: string, options: PlatformRequestOptions = {}): Promise<T> {
  const { sessionScope: suppliedScope, ...requestOptions } = options;
  const scope = suppliedScope === undefined ? capturePlatformSession() : suppliedScope;
  const headers = new Headers(options.headers);
  headers.set('Accept', 'application/json');
  if (options.body && typeof options.body === 'string') headers.set('Content-Type', 'application/json');
  if (scope) {
    headers.set('X-Wallet-Address', scope.walletAddress); headers.set('X-Wallet-Network', scope.network);
    if (options.method && options.method !== 'GET') headers.set('X-CSRF-Token', scope.csrfToken);
  }
  const controller = new AbortController();
  const abort = () => controller.abort(options.signal?.reason);
  if (options.signal?.aborted) abort(); else options.signal?.addEventListener('abort', abort, { once: true });
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(`${platformApiBase}${path}`, { ...requestOptions, headers, credentials: requestOptions.credentials ?? 'include', signal: controller.signal });
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) throw new PlatformError('This service is temporarily unavailable.', response.status);
    const payload = await response.json();
    if (!response.ok) throw new PlatformError(typeof payload.error?.message === 'string' ? payload.error.message : 'Unable to complete this request.', response.status, typeof payload.error?.code === 'string' ? payload.error.code : null);
    return payload as T;
  } catch (error) {
    if (error instanceof PlatformError) throw error;
    throw new PlatformError(controller.signal.aborted ? 'The request timed out. Please retry.' : 'Unable to reach the service. Please retry.', 0);
  } finally {
    clearTimeout(timeout);
    options.signal?.removeEventListener('abort', abort);
  }
}
