import { AppError } from './appError';

const NAMESPACE = 'addLiquidity.error';

/**
 * A liquidity failure a person can read: `code` is a key in `addLiquidity.error.*`, `devMessage` is the
 * original English sentence. A screen renders the catalog message with `messageFor` and keeps the raw
 * sentence under Technical details; it never shows `error.message`.
 */
export const liquidityError = (code: string, devMessage: string, params: Record<string, string | number> = {}, cause?: unknown) =>
  new AppError(`${NAMESPACE}.${code}`, params, { devMessage, cause });

export const isLiquidityError = (error: unknown, code?: string): error is AppError =>
  error instanceof AppError && error.code.startsWith(`${NAMESPACE}.`) && (code === undefined || error.code === `${NAMESPACE}.${code}`);
