import { Address, Cell, beginCell } from '@ton/core';
import { Buffer } from 'buffer';
import type { ReleaseManifestV1 } from '../releaseManifest';
import { currentT3ActiveState, currentT3Cell, verifyCurrentT3Transaction, type CurrentT3Transaction, type CurrentT3TransactionEvidence } from './t3CurrentEvidence';
import { readT3WalletStorage, t3WalletAttemptFromCell, T3_OP } from './t3Contracts';
import { decodeSpotTokenTransfer, verifySpotMessageLink } from './spotSwapChainProof';
import { FAUCET_SYMBOLS, faucetClaimBody, faucetCodeMatches, readFaucetState, type FaucetAsset, type FaucetPins } from './faucetContracts';
import { indexerRequest } from './indexer';

export type FaucetEvidenceRequest = { network: 'testnet'|'localnet'; releaseId:string; manifestHash:string; kind:'claim'; owner:string; faucet:string;
  asset:FaucetAsset; queryId:string; bodyBoc:string; bodyHash:string; valueNano:string; createdAt:number; dispatch:{lt:string;hash:string;valueNano:string} };
export type FaucetEvidenceBinding = { release:ReleaseManifestV1; pins:FaucetPins; recipientWallet:string; minSeqno:number; minBlockRootHash:string };
export type FaucetDelivery = { status:'delivered'; transactionHash:string; faucetTransactionHash:string; sourceTransactionHash:string; amountRaw:string; wire:string };
export type FaucetRestored = Omit<FaucetDelivery,'status'>&{status:'restored'};
export type FaucetEvidence = FaucetDelivery | FaucetRestored | {status:'pending'|'unavailable'};
const hash=(c:Cell)=>c.hash().toString('hex');
const raw=(a:Address|null|undefined)=>a?.toRawString()??null;
const exact=(v:unknown,keys:string[]):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
function check(v:unknown,detail:string):asserts v{if(!v)throw Error(`Faucet evidence: ${detail}`);}
const only=<T>(rows:T[],detail:string)=>{check(rows.length===1,detail);return rows[0];};
const tryRead=<T>(read:()=>T)=>{try{return read();}catch{return null;}};
function input(t:CurrentT3Transaction,owner:string){const m=t.tx.inMessage;check(m?.info.type==='internal'&&!m.info.bounced&&raw(m.info.src)===owner,'message sender');return m;}
function balance(t:CurrentT3Transaction,b:FaucetEvidenceBinding,asset:FaucetAsset,owner:string,after:boolean){
  const shard=after?t.after:t.before;if(!shard.account||shard.account.storage.state.type==='uninit')return 0n;
  const pin=b.pins.tokens[asset];check(shard.account.storage.state.type==='active','active wallet');const a=shard.account.storage.state.state;
  check(a.code&&a.data&&faucetCodeMatches(a.code,pin.walletCodeHash)&&!a.special&&(!a.libraries||a.libraries.size===0),'exact wallet code');
  if(asset===0){const s=readT3WalletStorage(a.data);check(a.splitDepth==null&&raw(s.owner)===owner&&s.master.equals(pin.master)&&s.proofCodeHash===BigInt('0x'+b.release.templates.T3RecoveryProof),'current T3 identity');return s.balance;}
  const v21=pin.walletCodeHash===b.release.templates.JettonV21Wallet;
  check(v21||pin.walletCodeHash===b.release.vendor.stablecoin.wallet.codeHash,'supported external wallet');
  check(a.splitDepth==null||v21&&a.splitDepth===8,'wallet layout');const s=a.data.beginParse();if(!v21)s.loadUint(4);
  const amount=s.loadCoins();check(raw(s.loadAddress())===owner&&s.loadAddress().equals(pin.master),'external wallet identity');s.endParse();return amount;
}
function delta(t:CurrentT3Transaction,b:FaucetEvidenceBinding,asset:FaucetAsset,owner:string,amount:bigint){check(t.succeeded&&balance(t,b,asset,owner,true)-balance(t,b,asset,owner,false)===amount,'physical token balance');}
function empty(cell:Cell){return !cell.isExotic&&!cell.bits.length&&!cell.refs.length;}
function either(s:ReturnType<Cell['beginParse']>){if(s.loadBit()){const cell=s.loadRef();s.endParse();return cell;}return beginCell().storeSlice(s).endCell();}

/** Only original successful execution and its exactly linked token debit/credit prove delivery. */
export function decodeFaucetEvidence(value:unknown,p:FaucetEvidenceRequest,b:FaucetEvidenceBinding,now=Date.now()):FaucetEvidence{
 try{
  const {release:r,pins}=b,pin=pins.tokens[p.asset];
  check(r.network===`ton:${p.network}`&&r.releaseId===p.releaseId&&r.manifestHash===p.manifestHash&&pins.address.toRawString()===p.faucet
    &&r.contracts.TestnetFaucet?.codeHash===pins.codeHash&&r.tokens.find(t=>t.symbol===FAUCET_SYMBOLS[p.asset])?.root===pin.master.toRawString(),'release binding');
  const body=faucetClaimBody(p.asset,BigInt(p.queryId));check(hash(body)===p.bodyHash&&body.equals(currentT3Cell(p.bodyBoc)),'exact original claim');
  check(Buffer.byteLength(JSON.stringify(value),'utf8')<=8*1024*1024,'response bound');
  check(exact(value,['schema','releaseId','manifestHash','asOf','request','coverage','transactions'])&&value.schema==='tonswap-faucet-operation-evidence-v1'
    &&value.releaseId===p.releaseId&&value.manifestHash===p.manifestHash,'envelope');
  const h=value.asOf;check(exact(h,['masterchainSeqno','unixTime','blockRootHash'])&&Number.isSafeInteger(h.masterchainSeqno)&&h.masterchainSeqno>=b.minSeqno
    &&h.masterchainSeqno>0&&Number.isSafeInteger(h.unixTime)&&h.unixTime>0&&/^[a-f0-9]{64}$/.test(h.blockRootHash)
    &&(h.masterchainSeqno>b.minSeqno||h.blockRootHash===b.minBlockRootHash)&&h.unixTime*1000<=now+5000&&now-h.unixTime*1000<=30000,'current head');
  check(exact(value.request,['kind','owner','bodyHash'])&&value.request.kind==='claim'&&value.request.owner===p.owner&&value.request.bodyHash===p.bodyHash,'request echo');
  check(exact(value.coverage,['complete','gaps'])&&typeof value.coverage.complete==='boolean'&&Array.isArray(value.coverage.gaps)&&value.coverage.gaps.length<=256,'coverage');
  if(!value.coverage.complete||value.coverage.gaps.length)return{status:'unavailable'};
  check(Array.isArray(value.transactions)&&value.transactions.length<=256,'transaction bound');
  const txs:CurrentT3Transaction[]=value.transactions.map((row:unknown)=>{check(exact(row,['account','transactionBoc','beforeShardAccountBoc','afterShardAccountBoc']),'original envelope');const t=verifyCurrentT3Transaction(row as CurrentT3TransactionEvidence);check(t.tx.now<=h.unixTime,'future transaction');return t;});
  check(new Set(txs.map(t=>t.hash)).size===txs.length,'duplicate transaction');
  const owner=only(txs.filter(t=>t.account===p.owner&&t.tx.lt.toString()===p.dispatch.lt&&t.hash===p.dispatch.hash),'owner dispatch');check(owner.succeeded,'owner dispatch execution');
  const claims=txs.filter(t=>t.account===p.faucet&&tryRead(()=>{const m=input(t,p.owner);return m.body.equals(body)&&m.info.type==='internal'&&m.info.value.coins.toString()===p.dispatch.valueNano&&verifySpotMessageLink(owner,t);}));
  if(!claims.length)return{status:'pending'};const claim=only(claims,'unique executed claim');if(!claim.succeeded)return{status:'pending'};
  const before=readFaucetState(currentT3ActiveState(claim.before,pins.codeHash).data),after=readFaucetState(currentT3ActiveState(claim.after,pins.codeHash).data);
  check(before.supplyBase===pins.supplyBase&&after.supplyBase===pins.supplyBase&&before.nextWire+1n===after.nextWire,'faucet transition');
  const amount=before.grants[p.asset],wire=before.nextWire,claimer=after.claimers.get(Address.parse(p.owner)),sourceWallet=before.slots.get(p.asset)?.wallet;
  check(sourceWallet&&before.slots.get(p.asset)!.master.equals(pin.master)&&after.slots.get(p.asset)?.wallet?.equals(sourceWallet)
    &&before.available[p.asset]-after.available[p.asset]===amount&&claimer?.last[p.asset]===claim.tx.now&&claimer.wire[p.asset]===wire,'allocated source command');
  const sources=txs.filter(t=>t.account===raw(sourceWallet)&&verifySpotMessageLink(claim,t)&&tryRead(()=>{const m=input(t,p.faucet),q=decodeSpotTokenTransfer(m.body);
    return q.query===wire&&q.amount===amount&&q.owner===p.owner&&q.response===p.owner&&!q.custom&&q.forwardValue===0n&&empty(q.payload);}));
  if(!sources.length)return{status:'pending'};const source=only(sources,'unique source transfer');
  // A source refusal restores inventory and the same allocated cooldown only
  // through its actual bounced message. It never counts as token delivery.
  if(!source.succeeded){
    const restored=txs.filter(t=>t.account===p.faucet&&t.succeeded&&verifySpotMessageLink(source,t)&&tryRead(()=>{
      const m=t.tx.inMessage;check(m?.info.type==='internal'&&m.info.bounced&&raw(m.info.src)===source.account,'source refusal bounce');
      const prior=readFaucetState(currentT3ActiveState(t.before,pins.codeHash).data),next=readFaucetState(currentT3ActiveState(t.after,pins.codeHash).data),o=Address.parse(p.owner);
      check(prior.claimers.get(o)?.wire[p.asset]===wire&&next.claimers.get(o)?.wire[p.asset]===wire&&prior.claimers.get(o)!.last[p.asset]>0&&next.claimers.get(o)!.last[p.asset]===0,'exact cooldown restoration');
      check(next.available[p.asset]-prior.available[p.asset]===amount&&balance(source,b,p.asset,p.faucet,true)===balance(source,b,p.asset,p.faucet,false),'inventory restored without source debit');return true;
    }));
    if(!restored.length)return{status:'pending'};const bounce=only(restored,'unique grant restoration');
    return{status:'restored',transactionHash:bounce.hash,faucetTransactionHash:claim.hash,sourceTransactionHash:source.hash,amountRaw:amount.toString(),wire:wire.toString()};
  }
  const recipients=txs.filter(t=>t.account===b.recipientWallet&&verifySpotMessageLink(source,t)&&tryRead(()=>{
    const m=input(t,source.account);if(p.asset===0){const s=m.body.beginParse();check(s.loadUint(32)===T3_OP.T3_WALLET_DELIVERY,'current T3 delivery');const a=t3WalletAttemptFromCell(s.loadRef());s.endParse();
      return !a.burn&&a.originLt===source.tx.lt&&a.attempt===0n&&raw(a.owner)===p.faucet&&raw(a.recipient)===p.owner&&a.amount===amount&&a.details.queryId===wire
        &&raw(a.details.response)===p.owner&&!a.details.customPayload&&a.details.forwardValue===0n&&empty(either(a.details.forwardPayload.beginParse()));}
    const q=decodeSpotTokenTransfer(m.body,true);return q.query===wire&&q.amount===amount&&q.owner===p.faucet&&q.response===p.owner&&q.forwardValue===0n&&empty(q.payload);
  }));
  if(!recipients.length)return{status:'pending'};const recipient=only(recipients,'unique recipient credit');if(!recipient.succeeded)return{status:'pending'};
  delta(source,b,p.asset,p.faucet,-amount);delta(recipient,b,p.asset,p.owner,amount);
  return{status:'delivered',transactionHash:recipient.hash,faucetTransactionHash:claim.hash,sourceTransactionHash:source.hash,amountRaw:amount.toString(),wire:wire.toString()};
 }catch{return{status:'unavailable'};}
}
export async function readFaucetEvidence(request:FaucetEvidenceRequest,binding:FaucetEvidenceBinding,signal?:AbortSignal):Promise<FaucetEvidence>{
  try{const value=await indexerRequest('/v1/faucet/operation-evidence',{method:'POST',body:request,signal});return decodeFaucetEvidence(value,request,binding);}catch{return{status:'unavailable'};}
}
