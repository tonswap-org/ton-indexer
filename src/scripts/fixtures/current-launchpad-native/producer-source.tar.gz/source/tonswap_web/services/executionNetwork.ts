export type ExecutionNetwork = 'mainnet' | 'testnet' | 'localnet';
/** A validated immutable release manifest is the execution identity. Public
 * wallet chain selection never remaps a local qualification ledger. */
export function resolveExecutionNetwork(
  manifestNetwork: unknown,
  runtimeNetwork: unknown,
  manifestInvalid = false,
): ExecutionNetwork | null {
  if (manifestInvalid) return null;
  if (manifestNetwork !== null && manifestNetwork !== undefined) {
    if (manifestNetwork === 'ton:mainnet') return 'mainnet';
    if (manifestNetwork === 'ton:testnet') return 'testnet';
    if (manifestNetwork === 'ton:localnet') return 'localnet';
    return null;
  }
  return runtimeNetwork === 'mainnet' ||
    runtimeNetwork === 'testnet' ||
    runtimeNetwork === 'localnet'
    ? runtimeNetwork
    : null;
}
