import { Address, beginCell, Cell, contractAddress, loadShardAccount } from '@ton/core';
import { Buffer } from 'buffer';
import { TONSWAP_RELEASE } from '../releaseManifest';
import { appExecutionNetwork } from './appExecutionNetwork';
import { indexerRequest } from './indexer';
import { currentT3ActiveState, currentT3Cell, verifyCurrentT3Transaction, verifyCurrentT3MessageLink, type CurrentT3Transaction } from './t3CurrentEvidence';
import { decodeLaunchChild, launchChildren, readLaunchpadState, readLaunchpadRecoveryState, readLaunchpadRecoveryReceipt } from './launchpadContracts';
import { readT3ReceiptTree, readT3WalletStorage, t3WalletInitialData, t3WalletAttemptFromCell, verifyT3Witness } from './t3Contracts';
import { decodeSpotTokenTransfer } from './spotSwapChainProof';
import { validLaunchpadRequest } from './launchpadOperationStore';
import type { LaunchpadEvidenceRequest, LaunchpadProofBinding } from './launchpadOperationSettlement';
export type LaunchpadHolderCandidate = { key:string;kind:'notification'|'failure';holder:string;wallet:string;sourceLt:string;sourceHash:string;target:string;targetLt:string;targetHash:string;
 requestBoc:string;receiverRequestBoc:string;receiptBodyBoc:string;wire:string;amountRaw:string;recordBoc:string|null;proofBoc:string };
export type LaunchpadHolderRecovery = LaunchpadHolderCandidate & {status:'certificate-required'|'claim-receipt'|'claimed';head:{seqno:number;utime:number;rootHashHex:string};walletCodeBoc:string;sourceBeforeAccountBoc:string;sourceAfterAccountBoc:string};
export type LaunchpadHolderRecoveries = {status:'ready';candidates:LaunchpadHolderRecovery[]}|{status:'unavailable'};
const exact=(v:unknown,keys:string[]):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).sort().join()===keys.sort().join();
const digest=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
function check(v:unknown):asserts v{if(!v)throw Error('Unverified Launchpad holder recovery');}
const raw=(a:Address)=>a.toRawString();
const one=<T>(v:T[])=>{check(v.length===1);return v[0];};
const uint=(v:unknown,bits=64)=>{check(typeof v==='string'&&/^(0|[1-9][0-9]{0,36})$/.test(v));const n=BigInt(v);check(n<1n<<BigInt(bits));return n;};
const emptyRoot=()=>{let h=beginCell().storeUint(0,8).endCell().hash();for(let i=0;i<64;i++)h=beginCell().storeUint(4,8).storeBuffer(h).storeBuffer(h).endCell().hash();return BigInt('0x'+h.toString('hex'));};
export function holderReceiptAbsent(key:bigint,proof:Cell,root:bigint){let h=beginCell().storeUint(0,8).endCell().hash(),node=proof;for(let i=0;i<64;i++){check(!node.isExotic);const s=node.beginParse(),other=s.loadBuffer(32),tail=s.loadMaybeRef();s.endParse();check((tail===null)===(i===63));h=(key>>BigInt(i)&1n)===0n?beginCell().storeUint(4,8).storeBuffer(h).storeBuffer(other).endCell().hash():beginCell().storeUint(4,8).storeBuffer(other).storeBuffer(h).endCell().hash();if(tail)node=tail;}return BigInt('0x'+h.toString('hex'))===root;}
export function validLaunchpadHolderOriginal(p:LaunchpadEvidenceRequest){try{
 const{owner,dispatch,...r}=p;check(exact(dispatch,['lt','hash','valueNano'])&&uint(dispatch.lt)>0n&&digest(dispatch.hash)&&dispatch.valueNano===p.valueNano);
 return validLaunchpadRequest({...r,wallet:owner,destination:p.sourceWallet??p.target,validUntil:1});
}catch{return false;}}
const failed=(t:CurrentT3Transaction)=>t.tx.description.type==='generic'&&t.tx.description.aborted;
/** Current membership restores accounting only. Every source and target must
 * belong to the exact original dispatch graph; query equality is insufficient. */
export function decodeLaunchpadHolderRecoveries(value:unknown,p:LaunchpadEvidenceRequest,b:LaunchpadProofBinding,now=Date.now()):LaunchpadHolderRecoveries{
 try{
  check(validLaunchpadHolderOriginal(p)&&Buffer.byteLength(JSON.stringify(value))<=8*1024*1024);
  check(exact(value,['schema','releaseId','manifestHash','asOf','request','coverage','transactions','holders','candidates'])&&value.schema==='tonswap-launchpad-holder-recovery-evidence-v1'&&value.releaseId===p.releaseId&&value.manifestHash===p.manifestHash);
  check(exact(value.request,['kind','owner','bodyHash'])&&value.request.kind===p.kind&&value.request.owner===p.owner&&value.request.bodyHash===p.bodyHash);
  const h=value.asOf;check(exact(h,['masterchainSeqno','unixTime','blockRootHash'])&&Number.isSafeInteger(h.masterchainSeqno)&&h.masterchainSeqno>=b.state.head.seqno&&h.masterchainSeqno>0&&digest(h.blockRootHash)&&Number.isSafeInteger(h.unixTime)&&h.unixTime>0&&h.unixTime<=0xffffffff&&h.unixTime*1000<=now+5000&&now-h.unixTime*1000<=30000&&(h.masterchainSeqno!==b.state.head.seqno||h.blockRootHash===b.state.head.rootHashHex));
  check(exact(value.coverage,['complete','gaps'])&&value.coverage.complete===true&&Array.isArray(value.coverage.gaps)&&value.coverage.gaps.length===0);
  const ids=launchChildren(b.state,Address.parse(p.creator),BigInt(p.nonce),p.model);check(p.factory===raw(b.state.binding.factory)&&p.sale===raw(ids.sale));
  check(Array.isArray(value.transactions)&&value.transactions.length<=256&&value.transactions.every((e:unknown)=>exact(e,['account','transactionBoc','beforeShardAccountBoc','afterShardAccountBoc'])));
  const txs:CurrentT3Transaction[]=value.transactions.map(verifyCurrentT3Transaction).sort((a:CurrentT3Transaction,c:CurrentT3Transaction)=>a.tx.lt<c.tx.lt?-1:1);check(new Set(txs.map(t=>t.hash)).size===txs.length&&txs.every(t=>t.tx.now<=h.unixTime));
  const original=one(txs.filter(t=>t.account===p.owner&&t.hash===p.dispatch.hash&&String(t.tx.lt)===p.dispatch.lt));check(original.succeeded&&original.tx.now*1000>=p.createdAt-300000);
  const first=one(txs.filter(t=>t.account===(p.sourceWallet??p.target)&&verifyCurrentT3MessageLink(original,t)&&t.tx.inMessage?.body.equals(currentT3Cell(p.bodyBoc))));
  const m=first.tx.inMessage;check(m?.info.type==='internal'&&!m.info.bounced&&raw(m.info.src)===p.owner&&String(m.info.value.coins)===p.valueNano);
  const causal=new Set([first.hash]);for(const t of txs)if(txs.some(a=>causal.has(a.hash)&&verifyCurrentT3MessageLink(a,t)))causal.add(t.hash);
  check(Array.isArray(value.holders)&&value.holders.length<=2&&new Set(value.holders.map((v:any)=>v.address)).size===value.holders.length&&Array.isArray(value.candidates)&&value.candidates.length<=32&&new Set(value.candidates.map((v:any)=>v.key)).size===value.candidates.length);
  const holders=new Map<string,{root:bigint;pending:bigint;wallet:string;code:Cell}>();
  const walletState=(shard:CurrentT3Transaction['after'],owner:string,wallet:string)=>{const a=currentT3ActiveState(shard,b.state.binding.t3WalletHash),s=readT3WalletStorage(a.data);check(a.splitDepth===null&&raw(s.owner)===owner&&raw(s.master)===raw(b.state.binding.t3Root)&&s.proofCodeHash===BigInt('0x'+b.proofCodeHash)&&raw(contractAddress(0,{code:a.code,data:t3WalletInitialData(s.owner,s.master,s.proofCodeHash)}))===wallet);return{...s,code:a.code};};
  for(const v of value.holders){
   check(exact(v,['address','shardAccountBoc','wallet'])&&exact(v.wallet,['address','shardAccountBoc']));const role=v.address===raw(ids.sale)?0:v.address===raw(ids.lp)?1:-1;check(role>=0);
   const shard=loadShardAccount(currentT3Cell(v.shardAccountBoc).beginParse());check(shard.account?.addr.toRawString()===v.address);const code=b.state.factory.codes.get(role===0?p.model:3)!.code,a=currentT3ActiveState(shard,code.hash().toString('hex'));check(a.splitDepth===null);
   const child=decodeLaunchChild(a.data),id=child.identity;check(id.role===role&&id.kind===p.model&&raw(id.factory)===p.factory&&raw(id.creator)===p.creator&&id.nonce===BigInt(p.nonce));const slot=child.slots.get(0);check(slot?.wallet&&slot.wallet.toRawString()===v.wallet.address&&slot.master.equals(b.state.binding.t3Root)&&slot.budget.creditProtection);
   const state=child.recovery.get(0);check(state);const recovery=readLaunchpadRecoveryState(state!),tree=recovery.tree?readT3ReceiptTree(recovery.tree):null;
   const walletShard=loadShardAccount(currentT3Cell(v.wallet.shardAccountBoc).beginParse());check(walletShard.account?.addr.toRawString()===v.wallet.address);const ws=walletState(walletShard,v.address,v.wallet.address);
   holders.set(v.address,{root:tree?.root??emptyRoot(),pending:recovery.pending,wallet:v.wallet.address,code:ws.code});
  }
  const candidates:LaunchpadHolderRecovery[]=[];
  for(const c of value.candidates){
   check(exact(c,['key','kind','holder','wallet','sourceLt','sourceHash','target','targetLt','targetHash','requestBoc','receiverRequestBoc','receiptBodyBoc','wire','amountRaw','recordBoc','proofBoc'])&&['notification','failure'].includes(c.kind));
   const holder=holders.get(c.holder);check(holder&&c.wallet===holder.wallet&&c.key===`${c.holder}:${c.sourceLt}:${c.sourceHash}`&&digest(c.sourceHash)&&digest(c.targetHash));const sourceLt=uint(c.sourceLt),targetLt=uint(c.targetLt),amount=uint(c.amountRaw,120),wire=uint(c.wire);check(sourceLt>0n&&targetLt>=sourceLt&&amount>0n);
   const source=one(txs.filter(t=>t.account===c.wallet&&t.tx.lt===sourceLt&&t.hash===c.sourceHash)),target=one(txs.filter(t=>t.account===c.target&&t.tx.lt===targetLt&&t.hash===c.targetHash));check(causal.has(source.hash)&&failed(target));
   const incoming=source.tx.inMessage,request=currentT3Cell(c.requestBoc),receiverRequest=currentT3Cell(c.receiverRequestBoc),receiptBody=currentT3Cell(c.receiptBodyBoc);check(incoming?.info.type==='internal'&&!incoming.info.bounced&&incoming.body.equals(request));
   if(c.kind==='notification'){
    const s=request.beginParse();check(s.loadUint(32)===0x5433444c&&s.loadRef().equals(receiverRequest));s.endParse();const a=t3WalletAttemptFromCell(receiverRequest);check(source.succeeded&&!a.burn&&raw(a.recipient)===c.holder&&a.amount===amount&&a.details.queryId===wire&&a.details.forwardValue>0n&&c.target===c.holder&&targetLt>sourceLt&&verifyCurrentT3MessageLink(source,target));
    const expected=beginCell().storeUint(0x7362d09c,32).storeUint(wire,64).storeCoins(amount).storeAddress(a.owner).storeSlice(a.details.forwardPayload.beginParse()).endCell();check(receiptBody.equals(expected)&&target.tx.inMessage?.body.equals(expected)&&source.outgoing.get(0)&&target.incoming&&source.outgoing.get(0)!.equals(target.incoming));
    const after=walletState(source.after,c.holder,c.wallet),before=source.before.account?.storage.state.type==='active'?walletState(source.before,c.holder,c.wallet):null;
    if(!before){check(!source.before.account||source.before.account.storage.state.type==='uninit');check(incoming.init&&contractAddress(0,incoming.init).toRawString()===c.wallet&&incoming.init.data?.equals(t3WalletInitialData(Address.parse(c.holder),b.state.binding.t3Root,BigInt('0x'+b.proofCodeHash)))&&incoming.init.code?.equals(holder.code));}
    check(after.balance-(before?.balance??0n)===amount&&after.protectedCredits-(before?.protectedCredits??0n)===amount&&after.acceptedTransfers===(before?.acceptedTransfers??0n));
   }else{
    check(failed(source)&&raw(incoming.info.src)===c.holder&&receiverRequest.equals(request)&&receiptBody.equals(request));const transfer=decodeSpotTokenTransfer(request);check(transfer.amount===amount&&transfer.query===wire&&!transfer.custom);
    one(txs.filter(t=>t.account===c.holder&&t.succeeded&&causal.has(t.hash)&&verifyCurrentT3MessageLink(t,source)));
    if(c.target===c.wallet)check(target===source&&source.tx.outMessages.values().every(m=>m.info.type!=='internal'));
    else{check(c.target===c.holder&&targetLt>sourceLt&&verifyCurrentT3MessageLink(source,target)&&source.tx.outMessages.size===1&&target.tx.inMessage?.info.type==='internal'&&target.tx.inMessage.info.bounced&&source.outgoing.get(0)&&target.incoming&&source.outgoing.get(0)!.equals(target.incoming));const q=target.tx.inMessage!.body.beginParse();check(q.loadUint(32)===0xfffffffe&&q.loadRef().equals(request));}
   }
   const proof=currentT3Cell(c.proofBoc);let status:LaunchpadHolderRecovery['status']='certificate-required';
   if(c.recordBoc===null)check(holderReceiptAbsent(sourceLt,proof,holder.root));else{const record=currentT3Cell(c.recordBoc),rec=readLaunchpadRecoveryReceipt(record);check(rec.key===sourceLt&&rec.incoming===(c.kind==='notification')&&rec.amount===amount&&rec.body.equals(receiptBody)&&verifyT3Witness(record,sourceLt,proof,holder.root));status=rec.claimed?'claimed':'claim-receipt';if(!rec.claimed)check(holder.pending>=amount);}
   const rawSource=one(value.transactions.filter((e:any)=>e.account===c.wallet&&verifyCurrentT3Transaction(e).hash===c.sourceHash));
   candidates.push({...c as LaunchpadHolderCandidate,status,head:{seqno:h.masterchainSeqno,utime:h.unixTime,rootHashHex:h.blockRootHash},walletCodeBoc:holder.code.toBoc().toString('base64'),sourceBeforeAccountBoc:currentT3Cell(rawSource.beforeShardAccountBoc).refs[0].toBoc().toString('base64'),sourceAfterAccountBoc:currentT3Cell(rawSource.afterShardAccountBoc).refs[0].toBoc().toString('base64')});
  }
  return{status:'ready',candidates};
 }catch{return{status:'unavailable'};}
}
export async function readLaunchpadHolderRecoveries(original:LaunchpadEvidenceRequest,signal?:AbortSignal):Promise<LaunchpadHolderRecoveries>{
 try{signal?.throwIfAborted();const release=TONSWAP_RELEASE,p=structuredClone(original);check(release&&p.network===appExecutionNetwork&&release.network===`ton:${p.network}`&&p.releaseId===release.releaseId&&p.manifestHash===release.manifestHash);
  const state=await readLaunchpadState(null,{signal}),value=await indexerRequest('/v1/launchpad/holder-recovery-evidence',{method:'POST',body:p,signal,timeoutMs:20000,maxAttempts:1,cache:'no-store'});signal?.throwIfAborted();check(TONSWAP_RELEASE===release&&JSON.stringify(p)===JSON.stringify(original));
  return decodeLaunchpadHolderRecoveries(value,p,{state,proofCodeHash:release.templates.T3RecoveryProof,v21WalletHash:release.templates.JettonV21Wallet,stablecoinWalletHash:release.vendor.stablecoin.wallet.codeHash});
 }catch(e){if(signal?.aborted)throw signal.reason;return{status:'unavailable'};}
}
