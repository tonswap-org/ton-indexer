import { Buffer } from 'buffer';
import { getTransactions, readChain } from './toncenter';
import type { AccountTip, OwnerHead, StandardWalletKind, WalletRequestChain } from './walletRequest';

export const STANDARD_WALLET_CODE_HASHES: Readonly<Record<string, StandardWalletKind>> = Object.freeze({
  b61041a58a7980b946e8fb9e198e3c904d24799ffa36574ea4251c41a566f581: 'v3r1',
  '84dafa449f98a6987789ba232358072bc0f76dc4524002a5d0918b9a75d2d599': 'v3r2',
  feb5ff6820e2ff0d9483e7e0d62c817d846789fb4ae580c878866d959dabd5c0: 'v4r2',
  '20834b7b72b112147e1b2fb457b84e74d1a30f04f737d4f62a668e9552d2b72f': 'v5r1',
});
const zero = { lt: '0', hash: '0'.repeat(64) };
const tips = new Map<string, { at: number; pending: Promise<AccountTip> }>();

export const walletRequestChain: WalletRequestChain = {
  async readOwnerHead(owner, signal, lane = 'user'): Promise<OwnerHead> {
    const observation = await readChain([{ kind: 'account', address: owner }], {
      anchored: true, lane, deadlineMs: 12_000, signal,
    });
    const account = observation.results[0], head = observation.head;
    if (!head || !Number.isSafeInteger(head.utime) || head.utime! <= 0 || !Number.isSafeInteger(head.seqno) || head.seqno <= 0)
      throw new Error('The wallet head has no chain anchor.');
    let wallet = account.code ? STANDARD_WALLET_CODE_HASHES[account.code.hash().toString('hex')] ?? null : null;
    let seqno: number | null = null;
    if (wallet && account.data) {
      try {
        const data = account.data.beginParse();
        if (wallet === 'v5r1') {
          const signaturesAllowed = data.loadBit();
          seqno = data.loadUint(32);
          data.skip(32 + 256);
          const hasExtensions = data.loadBit();
          if (!signaturesAllowed || hasExtensions || data.remainingBits || data.remainingRefs) wallet = null;
        } else seqno = data.loadUint(32);
      } catch { wallet = null; }
    } else wallet = null;
    if (!wallet) seqno = null;
    if (account.state === 'active' && wallet && seqno! >= 1 && account.lastTx === null)
      throw new Error('An active wallet sequence requires its last transaction.');
    return { ...(account.lastTx ?? zero), chainTime: head.utime!, mcSeqno: head.seqno,
      state: account.state, balance: account.balance, wallet, seqno };
  },
  async readAccountTip(account, signal) {
    if (signal?.aborted) throw signal.reason;
    const now = performance.now(), cached = tips.get(account);
    if (cached && now - cached.at < 4_000) {
      const result = await cached.pending;
      if (signal?.aborted) throw signal.reason;
      return result;
    }
    const pending = readChain([{ kind: 'account', address: account }], { lane: 'background', signal })
      .then(observation => ({ ...(observation.results[0].lastTx ?? zero), source: observation.source }));
    const entry = { at: now, pending };
    tips.set(account, entry);
    try { return await pending; } catch (error) { if (tips.get(account) === entry) tips.delete(account); throw error; }
  },
  readTransactions(account, from, limit, signal) {
    return getTransactions(account, Math.min(32, limit), {
      lt: from.lt, hash: Buffer.from(from.hash, 'hex').toString('base64'),
    }, { raw: true, lane: 'background', signal });
  },
};
