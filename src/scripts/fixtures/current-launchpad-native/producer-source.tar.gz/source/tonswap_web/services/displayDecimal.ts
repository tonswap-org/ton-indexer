/** Exact decimal arithmetic for presentation. Transaction amounts retain their own atomic-unit validation. */
export type DisplayDecimal = { coefficient: bigint; scale: number };
export function displayDecimal(value: number | string | null | undefined): DisplayDecimal | null {
  if (value == null || (typeof value !== 'string' && typeof value !== 'number')) return null;
  const text = String(value).trim();
  if (text.length > 1200) return null;
  const match = /^([+-]?)(\d+(?:\.\d*)?|\.\d+)(?:e([+-]?\d{1,4}))?$/i.exec(text);
  if (!match) return null;
  const [whole, fraction = ''] = match[2]!.split('.'); const exponent = Number(match[3] ?? 0);
  if (Math.abs(exponent) > 1000) return null;
  let coefficient = BigInt((match[1] === '-' ? '-' : '') + (whole || '0') + fraction);
  let scale = fraction.length - exponent;
  if (scale < 0) { coefficient *= 10n ** BigInt(-scale); scale = 0; }
  return { coefficient, scale };
}
export function displayDecimalString(value: DisplayDecimal): string {
  const negative = value.coefficient < 0n; const digits = (negative ? -value.coefficient : value.coefficient).toString().padStart(value.scale + 1, '0');
  const fraction = value.scale ? digits.slice(-value.scale).replace(/0+$/, '') : '';
  return `${negative ? '-' : ''}${value.scale ? digits.slice(0, -value.scale) : digits}${fraction ? '.' + fraction : ''}`;
}
export function multiplyDisplay(...values: (number | string | null | undefined)[]): string | null {
  let product: DisplayDecimal = { coefficient: 1n, scale: 0 };
  for (const value of values) { const parsed = displayDecimal(value); if (!parsed) return null;
    product = { coefficient: product.coefficient * parsed.coefficient, scale: product.scale + parsed.scale }; }
  return displayDecimalString(product);
}
export function sumDisplay(values: (number | string | null | undefined)[]): string | null {
  const parsed = values.map(displayDecimal).filter((value): value is DisplayDecimal => value !== null);
  if (!parsed.length) return null;
  const scale = Math.max(...parsed.map(value => value.scale));
  return displayDecimalString({ coefficient: parsed.reduce((sum, value) => sum + value.coefficient * 10n ** BigInt(scale - value.scale), 0n), scale });
}
export function rawDisplay(raw: string | bigint | null | undefined, decimals: number): string | null {
  if (raw == null || !/^\d+$/.test(String(raw)) || !Number.isInteger(decimals) || decimals < 0 || decimals > 30) return null;
  return displayDecimalString({ coefficient: BigInt(raw), scale: decimals });
}
