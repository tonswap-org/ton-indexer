import { Address, beginCell, Cell } from '@ton/core';
import { AppError } from './appError';
import { parseAmountInput } from './tonUnits';
const invalid = (devMessage: string) => new AppError('errors.unknown', {}, { devMessage });

export type JettonWalletBudget = {
    senderGas: number; walletBounceGas: number; burnWalletGas: number; smallPayloadCells: number; largeWalletGas: number; largeSenderGas: number; rentSeconds: number; rentBits: number; rentCells: number;
    initBits: number; initCells: number; initCopies: number;
    transferBits: number; transferCells: number; transferCopies: number; creditProtection: boolean;
};
export type JettonWalletProfile = { walletGas: number; walletGram: bigint; budget: JettonWalletBudget };
export const JETTON_V21_WALLET_GAS = 14_000;
export const JETTON_DEFAULT_WALLET_GAS = 30_000;
export const JETTON_WALLET_RENT_SECONDS = 157_680_000;

/** Explicit opt-in for ordinary TEP-74 wallet implementations with the qualified v2.1 bounds. */
export function standardJettonWalletProfile(walletGas: number, walletGram = 0n): JettonWalletProfile {
    return { walletGas, walletGram, budget: { senderGas: walletGas, walletBounceGas: 0, burnWalletGas: walletGas, smallPayloadCells: 65535, largeWalletGas: walletGas, largeSenderGas: walletGas, rentSeconds: JETTON_WALLET_RENT_SECONDS,
        rentBits: 1100, rentCells: 3, initBits: 8500, initCells: 18, initCopies: 1,
        transferBits: 880, transferCells: 1, transferCopies: 3, creditProtection: false } };
}
export const JETTON_V21_WALLET_PROFILE = standardJettonWalletProfile(JETTON_V21_WALLET_GAS);
export const JETTON_DEFAULT_WALLET_PROFILE = standardJettonWalletProfile(JETTON_DEFAULT_WALLET_GAS);

/** Fresh T3: a funded source, one cold recipient, and both possible frontier appends. */
export function t3JettonWalletProfile(walletCode: Cell): JettonWalletProfile {
    const seen = new Set<string>();
    let codeBits = 0;
    const visit = (cell: Cell) => {
        const hash = cell.hash().toString('hex');
        if (seen.has(hash)) return;
        seen.add(hash); codeBits += cell.bits.length;
        for (const ref of cell.refs) visit(ref);
    };
    visit(walletCode);
    // Config, state and journal include a maximum-width Coins balance. The code
    // wrapper matches the wallet's cold-rent helper; each append adds <=2/292.
    const coldCells = seen.size + 4, coldBits = codeBits + 2069;
    const profile: JettonWalletProfile = { walletGas: 200000, walletGram: 0n, budget: {
        senderGas: 150000, walletBounceGas: 125000, burnWalletGas: 400000, smallPayloadCells: 62, largeWalletGas: 500000, largeSenderGas: 250000,
        rentSeconds: JETTON_WALLET_RENT_SECONDS, rentCells: coldCells + 4, rentBits: coldBits + 584,
        initCells: seen.size + 4, initBits: codeBits + 2074, initCopies: 2,
        // Full private delivery (1340 bits/5 cells) plus rich-bounce metadata.
        // Five envelopes cover command, delivery, bounce, notification and excess.
        transferBits: 1698, transferCells: 7, transferCopies: 5, creditProtection: true,
    } };
    validateJettonWalletProfile(profile);
    return profile;
}

export function jettonWalletBudgetToCell(p: JettonWalletBudget): Cell {
    const b = beginCell();
    for (const [key, width] of [['senderGas',32],['walletBounceGas',32],['burnWalletGas',32],['smallPayloadCells',16],['largeWalletGas',32],['largeSenderGas',32],['rentSeconds',32],['rentBits',32],['rentCells',16],
        ['initBits',32],['initCells',16],['initCopies',8],['transferBits',16],['transferCells',8],['transferCopies',8]] as const) {
        if (!Number.isInteger(p[key]) || (key === 'walletBounceGas' ? p[key] < 0 : p[key] <= 0) || p[key] >= 2 ** width) throw invalid(`Invalid wallet budget ${key}`);
        b.storeUint(p[key], width);
    }
    if (p.walletBounceGas > 500000 || p.senderGas < 10000 || p.initCopies > 4 || p.transferBits < 880 || p.transferCopies < 3 || p.transferCopies > 8) throw invalid('Invalid wallet budget bounds');
    if (typeof p.creditProtection !== 'boolean') throw invalid('Explicit credit protection capability required');
    return b.storeBit(p.creditProtection).endCell();
}
export function decodeJettonWalletBudget(cell: Cell): JettonWalletBudget {
    const s = cell.beginParse(), p = { senderGas: s.loadUint(32), walletBounceGas: s.loadUint(32), burnWalletGas: s.loadUint(32), smallPayloadCells: s.loadUint(16), largeWalletGas: s.loadUint(32), largeSenderGas: s.loadUint(32), rentSeconds: s.loadUint(32), rentBits: s.loadUint(32), rentCells: s.loadUint(16),
        initBits: s.loadUint(32), initCells: s.loadUint(16), initCopies: s.loadUint(8),
        transferBits: s.loadUint(16), transferCells: s.loadUint(8), transferCopies: s.loadUint(8), creditProtection: s.loadBit() };
    s.endParse(); jettonWalletBudgetToCell(p); return p;
}
export function validateJettonWalletProfile(p: JettonWalletProfile): void {
    jettonWalletBudgetToCell(p.budget);
    if (!Number.isInteger(p.walletGas) || p.walletGas < 10000 || p.walletGas > 500000 || p.budget.senderGas > p.walletGas || p.budget.burnWalletGas < p.budget.senderGas || p.budget.burnWalletGas > 2000000 || p.budget.largeSenderGas < p.budget.senderGas || p.budget.largeWalletGas < p.walletGas || p.budget.largeSenderGas > p.budget.largeWalletGas || p.budget.largeWalletGas > 2000000
        || p.walletGram < 0n || p.walletGram > 500000000n) throw invalid('Invalid wallet gas or GRAM floor');
}

/** Current basechain prices, read from the same network as the quoted pool. */
export type JettonQuotePrices = {
    gas: { flatGasPrice: bigint; flatLimit: bigint; other: { gasPrice: bigint } };
    forward: { lumpPrice: bigint; bitPrice: bigint; cellPrice: bigint };
    storage: { bit_price_ps: bigint; cell_price_ps: bigint };
};
const ceil16 = (value: bigint) => (value + 65535n) >> 16n;
export function jettonGasValue(prices: JettonQuotePrices, gas: number): bigint {
    if (!Number.isSafeInteger(gas) || gas < 0) throw invalid('Invalid gas amount');
    const p = prices.gas, units = BigInt(gas);
    return p.flatGasPrice + (units <= p.flatLimit ? 0n : ceil16((units - p.flatLimit) * p.other.gasPrice));
}
export function jettonForwardValue(prices: JettonQuotePrices, bits: number, cells: number, includeLump = true): bigint {
    if (![bits, cells].every(n => Number.isSafeInteger(n) && n >= 0)) throw invalid('Invalid message geometry');
    const p = prices.forward;
    return (includeLump ? p.lumpPrice : 0n) + ceil16(BigInt(bits) * p.bitPrice + BigInt(cells) * p.cellPrice);
}
export function jettonRentValue(prices: JettonQuotePrices, seconds: number, bits: number, cells: number): bigint {
    if (![seconds, bits, cells].every(n => Number.isSafeInteger(n) && n >= 0)) throw invalid('Invalid rent geometry');
    const p = prices.storage;
    return ceil16(BigInt(seconds) * (BigInt(bits) * p.bit_price_ps + BigInt(cells) * p.cell_price_ps));
}

/** Mirrors jetton_leg_bounds; each source/recipient transaction pays its own flat gas charge. */
export function jettonLegBounds(prices: JettonQuotePrices, profile: JettonWalletProfile, payloadBits = 0, payloadCells = 0, bounceGas = 0) {
    validateJettonWalletProfile(profile);
    const p = profile.budget, large = payloadCells > p.smallPayloadCells;
    const sender = large ? p.largeSenderGas : p.senderGas, total = large ? p.largeWalletGas : profile.walletGas;
    const own = jettonGasValue(prices, sender) + jettonGasValue(prices, total - sender)
        + jettonRentValue(prices, p.rentSeconds, p.rentBits, p.rentCells);
    const accepted = BigInt(p.transferCopies) * jettonForwardValue(prices, p.transferBits + payloadBits, p.transferCells + payloadCells)
        + BigInt(p.initCopies) * jettonForwardValue(prices, p.initBits, p.initCells, false)
        + (own > profile.walletGram ? own : profile.walletGram) + 1n;
    const downstream = p.walletBounceGas === 0 ? 0n : accepted + jettonGasValue(prices, p.walletBounceGas);
    if (bounceGas === 0) return { accepted, refused: downstream };
    const refused = jettonGasValue(prices, sender) + jettonGasValue(prices, bounceGas)
        + jettonRentValue(prices, JETTON_WALLET_RENT_SECONDS, 1100, 3)
        + 4n * jettonForwardValue(prices, 1238 + payloadBits, 3 + payloadCells) + 1n;
    return { accepted, refused: refused > downstream ? refused : downstream };
}

/** Profile funding assumes the source wallet's existing retained rent is already funded. */
export function jettonLegValue(prices: JettonQuotePrices, profile: JettonWalletProfile, forwardGram = 0n, payloadBits = 0, payloadCells = 0, bounceGas = 0): bigint {
    if (forwardGram < 0n) throw invalid('Negative forward value');
    const { accepted, refused } = jettonLegBounds(prices, profile, payloadBits, payloadCells, bounceGas);
    return accepted + forwardGram > refused ? accepted + forwardGram : refused;
}


export type JettonTransfer = { queryId?: bigint; amount: bigint; destination: Address; responseDestination: Address | null;
    customPayload?: Cell | null; forwardGram: bigint; forwardPayload?: Cell | null; either?: 'inline' | 'ref' };
/** Standard TEP-74: forward payload is Either Cell ^Cell, never Maybe ^Cell. */
export function jettonTransferBody(t: JettonTransfer): Cell {
    if (t.amount <= 0n || t.amount >= 1n << 120n || t.forwardGram < 0n || t.destination.workChain !== 0
        || (t.responseDestination && t.responseDestination.workChain !== 0)) throw invalid('Invalid transfer terms');
    const b = beginCell().storeUint(0x0f8a7ea5, 32).storeUint(t.queryId ?? 0n, 64).storeCoins(t.amount)
        .storeAddress(t.destination).storeAddress(t.responseDestination).storeMaybeRef(t.customPayload).storeCoins(t.forwardGram);
    if (!t.forwardPayload) return b.storeBit(false).endCell();
    if (t.forwardPayload.isExotic) throw invalid('Exotic transfer payload');
    return (t.either === 'inline' ? b.storeBit(false).storeSlice(t.forwardPayload.beginParse()) : b.storeBit(true).storeRef(t.forwardPayload)).endCell();
}
export function parseJettonAmount(text: string, decimals: number): bigint {
    const parsed = parseAmountInput(text, decimals);
    if (!parsed.ok || parsed.raw <= 0n || parsed.raw >= 1n << 120n) throw invalid('Invalid token amount or precision');
    return parsed.raw;
}
/** Distinct-cell geometry, including the root, matching the contract's payload walk. */
export function payloadGeometry(root: Cell): { bits: number; cells: number } {
    const seen = new Set<string>(); let bits = 0;
    const visit = (cell: Cell) => { if (cell.isExotic) throw invalid('Exotic payload graph'); const hash = cell.hash().toString('hex');
        if (seen.has(hash)) return; seen.add(hash); bits += cell.bits.length; cell.refs.forEach(visit); };
    visit(root); return { bits, cells: seen.size };
}
/** Full wallet attachment, not just pool forward. Existing source rent must be independently funded. */
export function quoteJettonTransfer(prices: JettonQuotePrices, profile: JettonWalletProfile, transfer: JettonTransfer): bigint {
    jettonTransferBody(transfer);
    const shape = transfer.forwardPayload ? payloadGeometry(transfer.forwardPayload) : { bits: 0, cells: 0 };
    return jettonLegValue(prices, profile, transfer.forwardGram, shape.bits, shape.cells);
}

/** Wallet-review input. The destination is the token owner/pool; `to` is its authenticated source wallet. */
export function prepareJettonTransfer(wallet: Address, prices: JettonQuotePrices, profile: JettonWalletProfile, transfer: JettonTransfer) {
    if (wallet.workChain !== 0) throw invalid('Invalid source wallet');
    return { to: wallet, value: quoteJettonTransfer(prices, profile, transfer), body: jettonTransferBody(transfer), bounce: true as const };
}
