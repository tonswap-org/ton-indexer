import { Address, beginCell, Builder, Cell, Slice } from '@ton/core';
import { Dictionary } from '@ton/core';
import { Buffer } from 'buffer';
import { AppError } from './appError';
import { ChainReadError } from './chainReadError';
import type { ChainCall, ChainObservation, ReadChainOptions, GetterArg } from './toncenter';
import { decodeJettonWalletBudget, validateJettonWalletProfile, payloadGeometry, type JettonWalletProfile } from './jettonWalletProfile';
const OP = { SWAP: 0x53575033, SWAP_RESULT: 0x53575233, SWAP_OUTCOME: 0x53574f33, SWAP_EVENT: 0x53574533, ROUTE_CONT: 0x52435433 };
export const spotError = (devMessage: string) => new AppError('errors.unknown', {}, { devMessage });

export const NOTIFY_GAS = 24_000;
export const POOL_REFUND_GAS_MAX = 400_000;
export const POOL_REFUND_SEND_GAS_MAX = 95_000;
export const POOL_ROUTE_REFUND_SEND_GAS_MAX = 110_000;
export const POOL_BOUNCE_GAS = 250_000;
export const COORD_BOUNCE_GAS = 250_000;
export const ROUTE_GAS_MAX = 48_000;
export const PAYLOAD_RECIPIENT_GAS = 65_000;

export const SwapStatus = { EXECUTED: 0, REFUND: 1, INPUT_OWED: 2, REFUND_PLAIN: 3 } as const;
export const SwapReason = {
    NONE: 0, MALFORMED: 1, NOT_READY: 2, PAUSED: 3, DEADLINE: 4, ADDRESS: 5, VALUE: 6,
    SLIPPAGE: 7, LIQUIDITY: 8, MATH: 10, PAYLOAD_SIZE: 11, BIN: 12, WRONG_SIDE: 13,
    MIN_VALUE: 14, CAPACITY: 15, STAKED: 16, ROUTE: 17,
} as const;

export type Swap = {
    minOut: bigint; deadline: number; recipient: Address; refundTo: Address; notifyOrigin: boolean;
    fwdGram: bigint; refundFwdGram: bigint; fwdPayload: Cell | null;
};
export type SwapResult = {
    queryId: bigint; origin: Address; status: number; reason: number;
    amountIn: bigint; amountOut: bigint; user: Cell | null;
};
export type SwapOutcome = {
    queryId: bigint; status: number; reason: number; inSide: number; amountIn: bigint; amountOut: bigint;
};
export type SwapEvent = SwapOutcome & {
    origin: Address; grossFeeT3: bigint; protocolFeeT3: bigint; activeBin: number; binsLoaded: number;
};
export type RouteCont = { pool: Address; swap: Cell };
type Payload = Cell | Slice;

// A slice must already have been opened as an ordinary cell by the TEP-74 decoder.
// Cloning leaves that decoder's cursor untouched. A public cell input is checked here.
function parse<T>(payload: Payload, op: number, read: (s: Slice) => T): T | null {
    try {
        if (payload instanceof Cell && payload.isExotic) return null;
        const s = payload instanceof Cell ? payload.beginParse() : payload.clone();
        if (s.loadUint(32) !== op) return null;
        const value = read(s);
        s.endParse();
        return value;
    } catch { return null; }
}

function address(s: Slice): Address {
    if (s.preloadUint(11) !== 0b10000000000) throw spotError('Expected a standard workchain-0 address');
    return s.loadAddress();
}

function ordinary(c: Cell): Cell {
    if (c.isExotic) throw spotError('Expected an ordinary payload cell');
    return c;
}

function maybeRef(s: Slice): Cell | null {
    return s.loadBit() ? ordinary(s.loadRef()) : null;
}

function disposition(status: number, reason: number, maxStatus: number, inSide = 0) {
    if (status > maxStatus || reason > SwapReason.ROUTE || reason === 9 || inSide > 1) {
        throw spotError('Unknown swap disposition');
    }
}

// Apply the same address and disposition rules to outgoing values as to incoming cells.
function encoded<T>(builder: Builder, decode: (cell: Cell) => T | null): Cell {
    const cell = builder.endCell();
    if (decode(cell) === null) throw spotError('Invalid swap wire fields');
    return cell;
}

export function encodeSwap(swap: Swap): Cell {
    return encoded(beginCell().storeUint(OP.SWAP, 32).storeCoins(swap.minOut).storeUint(swap.deadline, 32)
        .storeAddress(swap.recipient).storeAddress(swap.refundTo).storeBit(swap.notifyOrigin)
        .storeCoins(swap.fwdGram).storeCoins(swap.refundFwdGram).storeMaybeRef(swap.fwdPayload), decodeSwap);
}

export function decodeSwap(payload: Payload): Swap | null {
    return parse(payload, OP.SWAP, s => ({
        minOut: s.loadCoins(), deadline: s.loadUint(32), recipient: address(s), refundTo: address(s),
        notifyOrigin: s.loadBit(), fwdGram: s.loadCoins(), refundFwdGram: s.loadCoins(), fwdPayload: maybeRef(s),
    }));
}

export function encodeSwapResult(result: SwapResult): Cell {
    return encoded(beginCell().storeUint(OP.SWAP_RESULT, 32).storeUint(result.queryId, 64).storeAddress(result.origin)
        .storeUint(result.status, 8).storeUint(result.reason, 8).storeCoins(result.amountIn).storeCoins(result.amountOut)
        .storeMaybeRef(result.user), decodeSwapResult);
}

export function decodeSwapResult(payload: Payload): SwapResult | null {
    return parse(payload, OP.SWAP_RESULT, s => {
        const result = {
            queryId: s.loadUintBig(64), origin: address(s), status: s.loadUint(8), reason: s.loadUint(8),
            amountIn: s.loadCoins(), amountOut: s.loadCoins(), user: maybeRef(s),
        };
        disposition(result.status, result.reason, SwapStatus.REFUND);
        return result;
    });
}

export function encodeSwapOutcome(outcome: SwapOutcome): Cell {
    return encoded(beginCell().storeUint(OP.SWAP_OUTCOME, 32).storeUint(outcome.queryId, 64)
        .storeUint(outcome.status, 8).storeUint(outcome.reason, 8).storeUint(outcome.inSide, 8)
        .storeCoins(outcome.amountIn).storeCoins(outcome.amountOut), decodeSwapOutcome);
}

export function decodeSwapOutcome(payload: Payload): SwapOutcome | null {
    return parse(payload, OP.SWAP_OUTCOME, s => {
        const outcome = {
            queryId: s.loadUintBig(64), status: s.loadUint(8), reason: s.loadUint(8), inSide: s.loadUint(8),
            amountIn: s.loadCoins(), amountOut: s.loadCoins(),
        };
        disposition(outcome.status, outcome.reason, SwapStatus.INPUT_OWED, outcome.inSide);
        return outcome;
    });
}

export function encodeSwapEvent(event: SwapEvent): Cell {
    return encoded(beginCell().storeUint(OP.SWAP_EVENT, 32).storeUint(event.queryId, 64).storeAddress(event.origin)
        .storeUint(event.inSide, 8).storeUint(event.status, 8).storeUint(event.reason, 8)
        .storeCoins(event.amountIn).storeCoins(event.amountOut).storeCoins(event.grossFeeT3).storeCoins(event.protocolFeeT3)
        .storeInt(event.activeBin, 32).storeUint(event.binsLoaded, 8), decodeSwapEvent);
}

export function decodeSwapEvent(payload: Payload): SwapEvent | null {
    return parse(payload, OP.SWAP_EVENT, s => {
        const event = {
            queryId: s.loadUintBig(64), origin: address(s), inSide: s.loadUint(8), status: s.loadUint(8), reason: s.loadUint(8),
            amountIn: s.loadCoins(), amountOut: s.loadCoins(), grossFeeT3: s.loadCoins(), protocolFeeT3: s.loadCoins(),
            activeBin: s.loadInt(32), binsLoaded: s.loadUint(8),
        };
        disposition(event.status, event.reason, SwapStatus.REFUND_PLAIN, event.inSide);
        return event;
    });
}

export function encodeRouteCont(cont: RouteCont): Cell {
    return encoded(beginCell().storeUint(OP.ROUTE_CONT, 32).storeAddress(cont.pool).storeRef(cont.swap), decodeRouteCont);
}

/** Keeps the inner cell intact. The destination pool separately parses it as Swap. */
export function decodeRouteCont(payload: Payload): RouteCont | null {
    return parse(payload, OP.ROUTE_CONT, s => ({ pool: address(s), swap: ordinary(s.loadRef()) }));
}

export type SwapPool = {
    address: Address;
    getPoolInfo(): Promise<{ ready: boolean; t3Master: Address; id: { xMaster: Address } }>;
    getSwapValue(inSide: number, amountIn: bigint, swap: Cell): Promise<{ status: number; reason: number; value: bigint; amountOut: bigint }>;
};
export type SwapRequest = Swap & { pool: SwapPool; inputMaster: Address; amountIn: bigint };

/** Quotes the exact single-pool request. poolForwardGram excludes the sending wallet's fee. */
export async function buildSwap(request: SwapRequest): Promise<{ payload: Cell; inSide: number; poolForwardGram: bigint; amountOut: bigint }> {
    if (request.amountIn <= 0n || request.minOut <= 0n) throw spotError('A swap requires positive input and minimum output');
    const info = await request.pool.getPoolInfo();
    if (!info.ready) throw spotError('The swap pool must be ready');
    const inSide = request.inputMaster.equals(info.t3Master) ? 0 : request.inputMaster.equals(info.id.xMaster) ? 1 : -1;
    if (inSide < 0) throw spotError('Swap input does not match either pool token');
    const payload = encodeSwap(request);
    const quote = await request.pool.getSwapValue(inSide, request.amountIn, payload);
    if (quote.status !== 0 || quote.amountOut < request.minOut || quote.value <= 0n) throw spotError(`Swap pool refused the quote: ${quote.reason}`);
    return { payload, inSide, poolForwardGram: quote.value, amountOut: quote.amountOut };
}

export type RoutePool = SwapPool & {
    getQuote(inSide: number, amountIn: bigint): Promise<{ status: number; amountOut: bigint }>;
};
export type RouteRequest = {
    pool1: RoutePool; pool2: RoutePool; inputMaster: Address; amountIn: bigint; recipient: Address; refundTo: Address;
    minT3: bigint; finalMin: bigint; deadline: number; fwdGram: bigint; refundFwdGram: bigint; fwdPayload?: Cell | null;
};

function routePayloadFits(root: Cell): boolean {
    const seen = new Set<string>();
    const todo = [root];
    while (todo.length > 0) {
        const cell = todo.pop()!;
        const hash = cell.hash().toString('hex');
        if (seen.has(hash)) continue;
        seen.add(hash);
        if (seen.size > 7) return false;
        todo.push(...cell.refs);
    }
    return true;
}

/** Quotes X -> T3 -> X from current getter values. poolForwardGram excludes the sender wallet's fee. */
export async function buildRoute(request: RouteRequest): Promise<{ payload: Cell; inner: Cell; poolForwardGram: bigint }> {
    const r = request;
    if (r.amountIn <= 0n || r.minT3 <= 0n || r.finalMin <= 0n || r.pool1.address.equals(r.pool2.address)) throw spotError('A route requires positive amounts and distinct pools');
    const [first, second] = await Promise.all([r.pool1.getPoolInfo(), r.pool2.getPoolInfo()]);
    if (!first.ready || !second.ready) throw spotError('Both route pools must be ready');
    if (r.inputMaster.equals(first.t3Master)) throw spotError('A route cannot start with T3');
    if (!r.inputMaster.equals(first.id.xMaster) || !first.t3Master.equals(second.t3Master)) {
        throw spotError('Route pool tokens do not match');
    }
    const inner = encodeSwap({
        minOut: r.finalMin, deadline: r.deadline, recipient: r.recipient, refundTo: r.refundTo, notifyOrigin: false,
        fwdGram: r.fwdGram, refundFwdGram: r.refundFwdGram, fwdPayload: r.fwdPayload ?? null,
    });
    // The destination admits seven cells for Swap and its payload; RCT3 is the eighth at hop 1.
    if (!routePayloadFits(inner)) throw spotError('A routed inner swap must fit seven cells');
    const firstQuote = await r.pool1.getQuote(1, r.amountIn);
    if (firstQuote.status !== 0 || firstQuote.amountOut < r.minT3) throw spotError('First route pool cannot fill this amount');
    const secondQuote = await r.pool2.getSwapValue(0, firstQuote.amountOut, inner);
    if (secondQuote.status !== 0 || secondQuote.amountOut < r.finalMin) throw spotError(`Second route pool refused the quote: ${secondQuote.reason}`);
    const payload = encodeSwap({
        minOut: r.minT3, deadline: r.deadline, recipient: r.pool2.address, refundTo: r.refundTo, notifyOrigin: false,
        fwdGram: secondQuote.value, refundFwdGram: r.refundFwdGram, fwdPayload: encodeRouteCont({ pool: r.pool2.address, swap: inner }),
    });
    const firstValue = await r.pool1.getSwapValue(1, r.amountIn, payload);
    if (firstValue.status !== 0) throw spotError(`First route pool refused the quote: ${firstValue.reason}`);
    return { payload, inner, poolForwardGram: firstValue.value };
}

/** Inject the existing readChain seam; no global endpoints or signing side effects. */
export type FreshChainRead = (calls: readonly ChainCall[], options?: ReadChainOptions) => Promise<ChainObservation>;
export const freshInt = (value: number | bigint): GetterArg => ({ type: 'int', value: BigInt(value) });
export const freshAddressArg = (value: Address): GetterArg => ({ type: 'slice', cell: beginCell().storeAddress(value).endCell() });
export class FreshStack {
    private index = 0;
    constructor(private readonly entries: readonly [string, unknown][]) {}
    private next() { const entry = this.entries[this.index++]; if (!entry) throw spotError('Missing getter field'); return entry; }
    int(): bigint {
        const [type, value] = this.next();
        if (type !== 'num' || !(typeof value === 'string' || typeof value === 'number' && Number.isSafeInteger(value))) throw spotError('Invalid integer stack field');
        const s = String(value); if (!/^[+-]?(?:0x[0-9a-fA-F]+|\d+)$/.test(s)) throw spotError('Invalid integer encoding');
        const sign = s[0] === '-' ? -1n : 1n; return sign * BigInt(s.replace(/^[+-]/, ''));
    }
    uint(bits = 120): bigint { const n = this.int(); if (n < 0n || n >= 1n << BigInt(bits)) throw spotError('Out-of-range getter integer'); return n; }
    number(bits = 32): number { return Number(this.uint(bits)); }
    bool(): boolean { const n = this.int(); if (n !== 0n && n !== -1n) throw spotError('Invalid TVM boolean'); return n !== 0n; }
    cell(optional = false): Cell | null {
        const [type, value] = this.next(); if (optional && type === 'null' && value === null) return null;
        if (!['cell', 'slice', 'tvm.Cell', 'tvm.Slice'].includes(type)) throw spotError('Invalid cell stack field');
        const bytes = typeof value === 'string' ? value : value && typeof value === 'object' && 'bytes' in value ? (value as { bytes: unknown }).bytes : null;
        if (typeof bytes !== 'string') throw spotError('Missing getter BOC');
        const roots = Cell.fromBoc(Buffer.from(bytes, 'base64')); if (roots.length !== 1 || roots[0].isExotic) throw spotError('Invalid getter BOC'); return roots[0];
    }
    address(optional = false): Address | null {
        const c = this.cell(optional); if (c === null) return null;
        const s = c.beginParse(), a = s.loadMaybeAddress(); s.endParse();
        if ((!optional && !a) || a && a.workChain !== 0) throw spotError('Invalid basechain getter address'); return a;
    }
    end() { if (this.index !== this.entries.length) throw spotError('Unexpected getter fields'); }
}
export async function freshGet(read: FreshChainRead, address: Address, method: string, args: readonly GetterArg[] = [], options: ReadChainOptions = {}) {
    const observation = await read([{ kind: 'getter', address: address.toRawString(), method, args }], { lane: 'user', anchored: true, ...options });
    if (!observation.head || !Number.isSafeInteger(observation.head.seqno) || observation.head.seqno <= 0) throw new ChainReadError('unavailable', { devMessage: 'Unanchored fresh contract read' });
    const result = observation.results[0];
    if (!result || result.kind !== 'getter' || result.exitCode !== 0 || observation.results.length !== 1) throw spotError(`Failed ${method}`);
    return { stack: new FreshStack(result.stack), head: observation.head };
}
export async function verifyFreshCode(read: FreshChainRead, address: Address, codeHash: string) {
    if (!/^[0-9a-f]{64}$/.test(codeHash)) throw spotError('Missing release code hash');
    const observation = await read([{ kind: 'account', address: address.toRawString() }], { lane: 'user', anchored: true });
    const a = observation.results[0];
    if (!observation.head || !a || a.kind !== 'account' || a.state !== 'active' || a.code?.hash().toString('hex') !== codeHash) throw spotError('Contract code differs from release');
    return observation.head;
}
export type FreshPoolId = { xMaster: Address; binSpacing: number; feePips: number; xDecimals: number; walletGasX: number; walletGramX: bigint; walletBudgetX: JettonWalletProfile['budget'] };
export function decodeFreshPoolId(cell: Cell): FreshPoolId {
    if (cell.isExotic) throw spotError('Exotic pool identity');
    const s = cell.beginParse(); const id = { xMaster: s.loadAddress(), binSpacing: s.loadUint(16), feePips: s.loadUint(32), xDecimals: s.loadUint(8),
        walletGasX: s.loadUint(32), walletGramX: s.loadCoins(), walletBudgetX: decodeJettonWalletBudget(s.loadRef()) }; s.endParse();
    validateJettonWalletProfile({ walletGas: id.walletGasX, walletGram: id.walletGramX, budget: id.walletBudgetX });
    if (id.xMaster.workChain !== 0 || id.binSpacing < 1 || id.binSpacing > 10000 || id.feePips > 100000 || id.xDecimals > 18) throw spotError('Invalid pool identity'); return id;
}
export type FreshJettonSlot = JettonWalletProfile & { master: Address; wallet: Address | null; optional: boolean };
export async function readFreshJettonSlots(read: FreshChainRead, holder: Address) {
    const { stack } = await freshGet(read, holder, 'get_jetton_slots'); const root = stack.cell(true); stack.end();
    return Dictionary.loadDirect(Dictionary.Keys.Uint(8), { serialize() { throw spotError('Read-only slot codec'); }, parse(s): FreshJettonSlot {
        const value = { master: s.loadAddress(), wallet: s.loadMaybeAddress(), walletGas: s.loadUint(32), walletGram: s.loadCoins(), optional: s.loadBit(), budget: decodeJettonWalletBudget(s.loadRef()) };
        s.endParse(); validateJettonWalletProfile(value); if (value.master.workChain !== 0 || value.wallet && value.wallet.workChain !== 0) throw spotError('Invalid slot peer'); return value;
    } }, root);
}
/** Each quote uses current data. Code identity is verified before exposing a pool for transaction preparation. */
export function createSpotPool(read: FreshChainRead, address: Address, expectedCodeHash: string) {
    const get = (method: string, args: readonly GetterArg[] = []) => freshGet(read, address, method, args);
    return {
        address,
        async getPoolInfo() {
            await verifyFreshCode(read, address, expectedCodeHash);
            const { stack: s, head } = await get('get_pool_info'); const id = decodeFreshPoolId(s.cell()!);
            const info = { id, factory: s.address()!, feeSink: s.address()!, treasury: s.address()!, t3Master: s.address()!, flags: s.number(8), ready: s.bool(),
                activeBin: Number(s.int()), reserveT: s.uint(), reserveX: s.uint(), protocolFeesT3: s.uint(), binCount: s.number(16), positionCount: s.number(16), campaignCount: s.number(8), head };
            s.end(); return info;
        },
        getJettonSlots: () => readFreshJettonSlots(read, address),
        async getQuote(side: number, amount: bigint) {
            const { stack: s } = await get('get_quote', [freshInt(side), freshInt(amount)]);
            const q = { status: s.number(8), amountOut: s.uint(), grossFeeT3: s.uint(), protocolFeeT3: s.uint(), finalBin: Number(s.int()), binsLoaded: s.number(8) }; s.end(); return q;
        },
        async getSwapValue(side: number, amount: bigint, swap: Cell) {
            const { stack: s } = await get('get_swap_value', [freshInt(side), freshInt(amount), { type: 'cell', cell: swap }]);
            const q = { status: s.number(8), reason: s.number(8), value: s.uint(), amountOut: s.uint() }; s.end(); return q;
        },
        async getSwapCheck(side: number, amount: bigint, swap: Cell, value: bigint) {
            const { stack: s } = await get('get_swap_check', [freshInt(side), freshInt(amount), { type: 'cell', cell: swap }, freshInt(value)]);
            const q = { status: s.number(8), reason: s.number(8), amountOut: s.uint() }; s.end(); return q;
        },
        async getFillLimit(side: number) { const { stack: s } = await get('get_fill_limit', [freshInt(side)]); const q = { amountIn: s.uint(), amountOut: s.uint() }; s.end(); return q; },
    };
}
export function createSpotCoordinator(read: FreshChainRead, address: Address, expectedCodeHash: string) {
    return { address, async getReady() {
        await verifyFreshCode(read, address, expectedCodeHash); const { stack: s } = await freshGet(read, address, 'get_coordinator_info');
        const peers = { governance: s.address()!, treasury: s.address()!, ready: s.bool() }; s.end();
        const slots = await readFreshJettonSlots(read, address); return { ...peers, t3Master: slots.get(0)?.master, wallet: slots.get(0)?.wallet };
    }, async getRouteMinForward(hop2Forward: bigint) { const { stack: s } = await freshGet(read, address, 'get_route_min_forward', [freshInt(hop2Forward)]); const value = s.uint(); s.end(); return value; } };
}
export type CoordinatorRouteRequest = RouteRequest & { coordinator: ReturnType<typeof createSpotCoordinator> };
/** Explicit retained-coordinator route. It never silently replaces the direct two-pool SDK route. */
export async function buildCoordinatorRoute(r: CoordinatorRouteRequest) {
    if (r.amountIn <= 0n || r.minT3 <= 0n || r.finalMin <= 0n || r.pool1.address.equals(r.pool2.address)) throw spotError('Invalid route amounts or pools');
    const [first, second, coordinator] = await Promise.all([r.pool1.getPoolInfo(), r.pool2.getPoolInfo(), r.coordinator.getReady()]);
    if (!first.ready || !second.ready || !coordinator.ready || !coordinator.wallet || !coordinator.t3Master?.equals(first.t3Master)
        || !first.t3Master.equals(second.t3Master) || !r.inputMaster.equals(first.id.xMaster)) throw spotError('Unready or mismatched coordinator route');
    const inner = encodeSwap({ minOut: r.finalMin, deadline: r.deadline, recipient: r.recipient, refundTo: r.refundTo, notifyOrigin: false,
        fwdGram: r.fwdGram, refundFwdGram: r.refundFwdGram, fwdPayload: r.fwdPayload ?? null });
    if (payloadGeometry(inner).cells > 7) throw spotError('Routed payload exceeds seven cells');
    const firstQuote = await r.pool1.getQuote(1, r.amountIn);
    if (firstQuote.status !== 0 || firstQuote.amountOut < r.minT3) throw spotError('First route cannot meet minimum');
    const secondQuote = await r.pool2.getSwapValue(0, firstQuote.amountOut, inner);
    if (secondQuote.status !== 0 || secondQuote.amountOut < r.finalMin) throw spotError('Second route cannot meet minimum');
    const coordinatorForwardGram = await r.coordinator.getRouteMinForward(secondQuote.value);
    const payload = encodeSwap({ minOut: r.minT3, deadline: r.deadline, recipient: r.coordinator.address, refundTo: r.refundTo, notifyOrigin: false,
        fwdGram: coordinatorForwardGram, refundFwdGram: r.refundFwdGram, fwdPayload: encodeRouteCont({ pool: r.pool2.address, swap: inner }) });
    const q = await r.pool1.getSwapValue(1, r.amountIn, payload); if (q.status !== 0) throw spotError(`First route refused: ${q.reason}`);
    return { payload, inner, poolForwardGram: q.value, coordinatorForwardGram, amountOut: secondQuote.amountOut };
}
export const claimOwedBody = (slot: number, owner: Address, queryId = 0n) => beginCell().storeUint(0x434c4d4a, 32).storeUint(queryId, 64).storeUint(slot, 8).storeAddress(owner).endCell();
export type ArchivedSpotClaim = { slot: number; id: bigint; owner: Address; amount: bigint; proof: Cell };
export const claimArchivedBody = (r: ArchivedSpotClaim, queryId = 0n) => beginCell().storeUint(0x434c4d41, 32).storeUint(queryId, 64).storeUint(r.slot, 8)
    .storeUint(r.id, 64).storeAddress(r.owner).storeCoins(r.amount).storeRef(r.proof).endCell();
export async function readSpotOwed(read: FreshChainRead, holder: Address, slot: number, owner: Address) {
    const calls: ChainCall[] = [
        { kind: 'getter', address: holder.toRawString(), method: 'get_owed', args: [freshInt(slot), freshAddressArg(owner)] },
        ...['get_owed_book', 'get_owed_archive', 'get_min_claim', 'get_min_archive_claim'].map(method => ({ kind: 'getter' as const, address: holder.toRawString(), method, args: [freshInt(slot)] })),
    ];
    const observation = await read(calls, { lane: 'user', anchored: true });
    if (!observation.head || observation.results.length !== 5) throw new ChainReadError('unavailable');
    const values = observation.results.map(r => { if (r.kind !== 'getter' || r.exitCode !== 0) throw spotError('Owed snapshot unavailable'); return { stack: new FreshStack(r.stack) }; });
    const [owed, book, archive, direct, archived] = values.map(x => x.stack);
    const result = { amount: owed.uint(), total: book.uint(), directCount: book.number(16), archive: { count: archive.uint(65), root: archive.uint(256), total: archive.uint() },
        claimValue: direct.uint(), archiveClaimValue: archived.uint() }; values.forEach(x => x.stack.end()); return result;
}
/** Checks a supplied exact 64-level archive proof against the CURRENT get_owed_archive root. */
export function verifyArchivedSpotClaim(holder: Address, claim: ArchivedSpotClaim, root: bigint): boolean {
    try {
        if (claim.amount <= 0n || claim.amount >= 1n << 120n || claim.owner.workChain !== 0) return false;
        let hash = beginCell().storeUint(1, 8).storeAddress(holder).storeUint(claim.slot, 8).storeUint(claim.id, 64).storeAddress(claim.owner).storeUint(claim.amount, 120).endCell().hash();
        let proof: Cell | null = claim.proof, id = claim.id;
        for (let i = 0; i < 64; i++) {
            if (!proof || proof.isExotic) return false; const s = proof.beginParse(), sibling = s.loadBuffer(32); proof = s.loadMaybeRef(); s.endParse();
            hash = beginCell().storeUint(3, 8).storeBuffer(id & 1n ? sibling : hash).storeBuffer(id & 1n ? hash : sibling).endCell().hash(); id >>= 1n;
        }
        return proof === null && id === 0n && BigInt('0x' + hash.toString('hex')) === root;
    } catch { return false; }
}
export async function prepareArchivedSpotClaim(read: FreshChainRead, holder: Address, request: ArchivedSpotClaim, queryId = 0n) {
    const { stack: s } = await freshGet(read, holder, 'get_owed_archive', [freshInt(request.slot)]); const count = s.uint(65), root = s.uint(256); s.uint(); s.end();
    if (request.id >= count || !verifyArchivedSpotClaim(holder, request, root)) throw spotError('Missing or stale archive proof');
    const { stack: q } = await freshGet(read, holder, 'get_min_archive_claim', [freshInt(request.slot)]); const value = q.uint(); q.end();
    return { to: holder, value, body: claimArchivedBody(request, queryId), bounce: true, root };
}

export function decodeRouteEvent(cell: Cell) {
    if (cell.isExotic) return null;
    try { const s = cell.beginParse(); if (s.loadUint(32) !== 0x52544533) return null;
        const r = { queryId: s.loadUintBig(64), status: s.loadUint(8), reason: s.loadUint(8), amount: s.loadCoins(), pool: s.loadMaybeAddress(), beneficiary: s.loadAddress() }; s.endParse(); return r;
    } catch { return null; }
}
export async function prepareSpotClaim(read: FreshChainRead, holder: Address, slot: number, owner: Address, queryId = 0n) {
    const owed = await readSpotOwed(read, holder, slot, owner); if (owed.amount <= 0n) throw spotError('No direct owed claim');
    return { to: holder, value: owed.claimValue, body: claimOwedBody(slot, owner, queryId), bounce: true, amount: owed.amount };
}
