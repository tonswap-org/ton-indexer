import path from 'node:path';
import {
  existsSync,
  lstatSync,
  mkdirSync,
  realpathSync
} from 'node:fs';

const assertExistingPathPrefixIsCanonical = (target: string) => {
  const parsed = path.parse(target);
  let current = parsed.root;
  for (const segment of target.slice(parsed.root.length).split(path.sep)) {
    if (!segment) continue;
    current = path.join(current, segment);
    if (!existsSync(current)) break;
    const info = lstatSync(current);
    if (
      info.isSymbolicLink() ||
      (!info.isDirectory() && current !== target) ||
      realpathSync(current) !== current
    ) {
      throw new Error(
        'TONSWAP_RELEASE_VITE_CACHE_DIR must not traverse symlinks or non-directory ancestors.'
      );
    }
  }
};

export const resolveReleaseViteCacheDir = (
  value: string | undefined,
  fallback?: string
): string | undefined => {
  const selected = value === undefined || value === '' ? fallback : value;
  if (selected === undefined || selected === '') return undefined;
  if (
    selected.trim() !== selected ||
    selected.includes('\0') ||
    !path.isAbsolute(selected) ||
    path.resolve(selected) !== selected ||
    selected.split(path.sep).includes('node_modules')
  ) {
    throw new Error(
      'TONSWAP_RELEASE_VITE_CACHE_DIR must be an absolute canonical path outside node_modules.'
    );
  }
  assertExistingPathPrefixIsCanonical(selected);
  mkdirSync(selected, { recursive: true, mode: 0o700 });
  const info = lstatSync(selected);
  if (
    !info.isDirectory() ||
    info.isSymbolicLink() ||
    (info.mode & 0o777) !== 0o700 ||
    realpathSync(selected) !== selected
  ) {
    throw new Error(
      'TONSWAP_RELEASE_VITE_CACHE_DIR must remain a canonical private 0700 directory.'
    );
  }
  return selected;
};
