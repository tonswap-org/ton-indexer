import type { CatalogTree } from '../../message.ts';

/**
 * The wallet request: the review dialog, the reasons a request was never sent, and the wallet session
 * (connection problems, the signing prompt). This is the safety surface: every figure the person
 * approves is shown here first, so the copy is plain and exact. Shared verbs and labels come from
 * `common`; a caller's own rows (a swap, a claim) use keys from the caller's namespace.
 */
const review = {
  dialog: {
    keepShort: "After this request your wallet will have about {left} {symbol}. Finishing or closing this later needs {keep} {symbol}. You can continue now; add {symbol} before then.",
    proof: {
      unsupportedWallet: "This wallet type can't show us that an expired request was never sent. If you don't approve this request in time, it stays pending here until its result appears on TON.",
    },
    step: 'Wallet approval {current} of {total}',
    confirm: 'Confirm in wallet',
    cancel: 'Cancel',
    countdown: 'Time left to confirm: {time}',
    expired: 'Too little time is left to confirm. Cancel and prepare a fresh review.',
    detailsSummary: 'Transaction details · {count, plural, one {# message} other {# messages}}',
    from: 'From',
    message: 'Message {index}',
    copyAddress: 'Copy address',
    unreadable: {
      title: 'This request cannot be shown',
      body: 'A request that cannot be shown in full cannot be approved. Cancel and try again.'
    }
  },
  network: {
    mainnet: 'TON Mainnet',
    testnet: 'Test network',
    localnet: 'TON Localnet',
    unknown: 'Unknown network'
  },
  terms: {
    summary: 'Summary',
    request: 'Request details',
    transfer: 'Payment details',
    perps: 'Leverage order terms',
    option: 'Option transaction terms'
  },
  payload: {
    title: 'What this request signs',
    message: 'Message {index} of {count}',
    row: {
      action: 'Action',
      to: 'Sent to',
      contract: 'Contract',
      amount: 'GRAM in this message',
      tokenAmount: 'Token amount (raw units)',
      tokenRecipient: 'Token recipient',
      opCode: 'Operation code',
      comment: 'Comment',
      deploys: 'Contract deployment'
    },
    action: {
      transfer: 'GRAM transfer',
      jettonTransfer: 'Token transfer',
      call: 'Contract call'
    },
    value: {
      deploys: 'Includes contract code',
      opUnknown: 'Not available',
      none: 'None'
    },
    detail: {
      destination: 'Full address',
      contract: 'Contract (full address)',
      tokenRecipient: 'Token recipient (full address)',
      response: 'Excess GRAM goes to',
      queryId: 'Query ID',
      forwardAmount: 'GRAM forwarded to the recipient'
    }
  },
  row: {
    networkFunding: 'Total GRAM sent'
  },
  footnote: {
    refund: "This {symbol} pays for processing on TON. Do not count on any of it coming back.",
    escrow: 'This GRAM reserve must be confirmed by the Option contract.',
    retire: 'This attachment starts the escrow-funded retirement attempt. The previously funded writer escrow pays Pool work.',
    reserve: 'This request sends only the amount above. When it was prepared, your balance covered that amount plus {amount} {symbol} for network fees.',
    attached: "This {symbol} pays for processing on TON. Do not count on any of it coming back.",
    setup: 'The setup cost is sent with this request.'
  },
  transfer: {
    title: {
      send: 'Send {amount} {symbol}',
      activate: 'Set up recipient to receive {symbol}'
    },
    summary: {
      send: 'You are sending {amount} {symbol} to the address below.',
      activate: 'One-time setup so the recipient can receive {symbol}. This step sends no {symbol}; you approve the transfer separately.'
    },
    row: {
      amount: 'Amount',
      to: 'To',
      memo: 'Memo',
      feeReserve: 'Balance needed for network fees',
      feeAttached: 'Sent with this request for network fees',
    },
    atLeast: 'At least {amount} {symbol}'
  },
  perps: {
    title: {
      open: { long: 'Open long position', short: 'Open short position' },
      close: { long: 'Close long position', short: 'Close short position' }
    },
    summary: {
      open: 'You are opening a {side, select, long {long} other {short}} position on {asset}. Your stake of {collateral} T3 is at risk. You pay at most {maxDebit} T3. The request sends {funding} GRAM in total.',
      close: 'You are closing your full {side, select, long {long} other {short}} position of {size} {asset}. The T3 you get back depends on the price when it closes. The request sends {funding} GRAM in total.'
    },
    row: {
      market: 'Market',
      size: 'Position size',
      leverage: 'Leverage',
      collateral: 'Your stake at risk',
      maxFee: 'Maximum trading fee',
      maxDebit: 'Maximum T3 debit',
      returned: 'T3 return and trading fee',
      maxBuy: 'Maximum buy price',
      minSell: 'Minimum sell price',
    },
    value: {
      market: '{asset} / T3 · #{id}',
      size: '{amount} {asset} · {side, select, long {long} other {short}}',
      leverage: '{value}×',
      returned: 'Determined at execution',
      price: '{amount} T3 / {asset}',
    },
    group: {
      cap: 'How profit is capped'
    },
    note: {
      open: 'Gross price profit and positive funding share this limit; amounts used to cover losses or funding debt also count. Adding collateral or retrying settlement does not reset it. LP reserve does not increase the payout limit. Net profit and funding claims already include funding. {collateral} T3 is exposed to position losses. The maximum debit includes collateral and the fee budget; any unused fee budget is returned after settlement. Trading fees go to the protocol fee router; this release does not pay Perps referral rewards.',
      close: 'The returned T3 depends on the actual fill, realized profit or loss, funding and fees. The price limit is binding; a return amount is not guaranteed. Trading fees go to the protocol fee router; this release does not pay Perps referral rewards.'
    }
  },
  option: {
    headline: {
      payout: 'Estimated T3 payout',
      pay: 'T3 you pay',
      lock: 'T3 backing you lock',
      deposit: 'Total GRAM deposit',
      receive: 'T3 you receive',
      refund: 'T3 refund',
      send: 'T3 you send'
    }
  },
  notSent: {
    otherTab: "Another tab is using this wallet for a request. No wallet request was sent. Finish or cancel it there first.",
    locksUnavailable: "This browser can't coordinate wallet requests between tabs. No wallet request was sent. Use a current browser on a secure connection.",
    walletUnverified: "We couldn't check your wallet's balance and latest activity on TON. No wallet request was sent. Try again in a moment.",
    needGram: "You need {needed} {symbol} for this request: {attached} {symbol} is sent with it and {reserve} {symbol} must stay for your wallet's network fee. Your wallet has {have} {symbol}. No wallet request was sent.",
    requestPending: "An earlier request to the same address may still be approved in your wallet. No wallet request was sent. Try again after that request is confirmed on TON, or in {time}, when it can no longer be approved.",
    requestSigned: "Your wallet signed an earlier request to the same address with a later deadline than the one shown, and it has not appeared on TON yet. No wallet request was sent. Try again after that request is confirmed on TON.",
    clockSkew: "Your device's clock and TON disagree about this request's deadline. No wallet request was sent. Check your device's date and time, then review again.",
    recordUnsaved: "Your browser couldn't save this request before sending. No wallet request was sent. Allow site storage, then review again.",
    generic: 'No wallet request was sent.',
    busy: 'Finish the current wallet request before starting another.',
    invalid: 'The prepared request does not match the connected wallet, network, or validity period. Review the action again.',
    reviewExpired: 'This review expired before wallet approval. No wallet request was sent. Prepare a fresh review.',
    contextChanged: 'The wallet or page changed. No wallet request was sent. Review the action again.',
    tooLate: 'This request has too little time left for wallet approval. No wallet request was sent. Prepare a fresh review.',
    pageClosed: 'The page closed before approval. No wallet request was sent.',
    sessionChanged: 'The wallet, network, or page changed. No wallet request was sent. Review the action again.',
    notConfigured: 'TonConnect is not configured for this build. No wallet request was sent.',
    notConnected: 'Connect a wallet to continue. No wallet request was sent.',
    networkUnverified: 'Unable to verify the wallet network. No wallet request was sent.',
    tradingChanged: 'The trading context changed. No wallet request was sent. Review the action again.',
    tradingUnverified: 'The trading service could not be verified. No wallet request was sent.',
    tradingExpired: 'The trading context changed or expired. No wallet request was sent. Review the action again.',
    reviewChanged: 'The review changed or expired before dispatch. No wallet request was sent. Review the action again.',
    connectionChanged: 'The wallet connection changed. No wallet request was sent. Review the action again.',
    handoffChanged: 'The wallet connection or reviewed action changed. No wallet request was sent. Review the action again.',
    handoff: 'Unable to prepare the wallet handoff. No wallet request was sent.',
    verifyFailed: 'The request could not be checked against what you reviewed. No wallet request was sent. Review the action again.',
    verifyTimeout: 'Checking the request took too long. No wallet request was sent. Review the action again.',
    rowMismatch: 'A figure in this review does not match the request that would be signed. No wallet request was sent. Review the action again.',
    extraCurrency: 'This request carries an extra currency that cannot be shown. No wallet request was sent.'
  },
  outcome: {
    inWallet: "This request is still waiting in your wallet. Approve or decline it there.",
    checking: "The wallet request expired without a response. We're checking that nothing was sent. This takes about a minute.",
    signedLate: "Your wallet signed this request with a later deadline than the one shown. It stays saved here until that deadline has passed on TON or its result appears.",
    expired: "Expired: this request never reached TON, and it no longer can. You can try again.",
    neverSent: "This request never reached your wallet. Nothing was sent. You can try again.",
    unavailable: "We can't reach TON to check the expired request right now. We'll keep checking. Don't send it again.",
    newWallet: "This wallet hasn't sent a transaction yet, so we can't confirm that the expired request was never sent. Send any transaction from this wallet (for example, a faucet claim) and we'll check again.",
    unsupportedWallet: "Your wallet type doesn't let us confirm that the expired request can no longer be sent. It stays saved until its result appears on TON.",
    unreadableAnswer: "We couldn't read the signed message your wallet returned, so we can't confirm that this request can no longer be sent. It stays saved until its result appears on TON.",
    observed: "Your wallet sent this request. Checking its result on TON.",
    partial: "Your wallet sent only part of this request. Checking each part on TON.",
    ambiguous: "More than one transaction from your wallet matches this request, so we can't tell which one belongs to it. It stays saved here. Check your wallet's history.",
    rejected: "TON rejected this request and returned {returned} {symbol} to your wallet. Nothing was changed.",
    rejectedKept: "TON rejected this request. Nothing was changed, and the {symbol} sent with it was not returned.",
    exitCode: "Exit code {code}",
  },
  unprovable: {
    body: "We cannot prove that this request can no longer run. Discarding removes it from this browser only.",
    discard: "Discard this request",
    title: "Discard this request?",
    confirmation: "If you approved it in your wallet, it can still run. Discarding this request does not cancel it on TON.",
    checking: "Checking TON…",
    unavailable: "We could not verify the chain time. This request is still saved. Try again.",
  },
  expired: {
    noResponse: "The wallet request expired without a response. We're checking that nothing was sent."
  },
  session: {
    sentOnChain: "Your wallet sent the request. Checking the result.",
    issue: {
      picker: 'The wallet picker could not open. Check your connection, then try again.',
      restore: 'Your wallet could not reconnect. Try again and choose your wallet.',
      timeout: 'The wallet connection timed out. Try again and choose your wallet, or scan a fresh QR code in your wallet app.'
    },
    tryAgain: 'Try connecting again',
    networkMismatch: 'Connect a TON {network} wallet to transact.',
    openWallet: 'Open your wallet to continue.',
    testSignerActive: 'The test signer is active on localhost.',
    notConfigured: 'TonConnect is not configured for this build.',
    pickerError: 'Could not open the wallet picker.',
    cancelledInWallet: 'Transaction cancelled in your wallet.',
    walletError: 'The wallet connection reported an error.',
    disconnectFailed: 'Wallet data cleared. The wallet connection could not be closed; try again in your wallet.',
    loadFailed: 'Failed to load TonConnect UI. Check your network connection and reload.'
  },
  picker: {
    title: 'Connect wallet',
    loading: 'Loading wallets…',
    choose: 'Choose your wallet.',
    empty: 'No compatible wallets are available in this browser.',
    waiting: 'Approve the connection in {wallet}.',
    qrLabel: 'Connection QR code for {wallet}',
    scan: 'Scan this QR code with your wallet app, or open your wallet below.',
    openWallet: 'Open wallet',
    chooseAnother: 'Choose another wallet',
    failed: 'The wallet connection could not be started. Try again.',
    retry: 'Try again',
    help: 'How to connect',
    helpBody: 'Choose an installed wallet or scan the QR code with your wallet app. Connecting shares your address; every transaction still needs your approval. Close this dialog to cancel a pending connection.'
  },
  prompt: {
    elsewhere: "A request is waiting in your wallet",
    opening: 'Opening your wallet…',
    confirm: 'Confirm in your wallet',
    expires: 'Expires in {time}',
    open: 'Open wallet',
    dismiss: 'Dismiss wallet prompt'
  }
} satisfies CatalogTree;

export default review;
