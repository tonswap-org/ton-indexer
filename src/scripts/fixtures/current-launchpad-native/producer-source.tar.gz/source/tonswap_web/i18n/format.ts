import { isPseudoLocale, type AppLocale } from './meta.ts';

/**
 * Intl bound to the app locale. Every figure the app prints (amounts, counts,
 * percentages, dates, times) uses Latin digits and the Gregorian calendar so a
 * number reads the same in the wallet, the explorer and this app, whatever the
 * language. The locale still decides separators, order and plural rules.
 */

const LATIN_DIGITS = 'nu-latn';

/** `en-u-nu-latn`: appends a Unicode extension without clobbering an existing one. */
function withExtension(tag: string, extension: string): string {
  const keywords = extension.split('-').reduce<string[][]>((pairs, part, index) => {
    if (index % 2 === 0) pairs.push([part]);
    else pairs[pairs.length - 1].push(part);
    return pairs;
  }, []);
  let result = tag;
  for (const [key, value] of keywords) {
    if (new RegExp(`-u(?:-[a-z0-9]{2,8})*?-${key}(?:-|$)`, 'i').test(result)) continue;
    result += result.includes('-u-') ? `-${key}-${value}` : `-u-${key}-${value}`;
  }
  return result;
}

/** Tag for money and amounts: the locale's separators with Latin digits. */
export const moneyTag = (tag: string): string => withExtension(tag, LATIN_DIGITS);

const supportedTags = new Map<string, string>();

/**
 * The BCP 47 tag Intl should use for an app locale. A locale the runtime has no
 * number data for (for example `dv` in some engines) resolves to English, never
 * to the device default, so output cannot depend on the device.
 */
export function intlTag(locale: AppLocale): string {
  const base = isPseudoLocale(locale) ? (locale === 'ar-XB' ? 'ar' : 'en') : locale;
  const cached = supportedTags.get(base);
  if (cached) return cached;
  let tag = 'en';
  try {
    if (Intl.NumberFormat.supportedLocalesOf([base]).length > 0) tag = base;
  } catch {
    tag = 'en';
  }
  supportedTags.set(base, tag);
  return tag;
}

export type NumberInput = number | bigint;
export type DateInput = Date | number | string;

export interface RelativeOptions {
  /** Reference instant; defaults to now. */
  now?: DateInput;
  numeric?: Intl.RelativeTimeFormatNumeric;
  style?: Intl.RelativeTimeFormatStyle;
}

export interface Formatters {
  readonly locale: AppLocale;
  /** Number with the locale's separators and Latin digits. */
  n(value: NumberInput, options?: Intl.NumberFormatOptions): string;
  /** Date and time, Gregorian calendar, Latin digits. Defaults to a medium date. */
  d(value: DateInput, options?: Intl.DateTimeFormatOptions): string;
  /** "in 2 hours", "3 days ago". */
  relative(value: DateInput, options?: RelativeOptions): string;
  /** "A, B, and C" in the locale's list style. */
  list(items: readonly string[], options?: Intl.ListFormatOptions): string;
  /** CLDR plural category for a count. */
  pluralCategory(value: number): Intl.LDMLPluralRule;
  /** Plural categories the locale uses, for parity checks. */
  pluralCategories(): readonly Intl.LDMLPluralRule[];
  readonly decimalSeparator: string;
  readonly groupSeparator: string;
}

const toTime = (value: DateInput): number => (value instanceof Date ? value.getTime() : new Date(value).getTime());

const cache = new Map<string, Formatters>();

function memo<T>(store: Map<string, T>, key: string, create: () => T): T {
  let value = store.get(key);
  if (!value) { value = create(); store.set(key, value); }
  return value;
}

export function createFormatters(locale: AppLocale): Formatters {
  const existing = cache.get(locale);
  if (existing) return existing;
  const tag = intlTag(locale);
  const numberTag = moneyTag(tag);
  const dateTag = withExtension(tag, 'ca-gregory-nu-latn');
  const numbers = new Map<string, Intl.NumberFormat>();
  const dates = new Map<string, Intl.DateTimeFormat>();
  const relatives = new Map<string, Intl.RelativeTimeFormat>();
  const lists = new Map<string, Intl.ListFormat>();
  const plural = new Intl.PluralRules(tag);
  const sample = new Intl.NumberFormat(numberTag).formatToParts(1234567.5);

  const formatters: Formatters = {
    locale,
    n(value, options) {
      const key = JSON.stringify(options ?? null);
      return memo(numbers, key, () => new Intl.NumberFormat(numberTag, options)).format(value);
    },
    d(value, options = { dateStyle: 'medium' }) {
      const key = JSON.stringify(options);
      const time = toTime(value);
      if (!Number.isFinite(time)) return '—';
      return memo(dates, key, () => new Intl.DateTimeFormat(dateTag, options)).format(time);
    },
    relative(value, options = {}) {
      const time = toTime(value);
      const now = toTime(options.now ?? Date.now());
      if (!Number.isFinite(time) || !Number.isFinite(now)) return '—';
      const seconds = Math.round((time - now) / 1000);
      const magnitude = Math.abs(seconds);
      const [unit, size]: [Intl.RelativeTimeFormatUnit, number] =
        magnitude < 60 ? ['second', 1]
          : magnitude < 3600 ? ['minute', 60]
            : magnitude < 86400 ? ['hour', 3600]
              : magnitude < 2592000 ? ['day', 86400]
                : magnitude < 31536000 ? ['month', 2592000]
                  : ['year', 31536000];
      const key = JSON.stringify([options.numeric ?? 'auto', options.style ?? 'long']);
      const format = memo(relatives, key, () => new Intl.RelativeTimeFormat(numberTag, { numeric: options.numeric ?? 'auto', style: options.style ?? 'long' }));
      return format.format(Math.trunc(seconds / size) || 0, unit);
    },
    list(items, options = { style: 'long', type: 'conjunction' }) {
      const key = JSON.stringify(options);
      return memo(lists, key, () => new Intl.ListFormat(numberTag, options)).format(items);
    },
    pluralCategory: value => plural.select(value),
    pluralCategories: () => plural.resolvedOptions().pluralCategories,
    decimalSeparator: sample.find(part => part.type === 'decimal')?.value ?? '.',
    groupSeparator: sample.find(part => part.type === 'group')?.value ?? ','
  };
  cache.set(locale, formatters);
  return formatters;
}
