import { computed, readonly, shallowRef, type ComputedRef, type Ref } from 'vue';
import {
  createFormatters,
  type DateInput,
  type NumberInput,
  type RelativeOptions
} from './format.ts';
import {
  createTranslator,
  flattenNamespaces,
  type CatalogTree,
  type FlatCatalog,
  type MessageParams
} from './message.ts';
import {
  REFERENCE_LOCALE,
  REQUIRED_LOCALES,
  detectLocale,
  isPseudoLocale,
  localeDirection,
  parseLocale,
  type AppLocale,
  type LocaleKey,
  type PseudoLocale,
  type TextDirection
} from './meta.ts';

export type { AppLocale, LocaleKey, PseudoLocale, TextDirection } from './meta.ts';
export { MissingMessageError } from './message.ts';
export type { MessageParams } from './message.ts';

/**
 * Runtime i18n. One module singleton, shared by every component and service.
 *
 * - `en` is bundled and is the fallback for every other locale, per key.
 * - Every other locale loads on demand (one chunk per namespace file) the first
 *   time it is selected. `await i18nReady` before mounting the app so the first
 *   paint is already in the right language.
 * - Development and tests throw on a missing key in `en` and `ja` (the two
 *   complete locales); the other 25 fall back to `en` silently and count the
 *   miss. A production build never throws: a missing `en` key renders the key
 *   and logs once.
 */

const STORAGE_KEY = 'locale';
const STRICT = import.meta.env.DEV;
const ALLOW_PSEUDO = import.meta.env.DEV;

type NamespaceModule = { readonly default: CatalogTree };

const referenceModules = import.meta.glob<NamespaceModule>('./locales/en/*.ts', { eager: true });
const lazyModules = import.meta.glob<NamespaceModule>(['./locales/*/*.ts', '!./locales/en/*.ts']);

const MODULE_PATH = /^\.\/locales\/([^/]+)\/([^/]+)\.ts$/;

const referenceCatalog: FlatCatalog = flattenNamespaces(
  Object.fromEntries(
    Object.entries(referenceModules).flatMap(([path, module]) => {
      const namespace = MODULE_PATH.exec(path)?.[2];
      return namespace ? [[namespace, module.default] as const] : [];
    })
  )
);

const lazyLoaders = new Map<string, Array<readonly [string, () => Promise<NamespaceModule>]>>();
for (const [path, load] of Object.entries(lazyModules)) {
  const match = MODULE_PATH.exec(path);
  if (!match) continue;
  const [, localeKey, namespace] = match;
  const list = lazyLoaders.get(localeKey) ?? [];
  list.push([namespace, load]);
  lazyLoaders.set(localeKey, list);
}

/* ------------------------------------------------------------------------ */
/* State                                                                     */
/* ------------------------------------------------------------------------ */

const readStoredLocale = (): AppLocale | null => {
  try {
    return parseLocale(globalThis.localStorage?.getItem(STORAGE_KEY), ALLOW_PSEUDO);
  } catch {
    return null;
  }
};

const browserLanguages = (): string[] => {
  const navigatorLike = globalThis.navigator as Navigator | undefined;
  if (!navigatorLike) return [];
  if (Array.isArray(navigatorLike.languages) && navigatorLike.languages.length) return [...navigatorLike.languages];
  return navigatorLike.language ? [navigatorLike.language] : [];
};

const storedAtStart = readStoredLocale();
const initialLocale: AppLocale = storedAtStart ?? detectLocale(browserLanguages());

const catalogs = shallowRef<ReadonlyMap<LocaleKey, FlatCatalog>>(new Map([[REFERENCE_LOCALE, referenceCatalog]]));
const active = shallowRef<AppLocale>(initialLocale);
const preference = shallowRef<'auto' | AppLocale>(storedAtStart ?? 'auto');

/** The locale whose catalog supplies text: pseudo-locales render from English. */
const catalogLocale = (locale: AppLocale): LocaleKey => (isPseudoLocale(locale) ? REFERENCE_LOCALE : locale);

const applyDocumentLocale = (locale: AppLocale) => {
  if (typeof document === 'undefined') return;
  document.documentElement.setAttribute('lang', locale);
  document.documentElement.setAttribute('dir', localeDirection(locale));
};

/* ------------------------------------------------------------------------ */
/* Loading                                                                   */
/* ------------------------------------------------------------------------ */

const loading = new Map<LocaleKey, Promise<void>>();

/**
 * Loads a locale's catalog (all its namespaces). Resolves immediately for `en`
 * and pseudo-locales. A locale with no translation files yet loads as an empty
 * catalog: every key falls back to English.
 */
export function loadLocale(locale: AppLocale): Promise<void> {
  const key = catalogLocale(locale);
  if (catalogs.value.has(key)) return Promise.resolve();
  let pending = loading.get(key);
  if (!pending) {
    pending = (async () => {
      const loaders = lazyLoaders.get(key) ?? [];
      const trees = await Promise.all(loaders.map(async ([namespace, load]) => [namespace, (await load()).default] as const));
      catalogs.value = new Map(catalogs.value).set(key, flattenNamespaces(Object.fromEntries(trees)));
    })().finally(() => { loading.delete(key); });
    loading.set(key, pending);
  }
  return pending;
}

/**
 * Resolves once the starting locale's catalog is loaded. If that load fails
 * (for example a chunk could not be fetched) the app starts in English and the
 * stored preference is left untouched.
 */
export const i18nReady: Promise<void> = loadLocale(initialLocale).catch((error: unknown) => {
  console.error('Could not load the language files; using English.', error);
  active.value = REFERENCE_LOCALE;
  // The page text is now English, so lang and dir must describe English too.
  applyDocumentLocale(REFERENCE_LOCALE);
});

applyDocumentLocale(initialLocale);

/* ------------------------------------------------------------------------ */
/* Translation                                                               */
/* ------------------------------------------------------------------------ */

const fallbackCounts = new Map<string, number>();
const reportedMissing = new Set<string>();

/** Development counter of per-key English fallbacks, by locale. Empty in production. */
export const getFallbackCounts = (): ReadonlyMap<string, number> => fallbackCounts;

const translateIn = createTranslator({
  reference: referenceCatalog,
  // Reading the shallow ref here makes every render that calls `t` re-run when a catalog finishes loading.
  catalog: key => catalogs.value.get(key),
  strict: STRICT,
  required: REQUIRED_LOCALES,
  onFallback(locale, key) {
    if (!import.meta.env.DEV) return;
    const count = (fallbackCounts.get(locale) ?? 0) + 1;
    fallbackCounts.set(locale, count);
    const id = `${locale}:${key}`;
    if (!reportedMissing.has(id)) {
      reportedMissing.add(id);
      console.debug(`[i18n] ${locale} has no "${key}"; using English (${count} so far).`);
    }
  },
  onMissing(key) {
    if (reportedMissing.has(key)) return;
    reportedMissing.add(key);
    console.error(`[i18n] Missing message "${key}".`);
  }
});

export type Translate = (key: string, params?: MessageParams) => string;

/** Renders a catalog message in the active locale. Reactive to locale changes. */
export const t: Translate = (key, params) => translateIn(active.value, key, params);

/** True when the key exists (in the English source of truth). */
export const has = (key: string): boolean => referenceCatalog.has(key);

/** A number in the active locale's format, Latin digits. */
export const n = (value: NumberInput, options?: Intl.NumberFormatOptions): string =>
  createFormatters(active.value).n(value, options);

/** A date or time in the active locale, Gregorian calendar, Latin digits. */
export const d = (value: DateInput, options?: Intl.DateTimeFormatOptions): string =>
  createFormatters(active.value).d(value, options);

/** "in 2 hours" / "3 days ago" in the active locale. */
export const relative = (value: DateInput, options?: RelativeOptions): string =>
  createFormatters(active.value).relative(value, options);

/** "A, B and C" in the active locale. */
export const list = (items: readonly string[], options?: Intl.ListFormatOptions): string =>
  createFormatters(active.value).list(items, options);

/* ------------------------------------------------------------------------ */
/* Choosing a locale                                                         */
/* ------------------------------------------------------------------------ */

let sequence = 0;

/**
 * Switches the app language. `'auto'` forgets the stored choice and follows the
 * browser. Only an explicit locale is written to storage. The catalog loads
 * first, so the screen changes language in one step; if it fails to load the
 * current language stays and the promise rejects.
 */
export async function setLocale(next: LocaleKey | PseudoLocale | 'auto'): Promise<void> {
  const ticket = ++sequence;
  const explicit = next === 'auto' ? null : parseLocale(next, ALLOW_PSEUDO);
  if (next !== 'auto' && !explicit) throw new RangeError(`Unsupported locale: ${String(next)}`);
  const target = explicit ?? detectLocale(browserLanguages());
  await loadLocale(target);
  if (ticket !== sequence) return;
  active.value = target;
  preference.value = explicit ?? 'auto';
  applyDocumentLocale(target);
  try {
    if (explicit) globalThis.localStorage?.setItem(STORAGE_KEY, explicit);
    else globalThis.localStorage?.removeItem(STORAGE_KEY);
  } catch {
    // The choice still applies for this session.
  }
}

export interface I18n {
  t: Translate;
  has: (key: string) => boolean;
  n: typeof n;
  d: typeof d;
  relative: typeof relative;
  list: typeof list;
  /** The language in use. */
  locale: Readonly<Ref<AppLocale>>;
  /** What the person chose: a locale, or `'auto'` to follow the browser. */
  localePreference: Readonly<Ref<'auto' | AppLocale>>;
  setLocale: typeof setLocale;
  dir: ComputedRef<TextDirection>;
}

export const locale = readonly(active);
export const localePreference = readonly(preference);
export const dir = computed<TextDirection>(() => localeDirection(active.value));

export function useI18n(): I18n {
  return { t, has, n, d, relative, list, locale, localePreference, setLocale, dir };
}
