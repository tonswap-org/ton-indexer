/**
 * ICU MessageFormat subset, written for this app.
 *
 *   {name}                              a string or number parameter
 *   {count, number}                     a number in the locale's format
 *   {count, plural, =0 {..} one {..} other {..}}   (`#` is the count)
 *   {kind, select, buy {..} other {..}}
 *
 * There is no eval and no `new Function`: messages are parsed into a small tree
 * and interpreted, so the app's Content Security Policy (no `unsafe-eval`) holds.
 *
 * Quoting follows ICU's "DOUBLE_OPTIONAL" mode so copy can use plain
 * apostrophes ("can't"): `''` is one apostrophe, and an apostrophe directly
 * before `{`, `}` (or `#` inside a plural) starts a quoted literal that ends at
 * the next single apostrophe. Any other apostrophe is literal.
 *
 * Numbers passed as parameters are formatted for the locale. Money and other
 * exact decimals must be passed as strings; they are inserted verbatim.
 */

import { createFormatters } from './format.ts';
import { REFERENCE_LOCALE, isPseudoLocale, type AppLocale, type LocaleKey, type PseudoLocale } from './meta.ts';
import { accentText, markPseudo } from './pseudo.ts';

export type MessageParams = Readonly<Record<string, string | number>>;

export type PluralCategory = Intl.LDMLPluralRule;

export type MessageNode =
  | { readonly kind: 'text'; readonly value: string }
  | { readonly kind: 'arg'; readonly name: string }
  | { readonly kind: 'number'; readonly name: string; readonly style: 'decimal' | 'integer' | 'percent' }
  | { readonly kind: 'pound' }
  | { readonly kind: 'plural'; readonly name: string; readonly offset: number; readonly options: Readonly<Record<string, readonly MessageNode[]>> }
  | { readonly kind: 'select'; readonly name: string; readonly options: Readonly<Record<string, readonly MessageNode[]>> };

export class MessageSyntaxError extends Error {
  readonly source: string;
  readonly position: number;

  constructor(message: string, source: string, position: number) {
    super(`${message} at ${position} in ${JSON.stringify(source)}`);
    this.name = 'MessageSyntaxError';
    this.source = source;
    this.position = position;
  }
}

const NAME = /[A-Za-z_][A-Za-z0-9_]*/y;
const SELECTOR = /[A-Za-z0-9_=-]+/y;
const PLURAL_CATEGORIES: readonly string[] = ['zero', 'one', 'two', 'few', 'many', 'other'];

class Parser {
  private position = 0;
  private readonly source: string;

  constructor(source: string) {
    this.source = source;
  }

  parse(): MessageNode[] {
    const nodes = this.nodes(false, false);
    if (this.position < this.source.length) this.fail('Unmatched }');
    return nodes;
  }

  private fail(message: string): never {
    throw new MessageSyntaxError(message, this.source, this.position);
  }

  private peek(): string | undefined {
    return this.source[this.position];
  }

  private whitespace(): void {
    while (this.position < this.source.length && /\s/.test(this.source[this.position])) this.position++;
  }

  private expect(char: string): void {
    if (this.peek() !== char) this.fail(`Expected ${char}`);
    this.position++;
  }

  private match(pattern: RegExp, what: string): string {
    pattern.lastIndex = this.position;
    const found = pattern.exec(this.source);
    if (!found) this.fail(`Expected ${what}`);
    this.position += found[0].length;
    return found[0];
  }

  private nodes(nested: boolean, inPlural: boolean): MessageNode[] {
    const result: MessageNode[] = [];
    let text = '';
    const flush = () => { if (text) { result.push({ kind: 'text', value: text }); text = ''; } };
    while (this.position < this.source.length) {
      const char = this.source[this.position];
      if (char === '}') { if (nested) break; this.fail('Unmatched }'); }
      if (char === '{') { flush(); result.push(this.argument(inPlural)); continue; }
      if (char === '#' && inPlural) { flush(); result.push({ kind: 'pound' }); this.position++; continue; }
      if (char === "'") {
        const next = this.source[this.position + 1];
        if (next === "'") { text += "'"; this.position += 2; continue; }
        if (next === '{' || next === '}' || (next === '#' && inPlural)) {
          this.position++;
          while (this.position < this.source.length) {
            const quoted = this.source[this.position];
            if (quoted === "'") {
              if (this.source[this.position + 1] === "'") { text += "'"; this.position += 2; continue; }
              this.position++;
              break;
            }
            text += quoted;
            this.position++;
          }
          continue;
        }
      }
      text += char;
      this.position++;
    }
    flush();
    return result;
  }

  private argument(inPlural: boolean): MessageNode {
    this.expect('{');
    this.whitespace();
    const name = this.match(NAME, 'a parameter name');
    this.whitespace();
    if (this.peek() === '}') { this.position++; return { kind: 'arg', name }; }
    this.expect(',');
    this.whitespace();
    const type = this.match(NAME, 'a format type');
    this.whitespace();
    if (type === 'number') {
      let style: 'decimal' | 'integer' | 'percent' = 'decimal';
      if (this.peek() === ',') {
        this.position++;
        this.whitespace();
        const given = this.match(NAME, 'a number style');
        if (given !== 'integer' && given !== 'percent') this.fail(`Unknown number style ${given}`);
        style = given;
        this.whitespace();
      }
      this.expect('}');
      return { kind: 'number', name, style };
    }
    if (type !== 'plural' && type !== 'select') this.fail(`Unknown format type ${type}`);
    this.expect(',');
    this.whitespace();
    let offset = 0;
    if (type === 'plural' && this.source.startsWith('offset:', this.position)) {
      this.position += 'offset:'.length;
      offset = Number(this.match(/[0-9]+/y, 'an offset'));
      this.whitespace();
    }
    // No prototype: a selector such as `constructor` or `__proto__` is an ordinary key.
    const options: Record<string, readonly MessageNode[]> = Object.create(null);
    while (this.peek() !== '}') {
      if (this.position >= this.source.length) this.fail('Unterminated argument');
      const selector = this.match(SELECTOR, 'a selector');
      if (type === 'plural' && !selector.startsWith('=') && !PLURAL_CATEGORIES.includes(selector)) this.fail(`Unknown plural category ${selector}`);
      if (type === 'plural' && selector.startsWith('=') && !/^=[0-9]+$/.test(selector)) this.fail(`Bad exact selector ${selector}`);
      if (Object.hasOwn(options, selector)) this.fail(`Duplicate selector ${selector}`);
      this.whitespace();
      this.expect('{');
      options[selector] = this.nodes(true, type === 'plural' ? true : inPlural);
      this.expect('}');
      this.whitespace();
    }
    this.expect('}');
    if (!Object.hasOwn(options, 'other')) this.fail(`${type} needs an "other" option`);
    return type === 'plural' ? { kind: 'plural', name, offset, options } : { kind: 'select', name, options };
  }
}

const parsed = new Map<string, readonly MessageNode[]>();

/** Parses (and caches) a message. Throws MessageSyntaxError on malformed input. */
export function parseMessage(source: string): readonly MessageNode[] {
  let nodes = parsed.get(source);
  if (!nodes) { nodes = new Parser(source).parse(); parsed.set(source, nodes); }
  return nodes;
}

export interface MessageDescription {
  /** Every parameter name the message reads. */
  readonly params: readonly string[];
  /** `select` options per parameter. */
  readonly selects: Readonly<Record<string, readonly string[]>>;
  /** Named plural categories per parameter (exact `=N` selectors are not listed). */
  readonly plurals: Readonly<Record<string, readonly string[]>>;
}

/** Static description of a message for parity checks. */
export function describeMessage(source: string): MessageDescription {
  const params = new Set<string>();
  const selects: Record<string, Set<string>> = {};
  const plurals: Record<string, Set<string>> = {};
  const visit = (nodes: readonly MessageNode[]) => {
    for (const node of nodes) {
      if (node.kind === 'arg' || node.kind === 'number') params.add(node.name);
      else if (node.kind === 'plural' || node.kind === 'select') {
        params.add(node.name);
        const target = node.kind === 'plural' ? plurals : selects;
        const names = (target[node.name] ??= new Set());
        for (const [selector, body] of Object.entries(node.options)) {
          if (!selector.startsWith('=')) names.add(selector);
          visit(body);
        }
      }
    }
  };
  visit(parseMessage(source));
  const sorted = (record: Record<string, Set<string>>) =>
    Object.fromEntries(Object.entries(record).map(([key, value]) => [key, [...value].sort()]));
  return { params: [...params].sort(), selects: sorted(selects), plurals: sorted(plurals) };
}

export interface RenderContext {
  /** Formats a number for the locale (Latin digits). */
  formatNumber(value: number, style: 'decimal' | 'integer' | 'percent'): string;
  pluralCategory(value: number): PluralCategory;
  /** Rewrites literal text only (pseudo-locales); parameters are never touched. */
  transformText?(text: string): string;
  /** Called when a parameter is missing. Throw to be strict; return text to be lenient. */
  missingParam(name: string): string;
}

const asNumber = (value: string | number | undefined): number | undefined => {
  if (typeof value === 'number') return value;
  if (typeof value === 'string' && value.trim() !== '') {
    const parsedValue = Number(value);
    return Number.isFinite(parsedValue) ? parsedValue : undefined;
  }
  return undefined;
};

/** An option body by its own key only, so a parameter value can never name an inherited member. */
const ownOption = (options: Readonly<Record<string, readonly MessageNode[]>>, key: string): readonly MessageNode[] | undefined =>
  Object.hasOwn(options, key) ? options[key] : undefined;

function render(nodes: readonly MessageNode[], params: MessageParams, context: RenderContext, count: number | undefined): string {
  let output = '';
  for (const node of nodes) {
    switch (node.kind) {
      case 'text':
        output += context.transformText ? context.transformText(node.value) : node.value;
        break;
      case 'arg': {
        const value = params[node.name];
        if (value === undefined) output += context.missingParam(node.name);
        else output += typeof value === 'number' ? context.formatNumber(value, 'decimal') : value;
        break;
      }
      case 'number': {
        const value = asNumber(params[node.name]);
        output += value === undefined ? context.missingParam(node.name) : context.formatNumber(value, node.style);
        break;
      }
      case 'pound':
        output += count === undefined ? '#' : context.formatNumber(count, 'decimal');
        break;
      case 'plural': {
        const raw = asNumber(params[node.name]);
        if (raw === undefined) { output += context.missingParam(node.name); break; }
        const shifted = raw - node.offset;
        const body = ownOption(node.options, `=${raw}`) ?? ownOption(node.options, context.pluralCategory(shifted)) ?? node.options.other;
        output += render(body, params, context, shifted);
        break;
      }
      case 'select': {
        const raw = params[node.name];
        if (raw === undefined) { output += context.missingParam(node.name); break; }
        output += render(ownOption(node.options, String(raw)) ?? node.options.other, params, context, count);
        break;
      }
    }
  }
  return output;
}

/** Renders a message source with parameters. */
export function formatMessage(source: string, params: MessageParams | undefined, context: RenderContext): string {
  return render(parseMessage(source), params ?? {}, context, undefined);
}

/* ------------------------------------------------------------------------ */
/* Catalog shape                                                             */
/* ------------------------------------------------------------------------ */

/** A namespace file's default export: nested objects whose leaves are messages. */
export interface CatalogTree {
  readonly [segment: string]: string | CatalogTree;
}

/**
 * The same shape as another catalog with every leaf a string. Translations
 * write `satisfies Catalog<typeof en>` so the compiler rejects a missing or
 * extra key.
 */
export type Catalog<T> = { [K in keyof T]: T[K] extends string ? string : Catalog<T[K]> };

export type FlatCatalog = ReadonlyMap<string, string>;

/** Segment grammar: lowerCamel identifiers joined by dots, at least namespace + one segment. */
export const KEY_PATTERN = /^[a-z][A-Za-z0-9]*(\.[a-z][A-Za-z0-9]*)+$/;

/**
 * Flattens `{ namespace: tree }` into `namespace.path.to.leaf -> message`.
 * Throws on a non-string leaf so a malformed catalog fails loudly and early.
 */
export function flattenNamespaces(namespaces: Readonly<Record<string, CatalogTree>>): Map<string, string> {
  const flat = new Map<string, string>();
  const walk = (prefix: string, tree: CatalogTree) => {
    for (const [segment, value] of Object.entries(tree)) {
      const key = `${prefix}.${segment}`;
      if (typeof value === 'string') flat.set(key, value);
      else if (value && typeof value === 'object') walk(key, value);
      else throw new TypeError(`Catalog entry ${key} must be a string or a nested object`);
    }
  };
  for (const [namespace, tree] of Object.entries(namespaces)) walk(namespace, tree);
  return flat;
}

/* ------------------------------------------------------------------------ */
/* Translator: catalog lookup, fallback and strictness                       */
/* ------------------------------------------------------------------------ */

export class MissingMessageError extends Error {
  readonly key: string;
  readonly locale: AppLocale;

  constructor(key: string, locale: AppLocale) {
    super(`Missing message "${key}" for locale "${locale}"`);
    this.name = 'MissingMessageError';
    this.key = key;
    this.locale = locale;
  }
}

export interface TranslatorOptions {
  /** The authored English source: complete, and the fallback for every locale. */
  readonly reference: FlatCatalog;
  /** The loaded catalog for a locale; undefined while it is still loading. */
  catalog(locale: LocaleKey): FlatCatalog | undefined;
  /** Throw on a missing key in `required` locales and in English (development and tests). */
  readonly strict: boolean;
  /** Locales that must be complete. */
  readonly required: readonly LocaleKey[];
  /** A loaded, incomplete locale fell back to English for this key. */
  onFallback?(locale: AppLocale, key: string): void;
  /** A key is missing from English too (production only; strict mode throws instead). */
  onMissing?(key: string): void;
}

export type TranslateIn = (locale: AppLocale, key: string, params?: MessageParams) => string;

/**
 * Builds the lookup used by the runtime and by tests.
 *
 * - The locale's own message wins.
 * - A locale whose catalog is still loading shows English without complaint.
 * - A loaded locale missing a key: required locales (en, ja) throw when
 *   strict; every other locale falls back to English per key, silently.
 * - English text always renders with English plural and number rules, so a
 *   fallback sentence never mixes in another language's grammar.
 * - Pseudo-locales render the English source accented, padded and marked.
 * - A key missing from English throws when strict; otherwise it renders the key.
 */
export function createTranslator(options: TranslatorOptions): TranslateIn {
  const { reference, strict } = options;

  const missingEverywhere = (key: string, locale: AppLocale): string => {
    if (strict) throw new MissingMessageError(key, locale);
    options.onMissing?.(key);
    return key;
  };

  return (locale, key, params) => {
    let source: string | undefined;
    let formatLocale: AppLocale = REFERENCE_LOCALE;
    let pseudo: PseudoLocale | null = null;
    if (isPseudoLocale(locale)) {
      pseudo = locale;
      source = reference.get(key);
    } else {
      const catalog = options.catalog(locale);
      source = catalog?.get(key);
      if (source !== undefined) formatLocale = locale;
      else {
        if (catalog && locale !== REFERENCE_LOCALE) {
          if (strict && options.required.includes(locale)) throw new MissingMessageError(key, locale);
          options.onFallback?.(locale, key);
        }
        source = reference.get(key);
      }
    }
    if (source === undefined) return missingEverywhere(key, locale);
    const formatters = createFormatters(formatLocale);
    const rendered = formatMessage(source, params, {
      formatNumber: (value, style) =>
        formatters.n(value, style === 'percent' ? { style: 'percent' } : style === 'integer' ? { maximumFractionDigits: 0 } : undefined),
      pluralCategory: value => formatters.pluralCategory(value),
      transformText: pseudo ? accentText : undefined,
      missingParam(name) {
        if (strict) throw new Error(`Message "${key}" needs the parameter "${name}"`);
        return '—';
      }
    });
    return pseudo ? markPseudo(pseudo, rendered) : rendered;
  };
}
