/**
 * Locale policy for the whole app. This module is pure (no Vue, no DOM) so the
 * runtime, the Node test helper and the catalog checker all read one table.
 *
 * Policy: all 27 locales are selectable and auto-detectable. `en` is the only
 * authored source; `ja` is complete. Every other locale carries whatever
 * translations exist and falls back to `en` per key.
 */

export const LOCALE_KEYS = [
  'en', 'de', 'ja', 'he', 'ar', 'ur', 'dv', 'ru', 'uk', 'tr', 'km', 'my', 'ne', 'fr',
  'es', 'pt', 'th', 'id', 'dz', 'ko', 'si', 'ta', 'fa', 'az', 'ka', 'hy', 'am'
] as const;
export type LocaleKey = (typeof LOCALE_KEYS)[number];

/** Pseudo-locales exist for CI sweeps only; they are never offered to people. */
export const PSEUDO_LOCALES = ['en-XA', 'ar-XB'] as const;
export type PseudoLocale = (typeof PSEUDO_LOCALES)[number];

/** Anything the runtime can display in. */
export type AppLocale = LocaleKey | PseudoLocale;

export type TextDirection = 'ltr' | 'rtl';

/** Informational. `complete` means a translated value exists for every `en` key. */
export type LocaleCoverage = 'complete' | 'partial';

export interface LocaleMeta {
  readonly key: LocaleKey;
  /** The language's own name, written in its own script. */
  readonly label: string;
  readonly dir: TextDirection;
  readonly coverage: LocaleCoverage;
}

/** The authored source and the fallback for every other locale. */
export const REFERENCE_LOCALE = 'en' satisfies LocaleKey;

/**
 * Locales that must be complete: a missing key is a build failure
 * (`scripts/i18n-check.mjs`) and throws in development and tests.
 */
export const REQUIRED_LOCALES = ['en', 'ja'] as const satisfies readonly LocaleKey[];

const entry = (key: LocaleKey, label: string, dir: TextDirection = 'ltr'): LocaleMeta => ({
  key,
  label,
  dir,
  coverage: (REQUIRED_LOCALES as readonly string[]).includes(key) ? 'complete' : 'partial'
});

/** Picker order. Every locale is listed. */
export const localeList: readonly LocaleMeta[] = [
  entry('en', 'English'),
  entry('de', 'Deutsch'),
  entry('ja', '日本語'),
  entry('he', 'עברית', 'rtl'),
  entry('ar', 'العربية', 'rtl'),
  entry('ur', 'اردو', 'rtl'),
  entry('dv', 'ދިވެހި', 'rtl'),
  entry('ru', 'Русский'),
  entry('uk', 'Українська'),
  entry('tr', 'Türkçe'),
  entry('km', 'ខ្មែរ'),
  entry('my', 'မြန်မာ'),
  entry('ne', 'नेपाली'),
  entry('fr', 'Français'),
  entry('es', 'Español'),
  entry('pt', 'Português'),
  entry('th', 'ไทย'),
  entry('id', 'Bahasa Indonesia'),
  entry('dz', 'རྫོང་ཁ'),
  entry('ko', '한국어'),
  entry('si', 'සිංහල'),
  entry('ta', 'தமிழ்'),
  entry('fa', 'فارسی', 'rtl'),
  entry('az', 'Azərbaycanca'),
  entry('ka', 'ქართული'),
  entry('hy', 'Հայերեն'),
  entry('am', 'አማርኛ')
];

export const localeMeta: Readonly<Record<LocaleKey, LocaleMeta>> = Object.freeze(
  Object.fromEntries(localeList.map(item => [item.key, item])) as Record<LocaleKey, LocaleMeta>
);

const PSEUDO_DIRECTION: Readonly<Record<PseudoLocale, TextDirection>> = { 'en-XA': 'ltr', 'ar-XB': 'rtl' };

/** Legacy language codes some browsers and operating systems still report. */
const LANGUAGE_ALIASES: Readonly<Record<string, LocaleKey>> = { iw: 'he', in: 'id' };

export const isLocaleKey = (value: unknown): value is LocaleKey =>
  typeof value === 'string' && Object.hasOwn(localeMeta, value);

export const isPseudoLocale = (value: unknown): value is PseudoLocale =>
  typeof value === 'string' && (PSEUDO_LOCALES as readonly string[]).includes(value);

export const localeDirection = (locale: AppLocale): TextDirection =>
  isPseudoLocale(locale) ? PSEUDO_DIRECTION[locale] : localeMeta[locale].dir;

/**
 * Maps a language tag (`pt-BR`, `ja_JP`, `iw`) to one of the 27 locales, or
 * null when the language is not supported. Never returns a pseudo-locale.
 */
export function normalizeLocale(value: string | null | undefined): LocaleKey | null {
  if (typeof value !== 'string') return null;
  const tag = value.trim().toLowerCase().replace(/_/g, '-');
  if (!tag) return null;
  if (isLocaleKey(tag)) return tag;
  const language = tag.split('-')[0];
  if (isLocaleKey(language)) return language;
  return LANGUAGE_ALIASES[language] ?? null;
}

/**
 * Reads a stored or requested locale. Pseudo-locales resolve only when the
 * caller allows them (development and end-to-end sweeps).
 */
export function parseLocale(value: string | null | undefined, allowPseudo = false): AppLocale | null {
  if (typeof value !== 'string') return null;
  if (allowPseudo) {
    const pseudo = PSEUDO_LOCALES.find(item => item.toLowerCase() === value.trim().toLowerCase());
    if (pseudo) return pseudo;
  }
  return normalizeLocale(value);
}

/** First supported language in the browser's preference order, else English. */
export function detectLocale(languages: readonly (string | null | undefined)[]): LocaleKey {
  for (const candidate of languages) {
    const resolved = normalizeLocale(candidate);
    if (resolved) return resolved;
  }
  return REFERENCE_LOCALE;
}
