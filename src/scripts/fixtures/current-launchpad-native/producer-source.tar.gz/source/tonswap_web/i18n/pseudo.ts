import type { PseudoLocale } from './meta.ts';

/**
 * Pseudo-locales for CI sweeps (development and end-to-end only).
 *
 * `en-XA` accents every letter of the English text and pads it by about 40% to
 * expose truncation. `ar-XB` does the same and forces right-to-left rendering to
 * expose mirroring bugs. Parameters (amounts, symbols, addresses) are inserted
 * verbatim, so a figure is never altered. Every pseudo-localized message is
 * wrapped in [ ] so a sweep can prove each visible string came through the
 * catalog: a text node, `aria-label`, `placeholder` or `title` that is not
 * marked is hard-coded.
 */

const FROM = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
const TO = 'áƀçðéƒĝĥíĵķļɱñóþʠŕšţúṽŵẋýžÁßÇÐÉƑĜĤÍĴĶĻṀÑÓÞɊŔŠŢÚṼŴẊÝŽ';
const ACCENTS = new Map([...FROM].map((letter, index) => [letter, TO[index]]));

const RIGHT_TO_LEFT_OVERRIDE = '\u202E';
const POP_DIRECTIONAL_FORMATTING = '\u202C';
const BIDI_CONTROLS = /[\u200E\u200F\u202A-\u202E\u2066-\u2069]/g;

/** Accents literal text only. Used while rendering so parameters stay untouched. */
export const accentText = (text: string): string => {
  let accented = '';
  for (const character of text) accented += ACCENTS.get(character) ?? character;
  return accented;
};

/** Marks a rendered message: pad ~40%, wrap in [ ], and force RTL for ar-XB. */
export function markPseudo(locale: PseudoLocale, rendered: string): string {
  const padding = rendered ? ` ${'ẋẋẋ '.repeat(Math.ceil((rendered.length * 0.4) / 4))}`.trimEnd() : '';
  const body = `${rendered}${padding}`;
  return locale === 'ar-XB'
    ? `[${RIGHT_TO_LEFT_OVERRIDE}${body}${POP_DIRECTIONAL_FORMATTING}]`
    : `[${body}]`;
}

/** True when text carries the pseudo-locale marker (ignoring bidi controls and outer spaces). */
export function isPseudoMarked(text: string): boolean {
  const visible = text.replace(BIDI_CONTROLS, '').trim();
  return visible.length >= 2 && visible.startsWith('[') && visible.endsWith(']');
}
