import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { Cell, serializeTuple, TupleItem } from '@ton/core';
import { Executor, IExecutor, RunCommonArgs, EmulationResult, PrevBlocksInfo, GetMethodArgs, GetMethodResult } from '@ton/sandbox/dist/executor/Executor';

function blocks(info: PrevBlocksInfo): string {
    const block = (value: PrevBlocksInfo['prevKeyBlock']): TupleItem => ({ type: 'tuple', items: [
        { type: 'int', value: BigInt(value.workchain) }, { type: 'int', value: value.shard },
        { type: 'int', value: BigInt(value.seqno) }, { type: 'int', value: BigInt('0x' + value.rootHash.toString('hex')) },
        { type: 'int', value: BigInt('0x' + value.fileHash.toString('hex')) }] });
    const tuple: TupleItem[] = [{ type: 'tuple', items: info.lastMcBlocks.map(block) }, block(info.prevKeyBlock)];
    if (info.lastMcBlocks100) tuple.push({ type: 'tuple', items: info.lastMcBlocks100.map(block) });
    const slice = serializeTuple([{ type: 'tuple', items: tuple }]).beginParse(); slice.skip(24); slice.loadRef();
    return slice.asCell().toBoc().toString('base64');
}

/** Explicit pinned native execution; never retry failures in another runtime.
 * Native getters are opt-in because SENDMSG with complete config43 v2 requires
 * the newer official runtime. Gas limits are passed through unchanged. */
export async function createNativeTransactionExecutor(options: { nativeGetters?: boolean } = {}): Promise<IExecutor & { close(): Promise<void>; transactions(): number }> {
    const root = path.resolve(__dirname, '../fixtures/native');
    const manifest = JSON.parse(fs.readFileSync(path.join(root, 'transaction-worker-build.json'), 'utf8'));
    if (process.platform !== manifest.platform.os || process.arch !== manifest.platform.arch) throw Error('Native test runtime platform mismatch');
    for (const ref of [manifest.binary, manifest.source]) {
        const file = path.join(root, ref.path), bytes = fs.readFileSync(file);
        if (bytes.length !== ref.bytes || createHash('sha256').update(bytes).digest('hex') !== ref.sha256) throw Error('Native test runtime bytes changed');
    }
    const wasm = options.nativeGetters ? undefined : await Executor.create();
    const worker = spawn(path.join(root, manifest.binary.path), [], { stdio: ['pipe', 'pipe', 'pipe'] });
    let text = '', stderr = '', failed: Error | undefined, count = 0, closing = false;
    let pending: { resolve(value: Record<string, unknown>): void; reject(error: Error): void; timer: NodeJS.Timeout } | undefined;
    const fail = (error: Error) => { failed = error; if (pending) { clearTimeout(pending.timer); pending.reject(error); pending = undefined; } };
    worker.stderr.setEncoding('utf8'); worker.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-8192); });
    worker.stdout.setEncoding('utf8');
    worker.stdout.on('data', chunk => {
        text += chunk;
        if (text.length > 64 * 1024 * 1024) { fail(Error('Native transaction output too large')); worker.kill(); return; }
        let end: number;
        while ((end = text.indexOf('\n')) >= 0) {
            const line = text.slice(0, end); text = text.slice(end + 1);
            if (!pending) { fail(Error('Unsolicited native transaction output')); worker.kill(); return; }
            const request = pending; pending = undefined; clearTimeout(request.timer);
            try {
                const output = JSON.parse(line);
                if (typeof output.success !== 'boolean') throw Error('Invalid native emulator response');
                request.resolve(output);
            } catch (error) { request.reject(error as Error); fail(error as Error); worker.kill(); }
        }
    });
    worker.on('error', fail);
    worker.on('exit', (code, signal) => { if (pending || code !== 0) fail(Error(`Native emulator exited (${code}, ${signal}): ${stderr}`)); });
    const levels = ['short', 'full', 'full_location', 'full_location_gas', 'full_location_stack', 'full_location_stack_verbose'];
    let queue: Promise<unknown> = Promise.resolve();
    const sendRequest = (frame: string[]): Promise<Record<string, unknown>> => {
        if (failed) return Promise.reject(failed);
        if (pending) return Promise.reject(Error('Native executor requires serial requests'));
        return new Promise((resolve, reject) => {
            pending = { resolve, reject, timer: setTimeout(() => { fail(Error('Native request exceeded45s')); worker.kill(); }, 45_000) };
            worker.stdin.write(frame.join('\n') + '\n', error => { if (error) fail(error); });
        });
    };
    const request = (frame: string[]): Promise<Record<string, unknown>> => {
        if (closing) return Promise.reject(Error('Native executor is closed'));
        if (frame.some(value => value.includes('\n') || value.length > 32 * 1024 * 1024)) return Promise.reject(Error('Invalid native transaction frame'));
        // Wrappers may quote several contracts concurrently; this worker has one framed stream.
        const result = queue.then(() => sendRequest(frame));
        queue = result.then(() => undefined, () => undefined);
        return result;
    };
    const run = async (args: RunCommonArgs, message: Cell | undefined, kind: string): Promise<EmulationResult> => {
        if (!Number.isSafeInteger(args.now) || args.now < 0 || args.now >= 2 ** 32 || args.lt < 0n || args.lt >= 1n << 64n) return Promise.reject(Error('Invalid native transaction time'));
        const verbosity = levels.indexOf(args.verbosity);
        if (verbosity < 0) return Promise.reject(Error('Invalid native transaction verbosity'));
        const frame = [args.config, args.shardAccount, message?.toBoc().toString('base64') ?? '', String(args.now), String(args.lt),
            args.randomSeed?.toString('hex') ?? '', args.ignoreChksig ? '1' : '0', args.debugEnabled ? '1' : '0',
            args.libs?.toBoc().toString('base64') ?? '', args.prevBlocksInfo ? blocks(args.prevBlocksInfo) : '', String(verbosity), kind, '', '', '', '', ''];
        const output = await request(frame);
        count++;
        return { result: output.success ? { success: true, transaction: output.transaction as string,
            shardAccount: output.shard_account as string, vmLog: output.vm_log as string ?? '', actions: output.actions as string | null }
            : { success: false, error: output.error as string, vmResults: 'vm_log' in output
                ? { vmLog: output.vm_log as string, vmExitCode: output.vm_exit_code as number } : undefined }, logs: '', debugLogs: '' };
    };
    const getter = async (args: GetMethodArgs): Promise<GetMethodResult> => {
        if (!Number.isSafeInteger(args.unixTime) || args.unixTime < 0 || args.unixTime >= 2 ** 32 ||
            args.balance < 0n || args.balance >= 1n << 64n || args.gasLimit < 0n || args.gasLimit >= 1n << 63n ||
            !Number.isInteger(args.methodId) || args.methodId < -(2 ** 31) || args.methodId >= 2 ** 31 || args.randomSeed.length !== 32)
            throw Error('Invalid native getter arguments');
        const verbosity = levels.indexOf(args.verbosity);
        if (verbosity < 0) throw Error('Invalid native getter verbosity');
        const extra = Object.entries(args.extraCurrency ?? {}).map(([id, balance]) => {
            if (!/^\d+$/.test(id) || BigInt(id) >= 1n << 32n || balance < 0n || balance >= 1n << 248n) throw Error('Invalid native getter extra currency');
            return `${id}=${balance}`;
        }).join(' ');
        const output = await request([args.config, args.code.toBoc().toString('base64'), args.data.toBoc().toString('base64'),
            String(args.unixTime), String(args.balance), args.randomSeed.toString('hex'), '', args.debugEnabled ? '1' : '0',
            args.libs?.toBoc().toString('base64') ?? '', args.prevBlocksInfo ? blocks(args.prevBlocksInfo) : '', String(verbosity), 'getter',
            args.address.toRawString(), String(args.methodId), serializeTuple(args.stack).toBoc().toString('base64'), String(args.gasLimit), extra]);
        return { output: output as GetMethodResult['output'], logs: '', debugLogs: '' };
    };
    return { runGetMethod: args => options.nativeGetters ? getter(args) : wasm!.runGetMethod(args), runTransaction: args => run(args, args.message, 'transaction'),
        runTickTock: args => run(args, undefined, args.which), transactions: () => count,
        close: async () => {
            closing = true;
            await queue;
            return new Promise<void>((resolve, reject) => {
                if (worker.exitCode !== null || worker.signalCode !== null) { if (failed) reject(failed); else resolve(); return; }
                worker.once('exit', (code, signal) => code === 0 ? resolve() : reject(Error(`Native emulator failed (${code}, ${signal}): ${stderr}`)));
                worker.stdin.end();
            });
        } };
}
