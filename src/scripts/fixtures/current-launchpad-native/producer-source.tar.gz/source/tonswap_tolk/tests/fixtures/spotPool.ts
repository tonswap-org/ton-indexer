import { JETTON_V21_WALLET_PROFILE, standardJettonWalletProfile } from '../../wrappers/jettonWalletBudget';
import { Address, Cell } from '@ton/core';
import { DlmmPool, PoolIdentity, PoolId, POOL_PUBLIC_BIN_SPACING, POOL_PUBLIC_FEE_PIPS, POOL_PUBLIC_WALLET_GAS_X, POOL_PUBLIC_WALLET_GRAM_X } from '../../wrappers/DlmmPool';

export function publicPoolId(xMaster: Address, xDecimals = 9): PoolId {
    return { walletBudgetX: standardJettonWalletProfile(POOL_PUBLIC_WALLET_GAS_X, POOL_PUBLIC_WALLET_GRAM_X).budget,  xMaster, xDecimals, binSpacing: POOL_PUBLIC_BIN_SPACING, feePips: POOL_PUBLIC_FEE_PIPS,
        walletGasX: POOL_PUBLIC_WALLET_GAS_X, walletGramX: POOL_PUBLIC_WALLET_GRAM_X };
}
/** Deterministic identity fixture; the factory is the only account that can initialize it. */
export function spotPoolFromIdentity(identity: Omit<PoolIdentity, 'id'> & { xMaster: Address; xDecimals?: number }, code: Cell): DlmmPool {
    const { xMaster, xDecimals, ...peers } = identity;
    return DlmmPool.createFromIdentity({ ...peers, id: publicPoolId(xMaster, xDecimals) }, code);
}

import { beginCell, Dictionary, DictionaryValue } from '@ton/core';
export type BinFixture = { t: bigint; x: bigint; shares: bigint; pq: bigint };
export type PositionKeyFixture = { owner: Address; binId: number };
export type PositionFixture = { shares: bigint; farmId: bigint; accSnap: bigint; rewardCarry: bigint };
export const binFixtureValue: DictionaryValue<BinFixture> = {
    serialize: (b, s) => { s.storeCoins(b.t).storeCoins(b.x).storeUint(b.shares, 256).storeUint(b.pq, 128); },
    parse: s => ({ t: s.loadCoins(), x: s.loadCoins(), shares: s.loadUintBig(256), pq: s.loadUintBig(128) }),
};
export const positionKeyFixture = Dictionary.Keys.BigUint(299);
export function positionFixtureKey(owner: Address, binId: number): bigint {
    return beginCell().storeAddress(owner).storeInt(binId, 32).endCell().beginParse().loadUintBig(299);
}
export function decodePositionFixtureKey(n: bigint): PositionKeyFixture {
    const s = beginCell().storeUint(n, 299).endCell().beginParse();
    return { owner: s.loadAddress(), binId: s.loadInt(32) };
}
export const positionFixtureValue: DictionaryValue<PositionFixture> = {
    serialize: (p, s) => { s.storeUint(p.shares, 256).storeUint(p.farmId, 64).storeUint(p.accSnap, 256).storeMaybeRef(p.rewardCarry === 0n ? null : beginCell().storeUint(p.rewardCarry, 128).endCell()); },
    parse: s => ({ shares: s.loadUintBig(256), farmId: s.loadUintBig(64), accSnap: s.loadUintBig(256), rewardCarry: s.loadMaybeRef()?.beginParse().loadUintBig(128) ?? 0n }),
};
export type OwnerPositionsFixture = { firstBin: number; first: PositionFixture; more: Dictionary<number, PositionFixture> };
export type PositionBucketFixture = { owner: Address; positions: OwnerPositionsFixture; others: Dictionary<Address, OwnerPositionsFixture> };
export const ownerPositionsFixtureValue: DictionaryValue<OwnerPositionsFixture> = {
    serialize: (p, s) => { s.storeInt(p.firstBin, 32); positionFixtureValue.serialize(p.first, s); s.storeDict(p.more); },
    parse: s => ({ firstBin: s.loadInt(32), first: positionFixtureValue.parse(s), more: s.loadDict(Dictionary.Keys.Int(32), positionFixtureValue) }),
};
export const positionBucketFixtureValue: DictionaryValue<PositionBucketFixture> = {
    serialize: (b, s) => { s.storeAddress(b.owner); ownerPositionsFixtureValue.serialize(b.positions, s); s.storeUint(b.others.size, 2).storeDict(b.others); },
    parse: s => { const owner = s.loadAddress(), positions = ownerPositionsFixtureValue.parse(s), count = s.loadUint(2);
        const others = s.loadDict(Dictionary.Keys.Address(), ownerPositionsFixtureValue);
        if (others.size !== count) throw new Error('Invalid owner bucket count'); return { owner, positions, others }; },
};
export const BOOK_FIXTURE_ADDRESS = new Address(0, Buffer.alloc(32, 190));
export function poolOwnerFixtureKey(owner: Address, pool: Address): bigint { return BigInt('0x' + beginCell().storeAddress(pool).storeAddress(owner).endCell().hash().subarray(0, 16).toString('hex')); }
export function positionIndexFixture(flat: Dictionary<bigint, PositionFixture>, pool: Address): Dictionary<bigint, PositionBucketFixture> {
    const index = Dictionary.empty(Dictionary.Keys.BigUint(128), positionBucketFixtureValue);
    for (const [key, position] of flat) {
        const { owner, binId } = decodePositionFixtureKey(key), hash = poolOwnerFixtureKey(owner, pool), found = index.get(hash);
        const p = found && (found.owner.equals(owner) ? found.positions : found.others.get(owner));
        if (p) p.more.set(binId, position);
        else {
            const positions = { firstBin: binId, first: position, more: Dictionary.empty(Dictionary.Keys.Int(32), positionFixtureValue) };
            if (!found) index.set(hash, { owner, positions, others: Dictionary.empty(Dictionary.Keys.Address(), ownerPositionsFixtureValue) });
            else { if (found.others.size === 3) throw new Error('Owner bucket full'); found.others.set(owner, positions); }
        }
    }
    return index;
}
export function flatPositionsFixture(index: Dictionary<bigint, PositionBucketFixture>): Dictionary<bigint, PositionFixture> {
    const flat = Dictionary.empty(positionKeyFixture, positionFixtureValue);
    const add = (owner: Address, p: OwnerPositionsFixture) => {
        flat.set(positionFixtureKey(owner, p.firstBin), p.first);
        for (const [binId, position] of p.more) flat.set(positionFixtureKey(owner, binId), position);
    };
    for (const [, b] of index) { add(b.owner, b.positions); for (const [owner, p] of b.others) add(owner, p); }
    return flat;
}
export type BookFixture = {
    activeBin: number; binCount: number; positionCount: number; protocolFeesT3: bigint; reserveT: bigint; reserveX: bigint;
    bins: Dictionary<number, BinFixture>; positions: Dictionary<bigint, PositionFixture>;
};
export function emptyBookFixture(): BookFixture {
    return { activeBin: 0, binCount: 0, positionCount: 0, protocolFeesT3: 0n, reserveT: 0n, reserveX: 0n,
        bins: Dictionary.empty(Dictionary.Keys.Int(32), binFixtureValue), positions: Dictionary.empty(positionKeyFixture, positionFixtureValue) };
}
export function bookFixtureCell(b: BookFixture): Cell {
    return beginCell().storeInt(b.activeBin, 32).storeUint(b.binCount, 16).storeUint(b.positionCount, 16).storeCoins(b.protocolFeesT3)
        .storeCoins(b.reserveT).storeCoins(b.reserveX).storeDict(b.bins).storeDict(positionIndexFixture(b.positions, BOOK_FIXTURE_ADDRESS)).endCell();
}
export function readBookFixture(cell: Cell): BookFixture {
    const s = cell.beginParse();
    const b = { activeBin: s.loadInt(32), binCount: s.loadUint(16), positionCount: s.loadUint(16), protocolFeesT3: s.loadCoins(),
        reserveT: s.loadCoins(), reserveX: s.loadCoins(), bins: s.loadDict(Dictionary.Keys.Int(32), binFixtureValue), positions: flatPositionsFixture(s.loadDict(Dictionary.Keys.BigUint(128), positionBucketFixtureValue)) };
    s.endParse(); return b;
}

import { Blockchain, BlockchainTransaction } from '@ton/sandbox';
import { IExecutor } from '@ton/sandbox/dist/executor/Executor';
import { SendMode, toNano } from '@ton/core';
import { compile } from '../helpers/compile';
import { FEE_CONFIGS } from './feeConfigs';
import { DlmmPoolFactory } from '../../wrappers/DlmmPoolFactory';
import { JettonV21Minter, JettonV21Wallet, jettonOnchainMetadata } from '../../wrappers/Jetton';
import { liqAddBody, LiqAddRow } from '../../wrappers/DlmmPool';
import { encodeSwap, Swap } from '../../wrappers/utils/swapPayload';
import { OP } from '../../wrappers/generated/opcodes';
import { deployStablecoinClone } from './stablecoin';
import { deployFreshT3 } from './freshT3';

/** Real TEP-89 discovery and TEP-74 transfer fixture; no pool storage is replaced. */
export async function spotPoolFixture(options: { config?: 'default' | 'x6' | Cell; tokenKind?: 'v21' | 'usdt' | 'fresh'; xTokenKind?: 'v21' | 'usdt' | 'usdt-library'; treasuryIsFeeSink?: boolean; id?: Partial<Omit<PoolId, 'xMaster'>>; create?: boolean; executor?: IExecutor; now?: number; callerWalletValue?: bigint } = {}) {
    const chain = await Blockchain.create({ config: options.config instanceof Cell ? options.config : FEE_CONFIGS[options.config ?? 'default'], ...(options.executor ? { executor: options.executor } : {}) }); chain.now = options.now ?? 1_800_000_000;
    const admin = await chain.treasury('spot-admin'), owner = await chain.treasury('spot-owner');
    const other = await chain.treasury('spot-other'), feeSink = await chain.treasury('spot-fee');
    const treasury = options.treasuryIsFeeSink ? feeSink : await chain.treasury('spot-treasury');
    const minterCode = await compile('JettonV21Minter');
    const stablecoin = options.tokenKind === 'usdt' ? await deployStablecoinClone(chain, admin, { walletCode: 'ordinary' }) : null;
    const freshT3 = options.tokenKind === 'fresh' ? await deployFreshT3(chain, admin) : null;
    const t3Profile = freshT3?.profile ?? JETTON_V21_WALLET_PROFILE;
    const t3 = freshT3?.minter ?? stablecoin?.minter ?? chain.openContract(JettonV21Minter.createFromConfig({ admin: admin.address, metadata: jettonOnchainMetadata({ symbol: 'T3', decimals: '9' }) }, minterCode));
    const xStablecoin = options.xTokenKind === 'usdt' || options.xTokenKind === 'usdt-library'
        ? await deployStablecoinClone(chain, admin, {walletCode: options.xTokenKind === 'usdt-library' ? 'library' : 'ordinary'}) : null;
    const x = xStablecoin?.minter ?? chain.openContract(JettonV21Minter.createFromConfig({ admin: admin.address, metadata: jettonOnchainMetadata({ symbol: 'X', decimals: String(options.id?.xDecimals ?? 9) }) }, minterCode));
    for (const m of [t3, x]) {
        if (m !== freshT3?.minter && m !== stablecoin?.minter && m !== xStablecoin?.minter) await m.sendDeploy(admin.getSender(), toNano('1'));
        // The clone is used as T3 only to exercise issuer refusal paths against the same pool wire.
        for (const target of [owner, other]) await m.sendMint(admin.getSender(), toNano('1'), {
            recipient: target.address, amount: 10n ** 30n, tonAmount: toNano('0.5'), responseDestination: admin.address,
        });
    }
    const poolCode = await compile('DlmmPool');
    const factory = chain.openContract(DlmmPoolFactory.createFromIdentity({ t3Wallet: t3Profile, governance: admin.address, feeSink: feeSink.address,
        treasury: treasury.address, t3Master: t3.address, blockedX: null, poolCode }, await compile('DlmmPoolFactory')));
    await factory.sendDeploy(admin.getSender(), toNano('1'));
    const id = { ...publicPoolId(x.address, options.id?.xDecimals ?? (xStablecoin ? 6 : 9)), ...options.id };
    const pool = chain.openContract(DlmmPool.createFromAddress(await factory.getPoolAddress(id)));
    let creation: { transactions: BlockchainTransaction[] } | undefined;
    if (options.create !== false) creation = await factory.sendPoolCreate(admin.getSender(), await factory.getCreateMinValueFor(id), id);
    const wallet = async (side: number, account: Address) => chain.openContract(JettonV21Wallet.createFromAddress(await (side === 0 ? t3 : x).getWalletAddress(account)));
    const ownerWallets = [await wallet(0, owner.address), await wallet(1, owner.address)];
    const poolWallets = [await wallet(0, pool.address), await wallet(1, pool.address)];
    let queryId = 1n;
    const credit = async (side: number, amount: bigint, payload: Cell, forward: bigint, who = owner) => {
        return (await wallet(side, who.address)).sendTransfer(who.getSender(), forward + (options.callerWalletValue ?? toNano('0.5')), {
            queryId: queryId++, amount, destination: pool.address, responseDestination: who.address,
            forwardTonAmount: forward, forwardPayload: payload,
        });
    };
    const add = async (side: number, rows: LiqAddRow[], who = owner, notify = false, forward?: bigint) => credit(side,
        rows.reduce((n, r) => n + r.amount, 0n), liqAddBody({ owner: who.address, notify, rows }), forward ?? await pool.getMinForward(OP.LIQ_ADD, side), who);
    const swap = async (side: number, amount: bigint, fields: Partial<Swap> = {}, forward?: bigint, who = owner) => {
        const request: Swap = { minOut: 0n, deadline: chain.now! + 60, recipient: who.address, refundTo: who.address,
            notifyOrigin: false, fwdGram: 0n, refundFwdGram: 0n, fwdPayload: null, ...fields };
        return credit(side, amount, encodeSwap(request), forward ?? await pool.getSwapMinForward(side, request.fwdGram, request.refundFwdGram, request.notifyOrigin), who);
    };
    const plain = (body: Cell, value: bigint, who = owner) => who.send({ to: pool.address, value, body, sendMode: SendMode.PAY_GAS_SEPARATELY });
    return { chain, admin, owner, other, feeSink, treasury, stablecoin, xStablecoin, freshT3, t3Profile, t3, x, factory, pool, id, creation, wallet, ownerWallets, poolWallets, credit, add, swap, plain };
}

import { createShardAccount } from '@ton/sandbox';
/** Capacity-only fixture: retain authentic slot bindings and immutable peers, replace bounded books. */
export async function installPoolBook(f: Awaited<ReturnType<typeof spotPoolFixture>>, b: BookFixture, oracle?: Cell, positionIndex = positionIndexFixture(b.positions, f.pool.address)) {
    const account = await f.chain.getContract(f.pool.address), state = account.accountState;
    if (state?.type !== 'active' || !state.state.data || !state.state.code) throw new Error('Pool is inactive');
    const root = state.state.data.beginParse();
    const flags = root.loadUint(8), spacing = root.loadUint(16), fee = root.loadUint(32), decimals = root.loadUint(8);
    root.loadInt(32); root.loadCoins(); root.loadUint(16); root.loadUint(16); const campaignCount = root.loadUint(8);
    const jet = root.loadRef(); root.loadRef(); const oldOracle = root.loadRef(), oldCold = root.loadRef().beginParse();
    const factory = oldCold.loadAddress(), sink = oldCold.loadAddress(), treasury = oldCold.loadAddress();
    oldCold.loadDict(Dictionary.Keys.BigUint(128), positionBucketFixtureValue); const farm = oldCold.loadRef();
    const cold = beginCell().storeAddress(factory).storeAddress(sink).storeAddress(treasury).storeDict(positionIndex).storeRef(farm).endCell();
    const data = beginCell().storeUint(flags, 8).storeUint(spacing, 16).storeUint(fee, 32).storeUint(decimals, 8)
        .storeInt(b.activeBin, 32).storeCoins(b.protocolFeesT3).storeUint(b.binCount, 16).storeUint(b.positionCount, 16).storeUint(campaignCount, 8)
        .storeRef(jet).storeRef(beginCell().storeCoins(b.reserveT).storeCoins(b.reserveX).storeDict(b.bins).endCell())
        .storeRef(oracle ?? oldOracle).storeRef(cold).endCell();
    const shard = createShardAccount({ address: f.pool.address, code: state.state.code, data, balance: account.balance });
    shard.account!.storageStats.lastPaid = f.chain.now!;
    await f.chain.setShardAccount(f.pool.address, shard);
}
