import { Cell } from '@ton/core';
import { TARGETS, type Target } from '../../contracts/targets';
import { build, compileTarget, isFresh, loadBuild } from '../../scripts/build/build';

const codes = new Map<string, Promise<Cell>>();

async function load(name: string): Promise<Cell> {
    if (!Object.prototype.hasOwnProperty.call(TARGETS, name)) throw new Error(`${name} is not a target in contracts/targets.ts`);
    const target = name as Target;
    return isFresh(target) ? loadBuild().code(target) : (await compileTarget(target)).code;
}

/** Same signature as @ton/blueprint's compile: build/<name>.boc while its inputs are unchanged, else an in-process compile. */
export function compile(name: string): Promise<Cell> {
    let code = codes.get(name);
    if (!code) {
        code = load(name);
        codes.set(name, code);
    }
    return code;
}

/** Jest globalSetup (jest.config.cjs): build every target once per run. A failing target fails only the suites that compile it. */
export default async function buildAllTargets(): Promise<void> {
    await build(Object.keys(TARGETS) as Target[]).catch((error: Error) => console.warn(error.message));
}
