import { defaultConfig, loadConfig, setGlobalVersion, updateConfig } from '@ton/sandbox';
import { Cell } from '@ton/core';

type Config = ReturnType<typeof loadConfig>;
type GasPrices = Config[21]['anon0'];
type ForwardPrices = Config[25]['anon0'];

// Complete observed SizeLimitsConfig v2, including its optional library-load limit.
const SIZE_LIMITS = {
    maxMsgBits: 2_097_152, maxMsgCells: 8_192, maxLibraryCells: 200, maxVmDataDepth: 512,
    maxExtMsgSize: 65_535, maxExtMsgDepth: 512, maxAccStateCells: 65_536, maxMcAccStateCells: 2_048,
    maxAccPublicLibraries: 256, deferOutQueueSizeLimit: 256, maxMsgExtraCurrencies: 0, maxAccFixedPrefixLength: 8,
    accStateCellsForStorageDict: 26, maxTransactionLibraryLoads: 3,
};
// Config param 21. A gas price is in nanogram per 65,536 gas units; the flat price buys the first flatGasLimit units.
const GAS_BASECHAIN = {
    flatGasLimit: 100n, flatGasPrice: 6_667n, gasPrice: 4_369_067n, gasLimit: 1_000_000n, specialGasLimit: 1_000_000n,
    gasCredit: 10_000n, blockGasLimit: 10_000_000n, freezeDueLimit: 100_000_000n, deleteDueLimit: 1_000_000_000n,
};
// Config param 18, per 65,536 seconds. Each network set the lower prices at its own time.
const storagePrices = (loweredAt: number) => [
    { utimeSince: 0, bitPricePs: 1n, cellPricePs: 500n, mcBitPricePs: 1_000n, mcCellPricePs: 500_000n },
    { utimeSince: loweredAt, bitPricePs: 0n, cellPricePs: 135n, mcBitPricePs: 1_000n, mcCellPricePs: 500_000n },
];

/**
 * What testnet and mainnet served on 2026-10-12 at the masterchain blocks named (A0 probes P1, P2, P5
 * and P6). A record of that day: a test that needs the value of another day reads the chain.
 */
export const OBSERVED_NETWORK = {
    testnet: {
        masterchainSeqno: 90_753_943, globalVersion: 15, capabilities: 0x3een, globalId: -3,
        sizeLimits: SIZE_LIMITS, storagePrices: storagePrices(1_777_471_189), gasBasechain: GAS_BASECHAIN,
    },
    mainnet: {
        masterchainSeqno: 98_541_113, globalVersion: 15, capabilities: 0x3een, globalId: -239,
        sizeLimits: SIZE_LIMITS, storagePrices: storagePrices(1_777_500_000), gasBasechain: GAS_BASECHAIN,
    },
};

// A gas table with other prices and the same limits.
function repriced(table: GasPrices, flat: (price: bigint, limit: bigint) => bigint, unit: (price: bigint) => bigint): GasPrices {
    return table.kind === 'GasLimitsPrices_gas_flat_pfx'
        ? { ...table, flat_gas_price: flat(table.flat_gas_price, table.flat_gas_limit), other: repriced(table.other, flat, unit) }
        : { ...table, gas_price: unit(table.gas_price) };
}

// Basechain gas at one price per unit, in nanogram.
function basechainGasAt(config: Cell, price: bigint): Cell {
    const gas = loadConfig(config)[21];
    return updateConfig(config, { ...gas, anon0: repriced(gas.anon0, (_, limit) => limit * price, () => price << 16n) });
}

function pricesTimes(config: Cell, factor: bigint): Cell {
    const { 18: storage, 20: mcGas, 21: gas, 24: mcForward, 25: forward } = loadConfig(config);
    const times = (price: bigint) => price * factor;
    const forwardTimes = (prices: ForwardPrices): ForwardPrices =>
        ({ ...prices, lump_price: times(prices.lump_price), bit_price: times(prices.bit_price), _cell_price: times(prices._cell_price) });
    for (const [since, prices] of storage.anon0) {
        storage.anon0.set(since, {
            ...prices, bit_price_ps: times(prices.bit_price_ps), _cell_price_ps: times(prices._cell_price_ps),
            mc_bit_price_ps: times(prices.mc_bit_price_ps), mc_cell_price_ps: times(prices.mc_cell_price_ps),
        });
    }
    return updateConfig(config, storage,
        { ...mcGas, anon0: repriced(mcGas.anon0, times, times) }, { ...gas, anon0: repriced(gas.anon0, times, times) },
        { ...mcForward, anon0: forwardTimes(mcForward.anon0) }, { ...forward, anon0: forwardTimes(forward.anon0) });
}

const sandboxDefault = Cell.fromBase64(defaultConfig);
const { globalVersion, capabilities } = OBSERVED_NETWORK.mainnet;
const networkVersion = setGlobalVersion(sandboxDefault, globalVersion, capabilities);

/**
 * The fee configs of the test suites, for `Blockchain.create({ config })` and `blockchain.setConfig`.
 * `default` is the sandbox's own config, whose gas and storage prices are those the networks served.
 * `stress` has the networks' global version and basechain gas at 400 nanogram, about six times their
 * price. `x6` has that version and every gas, forward and storage price at six times the default, so
 * it is at least `stress` in every component: a test that says "both fee configs" runs `default` and
 * `x6`.
 */
export const FEE_CONFIGS = { default: sandboxDefault, stress: basechainGasAt(networkVersion, 400n), x6: pricesTimes(networkVersion, 6n) };
export type FeeConfigName = keyof typeof FEE_CONFIGS;

/**
 * The config with the global id of testnet (config param 19), where the contracts' day is 600 seconds.
 * Every named config carries the sandbox's own id, -239, which is the mainnet scale.
 */
export function testScaleConfig(config: Cell): Cell {
    return updateConfig(config, { kind: 'ConfigParam__19', global_id: OBSERVED_NETWORK.testnet.globalId });
}

/** Varies basechain prices independently so surplus gas/rent cannot hide forward underquotes. */
export function independentFeeConfig(gasPrice: bigint, forwardFactor: bigint, storageFactor = 0n): Cell {
    const config = basechainGasAt(FEE_CONFIGS.default, gasPrice);
    const { 18: storage, 25: forward } = loadConfig(config);
    for (const [since, p] of storage.anon0) storage.anon0.set(since, { ...p,
        bit_price_ps: p.bit_price_ps * storageFactor, _cell_price_ps: p._cell_price_ps * storageFactor,
        mc_bit_price_ps: p.mc_bit_price_ps * storageFactor, mc_cell_price_ps: p.mc_cell_price_ps * storageFactor });
    return updateConfig(config, storage, { ...forward, anon0: { ...forward.anon0,
        lump_price: forward.anon0.lump_price * forwardFactor, bit_price: forward.anon0.bit_price * forwardFactor,
        _cell_price: forward.anon0._cell_price * forwardFactor } });
}
