import { Address, beginCell, Cell, contractAddress, Dictionary, toNano } from '@ton/core';
import { Blockchain, SandboxContract, SendMessageResult, TreasuryContract } from '@ton/sandbox';
import { loadVendorBoc, readStablecoinProvenance } from '../../scripts/build/vendor';
import { OP } from '../../wrappers/generated/opcodes';
import { JettonV21Minter, JettonV21Wallet, jettonBurnBody, jettonTransferBody, type JettonV21Mint } from '../../wrappers/Jetton';

// A clone of the governed stablecoin that issues USDT on TON, from the code cells read from mainnet
// (contracts/vendor/stablecoin/PROVENANCE.json): six decimals, and an issuer who can lock a wallet,
// move its balance and burn it. A model of that contract would test our assumptions about it.

export const STABLECOIN_DECIMALS = 6;
/** Wallet status bits; only the issuer writes them, through the minter. */
export const STABLECOIN_OUTGOING_LOCKED = 1;
export const STABLECOIN_INCOMING_LOCKED = 2;

/**
 * Probe A0 P3, 2026-10-12, on the code read at mainnet masterchain seqno 98580764.
 * tests/shared/jetton/StablecoinClone.spec.ts measures every value again on each run.
 */
export const STABLECOIN_MEASURED = {
    /** Exit codes of an owner's transfer at its own wallet. The wallet checks in this order, so a locked wallet says 45 whatever else is wrong. */
    exit: { outgoingLocked: 45, notOwner: 73, balance: 47, invalidPayload: 49, value: 48 },
    /** A wallet whose incoming transfers are locked refuses the sender wallet's message with this code; the sender wallet takes the tokens back and tells nobody. */
    incomingLockedExit: 45,
    /** With its code as the mainnet library reference the wallet is a precompiled contract (config parameter 45) at this fixed gas per message. */
    precompiledGas: 1000n,
    /** With the code as an ordinary cell, as on a network without the library: the sender wallet, and the recipient wallet that is deployed and notifies. */
    sendGas: 9145n,
    receiveGas: 10245n,
} as const;

/**
 * Probe A0 P4, 2026-10-12: provide_wallet_address emulated in the sandbox, at its default configuration,
 * on the account state of each master at mainnet masterchain seqno 98580764. Nothing was sent to a network.
 * Both answer TEP-89 with exactly a wallet and an owner reference, and with addr_none for an owner outside
 * workchain 0. `leastValue` is the least value in nanograms of a provide whose answer was delivered; the
 * provide was the 364-bit body in a reference, at a forward fee of 65,068 in its header.
 * The USDT figures are measured again on the clone by StablecoinClone.spec.ts; the jUSDC code is not in
 * the repository, so its figures stand as read. KUSD is open: its master is an owner input.
 */
export const RESERVE_MASTER_PROVIDE = {
    /** Priced in gas: one nanogram below the least value the answer cannot be sent (action result 37) and the provide bounces. */
    USDT: { master: 'EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs', answers: true, gas: 6813n, leastValue: 576_269n, gramFloor: 0n },
    /** Priced in GRAM: the bridge minter throws 75 unless the value exceeds 0.01 GRAM plus one and a half times that forward fee. */
    jUSDC: { master: 'EQB-MPwrd1G6WKNkLz_VnV6WqBDd142KMQv-g1O-8QUA3728', answers: true, gas: 8355n, leastValue: 10_097_603n, gramFloor: 10_000_000n },
} as const;

/** The exotic cell that stands for the wallet code where the code is a public library, as on mainnet. */
export function stablecoinLibraryCell(): Cell {
    return beginCell().storeUint(2, 8).storeBuffer(loadVendorBoc('JettonWallet').hash()).endCell({ exotic: true });
}

const libraries = (blockchain: Blockchain) => (blockchain.libs
    ? Dictionary.loadDirect(Dictionary.Keys.Buffer(32), Dictionary.Values.Cell(), blockchain.libs)
    : Dictionary.empty(Dictionary.Keys.Buffer(32), Dictionary.Values.Cell()));

/** Makes the wallet code a library of the sandbox, beside the libraries it already has. */
export function registerStablecoinLibrary(blockchain: Blockchain): void {
    const code = loadVendorBoc('JettonWallet');
    blockchain.libs = beginCell().storeDictDirect(libraries(blockchain).set(code.hash(), code)).endCell();
}

/**
 * Removes it again: a wallet whose code is the reference then fails with exit code 9 when it is run.
 * The sandbox keeps its last libraries when it is given none, so an empty cell stands in as the one
 * library that is left.
 */
export function unregisterStablecoinLibrary(blockchain: Blockchain): void {
    const rest = libraries(blockchain);
    rest.delete(loadVendorBoc('JettonWallet').hash());
    const placeholder = new Cell();
    blockchain.libs = beginCell().storeDictDirect(rest.set(placeholder.hash(), placeholder)).endCell();
}

export type StablecoinClone = {
    /** The standard TEP-74 and TEP-89 surface of the minter; its mint has the wire of the v2.1 minter, which descends from this contract. */
    minter: SandboxContract<JettonV21Minter>;
    /** What the minter puts into every wallet StateInit: the library reference, or the code itself. */
    walletCode: Cell;
    wallet(owner: Address): SandboxContract<JettonV21Wallet>;
    status(owner: Address): Promise<number>;
    mint(recipient: Address, amount: bigint, o?: Partial<Omit<JettonV21Mint, 'recipient' | 'amount'>>): Promise<SendMessageResult>;
    /** The issuer's powers, each one a message that the minter sends to the wallet of `owner`. */
    setStatus(owner: Address, status: number): Promise<SendMessageResult>;
    forceTransfer(owner: Address, to: Address, amount: bigint): Promise<SendMessageResult>;
    forceBurn(owner: Address, amount: bigint): Promise<SendMessageResult>;
};

// The minter keeps 1 GRAM aside on a mint and on a call to a wallet.
const MINTER_RESERVE = toNano('1');

/**
 * Deploys a clone under `issuer`. `library` (the default) is the mainnet form: the wallet code is a
 * reference to a library that this registers in the sandbox. `ordinary` is the form of a network
 * without that library: the same code as a plain cell, at another wallet address and at its real gas.
 */
export async function deployStablecoinClone(blockchain: Blockchain, issuer: SandboxContract<TreasuryContract>,
    o: { walletCode?: 'library' | 'ordinary'; metadataUri?: string } = {}): Promise<StablecoinClone> {
    const walletCode = o.walletCode === 'ordinary' ? loadVendorBoc('JettonWallet') : stablecoinLibraryCell();
    if (o.walletCode !== 'ordinary') registerStablecoinLibrary(blockchain);
    const data = beginCell().storeCoins(0n).storeAddress(issuer.address).storeAddress(null).storeRef(walletCode)
        .storeRef(beginCell().storeStringTail(o.metadataUri ?? 'https://example.invalid/stablecoin-clone.json')).endCell();
    const init = { code: loadVendorBoc('JettonMinter'), data };
    const minter = blockchain.openContract(new JettonV21Minter(contractAddress(0, init), init));
    // Unlike v2.1, this minter reads a query id before it looks at the op, also for a top-up.
    await issuer.send({ to: minter.address, init, value: 2n * MINTER_RESERVE, body: beginCell().storeUint(OP.JETTON_TOP_UP, 32).storeUint(0n, 64).endCell() });

    const walletAddress = (owner: Address) => contractAddress(0, { code: walletCode,
        data: beginCell().storeUint(0, 4).storeCoins(0n).storeAddress(owner).storeAddress(minter.address).endCell() });
    const callTo = (owner: Address, message: Cell) => issuer.send({ to: minter.address, value: toNano('0.2'), body: beginCell()
        .storeUint(OP.STABLECOIN_CALL_TO, 32).storeUint(0n, 64).storeAddress(owner).storeCoins(toNano('0.1')).storeRef(message).endCell() });
    return {
        minter, walletCode,
        wallet: (owner) => blockchain.openContract(JettonV21Wallet.createFromAddress(walletAddress(owner))),
        status: async (owner) => (await blockchain.runGetMethod(walletAddress(owner), 'get_status')).stackReader.readNumber(),
        mint(recipient, amount, mint = {}) {
            const tonAmount = mint.tonAmount ?? toNano('0.05') + (mint.forwardTonAmount ?? 0n);
            return minter.sendMint(issuer.getSender(), tonAmount + toNano('0.05'), { responseDestination: issuer.address, ...mint, recipient, amount, tonAmount });
        },
        setStatus: (owner, status) => callTo(owner, beginCell().storeUint(OP.STABLECOIN_SET_STATUS, 32).storeUint(0n, 64).storeUint(status, 4).endCell()),
        forceTransfer: (owner, to, amount) => callTo(owner, jettonTransferBody({ amount, destination: to, responseDestination: issuer.address })),
        forceBurn: (owner, amount) => callTo(owner, jettonBurnBody({ amount, responseDestination: issuer.address })),
    };
}

/** What a holder may assume about the token it is given: the hashes the record pins, for a test that compares code. */
export const stablecoinPins = () => {
    const { files, walletLibraryCell } = readStablecoinProvenance();
    return { minterCode: files['JettonMinter.code.boc'].cellHash, walletCode: files['JettonWallet.code.boc'].cellHash, walletLibraryCell: walletLibraryCell.hash };
};
