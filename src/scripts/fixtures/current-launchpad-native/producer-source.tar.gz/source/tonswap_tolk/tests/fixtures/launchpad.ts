import {IExecutor} from '@ton/sandbox/dist/executor/Executor';
import { Address,Cell,toNano } from '@ton/core';
import { SaleFactory } from '../../wrappers/SaleFactory';
import { Sale,saleContributeBody } from '../../wrappers/utils/launchpadInit';
import { SaleTerms,fixedPricingToCell,bondingPricingToCell,auctionPricingToCell } from '../../wrappers/utils/launchpadSaleConfigCodec';
import { LpVault } from '../../wrappers/LpVault';
import { VestingVault } from '../../wrappers/VestingVault';
import { OP } from '../../wrappers/generated/opcodes';
import { compile } from '../helpers/compile';
import { spotPoolFixture } from './spotPool';
export async function launchpadFixture(options:{kind?:number;vesting?:boolean;config?:'default'|'x6';create?:boolean;executor?:IExecutor;xTokenKind?:'v21'|'usdt';terms?:Partial<SaleTerms>}={}){
 const f=await spotPoolFixture({tokenKind:'fresh',create:false,executor:options.executor,config:options.config,xTokenKind:options.xTokenKind,id:{xDecimals:options.xTokenKind==='usdt'?6:9}});const kind=options.kind??0;
 const codes=await Promise.all(['SaleFixed','SaleBonding','SaleAuction','LpVault','VestingVault'].map(compile)) as [Cell,Cell,Cell,Cell,Cell];
 const factory=f.chain.openContract(SaleFactory.createFromConfig({governance:f.admin.address,t3Master:f.t3.address,t3Wallet:f.t3Profile,feeSink:f.feeSink.address,dlmmFactory:f.factory.address,codes},await compile('SaleFactory')));
 await factory.sendDeploy(f.admin.getSender(),toNano('2'));await factory.sendGate(f.admin.getSender(),toNano('0.1'),false);
 const terms:SaleTerms={projectMaster:f.x.address,lpRecipient:f.owner.address,xDecimals:options.xTokenKind==='usdt'?6:9,startTime:f.chain.now!+300,endTime:f.chain.now!+1200,seedBin:0,
 caps:{softCap:toNano('10'),hardCap:toNano('20'),minContribution:toNano('1'),maxContribution:toNano('20'),saleSupply:toNano('20')},
 pricing:kind===0?fixedPricingToCell({price:10n**18n}):kind===1?bondingPricingToCell({curveKind:1,basePrice:10n**18n,slopeNumerator:0n,slopeDenominator:1n}):auctionPricingToCell({startPrice:2n*10n**18n,reservePrice:10n**18n,decayInterval:30,tickSize:10n**17n}),
 vesting:options.vesting?{beneficiary:f.other.address,amount:toNano('5'),cliff:60,duration:300,period:30}:null};
 Object.assign(terms,options.terms);
 const nonce=1n,addresses=await factory.getChildAddresses(f.owner.address,nonce,kind);
 const sale=f.chain.openContract(Sale.createFromAddress(addresses.sale)),lp=f.chain.openContract(LpVault.createFromAddress(addresses.lp)),vesting=f.chain.openContract(VestingVault.createFromAddress(addresses.vesting));
 const creation=options.create===false?null:await factory.sendNewSale(f.owner.getSender(),await factory.getCreateValue(kind,!!terms.vesting,terms.vesting?.duration??0),nonce,kind,terms);
 const transfer=async(side:number,to:Address,amount:bigint,forward:bigint,payload=Cell.EMPTY,who=f.owner,queryId=0n)=>(await f.wallet(side,who.address)).sendTransfer(who.getSender(),forward+toNano('2'),{queryId,amount,destination:to,responseDestination:who.address,forwardTonAmount:forward,forwardPayload:payload});
 const arm=async()=>{
   await sale.sendDiscoverWallets(f.owner.getSender(),await sale.getMinDiscover());
   await lp.sendDiscoverWallets(f.owner.getSender(),await lp.getMinDiscover()+await f.factory.getCreateMinValueFor(f.id));
   // A second discovery also recovers a lost readiness reply.
   await lp.sendDiscoverWallets(f.owner.getSender(),await lp.getMinDiscover()+((await lp.getState()).pool?0n:await f.factory.getCreateMinValueFor(f.id)));
   await transfer(1,sale.address,terms.caps.saleSupply+terms.caps.saleSupply/2n,await sale.getMinForward(0,1));
   if(terms.vesting)await transfer(1,vesting.address,terms.vesting.amount,await vesting.getMinForward());
 };
 const contribute=async(amount:bigint,who=f.other,minTokens=1n,queryId=0n)=>transfer(0,sale.address,amount,await sale.getMinForward(OP.SALE_CONTRIBUTE,0),saleContributeBody(minTokens),who,queryId);
 return{...f,dlmmFactory:f.factory,factory,codes,kind,nonce,terms,sale,lp,vesting,creation,transfer,arm,contribute};
}

import { Blockchain,createShardAccount } from '@ton/sandbox';
import { beginCell } from '@ton/core';
/** Capacity/phase fixtures preserve immutable config and learned wallet identities. */
export async function replaceChildBook(chain:Blockchain,address:Address,book:Cell,balance?:bigint){
 const account=await chain.getContract(address),state=account.accountState;if(state?.type!=='active')throw Error('active child required');
 const s=state.state.data!.beginParse(),identity=s.loadRef(),config=s.loadMaybeRef(),ledger=s.loadRef();s.loadRef();s.endParse();
 const data=beginCell().storeRef(identity).storeMaybeRef(config).storeRef(ledger).storeRef(book).endCell();
 const shard=createShardAccount({address,code:state.state.code!,data,balance:balance??account.balance});shard.account!.storageStats.lastPaid=chain.now!;await chain.setShardAccount(address,shard);
}
