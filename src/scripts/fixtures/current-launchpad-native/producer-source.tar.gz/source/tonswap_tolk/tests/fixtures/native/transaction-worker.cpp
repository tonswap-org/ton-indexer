#include <array>
#include <cstdlib>
#include <iostream>
#include <string>
#include "emulator-extern.h"

// Test transport for TON's public emulator C API. The emulator, VM, gas
// schedule and transaction implementation are linked without source changes.
int main() {
    emulator_set_verbosity_level(0);
    void *engine = nullptr;
    std::string config, previous_blocks;
    int verbosity = -1;
    std::array<std::string, 17> p;
    while (std::getline(std::cin, p[0])) {
        for (size_t i = 1; i < p.size(); ++i) {
            if (!std::getline(std::cin, p[i]) || p[i].size() > 32 * 1024 * 1024) return 2;
        }
        if (p[0].empty() || p[0].size() > 1024 * 1024 || p[1].empty()) return 3;
        try {
            int next_verbosity = std::stoi(p[10]);
            if (p[11] == "getter") {
                void *vm = tvm_emulator_create(p[1].c_str(), p[2].c_str(), next_verbosity);
                if (!vm) return 10;
                if (!tvm_emulator_set_c7(vm, p[12].c_str(), std::stoul(p[3]), std::stoull(p[4]), p[5].c_str(), p[0].c_str()) ||
                    !tvm_emulator_set_gas_limit(vm, std::stoll(p[15])) ||
                    !tvm_emulator_set_debug_enabled(vm, p[7] == "1") ||
                    (!p[8].empty() && !tvm_emulator_set_libraries(vm, p[8].c_str())) ||
                    (!p[9].empty() && !tvm_emulator_set_prev_blocks_info(vm, p[9].c_str())) ||
                    (!p[16].empty() && !tvm_emulator_set_extra_currencies(vm, p[16].c_str()))) {
                    tvm_emulator_destroy(vm); return 11;
                }
                const char *result = tvm_emulator_run_get_method(vm, std::stoi(p[13]), p[14].c_str());
                if (!result) { tvm_emulator_destroy(vm); return 12; }
                std::cout << result << std::endl;
                string_destroy(result);
                tvm_emulator_destroy(vm);
                continue;
            }
            if (!engine || config != p[0] || verbosity != next_verbosity || previous_blocks != p[9]) {
                if (engine) transaction_emulator_destroy(engine);
                engine = transaction_emulator_create(p[0].c_str(), next_verbosity);
                if (!engine) return 4;
                config = p[0]; verbosity = next_verbosity; previous_blocks = p[9];
                if (!p[9].empty() && !transaction_emulator_set_prev_blocks_info(engine, p[9].c_str())) return 5;
            }
            if (!transaction_emulator_set_unixtime(engine, std::stoul(p[3])) ||
                !transaction_emulator_set_lt(engine, std::stoull(p[4])) ||
                (!p[5].empty() && !transaction_emulator_set_rand_seed(engine, p[5].c_str())) ||
                !transaction_emulator_set_ignore_chksig(engine, p[6] == "1") ||
                !transaction_emulator_set_debug_enabled(engine, p[7] == "1") ||
                !transaction_emulator_set_libs(engine, p[8].empty() ? nullptr : p[8].c_str())) return 6;
            const char *result = nullptr;
            if (p[11] == "transaction") result = transaction_emulator_emulate_transaction(engine, p[1].c_str(), p[2].c_str());
            else if (p[11] == "tick" || p[11] == "tock") result = transaction_emulator_emulate_tick_tock_transaction(engine, p[1].c_str(), p[11] == "tock");
            else return 7;
            if (!result) return 8;
            std::cout << result << std::endl;
            string_destroy(result);
        } catch (...) { return 9; }
    }
    if (engine) transaction_emulator_destroy(engine);
    return 0;
}
