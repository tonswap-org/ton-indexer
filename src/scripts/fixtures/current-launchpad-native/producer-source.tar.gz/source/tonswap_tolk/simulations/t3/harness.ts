import assert from 'node:assert/strict';
import { JETTON_DEFAULT_WALLET_PROFILE } from '../../wrappers/jettonWalletBudget';
import { Address, beginCell, Cell, Message, toNano } from '@ton/core';
import { Blockchain, SmartContractTransaction, IExecutor } from '@ton/sandbox';
import { compile } from '../../tests/helpers/compile';
import { deployStablecoinClone, STABLECOIN_MEASURED } from '../../tests/fixtures/stablecoin';
import { FEE_CONFIGS } from '../../tests/fixtures/feeConfigs';
import { T3Hub, t3HubIntent, t3HubReceiptProof, t3HubWitness } from '../../wrappers/T3Hub';
import { T3Wallet } from '../../wrappers/T3Wallet';
import { OP } from '../../wrappers/generated/opcodes';
import { discoverWalletsBody } from '../../wrappers/jettonSlots';

export type T3FeeConfig = 'default' | 'x6';
export function assertHubSuccess(txs: readonly SmartContractTransaction[], address: Address) {
    const transactions = txs.filter(tx => tx.inMessage && to(tx.inMessage, address));
    assert(transactions.length > 0, 'No hub transaction');
    for (const tx of transactions) assert(tx.description.type === 'generic' && !tx.description.aborted, 'Hub transaction aborted');
}
let codes: Promise<Cell[]> | undefined;
const hash = (c: Cell) => BigInt(`0x${c.hash().toString('hex')}`);
const gas = (tx: SmartContractTransaction) => tx.description.type === 'generic' && tx.description.computePhase.type === 'vm' ? tx.description.computePhase.gasUsed : 0n;
const to = (m: Message, a: Address) => m.info.type === 'internal' && m.info.dest.equals(a);
export async function createT3HubWorld(fee: 'default' | 'x6' = 'default', executor?: IExecutor) {
    const [code, walletCode, proofCode] = await (codes ??= Promise.all(['T3Hub', 'T3Wallet', 'T3RecoveryProof'].map(compile)));
    const chain = await Blockchain.create({ config: FEE_CONFIGS[fee], ...(executor ? { executor } : {}) }); chain.now = 1800000000;
    const [issuer, owner, other, constitutional] = await Promise.all(['issuer', 'owner', 'other', 'constitutional'].map(n => chain.treasury(n)));
    const reserves = await Promise.all([0, 1, 2].map(i => deployStablecoinClone(chain, issuer, { walletCode: 'ordinary', metadataUri: `https://example.invalid/${i}` })));
    const hub = chain.openContract(T3Hub.createFromConfig({ governance: issuer.address, amp: 150, walletCode,
        metadata: beginCell().storeUint(1, 8).storeStringTail('https://example.invalid/t3').endCell(), proofCodeHash: hash(proofCode),
        reserves: reserves.map((r, slot) => ({ ...JETTON_DEFAULT_WALLET_PROFILE, slot: slot as 0 | 1 | 2, master: r.minter.address, decimals: 6, codeHash: hash(r.walletCode), optional: slot === 2,
            lockExit: STABLECOIN_MEASURED.exit.outgoingLocked, balanceExit: STABLECOIN_MEASURED.exit.balance })) }, code));
    await hub.send(issuer.getSender(), toNano('10'));
    await hub.send(issuer.getSender(), await hub.getMinValue(OP.DISCOVER_WALLETS), discoverWalletsBody());
    await hub.send(issuer.getSender(), await hub.getMinValue(OP.DISCOVER_WALLETS), discoverWalletsBody());
    assert(await hub.getReady(), 'Reserve discovery failed');
    await hub.send(issuer.getSender(), toNano('1'), beginCell().storeUint(OP.WITHDRAWALS_ONLY_OFF, 32).endCell());
    for (const reserve of reserves) await reserve.mint(owner.address, 5_000_000_000_000n);
    const records = [new Map<bigint, Cell>(), new Map<bigint, Cell>(), new Map<bigint, Cell>(), new Map<bigint, Cell>()];
    const observed: Record<string, bigint> = {};
    const collect = (txs: readonly SmartContractTransaction[], label: string) => {
        for (const tx of txs.filter(t => t.inMessage && to(t.inMessage, hub.address))) {
            if (gas(tx) > (observed[label] ?? 0n)) observed[label] = gas(tx);
            for (const m of tx.outMessages.values()) {
                if (m.info.type !== 'external-out' || m.body.bits.length < 32 || m.body.beginParse().preloadUint(32) !== OP.T3_HUB_RECEIPT) continue;
                const b = m.body.beginParse(); b.loadUint(32); const slot = b.loadUint(2), r = b.loadRef(), key = r.beginParse().loadUintBig(64); records[slot].set(key, r);
            }
        }
    };
    const witness = (slot: number, key = [...records[slot].keys()].slice(-1)[0]!) => t3HubWitness(records[slot].get(key)!, t3HubReceiptProof(records[slot], key).proof);
    const deposit = async (slot: number, amount: bigint, intent: Cell, value?: bigint) => {
        const forward = value ?? await hub.getMinExecute(intent, slot, amount, 0n, false, owner.address);
        const result = await reserves[slot].wallet(owner.address).sendTransfer(owner.getSender(), forward + toNano('0.3'), {
            queryId: 7n, amount, destination: hub.address, responseDestination: owner.address, forwardTonAmount: forward, forwardPayload: intent });
        collect(result.transactions, 'deposit'); return result;
    };
    const pair = async (amount = 75_000_000_000n) => {
        const intent = t3HubIntent('pair', owner.address); await deposit(0, amount, intent); await deposit(1, amount, intent);
        const a = [...records[0].keys()].slice(-1)[0]!, b = [...records[1].keys()].slice(-1)[0]!;
        const bind = await hub.sendPair(owner.getSender(), toNano('2'), 0, 0, witness(0, a), witness(1, b)); collect(bind.transactions, 'bind');
        assertHubSuccess(bind.transactions, hub.address);
        const complete = await hub.sendPair(owner.getSender(), toNano('2'), 2, 0, witness(0, a), witness(1, b)); collect(complete.transactions, 'seal');
        assertHubSuccess(complete.transactions, hub.address);
        const accept = await hub.sendClaim(other.getSender(), await hub.getMinExecute(intent, 1, amount, amount, false, owner.address), 1, witness(1, b));
        collect(accept.transactions, 'pair'); assertHubSuccess(accept.transactions, hub.address);
        return { a, b, complete };
    };
    const wallet = (who = owner.address) => chain.openContract(T3Wallet.createFromConfig({ owner: who, master: hub.address, proofCodeHash: hash(proofCode) }, walletCode));
    return { chain, issuer, owner, other, constitutional, reserves, hub, records, collect, witness, deposit, pair, wallet, observed, proofCode, walletCode };
}
