import { Address, Builder, Cell, Contract, ContractProvider, Dictionary, Sender, SendMode, beginCell, contractAddress, storeStateInit } from '@ton/core';
import { sha256_sync } from '@ton/crypto';
import jettonV21 from '../contracts/vendor/jetton-v2.1/PROVENANCE.json';
import stablecoin from '../contracts/vendor/stablecoin/PROVENANCE.json';
import { OP } from './generated/opcodes';

// The vendored Jetton v2.1 minter and wallet (contracts/vendor/jetton-v2.1) and the standard bodies a
// TEP-74 and TEP-89 jetton takes. Every builder writes exactly the Maybe and Either bits of the layout.

/** The wallet StateInit carries this fixed prefix length: a wallet lives in its owner's shard. */
const SHARD_DEPTH = 8;

export type JettonV21MinterConfig = { admin: Address | null; metadata: Cell; totalSupply?: bigint; nextAdmin?: Address | null };

export function jettonV21MinterConfigToCell(config: JettonV21MinterConfig): Cell {
    return beginCell().storeCoins(config.totalSupply ?? 0n).storeAddress(config.admin).storeAddress(config.nextAdmin ?? null)
        .storeRef(config.metadata).endCell();
}

/**
 * The wallet of `owner` under a v2.1 minter: the hash of the empty wallet's StateInit with its first
 * SHARD_DEPTH bits replaced by the owner's. For verification only; no contract derives a wallet address.
 */
export function jettonV21WalletAddress(owner: Address, minter: Address, walletCode: Cell): Address {
    const data = beginCell().storeCoins(0n).storeAddress(owner).storeAddress(minter).endCell();
    const hash = beginCell().store(storeStateInit({ splitDepth: SHARD_DEPTH, code: walletCode, data })).endCell().hash();
    hash[0] = owner.hash[0];
    return new Address(0, hash);
}

export type WalletCodeKind = 'jetton-v2.1' | 'stablecoin' | 'unknown';

/**
 * What the code of a jetton wallet account is. The stablecoin wallet is its code cell on a network
 * without the public library and a reference to that library where there is one. Any other code is
 * unknown: its balance and its notifications are as good as that code.
 */
export function classifyWalletCode(code: Cell): WalletCodeKind {
    const hash = code.hash().toString('hex');
    if (hash === jettonV21.targets.JettonV21Wallet.codeHash) return 'jetton-v2.1';
    return hash === stablecoin.files['JettonWallet.code.boc'].cellHash || hash === stablecoin.walletLibraryCell.hash ? 'stablecoin' : 'unknown';
}

const metadataKey = (name: string) => BigInt(`0x${sha256_sync(name).toString('hex')}`);
const SNAKE = 0;
const ONCHAIN = 0;

/** TEP-64 on-chain metadata; every value must fit one cell after its snake prefix. */
export function jettonOnchainMetadata(entries: Record<string, string>): Cell {
    const dict = Dictionary.empty(Dictionary.Keys.BigUint(256), Dictionary.Values.Cell());
    for (const [name, value] of Object.entries(entries)) dict.set(metadataKey(name), beginCell().storeUint(SNAKE, 8).storeStringTail(value).endCell());
    return beginCell().storeUint(ONCHAIN, 8).storeDict(dict).endCell();
}

/** The `decimals` entry of TEP-64 on-chain metadata, or undefined when the content does not carry one on chain. */
export function readJettonDecimals(content: Cell): number | undefined {
    try {
        const slice = content.beginParse();
        if (slice.loadUint(8) !== ONCHAIN) return undefined;
        const value = slice.loadDict(Dictionary.Keys.BigUint(256), Dictionary.Values.Cell()).get(metadataKey('decimals'))?.beginParse();
        if (value === undefined || value.loadUint(8) !== SNAKE) return undefined;
        const text = value.loadStringTail();
        return /^(?:0|[1-9]\d{0,2})$/.test(text) ? Number(text) : undefined;
    } catch {
        return undefined;
    }
}

const storeForwardPayload = (payload: Cell | null | undefined) => (builder: Builder) => {
    // Either Cell ^Cell: left with nothing after it, or right with exactly one reference.
    if (payload) builder.storeBit(true).storeRef(payload);
    else builder.storeBit(false);
};

export type JettonTransferBody = {
    queryId?: bigint; amount: bigint; destination: Address; responseDestination: Address | null;
    forwardTonAmount?: bigint; forwardPayload?: Cell | null;
};

/** transfer#0f8a7ea5 with no custom payload and the forward payload in a reference, or absent. */
export function jettonTransferBody(t: JettonTransferBody): Cell {
    return beginCell().storeUint(OP.TEP74_TRANSFER, 32).storeUint(t.queryId ?? 0n, 64).storeCoins(t.amount).storeAddress(t.destination)
        .storeAddress(t.responseDestination).storeBit(false).storeCoins(t.forwardTonAmount ?? 0n).store(storeForwardPayload(t.forwardPayload)).endCell();
}

/** burn#595f07bc with no custom payload. */
export function jettonBurnBody(b: { queryId?: bigint; amount: bigint; responseDestination: Address | null }): Cell {
    return beginCell().storeUint(OP.TEP74_BURN, 32).storeUint(b.queryId ?? 0n, 64).storeCoins(b.amount).storeAddress(b.responseDestination)
        .storeBit(false).endCell();
}

export function jettonProvideWalletAddressBody(queryId: bigint, owner: Address, includeAddress = true): Cell {
    return beginCell().storeUint(OP.TEP89_PROVIDE_WALLET_ADDRESS, 32).storeUint(queryId, 64).storeAddress(owner).storeBit(includeAddress).endCell();
}

export type JettonTakeWalletAddress = { queryId: bigint; wallet: Address | null; owner: Address | null };

/** take_wallet_address#d1735400; the wallet is null when the minter cannot name one for that owner. */
export function parseJettonTakeWalletAddress(body: Cell): JettonTakeWalletAddress {
    const slice = body.beginParse();
    if (slice.loadUint(32) !== OP.TEP89_TAKE_WALLET_ADDRESS) throw new Error('not a take_wallet_address body');
    const queryId = slice.loadUintBig(64);
    const wallet = slice.loadMaybeAddress();
    const owner = slice.loadMaybeRef()?.beginParse().loadAddress() ?? null;
    slice.endParse();
    return { queryId, wallet, owner };
}

export type JettonV21Mint = {
    queryId?: bigint; recipient: Address; tonAmount: bigint; amount: bigint;
    from?: Address | null; responseDestination?: Address | null; forwardTonAmount?: bigint; forwardPayload?: Cell | null;
};

/** mint#642b7d07 of the vendored minter: the internal transfer for the recipient's wallet travels in a reference. */
export function jettonV21MintBody(m: JettonV21Mint): Cell {
    const internalTransfer = beginCell().storeUint(OP.TEP74_INTERNAL_TRANSFER, 32).storeUint(m.queryId ?? 0n, 64).storeCoins(m.amount)
        .storeAddress(m.from ?? null).storeAddress(m.responseDestination ?? null).storeCoins(m.forwardTonAmount ?? 0n)
        .store(storeForwardPayload(m.forwardPayload)).endCell();
    return beginCell().storeUint(OP.JETTON_MINT, 32).storeUint(m.queryId ?? 0n, 64).storeAddress(m.recipient).storeCoins(m.tonAmount)
        .storeRef(internalTransfer).endCell();
}

export const jettonV21TopUpBody = (): Cell => beginCell().storeUint(OP.JETTON_TOP_UP, 32).endCell();

export class JettonV21Minter implements Contract {
    constructor(readonly address: Address, readonly init?: { code: Cell; data: Cell }) {}

    static createFromAddress(address: Address) {
        return new JettonV21Minter(address);
    }

    static createFromConfig(config: JettonV21MinterConfig, code: Cell) {
        const init = { code, data: jettonV21MinterConfigToCell(config) };
        return new JettonV21Minter(contractAddress(0, init), init);
    }

    /** The minter throws on an empty body, so its StateInit is sent with a top-up. */
    async sendDeploy(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: jettonV21TopUpBody() });
    }

    async sendMint(provider: ContractProvider, via: Sender, value: bigint, mint: JettonV21Mint) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: jettonV21MintBody(mint) });
    }

    async sendProvideWalletAddress(provider: ContractProvider, via: Sender, value: bigint, p: { queryId?: bigint; owner: Address; includeAddress?: boolean }) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: jettonProvideWalletAddressBody(p.queryId ?? 0n, p.owner, p.includeAddress) });
    }

    async getJettonData(provider: ContractProvider) {
        const { stack } = await provider.get('get_jetton_data', []);
        return { totalSupply: stack.readBigNumber(), mintable: stack.readBoolean(), admin: stack.readAddressOpt(), content: stack.readCell(), walletCode: stack.readCell() };
    }

    async getWalletAddress(provider: ContractProvider, owner: Address): Promise<Address> {
        const { stack } = await provider.get('get_wallet_address', [{ type: 'slice', cell: beginCell().storeAddress(owner).endCell() }]);
        return stack.readAddress();
    }

    async getNextAdminAddress(provider: ContractProvider): Promise<Address | null> {
        return (await provider.get('get_next_admin_address', [])).stack.readAddressOpt();
    }
}

export class JettonV21Wallet implements Contract {
    constructor(readonly address: Address) {}

    static createFromAddress(address: Address) {
        return new JettonV21Wallet(address);
    }

    async sendTransfer(provider: ContractProvider, via: Sender, value: bigint, transfer: JettonTransferBody) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: jettonTransferBody(transfer) });
    }

    async sendBurn(provider: ContractProvider, via: Sender, value: bigint, burn: { queryId?: bigint; amount: bigint; responseDestination: Address | null }) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: jettonBurnBody(burn) });
    }

    async getWalletData(provider: ContractProvider) {
        const { stack } = await provider.get('get_wallet_data', []);
        return { balance: stack.readBigNumber(), owner: stack.readAddress(), minter: stack.readAddress(), walletCode: stack.readCell() };
    }

    /** Zero for a wallet that was never deployed. */
    async getBalance(provider: ContractProvider): Promise<bigint> {
        return (await provider.getState()).state.type === 'active' ? (await this.getWalletData(provider)).balance : 0n;
    }
}
