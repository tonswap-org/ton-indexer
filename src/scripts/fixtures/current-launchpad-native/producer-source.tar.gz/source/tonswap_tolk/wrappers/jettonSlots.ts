import { Address, beginCell, Builder, Cell, ContractProvider, Dictionary, DictionaryValue, Sender, SendMode, Slice } from '@ton/core';
import { OP } from './generated/opcodes';

import { JettonWalletProfile, jettonWalletBudgetToCell, decodeJettonWalletBudget, validateJettonWalletProfile } from './jettonWalletBudget';
export { JETTON_V21_WALLET_GAS, JETTON_DEFAULT_WALLET_GAS } from './jettonWalletBudget';
export const JETTON_OWED_CAP = 1024;

export type JettonSlot = JettonWalletProfile & { master: Address; wallet: Address | null; optional: boolean };
export type JettonSlotConfig = JettonWalletProfile & { slot: number; master: Address; optional?: boolean };
export const jettonSlotValue: DictionaryValue<JettonSlot> = {
    serialize(value, b) {
        b.storeAddress(value.master).storeAddress(value.wallet).storeUint(value.walletGas, 32).storeCoins(value.walletGram).storeBit(value.optional).storeRef(jettonWalletBudgetToCell(value.budget));
    },
    parse(s) {
        const result = { master: s.loadAddress(), wallet: s.loadMaybeAddress(), walletGas: s.loadUint(32), walletGram: s.loadCoins(), optional: s.loadBit(), budget: decodeJettonWalletBudget(s.loadRef()) };
        s.endParse();
        return result;
    },
};

export function jettonLedgerConfigToCell(slots: readonly JettonSlotConfig[]): Cell {
    if (slots.length > 16) throw new Error('A jetton ledger permits at most 16 slots');
    const masters = new Set<string>();
    const dict = Dictionary.empty(Dictionary.Keys.Uint(8), jettonSlotValue);
    let optionalPending = false;
    for (const s of slots) {
        validateJettonWalletProfile(s);
        if (!Number.isInteger(s.slot) || s.slot < 0 || s.slot > 255 || dict.has(s.slot)) throw new Error('Invalid or duplicate slot');
        if (s.master.workChain !== 0 || masters.has(s.master.toRawString())) throw new Error('Slot masters must be distinct basechain addresses');
        if (s.optional && optionalPending) throw new Error('Only one optional slot may be pending');
        if (s.optional) optionalPending = true;
        masters.add(s.master.toRawString());
        dict.set(s.slot, { master: s.master, wallet: null, walletGas: s.walletGas, walletGram: s.walletGram, optional: s.optional ?? false, budget: s.budget });
    }
    return beginCell().storeDict(dict).storeDict(null).endCell();
}

export type OwedArchive = { count: bigint; root: bigint; total: bigint; frontier: Dictionary<number, bigint> };
export function owedArchiveToCell(value: OwedArchive): Cell {
    return beginCell().storeUint(value.count, 65).storeUint(value.root, 256).storeCoins(value.total).storeDict(value.frontier).endCell();
}
export function parseOwedArchive(cell: Cell): OwedArchive {
    const s = cell.beginParse(), value = { count: s.loadUintBig(65), root: s.loadUintBig(256), total: s.loadCoins(),
        frontier: s.loadDict(Dictionary.Keys.Uint(8), Dictionary.Values.BigUint(256)) };
    s.endParse(); return value;
}
export type OwedBook = { total: bigint; count: number; entries: Dictionary<Address, bigint>; archive: OwedArchive | null };
export const owedBookValue: DictionaryValue<OwedBook> = {
    serialize(value, b) {
        b.storeCoins(value.total).storeUint(value.count, 16).storeDict(value.entries).storeMaybeRef(value.archive === null ? null : owedArchiveToCell(value.archive));
    },
    parse(s) {
        const total = s.loadCoins(), count = s.loadUint(16), entries = s.loadDict(Dictionary.Keys.Address(), Dictionary.Values.BigVarUint(4)), archive = s.loadMaybeRef();
        s.endParse(); return { total, count, entries, archive: archive === null ? null : parseOwedArchive(archive) };
    },
};

export function decodeJettonLedger(cell: Cell) {
    const s = cell.beginParse();
    const slots = s.loadDict(Dictionary.Keys.Uint(8), jettonSlotValue);
    const owed = s.loadDict(Dictionary.Keys.Uint(8), owedBookValue);
    s.endParse();
    return { slots, owed };
}

export function discoverWalletsBody(queryId = 0n): Cell {
    return beginCell().storeUint(OP.DISCOVER_WALLETS, 32).storeUint(queryId, 64).endCell();
}
export function claimOwedBody(slot: number, owner: Address, queryId = 0n): Cell {
    return beginCell().storeUint(OP.CLAIM_OWED, 32).storeUint(queryId, 64).storeUint(slot, 8).storeAddress(owner).endCell();
}
export async function sendDiscoverWallets(provider: ContractProvider, via: Sender, value: bigint, queryId = 0n) {
    await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: discoverWalletsBody(queryId) });
}
export async function sendClaimOwed(provider: ContractProvider, via: Sender, value: bigint, slot: number, owner: Address, queryId = 0n) {
    await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: claimOwedBody(slot, owner, queryId) });
}
export async function getJettonSlots(provider: ContractProvider) {
    return Dictionary.loadDirect(Dictionary.Keys.Uint(8), jettonSlotValue, (await provider.get('get_jetton_slots', [])).stack.readCellOpt());
}
export async function getOwed(provider: ContractProvider, slot: number, owner: Address) {
    return (await provider.get('get_owed', [{ type: 'int', value: BigInt(slot) }, { type: 'slice', cell: beginCell().storeAddress(owner).endCell() }])).stack.readBigNumber();
}
export async function getOwedBook(provider: ContractProvider, slot: number) {
    const s = (await provider.get('get_owed_book', [{ type: 'int', value: BigInt(slot) }])).stack;
    return { total: s.readBigNumber(), count: s.readNumber() };
}

export function sweepAllowBody(slot: number, amount: bigint, queryId = 0n): Cell {
    return beginCell().storeUint(OP.SWEEP_ALLOW, 32).storeUint(queryId, 64).storeUint(slot, 8).storeCoins(amount).endCell();
}
export function sweepProbeBody(slot: number, queryId = 0n): Cell {
    return beginCell().storeUint(OP.SWEEP_PROBE, 32).storeUint(queryId, 64).storeUint(slot, 8).endCell();
}
export async function sendSweepProbe(provider: ContractProvider, via: Sender, value: bigint, slot: number, queryId = 0n) {
    await provider.internal(via, { value, body: sweepProbeBody(slot, queryId), sendMode: SendMode.PAY_GAS_SEPARATELY });
}

export type JettonSweepState = { seq: bigint; allowance: bigint; pending: boolean; pAmount: bigint; pBase: bigint; pAllow: bigint; pCredits: bigint };
export async function getSweep(provider: ContractProvider, slot: number): Promise<JettonSweepState> {
    const s = (await provider.get('get_sweep', [{ type: 'int', value: BigInt(slot) }])).stack;
    return { seq: s.readBigNumber(), allowance: s.readBigNumber(), pending: s.readBoolean(), pAmount: s.readBigNumber(),
        pBase: s.readBigNumber(), pAllow: s.readBigNumber(), pCredits: s.readBigNumber() };
}
export async function getMinSweep(provider: ContractProvider, slot: number) {
    return (await provider.get('get_min_sweep', [{ type: 'int', value: BigInt(slot) }])).stack.readBigNumber();
}

export type ArchivedClaim = { id: bigint; owner: Address; amount: bigint };
export type ClaimArchivedRequest = ArchivedClaim & { slot: number; proof: Cell };
export function claimArchivedBody(request: ClaimArchivedRequest, queryId = 0n): Cell {
    return beginCell().storeUint(OP.CLAIM_ARCHIVED, 32).storeUint(queryId, 64).storeUint(request.slot, 8)
        .storeUint(request.id, 64).storeAddress(request.owner).storeCoins(request.amount).storeRef(request.proof).endCell();
}
export async function sendClaimArchived(provider: ContractProvider, via: Sender, value: bigint, request: ClaimArchivedRequest, queryId = 0n) {
    return provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: claimArchivedBody(request, queryId) });
}
export async function getOwedArchive(provider: ContractProvider, slot: number) {
    const s = (await provider.get('get_owed_archive', [{ type: 'int', value: BigInt(slot) }])).stack;
    return { count: s.readBigNumber(), root: s.readBigNumber(), total: s.readBigNumber() };
}
export async function getMinArchiveClaim(provider: ContractProvider, slot: number) {
    return (await provider.get('get_min_archive_claim', [{ type: 'int', value: BigInt(slot) }])).stack.readBigNumber();
}
const archivePair = (left: Buffer, right: Buffer) => beginCell().storeUint(3, 8).storeBuffer(left).storeBuffer(right).endCell().hash();
const archiveEmpty = () => beginCell().storeUint(0, 8).endCell().hash();
const archiveLeaf = (holder: Address, slot: number, c: ArchivedClaim) => beginCell().storeUint(1, 8).storeAddress(holder).storeUint(slot, 8)
    .storeUint(c.id, 64).storeAddress(c.owner).storeUint(c.amount, 120).endCell().hash();
const archiveConsumed = (holder: Address, slot: number, id: bigint) => beginCell().storeUint(2, 8).storeAddress(holder).storeUint(slot, 8).storeUint(id, 64).endCell().hash();

/** Public history reconstruction. JARC is an optional indexing hint; accepted transaction
 * bodies and state roots remain authoritative. Missing history or stale roots fail closed.
 * Keep consumed leaves: deleting them would reconstruct the wrong root. */
export class OwedArchiveReconstruction {
    readonly leaves = new Map<bigint, Buffer>();
    readonly claims = new Map<bigint, ArchivedClaim>();
    count = 0n;
    constructor(readonly holder: Address, readonly slot: number) {}
    append(claim: ArchivedClaim) {
        if (claim.id !== this.count || this.count >= 1n << 64n || claim.amount <= 0n || claim.amount >= 1n << 120n) throw new Error('Invalid archive append or missing history');
        this.leaves.set(claim.id, archiveLeaf(this.holder, this.slot, claim)); this.claims.set(claim.id, claim); this.count++;
    }
    consume(claim: ArchivedClaim) {
        const known = this.claims.get(claim.id);
        if (!known || !known.owner.equals(claim.owner) || known.amount !== claim.amount) throw new Error('Unknown or substituted archive claim');
        this.leaves.set(claim.id, archiveConsumed(this.holder, this.slot, claim.id)); this.claims.delete(claim.id);
    }
    witness(id: bigint, expectedRoot: bigint) {
        if (!this.claims.has(id)) throw new Error('No live archive claim');
        const result = this.reconstruct(id);
        if (result.root !== expectedRoot) throw new Error('Stale or incomplete archive history');
        return result.proof;
    }
    reconstruct(id = 0n) {
        let nodes = new Map(this.leaves), zero = archiveEmpty(), cursor = id;
        const siblings: Buffer[] = [];
        for (let level = 0; level < 64; level++) {
            siblings.push(nodes.get(cursor ^ 1n) ?? zero);
            const next = new Map<bigint, Buffer>();
            for (const key of new Set([...nodes.keys()].map(k => k >> 1n))) next.set(key, archivePair(nodes.get(key << 1n) ?? zero, nodes.get((key << 1n) | 1n) ?? zero));
            nodes = next; zero = archivePair(zero, zero); cursor >>= 1n;
        }
        let proof: Cell | null = null;
        for (let level = 63; level >= 0; level--) proof = beginCell().storeBuffer(siblings[level]).storeMaybeRef(proof).endCell();
        return { root: BigInt('0x' + (nodes.get(0n) ?? zero).toString('hex')), proof: proof! };
    }
}
export function parseOwedArchivedLog(cell: Cell): ({ slot: number } & ArchivedClaim) | null {
    if (cell.isExotic) return null;
    const s = cell.beginParse();
    if (s.remainingBits < 32 || s.preloadUint(32) !== OP.OWED_ARCHIVED) return null;
    s.loadUint(32); const result = { slot: s.loadUint(8), id: s.loadUintBig(64), owner: s.loadAddress(), amount: s.loadCoins() }; s.endParse(); return result;
}
