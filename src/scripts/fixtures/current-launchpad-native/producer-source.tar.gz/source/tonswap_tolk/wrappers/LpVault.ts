import { Address,beginCell,Cell,Contract,ContractProvider,Sender,contractAddress } from '@ton/core';
import { OP } from './generated/opcodes';
import { RecoverableLaunchpadChild,SaleIdentity,childInitialData,launchpadInt } from './utils/launchpadInit';
export class LpVault extends RecoverableLaunchpadChild implements Contract{
 static createFromAddress(a:Address){return new LpVault(a);}
 static createFromIdentity(id:Omit<SaleIdentity,'role'>,code:Cell){const init={code,data:childInitialData({...id,role:1})};return new LpVault(contractAddress(0,init),init);}
 async sendSeed(p:ContractProvider,via:Sender,value:bigint,fwdT3:bigint,fwdX:bigint,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.LP_SEED,32).storeUint(queryId,64).storeCoins(fwdT3).storeCoins(fwdX).endCell());}
 async sendRelease(p:ContractProvider,via:Sender,value:bigint,t3:bigint,x:bigint,remove=false,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.LP_RELEASE,32).storeUint(queryId,64).storeCoins(t3).storeCoins(x).storeBit(remove).endCell());}
 async getState(p:ContractProvider){const s=(await p.get('get_lp_vault',[])).stack,config=s.readCell(),b=s.readCell().beginParse();return{config,pool:b.loadMaybeAddress(),armedAt:b.loadUint(32),unlockAt:b.loadUint(32),t3Bal:b.loadCoins(),tokenBal:b.loadCoins(),ready:s.readBoolean()};}
 async getSeedFloor(p:ContractProvider,slot:number){return(await p.get('get_seed_floor',[launchpadInt(slot)])).stack.readBigNumber();}
 async getSeedValue(p:ContractProvider,fwdT3:bigint,fwdX:bigint){return(await p.get('get_seed_value',[launchpadInt(fwdT3),launchpadInt(fwdX)])).stack.readBigNumber();}
}
