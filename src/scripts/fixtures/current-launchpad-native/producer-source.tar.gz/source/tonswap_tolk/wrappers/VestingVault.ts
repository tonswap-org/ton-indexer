import { Address,beginCell,Cell,Contract,ContractProvider,Sender,contractAddress } from '@ton/core';
import { OP } from './generated/opcodes';
import { LaunchpadChild,SaleIdentity,childInitialData } from './utils/launchpadInit';
export class VestingVault extends LaunchpadChild implements Contract{
 static createFromAddress(a:Address){return new VestingVault(a);}
 static createFromIdentity(id:Omit<SaleIdentity,'role'>,code:Cell){const init={code,data:childInitialData({...id,role:2})};return new VestingVault(contractAddress(0,init),init);}
 async sendClaim(p:ContractProvider,via:Sender,value:bigint,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.VEST_CLAIM,32).storeUint(queryId,64).endCell());}
 async sendReturn(p:ContractProvider,via:Sender,value:bigint,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.VEST_RETURN,32).storeUint(queryId,64).endCell());}
 async getState(p:ContractProvider){const s=(await p.get('get_vesting',[])).stack,config=s.readCell(),b=s.readCell().beginParse();return{config,deposited:b.loadCoins(),claimed:b.loadCoins(),returned:b.loadCoins(),start:b.loadUint(32),failed:b.loadBit(),vested:s.readBigNumber(),claimable:s.readBigNumber()};}
}
