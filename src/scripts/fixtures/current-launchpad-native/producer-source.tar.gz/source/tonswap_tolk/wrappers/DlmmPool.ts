import { JettonWalletBudget, JettonWalletProfile, jettonWalletBudgetToCell, decodeJettonWalletBudget, validateJettonWalletProfile } from './jettonWalletBudget';
import { ClaimArchivedRequest, sendClaimArchived, getOwedArchive, getMinArchiveClaim } from './jettonSlots';
import { Address, beginCell, Cell, Contract, contractAddress, ContractProvider, Dictionary, DictionaryValue, Sender, SendMode, Slice } from '@ton/core';
import { OP } from './generated/opcodes';
import { jettonLedgerConfigToCell, getSweep, getMinSweep, sendSweepProbe, getOwed, getOwedBook, sendClaimOwed, getJettonSlots, sendDiscoverWallets } from './jettonSlots';
import { emptyRingCell, evidenceDecode } from './utils/oracleEvidence';

export const MAX_SWAP_BINS = 7;
export const MAX_LIQ_ADD_BINS = 1;
export const MAX_LIQ_REMOVE_BINS = 2;
export const MAX_BINS = 8192;
export const MAX_POSITIONS = 12288;
export const MAX_CAMPAIGNS = 32;
export const POOL_OWED_CAP = 512;
export const POOL_PUBLIC_BIN_SPACING = 2500;
export const POOL_PUBLIC_FEE_PIPS = 3000;
export const POOL_PUBLIC_WALLET_GAS_X = 30_000;
export const POOL_PUBLIC_WALLET_GRAM_X = 0n;
export const SWAP_PREWALK_GAS_MAX = 60_000;
export const APPLY_TAIL_GAS_MAX = 80_000;
export const STEP_GAS_MAX = 30_000;
export const SWAP_GAS_MAX = 300_000;
export const ADD_GAS_MAX = 300_000;
export const ADD_TAIL_GAS_MAX = 85_000;
export const REMOVE_GAS_MAX = 300_000;
export const FARM_GAS_MAX = 190_000;
export const POOL_REFUND_TAIL_GAS = 350_000;

export type PoolId = { xMaster: Address; binSpacing: number; feePips: number; xDecimals: number; walletGasX: number; walletGramX: bigint; walletBudgetX: JettonWalletBudget };
export type PoolIdentity = { factory: Address; feeSink: Address; treasury: Address; t3Master: Address; t3Wallet: JettonWalletProfile; id: PoolId };
export type LiqAddRow = { binId: number; amount: bigint; minShares: bigint };
export type LiqRemoveRow = { binId: number; shares: bigint };
export type LiqResultRow = { binId: number; shares: bigint };
export type LiqAdd = { owner: Address; notify: boolean; rows: readonly LiqAddRow[] };
export type LiqRemove = { queryId: bigint; recipient: Address; deadline: number; minT3: bigint; minX: bigint; rows: readonly LiqRemoveRow[] };
export type LiqOutcome = { queryId: bigint; status: number; reason: number; side: number; amount: bigint; rows: readonly LiqResultRow[] };
export type PoolBin = { t: bigint; x: bigint; shares: bigint; pq: bigint };
export type PoolPosition = { shares: bigint; farmId: bigint; accSnap: bigint; rewardCarry: bigint };
export const poolBinValue: DictionaryValue<PoolBin> = {
    serialize: (v, b) => { b.storeCoins(v.t).storeCoins(v.x).storeUint(v.shares, 256).storeUint(v.pq, 128); },
    parse: s => ({ t: s.loadCoins(), x: s.loadCoins(), shares: s.loadUintBig(256), pq: s.loadUintBig(128) }),
};
export const poolPositionValue: DictionaryValue<PoolPosition> = {
    serialize: (v, b) => { b.storeUint(v.shares, 256).storeUint(v.farmId, 64).storeUint(v.accSnap, 256).storeMaybeRef(v.rewardCarry === 0n ? null : beginCell().storeUint(v.rewardCarry, 128).endCell()); },
    parse: s => ({ shares: s.loadUintBig(256), farmId: s.loadUintBig(64), accSnap: s.loadUintBig(256), rewardCarry: s.loadMaybeRef()?.beginParse().loadUintBig(128) ?? 0n }),
};
export function farmCreateBody(binId: number, duration: number): Cell {
    return beginCell().storeUint(OP.FARM_CREATE, 32).storeInt(binId, 32).storeUint(duration, 32).endCell();
}
export function farmActionBody(action: number, farmId: bigint, owner: Address, queryId = 0n): Cell {
    if (owner.workChain !== 0 || !Number.isInteger(action) || action < 1 || action > 5) throw new Error('Invalid farm action');
    return beginCell().storeUint(OP.FARM_ACTION, 32).storeUint(queryId, 64).storeUint(action, 8).storeUint(farmId, 64).storeAddress(owner).endCell();
}
export function liqEvictBody(owner: Address, binId: number, queryId = 0n): Cell {
    if (owner.workChain !== 0) throw new Error('Invalid liquidity owner');
    return beginCell().storeUint(OP.LIQ_EVICT, 32).storeUint(queryId, 64).storeAddress(owner).storeInt(binId, 32).endCell();
}

export function poolIdToCell(id: PoolId): Cell {
    validateJettonWalletProfile({walletGas:id.walletGasX,walletGram:id.walletGramX,budget:id.walletBudgetX});
    if (id.xMaster.workChain !== 0 || !Number.isInteger(id.binSpacing) || id.binSpacing < 1 || id.binSpacing > 10_000
        || !Number.isInteger(id.feePips) || id.feePips < 0 || id.feePips > 100_000
        || !Number.isInteger(id.xDecimals) || id.xDecimals < 0 || id.xDecimals > 18
        || !Number.isInteger(id.walletGasX) || id.walletGasX < 10_000 || id.walletGasX > 500_000
        || id.walletGramX < 0n || id.walletGramX > 500_000_000n) throw new Error('Invalid pool identity');
    return beginCell().storeAddress(id.xMaster).storeUint(id.binSpacing, 16).storeUint(id.feePips, 32)
        .storeUint(id.xDecimals, 8).storeUint(id.walletGasX, 32).storeCoins(id.walletGramX).storeRef(jettonWalletBudgetToCell(id.walletBudgetX)).endCell();
}
export function decodePoolId(cell: Cell): PoolId | null {
    try {
        if (cell.isExotic) return null;
        const s = cell.beginParse();
        const id = { xMaster: s.loadAddress(), binSpacing: s.loadUint(16), feePips: s.loadUint(32), xDecimals: s.loadUint(8), walletGasX: s.loadUint(32), walletGramX: s.loadCoins(), walletBudgetX: decodeJettonWalletBudget(s.loadRef()) };
        s.endParse(); poolIdToCell(id); return id;
    } catch { return null; }
}
export function poolInitialData(cfg: PoolIdentity): Cell {
    poolIdToCell(cfg.id);
    for (const address of [cfg.factory, cfg.feeSink, cfg.treasury, cfg.t3Master]) if (address.workChain !== 0) throw new Error('Pool peers must use basechain addresses');
    const ledger = jettonLedgerConfigToCell([
        { slot: 0, master: cfg.t3Master, ...cfg.t3Wallet },
        { slot: 1, master: cfg.id.xMaster, walletGas: cfg.id.walletGasX, walletGram: cfg.id.walletGramX, budget: cfg.id.walletBudgetX, optional: true },
    ]);
    const recovery = cfg.t3Wallet.budget.creditProtection ? beginCell().storeUint(0,256).storeUint(0,256).storeCoins(0).storeBit(false).storeUint(0,256).endCell() : null;
    const jet = beginCell().storeSlice(ledger.beginParse()).storeUint(0, 256).storeDict(null).storeMaybeRef(recovery).endCell();
    const farming = beginCell().storeUint(1, 64).storeCoins(0).storeCoins(0).storeDict(null).endCell();
    const cold = beginCell().storeAddress(cfg.factory).storeAddress(cfg.feeSink).storeAddress(cfg.treasury).storeDict(null).storeRef(farming).endCell();
    return beginCell().storeUint(0, 8).storeUint(cfg.id.binSpacing, 16).storeUint(cfg.id.feePips, 32).storeUint(cfg.id.xDecimals, 8)
        .storeInt(0, 32).storeCoins(0).storeUint(0, 16).storeUint(0, 16).storeUint(0, 8)
        .storeRef(jet).storeRef(beginCell().storeCoins(0).storeCoins(0).storeDict(null).endCell()).storeRef(emptyRingCell()).storeRef(cold).endCell();
}
function liquidityRows<T extends { binId: number }>(rows: readonly T[], maxRows: number, encode: (row: T) => Cell): Cell {
    if (rows.length < 1 || rows.length > maxRows) throw new Error('Invalid liquidity row count');
    let next: Cell | null = null;
    for (let i = rows.length - 1; i >= 0; i--) {
        if (!Number.isInteger(rows[i].binId) || rows[i].binId < -200_000 || rows[i].binId > 200_000
            || (i > 0 && rows[i - 1].binId >= rows[i].binId)) throw new Error('Liquidity bins must be valid, unique and ascending');
        next = beginCell().storeSlice(encode(rows[i]).beginParse()).storeMaybeRef(next).endCell();
    }
    return next!;
}
function readLiquidityRows<T extends { binId: number }>(count: number, first: Cell, maxRows: number, read: (s: Slice) => T): T[] {
    if (count < 1 || count > maxRows) throw new Error('Invalid row count');
    const result: T[] = [];
    let next: Cell | null = first;
    for (let i = 0; i < count; i++) {
        if (!next || next.isExotic) throw new Error('Invalid liquidity row');
        const s: Slice = next.beginParse();
        const row = read(s);
        if (row.binId < -200_000 || row.binId > 200_000 || (i > 0 && result[i - 1].binId >= row.binId)) throw new Error('Invalid bin order');
        next = s.loadMaybeRef(); s.endParse(); result.push(row);
    }
    if (next) throw new Error('Trailing liquidity row');
    return result;
}
export function liqAddBody(request: LiqAdd): Cell {
    if (request.owner.workChain !== 0 || request.rows.some(row => row.amount <= 0n)) throw new Error('Invalid liquidity add');
    return beginCell().storeUint(OP.LIQ_ADD, 32).storeAddress(request.owner).storeBit(request.notify).storeUint(request.rows.length, 3)
        .storeRef(liquidityRows(request.rows, MAX_LIQ_ADD_BINS, row => beginCell().storeInt(row.binId, 32).storeCoins(row.amount).storeUint(row.minShares, 256).endCell())).endCell();
}
export function liqRemoveBody(request: LiqRemove): Cell {
    if (request.recipient.workChain !== 0) throw new Error('Invalid liquidity recipient');
    return beginCell().storeUint(OP.LIQ_REMOVE, 32).storeUint(request.queryId, 64).storeAddress(request.recipient).storeUint(request.deadline, 32)
        .storeCoins(request.minT3).storeCoins(request.minX).storeUint(request.rows.length, 3)
        .storeRef(liquidityRows(request.rows, MAX_LIQ_REMOVE_BINS, row => beginCell().storeInt(row.binId, 32).storeUint(row.shares, 256).endCell())).endCell();
}
export function liqOutcomeBody(request: LiqOutcome): Cell {
    return beginCell().storeUint(OP.LIQ_OUTCOME, 32).storeUint(request.queryId, 64).storeUint(request.status, 8).storeUint(request.reason, 8)
        .storeUint(request.side, 8).storeUint(request.rows.length, 3).storeCoins(request.amount)
        .storeRef(liquidityRows(request.rows, MAX_LIQ_ADD_BINS, row => beginCell().storeInt(row.binId, 32).storeUint(row.shares, 256).endCell())).endCell();
}
export function decodeLiqAdd(cell: Cell): LiqAdd | null {
    try {
        if (cell.isExotic) return null;
        const s = cell.beginParse(); if (s.loadUint(32) !== OP.LIQ_ADD) return null;
        const owner = s.loadAddress(), notify = s.loadBit(), count = s.loadUint(3);
        const rows = readLiquidityRows(count, s.loadRef(), MAX_LIQ_ADD_BINS, row => ({ binId: row.loadInt(32), amount: row.loadCoins(), minShares: row.loadUintBig(256) }));
        s.endParse(); if (owner.workChain !== 0 || rows.some(row => row.amount <= 0n)) return null;
        return { owner, notify, rows };
    } catch { return null; }
}
export function decodeLiqRemove(cell: Cell): LiqRemove | null {
    try {
        if (cell.isExotic) return null;
        const s = cell.beginParse(); if (s.loadUint(32) !== OP.LIQ_REMOVE) return null;
        const queryId = s.loadUintBig(64), recipient = s.loadAddress(), deadline = s.loadUint(32), minT3 = s.loadCoins(), minX = s.loadCoins(), count = s.loadUint(3);
        const rows = readLiquidityRows(count, s.loadRef(), MAX_LIQ_REMOVE_BINS, row => ({ binId: row.loadInt(32), shares: row.loadUintBig(256) }));
        s.endParse(); if (recipient.workChain !== 0) return null;
        return { queryId, recipient, deadline, minT3, minX, rows };
    } catch { return null; }
}
export function decodeLiqOutcome(cell: Cell): LiqOutcome | null {
    try {
        if (cell.isExotic) return null;
        const s = cell.beginParse(); if (s.loadUint(32) !== OP.LIQ_OUTCOME) return null;
        const queryId = s.loadUintBig(64), status = s.loadUint(8), reason = s.loadUint(8), side = s.loadUint(8), count = s.loadUint(3), amount = s.loadCoins();
        const rows = readLiquidityRows(count, s.loadRef(), MAX_LIQ_ADD_BINS, row => ({ binId: row.loadInt(32), shares: row.loadUintBig(256) }));
        s.endParse(); if (status > 2 || side > 1) return null;
        return { queryId, status, reason, side, amount, rows };
    } catch { return null; }
}

export class DlmmPool implements Contract {
    async sendClaimArchived(provider: ContractProvider, via: Sender, value: bigint, request: ClaimArchivedRequest, queryId = 0n) { return sendClaimArchived(provider, via, value, request, queryId); }
    async getOwedArchive(provider: ContractProvider, slot = 0) { return getOwedArchive(provider, slot); }
    async getMinArchiveClaim(provider: ContractProvider, slot = 0) { return getMinArchiveClaim(provider, slot); }

    async getJettonSlots(provider: ContractProvider) { return getJettonSlots(provider); }
    async getMinDiscover(provider: ContractProvider) { return (await provider.get('get_min_discover', [])).stack.readBigNumber(); }
    async sendDiscoverWallets(provider: ContractProvider, via: Sender, value: bigint, queryId = 0n) {
        return sendDiscoverWallets(provider, via, value, queryId);
    }
    async getMinClaim(provider: ContractProvider, slot: number) {
        return (await provider.get('get_min_claim', [{ type: 'int', value: BigInt(slot) }])).stack.readBigNumber();
    }
    async sendClaimOwed(provider: ContractProvider, via: Sender, value: bigint, slot: number, owner: Address, queryId = 0n) {
        return sendClaimOwed(provider, via, value, slot, owner, queryId);
    }

    async getOwed(provider: ContractProvider, slot: number, owner: Address) { return getOwed(provider, slot, owner); }
    async getOwedBook(provider: ContractProvider, slot: number) { return getOwedBook(provider, slot); }
    async getJettonLiabilities(provider: ContractProvider, slot: number) {
        return (await provider.get('get_jetton_liabilities', [{ type: 'int', value: BigInt(slot) }])).stack.readBigNumber();
    }
    async getCreditRecovery(provider: ContractProvider) {
        const cell=(await provider.get('get_credit_recovery',[])).stack.readCellOpt();
        if(!cell)return null;
        const s=cell.beginParse(),dispatched=s.loadUintBig(256),handled=s.loadUintBig(256),pending=s.loadCoins(),tree=s.loadMaybeRef(),restored=s.loadUintBig(256);s.endParse();
        return {handled,pending,tree,dispatched,restored};
    }
    async getMinCreditRecovery(provider: ContractProvider, claim=false) {
        return (await provider.get('get_min_credit_recovery',[{type:'int',value:claim?-1n:0n}])).stack.readBigNumber();
    }
    async sendClaimCredit(provider:ContractProvider,via:Sender,value:bigint,receipt:Cell,proof:Cell) {
        await provider.internal(via,{value,sendMode:SendMode.PAY_GAS_SEPARATELY,body:beginCell().storeUint(OP.POOL_NOTIFICATION_CLAIM,32).storeRef(receipt).storeRef(proof).endCell()});
    }

    async getSurplus(provider: ContractProvider, slot: number, balance: bigint, protectedCredits: bigint | null, acceptedTransfers: bigint | null) {
        const s=(await provider.get('get_unattributed_surplus', [{type:'int',value:BigInt(slot)}, {type:'int',value:balance},
            protectedCredits===null?{type:'null'}:{type:'int',value:protectedCredits},acceptedTransfers===null?{type:'null'}:{type:'int',value:acceptedTransfers}])).stack;
        return {liabilities:s.readBigNumber(),surplus:s.readBigNumber(),deficit:s.readBigNumber()};
    }
    async getSweep(provider: ContractProvider, slot: number) { return getSweep(provider, slot); }
    async getMinSweep(provider: ContractProvider, slot: number) { return getMinSweep(provider, slot); }
    async getSweepBusy(provider: ContractProvider) { return (await provider.get('get_sweep_busy', [])).stack.readBigNumber(); }
    async sendSweepProbe(provider: ContractProvider, via: Sender, value: bigint, slot: number, queryId = 0n) {
        return sendSweepProbe(provider, via, value, slot, queryId);
    }

    static createFromIdentity(config: PoolIdentity, code: Cell, workchain = 0) {
        if (workchain !== 0) throw new Error("Pool must use a basechain address");
        const init = { code, data: poolInitialData(config) };
        return new DlmmPool(contractAddress(workchain, init), init);
    }
    async getPoolInfo(provider: ContractProvider) {
        const { stack } = await provider.get('get_pool_info', []);
        const id = decodePoolId(stack.readCell());
        if (!id) throw new Error('Invalid pool getter identity');
        return { id, factory: stack.readAddress(), feeSink: stack.readAddress(), treasury: stack.readAddress(), t3Master: stack.readAddress(),
            flags: stack.readNumber(), ready: stack.readBoolean(), activeBin: stack.readNumber(), reserveT: stack.readBigNumber(), reserveX: stack.readBigNumber(),
            protocolFeesT3: stack.readBigNumber(), binCount: stack.readNumber(), positionCount: stack.readNumber(), campaignCount: stack.readNumber() };
    }
    async getSwapMinForward(provider: ContractProvider, inSide: number, fwdGram = 0n, refundFwdGram = 0n, notifyOrigin = false) {
        return (await provider.get('get_swap_min_forward', [{ type: 'int', value: BigInt(inSide) }, { type: 'int', value: fwdGram },
            { type: 'int', value: refundFwdGram }, { type: 'int', value: notifyOrigin ? -1n : 0n }])).stack.readBigNumber();
    }
    async getRefundFloors(provider: ContractProvider, slot: number, refundFwdGram = 0n, notifyOrigin = false) {
        const { stack } = await provider.get('get_refund_floors', [{ type: 'int', value: BigInt(slot) }, { type: 'int', value: refundFwdGram }, { type: 'int', value: notifyOrigin ? -1n : 0n }]);
        return { refund: stack.readBigNumber(), owed: stack.readBigNumber() };
    }
    async getRouteRefundFloor(provider: ContractProvider, refundFwdGram = 0n) {
        return (await provider.get('get_route_refund_floor', [{ type: 'int', value: refundFwdGram }])).stack.readBigNumber();
    }
    async getSwapCheck(provider: ContractProvider, inSide: number, amountIn: bigint, swap: Cell, value: bigint) {
        const { stack } = await provider.get('get_swap_check', [{ type: 'int', value: BigInt(inSide) }, { type: 'int', value: amountIn }, { type: 'cell', cell: swap }, { type: 'int', value }]);
        return { status: stack.readNumber(), reason: stack.readNumber(), amountOut: stack.readBigNumber() };
    }
    async getSwapValue(provider: ContractProvider, inSide: number, amountIn: bigint, swap: Cell) {
        const { stack } = await provider.get('get_swap_value', [{ type: 'int', value: BigInt(inSide) }, { type: 'int', value: amountIn }, { type: 'cell', cell: swap }]);
        return { status: stack.readNumber(), reason: stack.readNumber(), value: stack.readBigNumber(), amountOut: stack.readBigNumber() };
    }
    async getQuote(provider: ContractProvider, inSide: number, amountIn: bigint) {
        const { stack } = await provider.get('get_quote', [{ type: 'int', value: BigInt(inSide) }, { type: 'int', value: amountIn }]);
        return { status: stack.readNumber(), amountOut: stack.readBigNumber(), grossFeeT3: stack.readBigNumber(), protocolFeeT3: stack.readBigNumber(), finalBin: stack.readNumber(), binsLoaded: stack.readNumber() };
    }
    async getFillLimit(provider: ContractProvider, inSide: number) {
        const { stack } = await provider.get('get_fill_limit', [{ type: 'int', value: BigInt(inSide) }]);
        return { amountIn: stack.readBigNumber(), amountOut: stack.readBigNumber() };
    }
    async getMinForward(provider: ContractProvider, op: number, slot: number) {
        return (await provider.get('get_min_forward', [{ type: 'int', value: BigInt(op) }, { type: 'int', value: BigInt(slot) }])).stack.readBigNumber();
    }
    async getPosition(provider: ContractProvider, owner: Address, binId: number) {
        const { stack } = await provider.get('get_position', [{ type: 'slice', cell: beginCell().storeAddress(owner).endCell() }, { type: 'int', value: BigInt(binId) }]);
        return { shares: stack.readBigNumber(), farmId: stack.readBigNumber(), valueT3: stack.readBigNumber(), minValue: stack.readBigNumber() };
    }
    async getEntryFees(provider: ContractProvider) {
        const { stack } = await provider.get('get_entry_fees', []);
        return { bin: stack.readBigNumber(), position: stack.readBigNumber(), campaign: stack.readBigNumber(), minAddValue: stack.readBigNumber() };
    }
    async getRent(provider: ContractProvider) {
        const { stack } = await provider.get('get_rent', []);
        return { target: stack.readBigNumber(), tip: stack.readBigNumber() };
    }
    async getBin(provider: ContractProvider, binId: number) {
        const cell = (await provider.get('get_bin', [{ type: 'int', value: BigInt(binId) }])).stack.readCellOpt();
        return cell ? poolBinValue.parse(cell.beginParse()) : null;
    }
    async getBins(provider: ContractProvider, fromBin: number, limit = 64) {
        const { stack } = await provider.get('get_bins', [fromBin, limit].map(value => ({ type: 'int', value: BigInt(value) })));
        return Dictionary.loadDirect(Dictionary.Keys.Int(32), poolBinValue, stack.readCellOpt());
    }
    async getPositions(provider: ContractProvider, owner: Address, fromBin: number, limit = 64) {
        const { stack } = await provider.get('get_positions', [{ type: 'slice', cell: beginCell().storeAddress(owner).endCell() },
            ...[fromBin, limit].map(value => ({ type: 'int' as const, value: BigInt(value) }))]);
        return Dictionary.loadDirect(Dictionary.Keys.Int(32), poolPositionValue, stack.readCellOpt());
    }
    async getFarm(provider: ContractProvider, farmId: bigint) {
        const cell = (await provider.get('get_farm', [{ type: 'int', value: farmId }])).stack.readCellOpt();
        if (!cell) return null;
        const s = cell.beginParse();
        const campaign = { end: s.loadUint(32), lastTs: s.loadUint(32), acc: s.loadUintBig(256), weight: s.loadUintBig(128), paid: s.loadCoins() };
        const terms = s.loadRef().beginParse(); s.endParse();
        const result = { ...campaign, binId: terms.loadInt(32), side: terms.loadUint(8), sponsor: terms.loadAddress(),
            total: terms.loadCoins(), start: terms.loadUint(32), duration: terms.loadUint(32) };
        terms.endParse(); return result;
    }
    async getFarmPending(provider: ContractProvider, farmId: bigint, owner: Address) {
        return (await provider.get('get_farm_pending', [{ type: 'int', value: farmId },
            { type: 'slice', cell: beginCell().storeAddress(owner).endCell() }])).stack.readBigNumber();
    }
    async getNextFarmId(provider: ContractProvider) { return (await provider.get('get_next_farm_id', [])).stack.readBigNumber(); }
    async sendFarmAction(provider: ContractProvider, via: Sender, value: bigint, action: number, farmId: bigint, owner: Address, queryId = 0n) {
        return provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: farmActionBody(action, farmId, owner, queryId) });
    }
    async getOracleEvidence(provider: ContractProvider, at = 0) {
        const cell = (await provider.get('oracle_evidence', [{ type: 'int', value: BigInt(at) }])).stack.readCell();
        const evidence = evidenceDecode(cell); if (!evidence) throw new Error('Invalid oracle evidence'); return evidence;
    }
    async getTwapAt(provider: ContractProvider, at: number, window: number) {
        const { stack } = await provider.get('twap_at', [at, window].map(value => ({ type: 'int', value: BigInt(value) })));
        return { available: stack.readBoolean(), avgBin: stack.readNumber(), priceE9: stack.readBigNumber(), coverageBps: stack.readNumber() };
    }
    async getObservationBounds(provider: ContractProvider) {
        const { stack } = await provider.get('observation_bounds', []);
        return { count: stack.readNumber(), oldestStart: stack.readNumber(), newestStart: stack.readNumber(), curBin: stack.readNumber(), curHealthy: stack.readBoolean() };
    }
    async getOracleMinForward(provider: ContractProvider) { return (await provider.get('get_oracle_min_forward', [])).stack.readBigNumber(); }

    constructor(readonly address: Address, readonly init?: { code: Cell; data: Cell }) {}

    static createFromAddress(address: Address) {
        return new DlmmPool(address);
    }

    async sendDeploy(provider: ContractProvider, via: Sender, value: bigint) {
        return provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().endCell(),
        });
    }

}
