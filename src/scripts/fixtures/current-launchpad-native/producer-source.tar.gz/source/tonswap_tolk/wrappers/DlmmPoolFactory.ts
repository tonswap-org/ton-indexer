import { JettonWalletProfile, decodeJettonWalletBudget, jettonWalletBudgetToCell, validateJettonWalletProfile } from './jettonWalletBudget';
import { Address, beginCell, Cell, Contract, contractAddress, ContractProvider, Sender, SendMode } from '@ton/core';
import { PoolId, poolIdToCell } from './DlmmPool';
import { OP } from './generated/opcodes';

export type PoolFactoryConfig = { governance: Address; feeSink: Address; treasury: Address; t3Master: Address; t3Wallet: JettonWalletProfile; blockedX: Address | null; poolCode: Cell };
export function poolFactoryInitialData(cfg: PoolFactoryConfig): Cell {
    validateJettonWalletProfile(cfg.t3Wallet);
    for (const peer of [cfg.governance, cfg.feeSink, cfg.treasury, cfg.t3Master, cfg.blockedX]) if (peer && peer.workChain !== 0) throw new Error('Factory peers must use basechain addresses');
    const cells = new Set<string>(); let bits = 0;
    const visit = (cell: Cell) => {
        const hash = cell.hash().toString('hex'); if (cells.has(hash)) return;
        cells.add(hash); bits += cell.bits.length; cell.refs.forEach(visit);
    };
    visit(cfg.poolCode);
    return beginCell().storeRef(beginCell().storeAddress(cfg.governance).storeAddress(cfg.feeSink).storeAddress(cfg.treasury).endCell())
        .storeAddress(cfg.t3Master).storeAddress(cfg.blockedX).storeUint(bits, 32).storeUint(cells.size, 16).storeRef(cfg.poolCode).storeUint(cfg.t3Wallet.walletGas,32).storeCoins(cfg.t3Wallet.walletGram).storeRef(jettonWalletBudgetToCell(cfg.t3Wallet.budget)).endCell();
}

export function factorySweepAllowBody(pool: Address, slot: number, amount: bigint, queryId = 0n): Cell {
    return beginCell().storeUint(OP.FACTORY_SWEEP_ALLOW, 32).storeAddress(pool).storeUint(queryId, 64).storeUint(slot, 8).storeCoins(amount).endCell();
}

export class DlmmPoolFactory implements Contract {
    async getFactoryInfo(provider: ContractProvider) {
        const s = (await provider.get('get_factory_info', [])).stack;
        return { governance: s.readAddress(), feeSink: s.readAddress(), treasury: s.readAddress(),
            t3Master: s.readAddress(), blockedX: s.readAddressOpt(), poolCodeBits: s.readNumber(),
            poolCodeCells: s.readNumber(), poolCode: s.readCell(), t3Wallet: {
                walletGas: s.readNumber(), walletGram: s.readBigNumber(), budget: decodeJettonWalletBudget(s.readCell()),
            } };
    }
    async sendSweepAllow(provider: ContractProvider, via: Sender, value: bigint, pool: Address, slot: number, amount: bigint, queryId = 0n) {
        return provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: factorySweepAllowBody(pool, slot, amount, queryId) });
    }

    static createFromIdentity(config: PoolFactoryConfig, code: Cell, workchain = 0) {
        if (workchain !== 0) throw new Error("Factory must use a basechain address");
        const init = { code, data: poolFactoryInitialData(config) };
        return new DlmmPoolFactory(contractAddress(workchain, init), init);
    }

    async getPoolAddress(provider: ContractProvider, id: PoolId) {
        return (await provider.get('get_pool_address', [{ type: 'cell', cell: poolIdToCell(id) }])).stack.readAddress();
    }
    async getCreateMinValue(provider: ContractProvider) {
        return (await provider.get('get_create_min_value', [])).stack.readBigNumber();
    }
    async getCreateMinValueFor(provider: ContractProvider, id: PoolId) {
        return (await provider.get('get_create_min_value_for', [{ type: 'cell', cell: poolIdToCell(id) }])).stack.readBigNumber();
    }
    async getRelayMinValue(provider: ContractProvider) {
        return (await provider.get('get_relay_min_value', [])).stack.readBigNumber();
    }
    async sendPoolCreate(provider: ContractProvider, via: Sender, value: bigint, id: PoolId, notify = false) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().storeUint(OP.POOL_CREATE, 32).storeRef(poolIdToCell(id)).storeBit(notify).endCell() });
    }

    constructor(readonly address: Address, readonly init?: { code: Cell; data: Cell }) {}

    static createFromAddress(address: Address) {
        return new DlmmPoolFactory(address);
    }

    async sendDeploy(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().endCell(),
        });
    }

}
