import { Address, beginCell, Builder, Cell, Slice } from '@ton/core';
import { OP } from '../generated/opcodes';

export const NOTIFY_GAS = 24_000;
export const POOL_REFUND_GAS_MAX = 400_000;
export const POOL_REFUND_SEND_GAS_MAX = 95_000;
export const POOL_ROUTE_REFUND_SEND_GAS_MAX = 110_000;
export const POOL_BOUNCE_GAS = 250_000;
export const COORD_BOUNCE_GAS = 250_000;
export const ROUTE_GAS_MAX = 48_000;
export const PAYLOAD_RECIPIENT_GAS = 65_000;

export const SwapStatus = { EXECUTED: 0, REFUND: 1, INPUT_OWED: 2, REFUND_PLAIN: 3 } as const;
export const SwapReason = {
    NONE: 0, MALFORMED: 1, NOT_READY: 2, PAUSED: 3, DEADLINE: 4, ADDRESS: 5, VALUE: 6,
    SLIPPAGE: 7, LIQUIDITY: 8, MATH: 10, PAYLOAD_SIZE: 11, BIN: 12, WRONG_SIDE: 13,
    MIN_VALUE: 14, CAPACITY: 15, STAKED: 16, ROUTE: 17,
} as const;

export type Swap = {
    minOut: bigint; deadline: number; recipient: Address; refundTo: Address; notifyOrigin: boolean;
    fwdGram: bigint; refundFwdGram: bigint; fwdPayload: Cell | null;
};
export type SwapResult = {
    queryId: bigint; origin: Address; status: number; reason: number;
    amountIn: bigint; amountOut: bigint; user: Cell | null;
};
export type SwapOutcome = {
    queryId: bigint; status: number; reason: number; inSide: number; amountIn: bigint; amountOut: bigint;
};
export type SwapEvent = SwapOutcome & {
    origin: Address; grossFeeT3: bigint; protocolFeeT3: bigint; activeBin: number; binsLoaded: number;
};
export type RouteCont = { pool: Address; swap: Cell };
type Payload = Cell | Slice;

// A slice must already have been opened as an ordinary cell by the TEP-74 decoder.
// Cloning leaves that decoder's cursor untouched. A public cell input is checked here.
function parse<T>(payload: Payload, op: number, read: (s: Slice) => T): T | null {
    try {
        if (payload instanceof Cell && payload.isExotic) return null;
        const s = payload instanceof Cell ? payload.beginParse() : payload.clone();
        if (s.loadUint(32) !== op) return null;
        const value = read(s);
        s.endParse();
        return value;
    } catch { return null; }
}

function address(s: Slice): Address {
    if (s.preloadUint(11) !== 0b10000000000) throw new Error('Expected a standard workchain-0 address');
    return s.loadAddress();
}

function ordinary(c: Cell): Cell {
    if (c.isExotic) throw new Error('Expected an ordinary payload cell');
    return c;
}

function maybeRef(s: Slice): Cell | null {
    return s.loadBit() ? ordinary(s.loadRef()) : null;
}

function disposition(status: number, reason: number, maxStatus: number, inSide = 0) {
    if (status > maxStatus || reason > SwapReason.ROUTE || reason === 9 || inSide > 1) {
        throw new Error('Unknown swap disposition');
    }
}

// Apply the same address and disposition rules to outgoing values as to incoming cells.
function encoded<T>(builder: Builder, decode: (cell: Cell) => T | null): Cell {
    const cell = builder.endCell();
    if (decode(cell) === null) throw new Error('Invalid swap wire fields');
    return cell;
}

export function encodeSwap(swap: Swap): Cell {
    return encoded(beginCell().storeUint(OP.SWAP, 32).storeCoins(swap.minOut).storeUint(swap.deadline, 32)
        .storeAddress(swap.recipient).storeAddress(swap.refundTo).storeBit(swap.notifyOrigin)
        .storeCoins(swap.fwdGram).storeCoins(swap.refundFwdGram).storeMaybeRef(swap.fwdPayload), decodeSwap);
}

export function decodeSwap(payload: Payload): Swap | null {
    return parse(payload, OP.SWAP, s => ({
        minOut: s.loadCoins(), deadline: s.loadUint(32), recipient: address(s), refundTo: address(s),
        notifyOrigin: s.loadBit(), fwdGram: s.loadCoins(), refundFwdGram: s.loadCoins(), fwdPayload: maybeRef(s),
    }));
}

export function encodeSwapResult(result: SwapResult): Cell {
    return encoded(beginCell().storeUint(OP.SWAP_RESULT, 32).storeUint(result.queryId, 64).storeAddress(result.origin)
        .storeUint(result.status, 8).storeUint(result.reason, 8).storeCoins(result.amountIn).storeCoins(result.amountOut)
        .storeMaybeRef(result.user), decodeSwapResult);
}

export function decodeSwapResult(payload: Payload): SwapResult | null {
    return parse(payload, OP.SWAP_RESULT, s => {
        const result = {
            queryId: s.loadUintBig(64), origin: address(s), status: s.loadUint(8), reason: s.loadUint(8),
            amountIn: s.loadCoins(), amountOut: s.loadCoins(), user: maybeRef(s),
        };
        disposition(result.status, result.reason, SwapStatus.REFUND);
        return result;
    });
}

export function encodeSwapOutcome(outcome: SwapOutcome): Cell {
    return encoded(beginCell().storeUint(OP.SWAP_OUTCOME, 32).storeUint(outcome.queryId, 64)
        .storeUint(outcome.status, 8).storeUint(outcome.reason, 8).storeUint(outcome.inSide, 8)
        .storeCoins(outcome.amountIn).storeCoins(outcome.amountOut), decodeSwapOutcome);
}

export function decodeSwapOutcome(payload: Payload): SwapOutcome | null {
    return parse(payload, OP.SWAP_OUTCOME, s => {
        const outcome = {
            queryId: s.loadUintBig(64), status: s.loadUint(8), reason: s.loadUint(8), inSide: s.loadUint(8),
            amountIn: s.loadCoins(), amountOut: s.loadCoins(),
        };
        disposition(outcome.status, outcome.reason, SwapStatus.INPUT_OWED, outcome.inSide);
        return outcome;
    });
}

export function encodeSwapEvent(event: SwapEvent): Cell {
    return encoded(beginCell().storeUint(OP.SWAP_EVENT, 32).storeUint(event.queryId, 64).storeAddress(event.origin)
        .storeUint(event.inSide, 8).storeUint(event.status, 8).storeUint(event.reason, 8)
        .storeCoins(event.amountIn).storeCoins(event.amountOut).storeCoins(event.grossFeeT3).storeCoins(event.protocolFeeT3)
        .storeInt(event.activeBin, 32).storeUint(event.binsLoaded, 8), decodeSwapEvent);
}

export function decodeSwapEvent(payload: Payload): SwapEvent | null {
    return parse(payload, OP.SWAP_EVENT, s => {
        const event = {
            queryId: s.loadUintBig(64), origin: address(s), inSide: s.loadUint(8), status: s.loadUint(8), reason: s.loadUint(8),
            amountIn: s.loadCoins(), amountOut: s.loadCoins(), grossFeeT3: s.loadCoins(), protocolFeeT3: s.loadCoins(),
            activeBin: s.loadInt(32), binsLoaded: s.loadUint(8),
        };
        disposition(event.status, event.reason, SwapStatus.REFUND_PLAIN, event.inSide);
        return event;
    });
}

export function encodeRouteCont(cont: RouteCont): Cell {
    return encoded(beginCell().storeUint(OP.ROUTE_CONT, 32).storeAddress(cont.pool).storeRef(cont.swap), decodeRouteCont);
}

/** Keeps the inner cell intact. The destination pool separately parses it as Swap. */
export function decodeRouteCont(payload: Payload): RouteCont | null {
    return parse(payload, OP.ROUTE_CONT, s => ({ pool: address(s), swap: ordinary(s.loadRef()) }));
}

export type SwapPool = {
    address: Address;
    getPoolInfo(): Promise<{ ready: boolean; t3Master: Address; id: { xMaster: Address } }>;
    getSwapValue(inSide: number, amountIn: bigint, swap: Cell): Promise<{ status: number; reason: number; value: bigint; amountOut: bigint }>;
};
export type SwapRequest = Swap & { pool: SwapPool; inputMaster: Address; amountIn: bigint };

/** Quotes the exact single-pool request. poolForwardGram excludes the sending wallet's fee. */
export async function buildSwap(request: SwapRequest): Promise<{ payload: Cell; inSide: number; poolForwardGram: bigint; amountOut: bigint }> {
    if (request.amountIn <= 0n) throw new Error('A swap requires amountIn > 0');
    const info = await request.pool.getPoolInfo();
    if (!info.ready) throw new Error('The swap pool must be ready');
    const inSide = request.inputMaster.equals(info.t3Master) ? 0 : request.inputMaster.equals(info.id.xMaster) ? 1 : -1;
    if (inSide < 0) throw new Error('Swap input does not match either pool token');
    const payload = encodeSwap(request);
    const quote = await request.pool.getSwapValue(inSide, request.amountIn, payload);
    if (quote.status !== 0) throw new Error(`Swap pool refused the quote: ${quote.reason}`);
    return { payload, inSide, poolForwardGram: quote.value, amountOut: quote.amountOut };
}

export type RoutePool = SwapPool & {
    getQuote(inSide: number, amountIn: bigint): Promise<{ status: number; amountOut: bigint }>;
};
export type RouteRequest = {
    pool1: RoutePool; pool2: RoutePool; inputMaster: Address; amountIn: bigint; recipient: Address; refundTo: Address;
    minT3: bigint; finalMin: bigint; deadline: number; fwdGram: bigint; refundFwdGram: bigint; fwdPayload?: Cell | null;
};

function routePayloadFits(root: Cell): boolean {
    const seen = new Set<string>();
    const todo = [root];
    while (todo.length > 0) {
        const cell = todo.pop()!;
        const hash = cell.hash().toString('hex');
        if (seen.has(hash)) continue;
        seen.add(hash);
        if (seen.size > 7) return false;
        todo.push(...cell.refs);
    }
    return true;
}

/** Quotes X -> T3 -> X from current getter values. poolForwardGram excludes the sender wallet's fee. */
export async function buildRoute(request: RouteRequest): Promise<{ payload: Cell; inner: Cell; poolForwardGram: bigint }> {
    const r = request;
    if (r.minT3 <= 0n) throw new Error('A route requires minT3 > 0');
    const [first, second] = await Promise.all([r.pool1.getPoolInfo(), r.pool2.getPoolInfo()]);
    if (!first.ready || !second.ready) throw new Error('Both route pools must be ready');
    if (r.inputMaster.equals(first.t3Master)) throw new Error('A route cannot start with T3');
    if (!r.inputMaster.equals(first.id.xMaster) || !first.t3Master.equals(second.t3Master)) {
        throw new Error('Route pool tokens do not match');
    }
    const inner = encodeSwap({
        minOut: r.finalMin, deadline: r.deadline, recipient: r.recipient, refundTo: r.refundTo, notifyOrigin: false,
        fwdGram: r.fwdGram, refundFwdGram: r.refundFwdGram, fwdPayload: r.fwdPayload ?? null,
    });
    // The destination admits seven cells for Swap and its payload; RCT3 is the eighth at hop 1.
    if (!routePayloadFits(inner)) throw new Error('A routed inner swap must fit seven cells');
    const firstQuote = await r.pool1.getQuote(1, r.amountIn);
    if (firstQuote.status !== 0) throw new Error('First route pool cannot fill this amount');
    const secondQuote = await r.pool2.getSwapValue(0, firstQuote.amountOut, inner);
    if (secondQuote.status !== 0) throw new Error(`Second route pool refused the quote: ${secondQuote.reason}`);
    const payload = encodeSwap({
        minOut: r.minT3, deadline: r.deadline, recipient: r.pool2.address, refundTo: r.refundTo, notifyOrigin: false,
        fwdGram: secondQuote.value, refundFwdGram: r.refundFwdGram, fwdPayload: encodeRouteCont({ pool: r.pool2.address, swap: inner }),
    });
    const firstValue = await r.pool1.getSwapValue(1, r.amountIn, payload);
    if (firstValue.status !== 0) throw new Error(`First route pool refused the quote: ${firstValue.reason}`);
    return { payload, inner, poolForwardGram: firstValue.value };
}
