import { Address, beginCell, Cell } from '@ton/core';
export type SaleCaps={softCap:bigint;hardCap:bigint;minContribution:bigint;maxContribution:bigint;saleSupply:bigint};
export type SaleVesting={beneficiary:Address;amount:bigint;cliff:number;duration:number;period:number};
export type FixedPricing={price:bigint};
export type BondingPricing={curveKind:1;basePrice:bigint;slopeNumerator:bigint;slopeDenominator:bigint};
export type AuctionPricing={startPrice:bigint;reservePrice:bigint;decayInterval:number;tickSize:bigint};
export type SaleTerms={projectMaster:Address;lpRecipient:Address;xDecimals:number;startTime:number;endTime:number;seedBin:number;caps:SaleCaps;pricing:Cell;vesting?:SaleVesting|null};
export function fixedPricingToCell(p:FixedPricing){return beginCell().storeCoins(p.price).endCell();}
export function bondingPricingToCell(p:BondingPricing){return beginCell().storeUint(p.curveKind,8).storeCoins(p.basePrice).storeCoins(p.slopeNumerator).storeCoins(p.slopeDenominator).endCell();}
export function auctionPricingToCell(p:AuctionPricing){return beginCell().storeCoins(p.startPrice).storeCoins(p.reservePrice).storeUint(p.decayInterval,32).storeCoins(p.tickSize).endCell();}
export function saleVestingToCell(v:SaleVesting){return beginCell().storeAddress(v.beneficiary).storeCoins(v.amount).storeUint(v.cliff,32).storeUint(v.duration,32).storeUint(v.period,32).endCell();}
export function saleTermsToCell(t:SaleTerms){const c=t.caps;return beginCell().storeAddress(t.projectMaster).storeAddress(t.lpRecipient).storeUint(t.xDecimals,8).storeUint(t.startTime,32).storeUint(t.endTime,32).storeInt(t.seedBin,32)
 .storeRef(beginCell().storeCoins(c.softCap).storeCoins(c.hardCap).storeCoins(c.minContribution).storeCoins(c.maxContribution).storeCoins(c.saleSupply).endCell()).storeRef(t.pricing).storeMaybeRef(t.vesting?saleVestingToCell(t.vesting):null).endCell();}
export function decodeSaleTerms(cell:Cell):SaleTerms{const s=cell.beginParse(),projectMaster=s.loadAddress(),lpRecipient=s.loadAddress(),xDecimals=s.loadUint(8),startTime=s.loadUint(32),endTime=s.loadUint(32),seedBin=s.loadInt(32),c=s.loadRef().beginParse();
 const caps={softCap:c.loadCoins(),hardCap:c.loadCoins(),minContribution:c.loadCoins(),maxContribution:c.loadCoins(),saleSupply:c.loadCoins()},pricing=s.loadRef(),v=s.loadMaybeRef()?.beginParse();
 const vesting=v?{beneficiary:v.loadAddress(),amount:v.loadCoins(),cliff:v.loadUint(32),duration:v.loadUint(32),period:v.loadUint(32)}:null;c.endParse();v?.endParse();s.endParse();return{projectMaster,lpRecipient,xDecimals,startTime,endTime,seedBin,caps,pricing,vesting};}
