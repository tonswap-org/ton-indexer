import { Address, beginCell, Cell, Contract, ContractProvider, Dictionary, DictionaryValue, Sender, SendMode, Slice, contractAddress } from '@ton/core';
import { OP } from './generated/opcodes';
import { JettonSlotConfig, jettonLedgerConfigToCell } from './jettonSlots';
import { T3WalletAttempt, t3WalletAttemptFromCell } from './T3Wallet';

export type T3Basket = [bigint, bigint, bigint];
export type T3HubReserve = JettonSlotConfig & { slot: 0 | 1 | 2; decimals: number; codeHash: bigint; lockExit?: number; balanceExit?: number };
export type T3HubConfig = { governance: Address; proofCodeHash: bigint; walletCode: Cell; metadata: Cell; amp: number; reserves: T3HubReserve[] };
export type T3HubEconomy = { backing: T3Basket; pending: T3Basket; supply: bigint; feeBps: number; admitted: number; frozen: number; withdrawalsOnly: boolean; clears: T3Basket };
export type T3HubCredit = { certified: boolean; owner: Address; queryId: bigint; amount: bigint; intent: Cell; evidence: Cell | null };
export type T3HubMint = { amount: bigint; recipient: Address; attempt: bigint; sentLt: bigint; status: number };
export type T3HubLeg = { amount: bigint; attempt: bigint; sentLt: bigint; status: number; recipient: Address };
export type T3HubPayout = { owner: Address; recipient: Address; queryId: bigint; legs: [T3HubLeg, T3HubLeg, T3HubLeg] };
export type T3HubCreditRecord = { phase: number; linkedSlot: number; linkedKey: bigint; credit: T3HubCredit; mint: T3HubMint | null; payout: T3HubPayout | null; staged: Cell | null };
export type T3HubReceipt = { slot: number; key: bigint; record: Cell };
const readBasket = (s: Slice): T3Basket => [s.loadCoins(), s.loadCoins(), s.loadCoins()];
const readLeg = (s: Slice): T3HubLeg => { const leg = { amount: s.loadCoins(), attempt: s.loadUintBig(64), sentLt: s.loadUintBig(64), status: s.loadUint(1), recipient: s.loadAddress() }; s.endParse(); return leg; };
export function readT3HubEconomy(cell: Cell): T3HubEconomy {
    const s = cell.beginParse(), pending = s.loadRef().beginParse(), result = { backing: readBasket(s), pending: [pending.loadUintBig(256), pending.loadUintBig(256), pending.loadUintBig(256)] as T3Basket, supply: s.loadCoins(), feeBps: s.loadUint(16),
        admitted: s.loadUint(3), frozen: s.loadUint(3), withdrawalsOnly: s.loadBit() }; const c = s.loadRef().beginParse(); const clears: T3Basket = [c.loadUintBig(64), c.loadUintBig(64), c.loadUintBig(64)]; c.endParse(); pending.endParse(); s.endParse(); return { ...result, clears };
}
export function readT3HubPayout(cell: Cell): T3HubPayout {
    const s = cell.beginParse(), owner = s.loadAddress(), recipient = s.loadAddress(), queryId = s.loadUintBig(64), l = s.loadRef().beginParse();
    const legs: T3HubPayout['legs'] = [readLeg(l.loadRef().beginParse()), readLeg(l.loadRef().beginParse()), readLeg(l.loadRef().beginParse())]; s.endParse(); l.endParse(); return { owner, recipient, queryId, legs };
}
export function readT3HubCreditRecord(receipt: Cell): T3HubCreditRecord {
    const r = receipt.beginParse(); r.loadUintBig(64); const s = r.loadRef().beginParse(); r.endParse();
    const phase = s.loadUint(3), linkedSlot = s.loadUint(2), linkedKey = s.loadUintBig(64), c = s.loadRef().beginParse(), m = s.loadMaybeRef(), p = s.loadMaybeRef(), staged = s.loadMaybeRef(); s.endParse();
    const credit = { certified: c.loadBit(), owner: c.loadAddress(), queryId: c.loadUintBig(64), amount: c.loadCoins(), intent: c.loadRef(), evidence: c.loadMaybeRef() }; c.endParse();
    let mint: T3HubMint | null = null;
    if (m) { const x = m.beginParse(); mint = { amount: x.loadCoins(), recipient: x.loadAddress(), attempt: x.loadUintBig(64), sentLt: x.loadUintBig(64), status: x.loadUint(1) }; x.endParse(); }
    return { phase, linkedSlot, linkedKey, credit, mint, payout: p ? readT3HubPayout(p) : null, staged };
}
export function readT3HubBurnRecord(receipt: Cell): { attempt: T3WalletAttempt; payout: T3HubPayout | null } {
    const r = receipt.beginParse(); r.loadUintBig(64); const s = r.loadRef().beginParse(); r.endParse();
    const attempt = t3WalletAttemptFromCell(s.loadRef()), p = s.loadMaybeRef(); s.endParse(); return { attempt, payout: p ? readT3HubPayout(p) : null };
}
const emptyHash = () => beginCell().storeUint(0, 8).endCell().hash();
const pairHash = (a: Buffer, b: Buffer) => beginCell().storeUint(4, 8).storeBuffer(a).storeBuffer(b).endCell().hash();
export function t3HubReceiptProof(records: ReadonlyMap<bigint, Cell>, key: bigint) {
    if (key < 0n || key >= 1n << 64n) throw Error('Invalid physical receipt key');
    let nodes = new Map([...records].map(([k, c]) => [k, beginCell().storeUint(3, 8).storeRef(c).endCell().hash()])), zero = emptyHash(), cursor = key;
    const siblings: Buffer[] = [];
    for (let i = 0; i < 64; i++) {
        siblings.push(nodes.get(cursor ^ 1n) ?? zero); const next = new Map<bigint, Buffer>();
        for (const parent of new Set([...nodes.keys()].map(k => k >> 1n))) next.set(parent,
            pairHash(nodes.get(parent << 1n) ?? zero, nodes.get((parent << 1n) | 1n) ?? zero));
        nodes = next; cursor >>= 1n; zero = pairHash(zero, zero);
    }
    let proof: Cell | null = null;
    for (let i = 63; i >= 0; i--) proof = beginCell().storeBuffer(siblings[i]).storeMaybeRef(proof).endCell();
    return { root: BigInt(`0x${(nodes.get(0n) ?? zero).toString('hex')}`), proof: proof! };
}
export const t3HubWitness = (record: Cell, proof: Cell) => beginCell().storeRef(record).storeRef(proof).endCell();
const tree = () => beginCell().storeUint(t3HubReceiptProof(new Map(), 0n).root, 256).storeBit(false).storeUint(0n, 64).storeBuffer(emptyHash()).storeMaybeRef(null).endCell();
type Policy = { scale: number; codeHash: bigint; lockExit: number; balanceExit: number };
const policyValue: DictionaryValue<Policy> = {
    serialize: (p, b) => { b.storeUint(p.scale, 32).storeUint(p.codeHash, 256).storeUint(p.lockExit, 16).storeUint(p.balanceExit, 16); },
    parse: s => ({ scale: s.loadUint(32), codeHash: s.loadUintBig(256), lockExit: s.loadUint(16), balanceExit: s.loadUint(16) }),
};
export function t3HubGraphGeometry(root: Cell): { bits: number; cells: number } {
    const seen = new Set<string>(), queue = [root]; let bits = 0;
    while (queue.length) {
        const cell = queue.pop()!, hash = cell.hash().toString('hex'); if (seen.has(hash)) continue;
        seen.add(hash); bits += cell.bits.length; queue.push(...cell.refs);
    }
    return { bits, cells: seen.size };
}
export function t3HubConfigToCell(c: T3HubConfig, code: Cell): Cell {
    if (c.governance.workChain !== 0 || !Number.isInteger(c.amp) || c.amp < 100 || c.amp > 250) throw Error('Invalid hub authority or amp');
    if (c.reserves.length < 2 || c.reserves.length > 3 || c.reserves.some(r => r.slot < 0 || r.slot > 2)) throw Error('Exactly the core reserve slots and optional third reserve are supported');
    const policies = Dictionary.empty(Dictionary.Keys.Uint(8), policyValue);
    for (const slot of [0, 1, 2]) {
        const r = c.reserves.find(v => v.slot === slot);
        if ((!r && slot < 2) || (r && (!Number.isInteger(r.decimals) || r.decimals < 0 || r.decimals > 9 || !!r.optional !== (slot === 2)))) throw Error('Invalid reserve slots or precision');
        if (r && [r.lockExit ?? 0, r.balanceExit ?? 0].some(v => !Number.isInteger(v) || v < 0 || v > 65535)) throw Error('Invalid reserve refusal exit');
        policies.set(slot, { scale: r ? 10 ** (9 - r.decimals) : 1, codeHash: r?.codeHash ?? 0n, lockExit: r?.lockExit ?? 0, balanceExit: r?.balanceExit ?? 0 });
    }
    const geometry = t3HubGraphGeometry(beginCell().storeRef(code).storeRef(c.walletCode).storeRef(c.metadata).endCell());
    const config = beginCell().storeAddress(c.governance).storeUint(c.proofCodeHash, 256).storeUint(c.amp, 16).storeUint(geometry.bits, 32).storeUint(geometry.cells, 32)
        .storeRef(c.walletCode).storeRef(c.metadata).storeDict(policies).endCell();
    const economy = beginCell(); for (let i = 0; i < 4; i++) economy.storeCoins(0n);
    economy.storeRef(beginCell().storeUint(0, 768).endCell());
    economy.storeUint(30, 16).storeUint(3, 3).storeUint(0, 3).storeBit(true).storeRef(beginCell().storeUint(0, 192).endCell());
    return beginCell().storeRef(config).storeRef(jettonLedgerConfigToCell(c.reserves)).storeRef(economy.endCell())
        .storeRef(beginCell().storeRef(tree()).storeRef(tree()).storeRef(tree()).storeRef(tree()).endCell()).endCell();
}
export function t3HubIntent(kind: 'mint' | 'pair' | 'swap' | 'redeem', recipient: Address, minOut = 0n, output = 0, strict = false, single = false) {
    const b = beginCell().storeUint({ mint: OP.T3_MINT, pair: OP.T3_PAIR, swap: OP.T3_SWAP, redeem: OP.T3_REDEEM }[kind], 32);
    if (kind === 'redeem') b.storeBit(single);
    if (kind === 'swap' || kind === 'redeem') b.storeUint(output, 2).storeBit(strict);
    return b.storeCoins(minOut).storeAddress(recipient).endCell();
}
export class T3Hub implements Contract {
    constructor(readonly address: Address, readonly init?: { code: Cell; data: Cell }) {}
    static createFromConfig(config: T3HubConfig, code: Cell) { const init = { code, data: t3HubConfigToCell(config, code) }; return new T3Hub(contractAddress(0, init), init); }
    async send(provider: ContractProvider, via: Sender, value: bigint, body = Cell.EMPTY) { await provider.internal(via, { value, body, sendMode: SendMode.PAY_GAS_SEPARATELY }); }
    async sendPair(provider: ContractProvider, via: Sender, value: bigint, mode: 0 | 1 | 2, firstSlot: 0 | 1, first: Cell, second: Cell) {
        await this.send(provider, via, value, beginCell().storeUint(OP.T3_HUB_PAIR_BIND, 32).storeUint(mode, 2).storeUint(firstSlot, 2).storeRef(first).storeRef(second).endCell());
    }
    async sendClaim(provider: ContractProvider, via: Sender, value: bigint, slot: number, witness: Cell, refund = false, recipient: Address | null = null) {
        const body = beginCell().storeUint(refund ? OP.T3_HUB_REFUND : OP.T3_HUB_ACCEPT, 32).storeUint(slot, 2); if (refund) body.storeAddress(recipient);
        await this.send(provider, via, value, body.storeRef(witness).endCell());
    }
    async sendMintRetry(provider: ContractProvider, via: Sender, value: bigint, slot: number, witness: Cell, recipient: Address | null = null) {
        await this.send(provider, via, value, beginCell().storeUint(OP.T3_HUB_MINT_RETRY, 32).storeUint(slot, 2).storeAddress(recipient).storeRef(witness).endCell());
    }
    async sendPayoutRetry(provider: ContractProvider, via: Sender, value: bigint, slot: number, output: number, witness: Cell, recipient: Address | null = null) {
        await this.send(provider, via, value, beginCell().storeUint(OP.T3_HUB_PAYOUT_RETRY, 32).storeUint(slot, 2).storeUint(output, 2).storeAddress(recipient).storeRef(witness).endCell());
    }
    async getState(provider: ContractProvider) { return readT3HubEconomy((await provider.get('get_hub_state', [])).stack.readCell()); }
    async getConfig(provider: ContractProvider) {
        const s = (await provider.get('get_hub_config', [])).stack.readCell().beginParse();
        const result = { governance: s.loadAddress(), proofCodeHash: s.loadUintBig(256), amp: s.loadUint(16), rentBits: s.loadUint(32), rentCells: s.loadUint(32),
            walletCode: s.loadRef(), metadata: s.loadRef(), policies: s.loadDict(Dictionary.Keys.Uint(8), policyValue) };
        s.endParse(); return result;
    }
    async getLedger(provider: ContractProvider) { return (await provider.get('get_jetton_ledger', [])).stack.readCell(); }
    async getReady(provider: ContractProvider) { return (await provider.get('get_ready', [])).stack.readBoolean(); }
    async getWalletAddress(provider: ContractProvider, owner: Address) { return (await provider.get('get_wallet_address', [{ type: 'slice', cell: beginCell().storeAddress(owner).endCell() }])).stack.readAddress(); }
    async getJettonData(provider: ContractProvider) { const s = (await provider.get('get_jetton_data', [])).stack; return { supply: s.readBigNumber(), mintable: s.readBoolean(), admin: s.readAddressOpt(), metadata: s.readCell(), walletCode: s.readCell() }; }
    async getTree(provider: ContractProvider, slot: number) {
        const cell = (await provider.get('get_receipt_tree', [{ type: 'int', value: BigInt(slot) }])).stack.readCell(), s = cell.beginParse();
        return { cell, root: s.loadUintBig(256), initialized: s.loadBit(), lastKey: s.loadUintBig(64), lastLeaf: s.loadUintBig(256), frontier: s.loadMaybeRef() };
    }
    async getMinValue(provider: ContractProvider, op: number) { return (await provider.get('get_min_value', [{ type: 'int', value: BigInt(op) }])).stack.readBigNumber(); }
    async getQuote(provider: ContractProvider, intent: Cell, slot: number, amount: bigint, staged = 0n, burn = false) {
        const s = (await provider.get('get_quote', [{ type: 'cell', cell: intent }, ...[slot, amount, staged, burn ? -1 : 0].map(v => ({ type: 'int' as const, value: BigInt(v) }))])).stack;
        return { status: s.readNumber(), detail: s.readNumber(), minted: s.readBigNumber(), payout: [s.readBigNumber(), s.readBigNumber(), s.readBigNumber()] as T3Basket, feeBps: s.readNumber() };
    }
    async getMinMintRetry(provider: ContractProvider, slot: number, receipt: Cell) {
        return (await provider.get('get_min_mint_retry', [{ type: 'int', value: BigInt(slot) }, { type: 'cell', cell: receipt }])).stack.readBigNumber();
    }
    async getMinRefund(provider: ContractProvider, slot: number, receipt: Cell, recipient: Address | null = null) {
        return (await provider.get('get_min_refund', [{ type: 'int', value: BigInt(slot) }, { type: 'cell', cell: receipt },
            recipient ? { type: 'slice', cell: beginCell().storeAddress(recipient).endCell() } : { type: 'null' }])).stack.readBigNumber();
    }
    async getMinPayoutRetry(provider: ContractProvider, slot: number, output: number, receipt: Cell) {
        return (await provider.get('get_min_payout_retry', [{ type: 'int', value: BigInt(slot) }, { type: 'int', value: BigInt(output) }, { type: 'cell', cell: receipt }])).stack.readBigNumber();
    }
    async getMinExecute(provider: ContractProvider, intent: Cell, slot: number, amount: bigint, staged: bigint, burn: boolean, owner: Address) {
        return (await provider.get('get_min_execute', [{ type: 'cell', cell: intent }, ...[slot, amount, staged, burn ? -1 : 0].map(v => ({ type: 'int' as const, value: BigInt(v) })),
            { type: 'slice', cell: beginCell().storeAddress(owner).endCell() }])).stack.readBigNumber();
    }
}
