import { beginCell, Cell } from '@ton/core';

export type JettonWalletBudget = {
    senderGas: number; walletBounceGas: number; burnWalletGas: number; smallPayloadCells: number; largeWalletGas: number; largeSenderGas: number; rentSeconds: number; rentBits: number; rentCells: number;
    initBits: number; initCells: number; initCopies: number;
    transferBits: number; transferCells: number; transferCopies: number; creditProtection: boolean;
};
export type JettonWalletProfile = { walletGas: number; walletGram: bigint; budget: JettonWalletBudget };
export const JETTON_V21_WALLET_GAS = 14_000;
export const JETTON_DEFAULT_WALLET_GAS = 30_000;
export const JETTON_WALLET_RENT_SECONDS = 157_680_000;

/** Explicit opt-in for ordinary TEP-74 wallet implementations with the qualified v2.1 bounds. */
export function standardJettonWalletProfile(walletGas: number, walletGram = 0n): JettonWalletProfile {
    return { walletGas, walletGram, budget: { senderGas: walletGas, walletBounceGas: 0, burnWalletGas: walletGas, smallPayloadCells: 65535, largeWalletGas: walletGas, largeSenderGas: walletGas, rentSeconds: JETTON_WALLET_RENT_SECONDS,
        rentBits: 1100, rentCells: 3, initBits: 8500, initCells: 18, initCopies: 1,
        transferBits: 880, transferCells: 1, transferCopies: 3, creditProtection: false } };
}
export const JETTON_V21_WALLET_PROFILE = standardJettonWalletProfile(JETTON_V21_WALLET_GAS);
export const JETTON_DEFAULT_WALLET_PROFILE = standardJettonWalletProfile(JETTON_DEFAULT_WALLET_GAS);

/** Fresh T3: a funded source, one cold recipient, and both possible frontier appends. */
export function t3JettonWalletProfile(walletCode: Cell): JettonWalletProfile {
    const seen = new Set<string>();
    let codeBits = 0;
    const visit = (cell: Cell) => {
        const hash = cell.hash().toString('hex');
        if (seen.has(hash)) return;
        seen.add(hash); codeBits += cell.bits.length;
        for (const ref of cell.refs) visit(ref);
    };
    visit(walletCode);
    // Config, state and journal include a maximum-width Coins balance. The code
    // wrapper matches the wallet's cold-rent helper; each append adds <=2/292.
    const coldCells = seen.size + 4, coldBits = codeBits + 2069;
    const profile: JettonWalletProfile = { walletGas: 200000, walletGram: 0n, budget: {
        senderGas: 150000, walletBounceGas: 125000, burnWalletGas: 400000, smallPayloadCells: 62, largeWalletGas: 500000, largeSenderGas: 250000,
        rentSeconds: JETTON_WALLET_RENT_SECONDS, rentCells: coldCells + 4, rentBits: coldBits + 584,
        initCells: seen.size + 4, initBits: codeBits + 2074, initCopies: 2,
        // Full private delivery (1340 bits/5 cells) plus rich-bounce metadata.
        // Five envelopes cover command, delivery, bounce, notification and excess.
        transferBits: 1698, transferCells: 7, transferCopies: 5, creditProtection: true,
    } };
    validateJettonWalletProfile(profile);
    return profile;
}

export function jettonWalletBudgetToCell(p: JettonWalletBudget): Cell {
    const b = beginCell();
    for (const [key, width] of [['senderGas',32],['walletBounceGas',32],['burnWalletGas',32],['smallPayloadCells',16],['largeWalletGas',32],['largeSenderGas',32],['rentSeconds',32],['rentBits',32],['rentCells',16],
        ['initBits',32],['initCells',16],['initCopies',8],['transferBits',16],['transferCells',8],['transferCopies',8]] as const) {
        if (!Number.isInteger(p[key]) || (key === 'walletBounceGas' ? p[key] < 0 : p[key] <= 0) || p[key] >= 2 ** width) throw new Error(`Invalid wallet budget ${key}`);
        b.storeUint(p[key], width);
    }
    if (p.walletBounceGas > 500000 || p.senderGas < 10000 || p.initCopies > 4 || p.transferBits < 880 || p.transferCopies < 3 || p.transferCopies > 8) throw new Error('Invalid wallet budget bounds');
    if (typeof p.creditProtection !== 'boolean') throw Error('Explicit credit protection capability required');
    return b.storeBit(p.creditProtection).endCell();
}
export function decodeJettonWalletBudget(cell: Cell): JettonWalletBudget {
    const s = cell.beginParse(), p = { senderGas: s.loadUint(32), walletBounceGas: s.loadUint(32), burnWalletGas: s.loadUint(32), smallPayloadCells: s.loadUint(16), largeWalletGas: s.loadUint(32), largeSenderGas: s.loadUint(32), rentSeconds: s.loadUint(32), rentBits: s.loadUint(32), rentCells: s.loadUint(16),
        initBits: s.loadUint(32), initCells: s.loadUint(16), initCopies: s.loadUint(8),
        transferBits: s.loadUint(16), transferCells: s.loadUint(8), transferCopies: s.loadUint(8), creditProtection: s.loadBit() };
    s.endParse(); jettonWalletBudgetToCell(p); return p;
}
export function validateJettonWalletProfile(p: JettonWalletProfile): void {
    jettonWalletBudgetToCell(p.budget);
    if (!Number.isInteger(p.walletGas) || p.walletGas < 10000 || p.walletGas > 500000 || p.budget.senderGas > p.walletGas || p.budget.burnWalletGas < p.budget.senderGas || p.budget.burnWalletGas > 2000000 || p.budget.largeSenderGas < p.budget.senderGas || p.budget.largeWalletGas < p.walletGas || p.budget.largeSenderGas > p.budget.largeWalletGas || p.budget.largeWalletGas > 2000000
        || p.walletGram < 0n || p.walletGram > 500000000n) throw new Error('Invalid wallet gas or GRAM floor');
}
