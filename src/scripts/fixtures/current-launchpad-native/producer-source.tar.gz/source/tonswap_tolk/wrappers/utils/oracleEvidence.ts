import { beginCell, Cell, Dictionary, type DictionaryValue } from '@ton/core';
import { OP } from '../generated/opcodes';

// TypeScript mirror of contracts/shared/oracle: the wire codec, every verdict rule and the ring.
// Prices are whole T3 per whole X scaled 10^9, whatever the jetton's decimals.

export const ORACLE_FLAG_HEALTHY_NOW = 1;
export const ORACLE_FLAG_SHORT_OK = 2;
export const ORACLE_FLAG_MEDIUM_OK = 4;
export const ORACLE_FLAG_LONG_OK = 8;
export const ORACLE_FLAG_HISTORICAL = 16;
const ORACLE_FLAGS_ALL = 31;

export const ORACLE_WINDOW_SHORT = 300;
export const ORACLE_WINDOW_MEDIUM = 1800;
export const ORACLE_WINDOW_LONG = 7200;
export const OPTION_BUY_CUTOFF = ORACLE_WINDOW_LONG;

export const ORACLE_PRICE_E9_MIN = 1_000_000n;
export const ORACLE_PRICE_E9_LIMIT = 1n << 120n;
export const ORACLE_MIN_SIDE_T3 = 8_000_000_000_000n;
export const ORACLE_QUERY_GAS_MAX = 100_000n;
export const RING_TOUCH_GAS_MAX = 55_000n;

export const ORACLE_MAX_AGE = 30n;
export const ORACLE_REQUEST_TTL = 60n;
export const ORACLE_ALIGN_BPS = 150n;

export const ORACLE_EVIDENCE_BITS = 648;
const ORACLE_RESULT_BITS = 96;

export type Evidence = {
    servedAt: bigint;
    at: bigint;
    flags: number;
    spot: bigint;
    short: bigint;
    medium: bigint;
    long: bigint;
};

export function evidenceToCell(e: Evidence): Cell {
    return beginCell().storeUint(e.servedAt, 64).storeUint(e.at, 64).storeUint(e.flags, 8)
        .storeUint(e.spot, 128).storeUint(e.short, 128).storeUint(e.medium, 128).storeUint(e.long, 128).endCell();
}

const reported = (price: bigint, flagSet: boolean) => (flagSet ? price >= ORACLE_PRICE_E9_MIN && price < ORACLE_PRICE_E9_LIMIT : price === 0n);

/** The evidence in a cell, or null unless the cell holds exactly the layout and something a pool can have built. */
export function evidenceDecode(cell: Cell): Evidence | null {
    if (cell.isExotic || cell.bits.length !== ORACLE_EVIDENCE_BITS || cell.refs.length !== 0) return null;
    const s = cell.beginParse();
    const e: Evidence = {
        servedAt: s.loadUintBig(64), at: s.loadUintBig(64), flags: s.loadUint(8),
        spot: s.loadUintBig(128), short: s.loadUintBig(128), medium: s.loadUintBig(128), long: s.loadUintBig(128),
    };
    const has = (flag: number) => (e.flags & flag) !== 0;
    const consistent = (e.flags & ~ORACLE_FLAGS_ALL) === 0
        && reported(e.spot, has(ORACLE_FLAG_HEALTHY_NOW))
        && reported(e.short, has(ORACLE_FLAG_SHORT_OK))
        && reported(e.medium, has(ORACLE_FLAG_MEDIUM_OK))
        && reported(e.long, has(ORACLE_FLAG_LONG_OK))
        && (has(ORACLE_FLAG_HISTORICAL) ? !has(ORACLE_FLAG_HEALTHY_NOW) : e.at === e.servedAt);
    return consistent ? e : null;
}

/** `at` 0 asks for current evidence, any other value for the windows ending at that second. The echo is one cell without references. */
export function oracleQueryBody(query: { queryId: bigint; at: bigint; echo: Cell }): Cell {
    return beginCell().storeUint(OP.ORACLE_QUERY, 32).storeUint(query.queryId, 64).storeUint(query.at, 64).storeRef(query.echo).endCell();
}

/** A pool's reply as responder.tolk builds it. On chain only a pool sends one; off chain it is a test input. */
export function oracleResultBody(result: { queryId: bigint; evidence: Cell; echo: Cell }): Cell {
    return beginCell().storeUint(OP.ORACLE_RESULT, 32).storeUint(result.queryId, 64).storeRef(result.evidence).storeRef(result.echo).endCell();
}

/** The fields of a pool's reply, or null unless the body is exactly an oracle result. The evidence still needs evidenceDecode. */
export function parseOracleResult(body: Cell): { queryId: bigint; evidence: Cell; echo: Cell } | null {
    if (body.isExotic || body.bits.length !== ORACLE_RESULT_BITS || body.refs.length !== 2) return null;
    const s = body.beginParse();
    if (s.loadUint(32) !== OP.ORACLE_RESULT) return null;
    return { queryId: s.loadUintBig(64), evidence: s.loadRef(), echo: s.loadRef() };
}

const has = (e: Evidence, flags: number) => (e.flags & flags) === flags;
const min = (...values: bigint[]) => values.reduce((a, b) => (b < a ? b : a));
const max = (...values: bigint[]) => values.reduce((a, b) => (b > a ? b : a));
const PRICED = ORACLE_FLAG_HEALTHY_NOW | ORACLE_FLAG_SHORT_OK | ORACLE_FLAG_MEDIUM_OK | ORACLE_FLAG_LONG_OK;

export function oracleFresh(e: Evidence, now: bigint): boolean {
    return (e.flags & ORACLE_FLAG_HISTORICAL) === 0 && now - e.servedAt <= ORACLE_MAX_AGE;
}

export function oracleRequestLive(sentAt: bigint, now: bigint): boolean {
    return now - sentAt <= ORACLE_REQUEST_TTL;
}

export function oraclePriced(e: Evidence, now: bigint): boolean {
    return oracleFresh(e, now) && has(e, PRICED);
}

export function verdictMedian(e: Evidence): bigint {
    return max(min(e.short, e.medium), min(max(e.short, e.medium), e.long));
}

/** Rule A: priced, and spot and every window within 150 bps of the median. */
export function verdictAdmission(e: Evidence, now: bigint): boolean {
    const m = verdictMedian(e);
    const aligned = (price: bigint) => 10_000n * (price > m ? price - m : m - price) <= ORACLE_ALIGN_BPS * m;
    return oraclePriced(e, now) && [e.spot, e.short, e.medium, e.long].every(aligned);
}

/** Rule X. */
export function verdictExit(e: Evidence, now: bigint): boolean {
    return oraclePriced(e, now);
}

/** The trader-adverse extreme of spot and the three windows. */
export function verdictFill(e: Evidence, isBuy: boolean): bigint {
    return (isBuy ? max : min)(e.spot, e.short, e.medium, e.long);
}

/** Rule F: on exactly the evidence on which an exit is priced, at the short average. */
export function verdictForced(e: Evidence, now: bigint): { ok: boolean; price: bigint } {
    return { ok: oraclePriced(e, now), price: e.short };
}

/** Rule M. */
export function verdictMarketBuy(e: Evidence, now: bigint): { ok: boolean; price: bigint } {
    const ok = oracleFresh(e, now) && has(e, ORACLE_FLAG_HEALTHY_NOW | ORACLE_FLAG_SHORT_OK | ORACLE_FLAG_MEDIUM_OK);
    return { ok, price: ok ? min(e.short, e.medium) : 0n };
}

/** Rule E for one side. Each covered medium/long price is usable independently of the short window. */
export function verdictExpiry(e: Evidence, expiry: bigint): { accepted: boolean; mediumE9: bigint; longE9: bigint } {
    if ((e.flags & ORACLE_FLAG_HISTORICAL) === 0 || e.at !== expiry || e.servedAt < expiry) return { accepted: false, mediumE9: 0n, longE9: 0n };
    return { accepted: true, mediumE9: e.medium, longE9: e.long };
}

/** One window for the whole series: 1800, 7200 or 0 (void). A one-sided series passes its answer twice. */
export function verdictExpiryWindow(m0: bigint, l0: bigint, m1: bigint, l1: bigint): number {
    if (m0 !== 0n && m1 !== 0n) return ORACLE_WINDOW_MEDIUM;
    if (l0 !== 0n && l1 !== 0n) return ORACLE_WINDOW_LONG;
    return 0;
}

// The ring. A slot exists for each 8-second bucket in which the state changed, keyed by the bucket index.

export const OBS_BUCKET_SECONDS = 8;
export const OBS_CAPACITY = 2049;
const OBS_MIN_COVERAGE_BPS = 8000n;
const LANE_OFFSET = 1n << 31n;
const LANE_MASK = (1n << 32n) - 1n;
const LANES_ALL = (1n << 256n) - 1n;
const LANE_UNIT = LANES_ALL / LANE_MASK;   // 1 in each of the eight lanes

export type ObsSlot = { cumV: bigint; cumH: bigint; mask: number; lanes: bigint };
/** `slots` keeps its keys in ascending order, which is the order of creation. */
export type ObsRing = { count: number; curValue: number; curHealthy: boolean; slots: Map<number, ObsSlot> };

const slotValue: DictionaryValue<ObsSlot> = {
    serialize: (slot, builder) => builder.storeInt(slot.cumV, 64).storeUint(slot.cumH, 40).storeUint(slot.mask, 8).storeUint(slot.lanes, 256),
    parse: (s) => ({ cumV: s.loadIntBig(64), cumH: s.loadUintBig(40), mask: s.loadUint(8), lanes: s.loadUintBig(256) }),
};

export function emptyRing(): ObsRing {
    return { count: 0, curValue: 0, curHealthy: false, slots: new Map() };
}

export function ringToCell(ring: ObsRing): Cell {
    const slots = Dictionary.empty(Dictionary.Keys.Uint(32), slotValue);
    for (const [key, slot] of ring.slots) slots.set(key, slot);
    return beginCell().storeUint(ring.count, 16).storeInt(ring.curValue, 32).storeBit(ring.curHealthy).storeDict(slots).endCell();
}

/** The value of the `oracle` reference in a new pool's StateInit; equal to obs_ring_empty_cell(). */
export function emptyRingCell(): Cell {
    return ringToCell(emptyRing());
}

export function ringFromCell(cell: Cell): ObsRing {
    const s = cell.beginParse();
    const ring: ObsRing = { count: s.loadUint(16), curValue: s.loadInt(32), curHealthy: s.loadBit(), slots: new Map() };
    const slots = s.loadDict(Dictionary.Keys.Uint(32), slotValue);
    s.endParse();
    for (const key of slots.keys().sort((a, b) => a - b)) ring.slots.set(key, slots.get(key)!);
    return ring;
}

export function ringLane(slot: ObsSlot, i: number): number {
    return Number(((slot.lanes >> BigInt(32 * i)) & LANE_MASK) - LANE_OFFSET);
}

function slotCum(slot: ObsSlot, seconds: number): [bigint, bigint] {
    let v = slot.cumV;
    let h = slot.cumH;
    for (let i = 0; i < seconds; i += 1) {
        if ((slot.mask >> i) & 1) {
            v += BigInt(ringLane(slot, i));
            h += 1n;
        }
    }
    return [v, h];
}

/** ObsRing.write: records that the state is (value, healthy) from second `now` on; false when it already is. */
export function ringWrite(ring: ObsRing, now: number, value: number, healthy: boolean): boolean {
    if (ring.count > 0 && ring.curValue === value && ring.curHealthy === healthy) return false;
    const bucket = Math.floor(now / OBS_BUCKET_SECONDS);
    const offset = now % OBS_BUCKET_SECONDS;
    const keys = [...ring.slots.keys()];
    const lastKey = keys[keys.length - 1];
    let slot: ObsSlot = { cumV: 0n, cumH: 0n, mask: 0, lanes: 0n };
    if (lastKey === bucket) {
        slot = { ...ring.slots.get(bucket)! };
    } else {
        if (lastKey !== undefined) {
            const prev = ring.slots.get(lastKey)!;
            let [v, h] = slotCum(prev, OBS_BUCKET_SECONDS);
            const tail = BigInt(ringLane(prev, 7));
            const tailHealthy = (prev.mask >> 7) !== 0;
            if (tailHealthy) {
                const gap = BigInt((bucket - lastKey - 1) * OBS_BUCKET_SECONDS);
                v += tail * gap;
                h += gap;
            }
            slot = { cumV: v, cumH: h, mask: tailHealthy ? 255 : 0, lanes: (tail + LANE_OFFSET) * LANE_UNIT };
        }
        ring.count += 1;
        if (ring.count > OBS_CAPACITY) {
            ring.slots.delete(keys[0]);
            ring.count -= 1;
        }
    }
    const keepLanes = (1n << BigInt(32 * offset)) - 1n;
    const keepMask = (1 << offset) - 1;
    slot.lanes = (slot.lanes & keepLanes) | (((BigInt(value) + LANE_OFFSET) * LANE_UNIT) & ~keepLanes & LANES_ALL);
    slot.mask = (slot.mask & keepMask) | (healthy ? 255 & ~keepMask : 0);
    ring.slots.set(bucket, slot);
    ring.curValue = value;
    ring.curHealthy = healthy;
    return true;
}

/** ObsRing.cumAt: sum of the value and count of the healthy seconds before `t`; null when `t` precedes the retained history. */
export function ringCumAt(ring: ObsRing, t: number): { v: bigint; h: bigint } | null {
    if (t < 0) return null;
    const bucket = Math.floor(t / OBS_BUCKET_SECONDS);
    let key: number | undefined;
    for (const candidate of ring.slots.keys()) {
        if (candidate > bucket) break;
        key = candidate;
    }
    if (key === undefined) return null;
    const slot = ring.slots.get(key)!;
    const elapsed = t - key * OBS_BUCKET_SECONDS;
    let [v, h] = slotCum(slot, Math.min(elapsed, OBS_BUCKET_SECONDS));
    if (elapsed > OBS_BUCKET_SECONDS && (slot.mask >> 7) !== 0) {
        const rest = BigInt(elapsed - OBS_BUCKET_SECONDS);
        v += BigInt(ringLane(slot, 7)) * rest;
        h += rest;
    }
    return { v, h };
}

/** ObsRing.twapAt for `t` not after the last write's clock: the floor average over the healthy seconds of [t - window, t). */
export function ringTwapAt(ring: ObsRing, t: number, window: number): { available: boolean; avg: bigint; coverageBps: bigint } {
    const end = ringCumAt(ring, t);
    const start = ringCumAt(ring, t - window);
    if (!end || !start) return { available: false, avg: 0n, coverageBps: 0n };
    const healthy = end.h - start.h;
    const coverageBps = (healthy * 10_000n) / BigInt(window);
    if (healthy * 10_000n < OBS_MIN_COVERAGE_BPS * BigInt(window)) return { available: false, avg: 0n, coverageBps };
    const sum = end.v - start.v;
    const floor = sum / healthy - (sum % healthy !== 0n && sum < 0n ? 1n : 0n);
    return { available: true, avg: floor, coverageBps };
}
