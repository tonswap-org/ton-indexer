import { Address,beginCell,Cell,Contract,ContractProvider,Dictionary,DictionaryValue,Sender,SendMode,contractAddress } from '@ton/core';
import { JettonWalletProfile,jettonWalletBudgetToCell,validateJettonWalletProfile } from './jettonWalletBudget';
import { OP } from './generated/opcodes';
import { SaleTerms,saleTermsToCell } from './utils/launchpadSaleConfigCodec';
import { launchpadInt } from './utils/launchpadInit';
export type SaleFactoryConfig={governance:Address;t3Master:Address;t3Wallet:JettonWalletProfile;feeSink:Address;dlmmFactory:Address;codes:[Cell,Cell,Cell,Cell,Cell]};
export function launchpadCellSize(cell:Cell){const seen=new Set<string>();let bits=0,cells=0;const visit=(c:Cell)=>{const h=c.hash().toString('hex');if(seen.has(h))return;seen.add(h);bits+=c.bits.length;cells++;c.refs.forEach(visit);};visit(cell);return{bits,cells};}
const childCodeValue:DictionaryValue<{code:Cell;bits:number;cells:number}>={serialize:(v,b)=>{b.storeRef(v.code).storeUint(v.bits,32).storeUint(v.cells,16);},parse:s=>({code:s.loadRef(),bits:s.loadUint(32),cells:s.loadUint(16)})};
export function saleFactoryConfigToCell(c:SaleFactoryConfig){validateJettonWalletProfile(c.t3Wallet);const dict=Dictionary.empty(Dictionary.Keys.Uint(8),childCodeValue);c.codes.forEach((code,i)=>dict.set(i,{code,...launchpadCellSize(code)}));
 const p=c.t3Wallet;return beginCell().storeAddress(c.governance).storeBit(true).storeRef(beginCell().storeAddress(c.t3Master).storeAddress(c.feeSink).storeAddress(c.dlmmFactory)
 .storeRef(beginCell().storeUint(p.walletGas,32).storeCoins(p.walletGram).storeRef(jettonWalletBudgetToCell(p.budget)).endCell()).endCell()).storeUint(150,16).storeDict(dict).endCell();}
export class SaleFactory implements Contract{
 constructor(readonly address:Address,readonly init?:{code:Cell;data:Cell}){}
 static createFromAddress(a:Address){return new SaleFactory(a);}
 static createFromConfig(c:SaleFactoryConfig,code:Cell){const init={code,data:saleFactoryConfigToCell(c)};return new SaleFactory(contractAddress(0,init),init);}
 async sendBody(p:ContractProvider,via:Sender,value:bigint,body:Cell){return p.internal(via,{value,body,sendMode:SendMode.PAY_GAS_SEPARATELY});}
 async sendDeploy(p:ContractProvider,via:Sender,value:bigint){return this.sendBody(p,via,value,Cell.EMPTY);}
 async sendGate(p:ContractProvider,via:Sender,value:bigint,closed:boolean){return this.sendBody(p,via,value,beginCell().storeUint(closed?OP.WITHDRAWALS_ONLY_ON:OP.WITHDRAWALS_ONLY_OFF,32).endCell());}
 async sendSetFee(p:ContractProvider,via:Sender,value:bigint,feeBps:number,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.FACTORY_SET_FEE,32).storeUint(queryId,64).storeUint(feeBps,16).endCell());}
 async sendNewSale(p:ContractProvider,via:Sender,value:bigint,nonce:bigint,kind:number,terms:SaleTerms|Cell,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.FACTORY_NEW_SALE,32).storeUint(queryId,64).storeUint(nonce,64).storeUint(kind,8).storeRef(terms instanceof Cell?terms:saleTermsToCell(terms)).endCell());}
 async getCreateValue(p:ContractProvider,kind:number,hasVesting=false,duration=0){return(await p.get('get_create_value',[launchpadInt(kind),launchpadInt(hasVesting?-1:0),launchpadInt(duration)])).stack.readBigNumber();}
 async getChildAddresses(p:ContractProvider,creator:Address,nonce:bigint,kind:number){const s=(await p.get('get_child_addresses',[{type:'slice',cell:beginCell().storeAddress(creator).endCell()},launchpadInt(nonce),launchpadInt(kind)])).stack;return{sale:s.readAddress(),lp:s.readAddress(),vesting:s.readAddress()};}
 async getState(p:ContractProvider){const s=(await p.get('get_factory',[])).stack;return{governance:s.readAddress(),withdrawalsOnly:s.readBoolean(),feeBps:s.readNumber(),t3Master:s.readAddress(),feeSink:s.readAddress(),dlmmFactory:s.readAddress()};}
 async getChildCodeHash(p:ContractProvider,slot:number){return(await p.get('get_child_code_hash',[launchpadInt(slot)])).stack.readBigNumber();}
}
