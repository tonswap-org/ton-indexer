import { Address, beginCell, Cell, Contract, ContractProvider, Dictionary, DictionaryValue, Sender, SendMode, contractAddress } from '@ton/core';
import {getJettonRecovery,jettonRecoveryClaimBody,jettonManagedLedgerToCell,parseJettonManagedLedger,jettonRecoveriesConfig} from '../jettonRecovery';
import { OP } from '../generated/opcodes';
import { getJettonSlots,getOwed,getOwedBook,getOwedArchive,getMinArchiveClaim,sendClaimArchived,ClaimArchivedRequest,sendClaimOwed,sendDiscoverWallets,jettonLedgerConfigToCell } from '../jettonSlots';
export type SaleIdentity={factory:Address;creator:Address;nonce:bigint;kind:number;role:number};
export type SaleEntry={paid:bigint;tokens:bigint};
export const saleEntryValue:DictionaryValue<SaleEntry>={serialize:(v,b)=>{b.storeCoins(v.paid).storeCoins(v.tokens);},parse:s=>({paid:s.loadCoins(),tokens:s.loadCoins()})};
export function saleBookToCell(b:{ready:number;phase:number;inventory:bigint;raised:bigint;sold:bigint;t3Due:bigint;tokDue:bigint;openEntries:number;entries:Dictionary<Address,SaleEntry>}){return beginCell().storeUint(b.ready,8).storeUint(b.phase,8).storeCoins(b.inventory).storeCoins(b.raised).storeCoins(b.sold).storeCoins(b.t3Due).storeCoins(b.tokDue).storeUint(b.openEntries,16).storeDict(b.entries).endCell();}
export function decodeSaleBook(c:Cell){const s=c.beginParse();const b={ready:s.loadUint(8),phase:s.loadUint(8),inventory:s.loadCoins(),raised:s.loadCoins(),sold:s.loadCoins(),t3Due:s.loadCoins(),tokDue:s.loadCoins(),openEntries:s.loadUint(16),entries:s.loadDict(Dictionary.Keys.Address(),saleEntryValue)};s.endParse();return b;}
export function childInitialData(id:SaleIdentity){let book:Cell;
 if(id.role===0)book=saleBookToCell({ready:0,phase:0,inventory:0n,raised:0n,sold:0n,t3Due:0n,tokDue:0n,openEntries:0,entries:Dictionary.empty(Dictionary.Keys.Address(),saleEntryValue)});
 else if(id.role===1)book=beginCell().storeAddress(null).storeUint(0,32).storeUint(0,32).storeCoins(0).storeCoins(0).endCell();
 else book=beginCell().storeCoins(0).storeCoins(0).storeCoins(0).storeUint(0,32).storeBit(false).endCell();
 return beginCell().storeRef(beginCell().storeAddress(id.factory).storeAddress(id.creator).storeUint(id.nonce,64).storeUint(id.kind,8).storeUint(id.role,8).endCell()).storeMaybeRef(null).storeRef(jettonManagedLedgerToCell(jettonLedgerConfigToCell([]),jettonRecoveriesConfig([]))).storeRef(book).endCell();}
export const launchpadInt=(v:number|bigint)=>({type:'int' as const,value:BigInt(v)});
export class LaunchpadChild implements Contract {
 constructor(readonly address:Address,readonly init?:{code:Cell;data:Cell}){}
 async sendBody(p:ContractProvider,via:Sender,value:bigint,body:Cell){return p.internal(via,{value,body,sendMode:SendMode.PAY_GAS_SEPARATELY});}
 async sendDeploy(p:ContractProvider,via:Sender,value:bigint){return this.sendBody(p,via,value,Cell.EMPTY);}
 async sendDiscoverWallets(p:ContractProvider,via:Sender,value:bigint,queryId=0n){return sendDiscoverWallets(p,via,value,queryId);}
 async getMinValue(p:ContractProvider,op:number){return(await p.get('get_min_value',[launchpadInt(op)])).stack.readBigNumber();}
 async getMinDiscover(p:ContractProvider){return(await p.get('get_min_discover',[])).stack.readBigNumber();}
 async getMinForward(p:ContractProvider,op=0,slot=0){return(await p.get('get_min_forward',[launchpadInt(op),launchpadInt(slot)])).stack.readBigNumber();}
 async getJettonSlots(p:ContractProvider){return getJettonSlots(p);}
 async getJettonLiabilities(p:ContractProvider,slot:number){return(await p.get('get_jetton_liabilities',[launchpadInt(slot)])).stack.readBigNumber();}
 async getSurplus(p:ContractProvider,slot:number,observed:bigint){const s=(await p.get('get_unattributed_surplus',[launchpadInt(slot),launchpadInt(observed)])).stack;return{liabilities:s.readBigNumber(),surplus:s.readBigNumber(),deficit:s.readBigNumber()};}
}
export function decodeLaunchpadChildState(data:Cell){const s=data.beginParse(),identity=s.loadRef(),config=s.loadMaybeRef(),m=parseJettonManagedLedger(s.loadRef()),book=s.loadRef();s.endParse();return{identity,config,jetton:m.ledger,recovery:m.recovery,book};}
export function launchpadChildStateToCell(st:ReturnType<typeof decodeLaunchpadChildState>){return beginCell().storeRef(st.identity).storeMaybeRef(st.config).storeRef(jettonManagedLedgerToCell(st.jetton,st.recovery)).storeRef(st.book).endCell();}
export class RecoverableLaunchpadChild extends LaunchpadChild {
 async getRecovery(p:ContractProvider,slot=0){return getJettonRecovery(p,slot);}
 async getMinRecovery(p:ContractProvider,certificate:Cell){return(await p.get('get_min_recovery',[{type:'cell',cell:certificate}])).stack.readBigNumber();}
 async getMinRecoveryClaim(p:ContractProvider,receipt:Cell){return(await p.get('get_min_recovery_claim',[{type:'cell',cell:receipt}])).stack.readBigNumber();}
 async sendRecoveryClaim(p:ContractProvider,via:Sender,value:bigint,receipt:Cell,proof:Cell){return this.sendBody(p,via,value,jettonRecoveryClaimBody(receipt,proof));}
 async getSurplus(p:ContractProvider,slot:number,observed:bigint,protectedCredits:bigint|null=null,acceptedTransfers:bigint|null=null){const s=(await p.get('get_unattributed_surplus',[launchpadInt(slot),launchpadInt(observed),protectedCredits===null?{type:'null'}:launchpadInt(protectedCredits),acceptedTransfers===null?{type:'null'}:launchpadInt(acceptedTransfers)])).stack;return{liabilities:s.readBigNumber(),surplus:s.readBigNumber(),deficit:s.readBigNumber()};}
}
export class Sale extends RecoverableLaunchpadChild {
 static contributeBody(minTokens=1n){return saleContributeBody(minTokens);}
 static createFromAddress(address:Address){return new Sale(address);}
 static createFromIdentity(identity:Omit<SaleIdentity,'role'>,code:Cell){const init={code,data:childInitialData({...identity,role:0})};return new Sale(contractAddress(0,init),init);}
 async sendFinalize(p:ContractProvider,via:Sender,value:bigint,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.SALE_FINALIZE,32).storeUint(queryId,64).endCell());}
 async sendClaim(p:ContractProvider,via:Sender,value:bigint,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.SALE_CLAIM,32).storeUint(queryId,64).endCell());}
 async sendCancel(p:ContractProvider,via:Sender,value:bigint,queryId=0n){return this.sendBody(p,via,value,beginCell().storeUint(OP.SALE_CANCEL,32).storeUint(queryId,64).endCell());}
 async getState(p:ContractProvider){const s=(await p.get('get_sale',[])).stack;return{config:s.readCell(),...decodeSaleBook(s.readCell()),armed:s.readBoolean(),open:s.readBoolean()};}
 async getEntry(p:ContractProvider,owner:Address){const s=(await p.get('get_entry',[{type:'slice',cell:beginCell().storeAddress(owner).endCell()}])).stack;return{paid:s.readBigNumber(),tokens:s.readBigNumber()};}
 async getQuote(p:ContractProvider,amount:bigint){const s=(await p.get('get_quote',[launchpadInt(amount)])).stack;return{tokens:s.readBigNumber(),exactAmount:s.readBigNumber(),priceNow:s.readBigNumber()};}
 async sendClaimOwed(p:ContractProvider,via:Sender,value:bigint,slot:number,owner:Address,queryId=0n){return sendClaimOwed(p,via,value,slot,owner,queryId);}
 async getOwed(p:ContractProvider,slot:number,owner:Address){return getOwed(p,slot,owner);}
 async getOwedBook(p:ContractProvider,slot:number){return getOwedBook(p,slot);}
 async getMinClaim(p:ContractProvider,slot:number){return(await p.get('get_min_claim',[launchpadInt(slot)])).stack.readBigNumber();}
 async sendClaimArchived(p:ContractProvider,via:Sender,value:bigint,r:ClaimArchivedRequest,queryId=0n){return sendClaimArchived(p,via,value,r,queryId);}
 async getOwedArchive(p:ContractProvider,slot:number){return getOwedArchive(p,slot);}
 async getMinArchiveClaim(p:ContractProvider,slot:number){return getMinArchiveClaim(p,slot);}
}
export function saleContributeBody(minTokens=1n){return beginCell().storeUint(OP.SALE_CONTRIBUTE,32).storeCoins(minTokens).endCell();}
