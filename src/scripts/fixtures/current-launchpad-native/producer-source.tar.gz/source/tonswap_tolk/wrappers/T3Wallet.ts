import { Address, beginCell, Cell, Contract, ContractProvider, Sender, SendMode, contractAddress } from '@ton/core';
import { OP } from './generated/opcodes';

export type T3WalletConfig = { owner: Address; master: Address; proofCodeHash: bigint };
export type T3WalletDetails = {
    queryId: bigint; response: Address | null; forwardValue: bigint;
    /** Complete original Either, including the inline/reference bit. */
    forwardPayload: Cell; customPayload: Cell | null;
};
export type T3WalletAttempt = {
    id: bigint; originLt: bigint; attempt: bigint; owner: Address; recipient: Address;
    burn: boolean; amount: bigint; details: T3WalletDetails;
};
export type T3WalletRecord = { failed: boolean; cancelled: boolean; attempt: T3WalletAttempt };
export type T3WalletTransfer = {
    queryId?: bigint; amount: bigint; destination: Address; response?: Address | null;
    customPayload?: Cell | null; forwardValue?: bigint; forwardPayload?: Cell;
};
const emptyHash = () => beginCell().storeUint(0, 8).endCell().hash();
const pair = (a: Buffer, b: Buffer, domain: number) => beginCell().storeUint(domain, 8).storeBuffer(a).storeBuffer(b).endCell().hash();
const leaf = (c: Cell, domain: number) => beginCell().storeUint(domain, 8).storeRef(c).endCell().hash();
export function t3WalletDetailsToCell(d: T3WalletDetails) {
    return beginCell().storeUint(d.queryId, 64).storeAddress(d.response).storeCoins(d.forwardValue)
        .storeRef(d.forwardPayload).storeMaybeRef(d.customPayload).endCell();
}
export function t3WalletAttemptToCell(a: T3WalletAttempt) {
    const terms = beginCell().storeAddress(a.owner).storeAddress(a.recipient).storeBit(a.burn).storeCoins(a.amount)
        .storeRef(t3WalletDetailsToCell(a.details)).endCell();
    return beginCell().storeUint(a.id, 64).storeUint(a.originLt, 64).storeUint(a.attempt, 64).storeRef(terms).endCell();
}
export function t3WalletAttemptFromCell(c: Cell): T3WalletAttempt {
    const a = c.beginParse(); const id = a.loadUintBig(64), originLt = a.loadUintBig(64), attempt = a.loadUintBig(64), t = a.loadRef().beginParse(); a.endParse();
    const owner = t.loadAddress(), recipient = t.loadAddress(), burn = t.loadBit(), amount = t.loadCoins(), d = t.loadRef().beginParse(); t.endParse();
    const details = { queryId: d.loadUintBig(64), response: d.loadMaybeAddress(), forwardValue: d.loadCoins(),
        forwardPayload: d.loadRef(), customPayload: d.loadMaybeRef() }; d.endParse();
    return { id, originLt, attempt, owner, recipient, burn, amount, details };
}
export const t3WalletRecordToCell = (r: T3WalletRecord) => beginCell().storeBit(r.failed).storeBit(r.cancelled).storeRef(t3WalletAttemptToCell(r.attempt)).endCell();
export const t3WalletEvidence = (wallet: Address, a: T3WalletAttempt) => beginCell().storeAddress(wallet).storeRef(t3WalletAttemptToCell(a)).endCell();
export const t3WalletAttemptBody = (a: T3WalletAttempt) => beginCell().storeUint(a.burn ? OP.T3_WALLET_BURN : OP.T3_WALLET_DELIVERY, 32).storeRef(t3WalletAttemptToCell(a)).endCell();
export const t3WalletMintBody = (queryId: bigint, amount: bigint, mintIdentity: Cell, response: Address | null) => beginCell()
    .storeUint(OP.T3_WALLET_MINT, 32).storeUint(queryId, 64).storeCoins(amount).storeRef(mintIdentity).storeAddress(response).endCell();
export function t3WalletTransferBody(p: T3WalletTransfer) {
    return beginCell().storeUint(OP.TEP74_TRANSFER, 32).storeUint(p.queryId ?? 0n, 64).storeCoins(p.amount)
        .storeAddress(p.destination).storeAddress(p.response ?? null).storeMaybeRef(p.customPayload)
        .storeCoins(p.forwardValue ?? 0n).storeSlice((p.forwardPayload ?? beginCell().storeBit(false).endCell()).beginParse()).endCell();
}
export function t3WalletBurnBody(p: { queryId?: bigint; amount: bigint; response?: Address | null; customPayload?: Cell | null }) {
    return beginCell().storeUint(OP.TEP74_BURN, 32).storeUint(p.queryId ?? 0n, 64).storeCoins(p.amount)
        .storeAddress(p.response ?? null).storeMaybeRef(p.customPayload).endCell();
}
function witness(cells: ReadonlyMap<bigint, Cell>, key: bigint, domain: number) {
    if (key < 0n || key >= 1n << 64n) throw Error('Invalid wallet commitment index');
    let nodes = new Map([...cells].map(([k, c]) => [k, leaf(c, domain)])), zero = emptyHash(), cursor = key;
    const siblings: Buffer[] = [];
    for (let level = 0; level < 64; level++) {
        siblings.push(nodes.get(cursor ^ 1n) ?? zero);
        const next = new Map<bigint, Buffer>();
        for (const parent of new Set([...nodes.keys()].map(k => k >> 1n))) next.set(parent,
            pair(nodes.get(parent << 1n) ?? zero, nodes.get((parent << 1n) | 1n) ?? zero, domain + 1));
        nodes = next; cursor >>= 1n; zero = pair(zero, zero, domain + 1);
    }
    let proof: Cell | null = null;
    for (let i = 63; i >= 0; i--) proof = beginCell().storeBuffer(siblings[i]).storeMaybeRef(proof).endCell();
    return { root: BigInt(`0x${(nodes.get(0n) ?? zero).toString('hex')}`), proof: proof! };
}
export const t3WalletClaimWitness = (records: ReadonlyMap<bigint, T3WalletRecord>, key: bigint) =>
    witness(new Map([...records].map(([k, r]) => [k, t3WalletRecordToCell(r)])), key, 3);
export const t3WalletFailureWitness = (evidence: readonly Cell[], index: bigint) => witness(new Map(evidence.map((e, i) => [BigInt(i), e])), index, 1);
export const t3WalletCertificatePayload = (record: T3WalletRecord, proof: Cell) => beginCell().storeRef(t3WalletRecordToCell(record)).storeRef(proof).endCell();
export function t3WalletConfigToCell(c: T3WalletConfig) {
    const config = beginCell().storeAddress(c.owner).storeAddress(c.master).storeUint(c.proofCodeHash, 256).endCell();
    return beginCell().storeRef(config).storeCoins(0n).storeUint(0n, 65).storeUint(t3WalletClaimWitness(new Map(), 0n).root, 256)
        .storeRef(beginCell().storeUint(0n, 64).storeUint(0n, 256).storeDict(null).endCell()).storeDict(null).storeUint(0,256).storeUint(0,256).endCell();
}
export class T3Wallet implements Contract {
    constructor(readonly address: Address, readonly init?: { code: Cell; data: Cell }) {}
    static createFromConfig(config: T3WalletConfig, code: Cell): T3Wallet {
        const init = { code, data: t3WalletConfigToCell(config) }; return new T3Wallet(contractAddress(0, init), init);
    }
    async sendDeploy(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: Cell.EMPTY });
    }
    async sendTransfer(provider: ContractProvider, via: Sender, value: bigint, transfer: T3WalletTransfer) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: t3WalletTransferBody(transfer) });
    }
    async sendBurn(provider: ContractProvider, via: Sender, value: bigint, burn: Parameters<typeof t3WalletBurnBody>[0]) {
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body: t3WalletBurnBody(burn) });
    }
    async sendMark(provider: ContractProvider, via: Sender, value: bigint, record: T3WalletRecord, proof: Cell, index: bigint, evidenceProof: Cell) {
        const body = beginCell().storeUint(OP.T3_WALLET_MARK, 32).storeRef(t3WalletRecordToCell(record)).storeRef(proof)
            .storeUint(index, 64).storeRef(evidenceProof).endCell();
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body });
    }
    async sendRetry(provider: ContractProvider, via: Sender, value: bigint, record: T3WalletRecord, proof: Cell, recipient = record.attempt.recipient) {
        const body = beginCell().storeUint(OP.T3_WALLET_RETRY, 32).storeRef(t3WalletRecordToCell(record)).storeRef(proof).storeAddress(recipient).endCell();
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body });
    }
    async sendCancelBurn(provider: ContractProvider, via: Sender, value: bigint, record: T3WalletRecord, proof: Cell) {
        const body = beginCell().storeUint(OP.T3_WALLET_CANCEL, 32).storeRef(t3WalletRecordToCell(record)).storeRef(proof).endCell();
        await provider.internal(via, { value, sendMode: SendMode.PAY_GAS_SEPARATELY, body });
    }
    async getWalletData(provider: ContractProvider) {
        const s = (await provider.get('get_wallet_data', [])).stack;
        return { balance: s.readBigNumber(), owner: s.readAddress(), master: s.readAddress(), code: s.readCell() };
    }
    async getRecoveryState(provider: ContractProvider) {
        const s = (await provider.get('recovery_state', [])).stack;
        return { count: s.readBigNumber(), root: s.readBigNumber(), failures: s.readBigNumber(), failureRoot: s.readBigNumber() };
    }
    async getAcceptedTransfers(provider: ContractProvider) { return (await provider.get('accepted_transfers', [])).stack.readBigNumber(); }
    async getProtectedCredits(provider: ContractProvider) { return (await provider.get('protected_credits', [])).stack.readBigNumber(); }
    async getRecoveryValue(provider: ContractProvider) { return (await provider.get('recovery_value', [])).stack.readBigNumber(); }
    async getOutgoingValue(provider: ContractProvider, attempt: T3WalletAttempt) {
        return (await provider.get('outgoing_value', [{ type: 'cell', cell: t3WalletAttemptToCell(attempt) }])).stack.readBigNumber();
    }
    async getMintValue(provider: ContractProvider, queryId: bigint, response: Address | null) {
        return (await provider.get('mint_value', [{ type: 'int', value: queryId }, response ? { type: 'slice', cell: beginCell().storeAddress(response).endCell() } : { type: 'null' }])).stack.readBigNumber();
    }
}
