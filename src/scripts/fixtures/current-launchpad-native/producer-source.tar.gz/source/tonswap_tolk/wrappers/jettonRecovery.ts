import { beginCell, Cell, ContractProvider, Dictionary } from '@ton/core';
import { JettonSlotConfig } from './jettonSlots';
import { OP } from './generated/opcodes';

export type JettonRecovery = { dispatched: bigint; handled: bigint; pending: bigint; tree: Cell | null; restored: bigint };
export type JettonRecoveryItem = { incoming: boolean; slot: number; amount: bigint; claimed: boolean; body: Cell };
export function jettonRecoveryToCell(r: JettonRecovery): Cell {
    return beginCell().storeUint(r.dispatched, 256).storeUint(r.handled, 256).storeCoins(r.pending).storeMaybeRef(r.tree).storeUint(r.restored, 256).endCell();
}
export function parseJettonRecovery(cell: Cell): JettonRecovery {
    const s = cell.beginParse(); const r = { dispatched: s.loadUintBig(256), handled: s.loadUintBig(256), pending: s.loadCoins(), tree: s.loadMaybeRef(), restored: s.loadUintBig(256) };
    s.endParse(); return r;
}
export function jettonRecoveriesConfig(slots: readonly JettonSlotConfig[]): Dictionary<number, Cell> {
    const states = Dictionary.empty(Dictionary.Keys.Uint(8), Dictionary.Values.Cell());
    for (const slot of slots) if (slot.budget.creditProtection) states.set(slot.slot, jettonRecoveryToCell({ dispatched: 0n, handled: 0n, pending: 0n, tree: null, restored: 0n }));
    return states;
}
export function jettonManagedLedgerToCell(ledger: Cell, recovery: Dictionary<number, Cell>): Cell {
    return beginCell().storeSlice(ledger.beginParse()).storeDict(recovery).endCell();
}
export function parseJettonManagedLedger(cell: Cell) {
    const s = cell.beginParse(), ledger = beginCell().storeMaybeRef(s.loadMaybeRef()).storeMaybeRef(s.loadMaybeRef()).endCell();
    const recovery = s.loadDict(Dictionary.Keys.Uint(8), Dictionary.Values.Cell()); s.endParse(); return { ledger, recovery };
}
export function jettonRecoveryItemToCell(r: JettonRecoveryItem): Cell {
    return beginCell().storeBit(r.incoming).storeUint(r.slot, 8).storeCoins(r.amount).storeBit(r.claimed).storeRef(r.body).endCell();
}
export function parseJettonRecoveryItem(cell: Cell): JettonRecoveryItem {
    const s = cell.beginParse(), r = { incoming: s.loadBit(), slot: s.loadUint(8), amount: s.loadCoins(), claimed: s.loadBit(), body: s.loadRef() };
    s.endParse(); return r;
}
export function parseJettonRecoveryReceipt(receipt: Cell) {
    const s = receipt.beginParse(), key = s.loadUintBig(64), item = parseJettonRecoveryItem(s.loadRef()); s.endParse(); return { key, item };
}
export function jettonRecoveryClaimBody(receipt: Cell, proof: Cell): Cell {
    return beginCell().storeUint(OP.JETTON_RECOVERY_CLAIM, 32).storeRef(receipt).storeRef(proof).endCell();
}
export async function getJettonRecovery(provider: ContractProvider, slot: number) {
    const cell = (await provider.get('get_recovery', [{ type: 'int', value: BigInt(slot) }])).stack.readCellOpt();
    return cell === null ? null : parseJettonRecovery(cell);
}
