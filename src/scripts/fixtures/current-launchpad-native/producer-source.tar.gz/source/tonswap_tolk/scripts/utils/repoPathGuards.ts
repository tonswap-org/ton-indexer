import * as childProcess from 'node:child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { createHash, randomBytes } from 'crypto';

const NO_FOLLOW_FLAG = fs.constants.O_NOFOLLOW ?? 0;
const OPENAT_WRITE_HELPER = path.resolve(__dirname, 'openat_write.py');
const OPENAT_UNLINK_HELPER = path.resolve(__dirname, 'openat_unlink.py');
const OPENAT_MKDIR_HELPER = path.resolve(__dirname, 'openat_mkdir.py');
const OPENAT_RENAME_HELPER = path.resolve(__dirname, 'openat_rename.py');
const PINNED_OPENAT_ENV_ALLOWLIST = ['PATH', 'HOME', 'TMPDIR', 'TMP', 'TEMP', 'LANG', 'LC_ALL', 'TZ'] as const;
const PINNED_OPENAT_SOURCE_SHA256_ENV = 'TONSWAP_PINNED_OPENAT_SOURCE_SHA256';
const PINNED_OPENAT_REQUEST_SHA256_ENV = 'TONSWAP_PINNED_OPENAT_REQUEST_SHA256';
const PINNED_OPENAT_HELPER_BOOTSTRAP = [
    'import fcntl, hashlib, io, os, sys',
    'os.lseek(3, 0, os.SEEK_SET)',
    'source = bytearray()',
    'while True:',
    '    chunk = os.read(3, 65536)',
    '    if not chunk:',
    '        break',
    '    source.extend(chunk)',
    'expected_source = os.environ.pop("TONSWAP_PINNED_OPENAT_SOURCE_SHA256", "")',
    'if len(expected_source) != 64 or hashlib.sha256(source).hexdigest() != expected_source:',
    '    raise SystemExit("Pinned openat helper source digest mismatch.")',
    'expected_request = os.environ.pop("TONSWAP_PINNED_OPENAT_REQUEST_SHA256", "")',
    'if expected_request:',
    '    if fcntl.fcntl(0, fcntl.F_GETFL) & os.O_ACCMODE != os.O_RDONLY:',
    '        raise SystemExit("Pinned openat helper request descriptor is not read-only.")',
    '    os.lseek(0, 0, os.SEEK_SET)',
    '    request = sys.stdin.buffer.read()',
    '    if len(expected_request) != 64 or hashlib.sha256(request).hexdigest() != expected_request:',
    '        raise SystemExit("Pinned openat helper request digest mismatch.")',
    '    sys.stdin = io.TextIOWrapper(io.BytesIO(request), encoding="utf-8")',
    'sys.argv[0] = "/dev/fd/3"',
    'scope = {"__name__": "__main__", "__file__": "/dev/fd/3", "__builtins__": __builtins__}',
    'exec(compile(bytes(source), "/dev/fd/3", "exec"), scope, scope)',
].join('\n');
const DIRECT_MUTATION_ROOT_KIND = 'tonswap-direct-mutation-root-v1' as const;
const PREPARED_REPO_PATH_CONTEXTS = new WeakSet<object>();

export const PINNED_OPENAT_HELPER_MARKER_ENV = 'TONSWAP_PINNED_OPENAT_HELPER' as const;
export type PinnedOpenatHelperName = 'write' | 'unlink' | 'mkdir' | 'rename';

type PinnedOpenatHelper = Readonly<{
    name: PinnedOpenatHelperName;
    fd: number;
    dev: number;
    ino: number;
    bytes: number;
    sha256: string;
}>;

export type PinnedOpenatHelperExecutionOptions = {
    input?: string | Buffer;
    encoding?: 'utf8';
    timeout?: number;
    inheritedReadOnlyFds?: readonly number[];
};

export type PreparedPinnedOpenatHelperExecution = Readonly<{
    command: 'python3';
    args: readonly string[];
    env: Readonly<NodeJS.ProcessEnv>;
    input: string | Buffer | undefined;
    inheritedReadOnlyFds: readonly number[];
}>;

const PINNED_OPENAT_HELPERS: Readonly<Record<PinnedOpenatHelperName, PinnedOpenatHelper>> = Object.freeze({
    write: pinTrustedOpenatHelper('write', OPENAT_WRITE_HELPER),
    unlink: pinTrustedOpenatHelper('unlink', OPENAT_UNLINK_HELPER),
    mkdir: pinTrustedOpenatHelper('mkdir', OPENAT_MKDIR_HELPER),
    rename: pinTrustedOpenatHelper('rename', OPENAT_RENAME_HELPER),
});

export type RepoPathContext = Readonly<{
    root: string;
    lexicalRoot: string;
    pathHint: string;
    rootIdentity: Readonly<ParentDirectoryIdentity>;
}>;

export type PreparedWrite = {
    resolved: string;
    parent: string;
};

export type PreparedFileWrite = {
    target: PreparedWrite;
    contents: string | Buffer;
    label: string;
    append?: boolean;
    mode?: number;
    createOnly?: boolean;
};

export type PreparedFileWritePreflight = {
    target: PreparedWrite;
    label: string;
    append?: boolean;
    parentIdentity: ParentDirectoryIdentity;
    targetIdentity: RegularFileIdentity | null;
};

export type PreparedFileWritePrecondition = {
    resolved: string;
    label: string;
    bytes?: number;
    sha256?: string;
    expectedMode?: number;
    expectedUid?: number;
};

export type ParentDirectoryIdentity = {
    realpath: string;
    dev: number;
    ino: number;
};

export type DirectMutationRoot = Readonly<{
    kind: typeof DIRECT_MUTATION_ROOT_KIND;
    root: string;
    identity: Readonly<ParentDirectoryIdentity>;
}>;

export type RegularFileIdentity = {
    dev: number;
    ino: number;
    size: number;
    mtimeMs: number;
    ctimeMs: number;
};

export type DirectoryIdentity = {
    dev: number;
    ino: number;
};

type OpenatPreparedWrite = {
    target: PreparedWrite;
    contents: string | Buffer;
    label: string;
    append?: boolean;
    mode?: number;
    parentIdentity: ParentDirectoryIdentity;
    targetIdentity: RegularFileIdentity | null;
    displayParent: string;
    displayTarget: string;
};

type OpenatPreparedPrecondition = {
    resolved: string;
    label: string;
    parentIdentity: ParentDirectoryIdentity;
    targetIdentity: RegularFileIdentity;
    expectedBytes?: number;
    expectedSha256?: string;
    expectedMode?: number;
    expectedUid?: number;
    displayParent: string;
    displayTarget: string;
};

type OpenatPreparedUnlink = {
    entryType: 'file' | 'directory';
    filePath: string;
    label: string;
    parentIdentity: ParentDirectoryIdentity;
    targetIdentity: RegularFileIdentity | DirectoryIdentity;
    displayParent: string;
    displayTarget: string;
};

export type CheckedUnlinkOptions = {
    filePath: string;
    label: string;
    parentIdentity: ParentDirectoryIdentity;
    targetIdentity: RegularFileIdentity;
    displayParent: string;
    displayTarget: string;
    rootIdentity: ParentDirectoryIdentity;
};

export type CheckedRmdirOptions = {
    directoryPath: string;
    label: string;
    parentIdentity: ParentDirectoryIdentity;
    directoryIdentity: DirectoryIdentity;
    displayParent: string;
    displayTarget: string;
    rootIdentity: ParentDirectoryIdentity;
};

export type PreparedRead = {
    resolved: string;
    parentIdentity: ParentDirectoryIdentity;
    fileIdentity: RegularFileIdentity;
};

export function createRepoPathContext(options: { rootPath?: string; pathHint: string }): RepoPathContext {
    const rootPath = options.rootPath ?? process.cwd();
    if (typeof rootPath !== 'string' || rootPath.trim().length === 0) {
        throw new Error(`repo root must be a non-empty path; ${options.pathHint}`);
    }
    const lexicalRoot = path.resolve(rootPath.trim());
    if (lexicalRoot === path.parse(lexicalRoot).root) {
        throw new Error(`repo root must not be the filesystem root; ${options.pathHint}`);
    }
    const root = fs.realpathSync(lexicalRoot);
    if (root === path.parse(root).root) {
        throw new Error(`repo root must not resolve to the filesystem root; ${options.pathHint}`);
    }
    const rootIdentity = captureCanonicalRootIdentity(root, 'repo root');
    const context = Object.freeze({
        lexicalRoot,
        root,
        pathHint: options.pathHint,
        rootIdentity: Object.freeze({ ...rootIdentity }),
    });
    PREPARED_REPO_PATH_CONTEXTS.add(context);
    return context;
}

export function relativeToRoot(context: RepoPathContext, filePath: string) {
    return path.relative(context.root, filePath) || filePath;
}

export function resolveRepoPath(context: RepoPathContext, filePath: string, label: string) {
    captureContextRootIdentity(context);
    const normalizedPath = filePath.trim();
    if (!normalizedPath || normalizedPath.includes('\0') || isWindowsAbsolutePath(normalizedPath)) {
        throw new Error(`${label} must stay within the repo root; ${context.pathHint}`);
    }
    const candidate = path.resolve(context.lexicalRoot, normalizedPath);
    assertNoSymlinkSegments(context, candidate, label);
    const resolved = resolveThroughExistingParent(candidate);
    assertPathInsideRoot(context, resolved, label);
    return resolved;
}

export function repoPathMatches(context: RepoPathContext, candidatePath: string, expectedPath: string, label: string) {
    const candidate = resolveRepoPath(context, candidatePath, `${label} candidate`);
    const expected = resolveRepoPath(context, expectedPath, `${label} expected`);
    return path.relative(expected, candidate) === '';
}

export function assertDirectoryIfExists(context: RepoPathContext, directory: string, label: string) {
    const resolved = resolveRepoPath(context, directory, label);
    if (!fs.existsSync(resolved)) {
        return resolved;
    }
    const stat = fs.lstatSync(resolved);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, resolved)}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} must be a directory: ${relativeToRoot(context, resolved)}`);
    }
    return resolved;
}

export function requireRegularFile(context: RepoPathContext, filePath: string, label: string) {
    const resolved = resolveRepoPath(context, filePath, label);
    if (!fs.existsSync(resolved)) {
        throw new Error(`${label} not found: ${relativeToRoot(context, resolved)}`);
    }
    const stat = fs.lstatSync(resolved);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, resolved)}`);
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must be a regular file: ${relativeToRoot(context, resolved)}`);
    }
    if (stat.nlink > 1) {
        throw new Error(`${label} must not have hardlinks: ${relativeToRoot(context, resolved)}`);
    }
    return resolved;
}

export function prepareRegularFileRead(context: RepoPathContext, filePath: string, label: string): PreparedRead {
    const resolved = resolveRepoPath(context, filePath, label);
    const prepared = prepareResolvedRegularFileRead(context, resolved, label);
    captureContextRootIdentity(context);
    return prepared;
}

export function readPreparedTextFile(context: RepoPathContext, input: PreparedRead, label: string): string {
    captureContextRootIdentity(context);
    const contents = readPreparedTextFileWithFormatter(input, label, (filePath) => relativeToRoot(context, filePath));
    captureContextRootIdentity(context);
    return contents;
}

export function readPreparedFile(context: RepoPathContext, input: PreparedRead, label: string): Buffer {
    captureContextRootIdentity(context);
    const contents = readPreparedFileWithFormatter(input, label, (filePath) => relativeToRoot(context, filePath));
    captureContextRootIdentity(context);
    return contents;
}

function assertPreparedReadDescriptorCurrent(
    context: RepoPathContext,
    input: PreparedRead,
    fd: number,
    label: string,
) {
    captureContextRootIdentity(context);
    if (!parentIdentityMatches(path.dirname(input.resolved), input.parentIdentity)) {
        throw new Error(`${label} parent directory changed during read: ${relativeToRoot(context, path.dirname(input.resolved))}`);
    }
    const descriptorStat = fs.fstatSync(fd);
    if (descriptorStat.nlink > 1) {
        throw new Error(`${label} must not have hardlinks: ${relativeToRoot(context, input.resolved)}`);
    }
    if (descriptorStat.nlink < 1 || !regularFileReadIdentityMatches(descriptorStat, input.fileIdentity)) {
        throw new Error(`${label} changed during read: ${relativeToRoot(context, input.resolved)}`);
    }
    let pathStat: fs.Stats;
    try {
        pathStat = fs.lstatSync(input.resolved);
    } catch (error) {
        if (isFsError(error, 'ENOENT')) {
            throw new Error(`${label} changed during read: ${relativeToRoot(context, input.resolved)}`);
        }
        throw error;
    }
    if (pathStat.nlink > 1) {
        throw new Error(`${label} must not have hardlinks: ${relativeToRoot(context, input.resolved)}`);
    }
    if (!regularFileReadIdentityMatches(pathStat, input.fileIdentity)) {
        throw new Error(`${label} changed during read: ${relativeToRoot(context, input.resolved)}`);
    }
    captureContextRootIdentity(context);
}

function openPreparedReadDescriptor(
    context: RepoPathContext,
    input: PreparedRead,
    label: string,
) {
    captureContextRootIdentity(context);
    let fd: number;
    try {
        fd = fs.openSync(input.resolved, fs.constants.O_RDONLY | NO_FOLLOW_FLAG);
    } catch (error) {
        if (isFsError(error, 'ELOOP')) {
            throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, input.resolved)}`);
        }
        throw error;
    }
    try {
        assertPreparedReadDescriptorCurrent(context, input, fd, label);
        return fd;
    } catch (error) {
        fs.closeSync(fd);
        throw error;
    }
}

export function readPreparedFileWriteTargetText(
    context: RepoPathContext,
    input: PreparedFileWritePreflight,
    label: string,
): string | undefined {
    captureContextRootIdentity(context);
    if (input.targetIdentity === null) {
        return undefined;
    }
    const contents = readPreparedTextFileWithFormatter(
        {
            resolved: input.target.resolved,
            parentIdentity: input.parentIdentity,
            fileIdentity: input.targetIdentity,
        },
        label,
        (filePath) => relativeToRoot(context, filePath),
    );
    captureContextRootIdentity(context);
    return contents;
}

export function readStableTextFileDirect(filePath: string, label: string): string {
    if (typeof filePath !== 'string' || filePath.trim().length === 0 || filePath.includes('\0')) {
        throw new Error(`${label} must be a non-empty path`);
    }
    const resolved = path.resolve(filePath);
    return readPreparedFileWithFormatter(
        prepareResolvedRegularFileReadDirect(resolved, label),
        label,
        (candidate) => candidate,
    ).toString('utf8');
}

export function readStableFileDirect(filePath: string, label: string): Buffer {
    if (typeof filePath !== 'string' || filePath.trim().length === 0 || filePath.includes('\0')) {
        throw new Error(`${label} must be a non-empty path`);
    }
    const resolved = path.resolve(filePath);
    return readPreparedFileWithFormatter(
        prepareResolvedRegularFileReadDirect(resolved, label),
        label,
        (candidate) => candidate,
    );
}

export function requireDirectory(context: RepoPathContext, directory: string, label: string) {
    const resolved = resolveRepoPath(context, directory, label);
    if (!fs.existsSync(resolved)) {
        throw new Error(`${label} not found: ${relativeToRoot(context, resolved)}`);
    }
    const stat = fs.lstatSync(resolved);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, resolved)}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} must be a directory: ${relativeToRoot(context, resolved)}`);
    }
    return resolved;
}

export function prepareWritableFile(context: RepoPathContext, filePath: string, label: string): PreparedWrite {
    const resolved = resolveRepoPath(context, filePath, label);
    const parent = assertDirectoryIfExists(context, path.dirname(resolved), `${label} parent directory`);
    if (fs.existsSync(resolved)) {
        const stat = fs.lstatSync(resolved);
        if (stat.isSymbolicLink()) {
            throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, resolved)}`);
        }
        if (!stat.isFile()) {
            throw new Error(`${label} must be a regular file: ${relativeToRoot(context, resolved)}`);
        }
    }
    return { resolved, parent };
}

export function assertDistinctResolvedPaths(paths: Array<{ label: string; resolved: string }>, groupLabel: string) {
    const seen = new Map<string, string>();
    const existingFiles = new Map<string, { label: string; resolved: string }>();
    for (const entry of paths) {
        const existing = seen.get(entry.resolved);
        if (existing) {
            throw new Error(`${groupLabel} must resolve to distinct files: ${existing} and ${entry.label}`);
        }
        seen.set(entry.resolved, entry.label);
        if (!fs.existsSync(entry.resolved)) {
            continue;
        }
        const stat = fs.lstatSync(entry.resolved);
        if (!stat.isFile()) {
            continue;
        }
        const identity = `${stat.dev}:${stat.ino}`;
        const existingIdentity = existingFiles.get(identity);
        if (existingIdentity) {
            throw new Error(
                `${groupLabel} must resolve to distinct files: ${existingIdentity.label} and ${entry.label}`,
            );
        }
        existingFiles.set(identity, entry);
    }
}

function assertPreparedWriteTargetsDoNotOverlap(
    preparedWrites: Array<{ label: string; target: PreparedWrite; targetIdentity: RegularFileIdentity | null }>,
    groupLabel: string,
) {
    const seenPaths = new Map<string, string>();
    const seenIdentities = new Map<string, string>();
    for (const write of preparedWrites) {
        const existingPath = seenPaths.get(write.target.resolved);
        if (existingPath) {
            throw new Error(`${groupLabel} must resolve to distinct files: ${existingPath} and ${write.label}`);
        }
        seenPaths.set(write.target.resolved, write.label);
        if (write.targetIdentity === null) {
            continue;
        }
        const identity = `${write.targetIdentity.dev}:${write.targetIdentity.ino}`;
        const existingIdentity = seenIdentities.get(identity);
        if (existingIdentity) {
            throw new Error(`${groupLabel} must resolve to distinct files: ${existingIdentity} and ${write.label}`);
        }
        seenIdentities.set(identity, write.label);
    }
}

function sha256(contents: Buffer) {
    return createHash('sha256').update(contents).digest('hex');
}

function readExactDescriptorBytes(fd: number, bytes: number, label: string) {
    const contents = Buffer.alloc(bytes);
    let offset = 0;
    while (offset < bytes) {
        const read = fs.readSync(fd, contents, offset, bytes - offset, offset);
        if (read === 0) {
            throw new Error(`${label} changed while its trusted bytes were being pinned.`);
        }
        offset += read;
    }
    return contents;
}

function writeAllDescriptorBytes(fd: number, contents: Buffer, label: string) {
    let offset = 0;
    while (offset < contents.length) {
        const written = fs.writeSync(fd, contents, offset, contents.length - offset, offset);
        if (written === 0) {
            throw new Error(`${label} could not be materialized completely.`);
        }
        offset += written;
    }
}

function openAnonymousReadOnlySnapshot(contents: Buffer, prefix: string, mode: number, label: string) {
    const tempRoot = fs.realpathSync(os.tmpdir());
    let snapshotPath: string | undefined;
    let writeFd: number | undefined;
    let readFd: number | undefined;
    let createdIdentity: { dev: number; ino: number } | undefined;
    try {
        for (let attempt = 0; attempt < 32; attempt += 1) {
            const candidate = path.join(tempRoot, `.${prefix}-${process.pid}-${randomBytes(16).toString('hex')}`);
            try {
                writeFd = fs.openSync(
                    candidate,
                    fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | NO_FOLLOW_FLAG,
                    mode,
                );
                snapshotPath = candidate;
                break;
            } catch (error) {
                if (isFsError(error, 'EEXIST')) {
                    continue;
                }
                throw error;
            }
        }
        if (writeFd === undefined || snapshotPath === undefined) {
            throw new Error(`${label} could not allocate an anonymous pinned snapshot.`);
        }
        const created = fs.fstatSync(writeFd);
        if (
            !created.isFile() ||
            created.nlink !== 1 ||
            created.size !== 0 ||
            (created.mode & 0o777) !== mode
        ) {
            throw new Error(`${label} create-once snapshot was not an empty regular file with the required mode.`);
        }
        createdIdentity = { dev: created.dev, ino: created.ino };
        writeAllDescriptorBytes(writeFd, contents, label);
        fs.fsyncSync(writeFd);
        const materialized = fs.fstatSync(writeFd);
        if (
            !materialized.isFile() ||
            materialized.nlink !== 1 ||
            materialized.dev !== created.dev ||
            materialized.ino !== created.ino ||
            materialized.size !== contents.length ||
            (materialized.mode & 0o777) !== mode
        ) {
            throw new Error(`${label} anonymous pinned snapshot changed while it was materialized.`);
        }
        readFd = fs.openSync(snapshotPath, fs.constants.O_RDONLY | NO_FOLLOW_FLAG);
        const opened = fs.fstatSync(readFd);
        const linked = fs.lstatSync(snapshotPath);
        if (
            !opened.isFile() ||
            !linked.isFile() ||
            opened.nlink !== 1 ||
            linked.nlink !== 1 ||
            opened.dev !== materialized.dev ||
            opened.ino !== materialized.ino ||
            linked.dev !== materialized.dev ||
            linked.ino !== materialized.ino ||
            opened.size !== contents.length ||
            linked.size !== contents.length ||
            (opened.mode & 0o777) !== mode ||
            (linked.mode & 0o777) !== mode
        ) {
            throw new Error(`${label} anonymous pinned snapshot changed before it was sealed.`);
        }
        const pinnedContents = readExactDescriptorBytes(readFd, opened.size, label);
        if (!pinnedContents.equals(contents)) {
            throw new Error(`${label} anonymous pinned snapshot bytes changed before it was sealed.`);
        }
        fs.unlinkSync(snapshotPath);
        snapshotPath = undefined;
        fs.closeSync(writeFd);
        writeFd = undefined;
        const sealed = fs.fstatSync(readFd);
        if (
            !sealed.isFile() ||
            sealed.nlink !== 0 ||
            sealed.dev !== opened.dev ||
            sealed.ino !== opened.ino ||
            sealed.size !== contents.length ||
            (sealed.mode & 0o777) !== mode ||
            !readExactDescriptorBytes(readFd, sealed.size, label).equals(contents)
        ) {
            throw new Error(`${label} anonymous pinned snapshot was not sealed as an unlinked regular file.`);
        }
        const result = readFd;
        readFd = undefined;
        return result;
    } finally {
        if (writeFd !== undefined) {
            fs.closeSync(writeFd);
        }
        if (readFd !== undefined) {
            fs.closeSync(readFd);
        }
        if (snapshotPath !== undefined && createdIdentity !== undefined) {
            try {
                const current = fs.lstatSync(snapshotPath);
                if (current.dev === createdIdentity.dev && current.ino === createdIdentity.ino) {
                    fs.unlinkSync(snapshotPath);
                }
            } catch (error) {
                if (!isFsError(error, 'ENOENT')) {
                    // The random create-once path is intentionally abandoned if it
                    // was raced; never broaden cleanup to a directory tree.
                }
            }
        }
    }
}

function pinTrustedOpenatHelper(name: PinnedOpenatHelperName, helperPath: string): PinnedOpenatHelper {
    const canonicalPath = path.resolve(helperPath);
    const canonicalDirectory = fs.realpathSync(path.dirname(canonicalPath));
    if (canonicalDirectory !== path.dirname(canonicalPath) || fs.realpathSync(canonicalPath) !== canonicalPath) {
        throw new Error(`openat ${name} helper must be a canonical non-symlink checkout file.`);
    }
    const pathStat = fs.lstatSync(canonicalPath);
    if (!pathStat.isFile() || pathStat.isSymbolicLink() || pathStat.nlink !== 1) {
        throw new Error(`openat ${name} helper must be a single-link regular checkout file.`);
    }
    if ((pathStat.mode & 0o022) !== 0) {
        throw new Error(`openat ${name} helper must not be group- or world-writable.`);
    }
    if (typeof process.getuid === 'function' && pathStat.uid !== process.getuid()) {
        throw new Error(`openat ${name} helper must be owned by the current operator.`);
    }

    let sourceFd: number | undefined;
    try {
        sourceFd = fs.openSync(canonicalPath, fs.constants.O_RDONLY | NO_FOLLOW_FLAG);
        const before = fs.fstatSync(sourceFd);
        if (
            !before.isFile() ||
            before.nlink !== 1 ||
            before.dev !== pathStat.dev ||
            before.ino !== pathStat.ino ||
            before.size !== pathStat.size ||
            before.mtimeMs !== pathStat.mtimeMs ||
            before.ctimeMs !== pathStat.ctimeMs ||
            before.size <= 0 ||
            before.size > 2 * 1024 * 1024
        ) {
            throw new Error(`openat ${name} helper changed while its trusted source was being opened.`);
        }
        const contents = readExactDescriptorBytes(sourceFd, before.size, `openat ${name} helper`);
        const after = fs.fstatSync(sourceFd);
        const finalPathStat = fs.lstatSync(canonicalPath);
        if (
            after.dev !== before.dev ||
            after.ino !== before.ino ||
            after.size !== before.size ||
            after.mtimeMs !== before.mtimeMs ||
            after.ctimeMs !== before.ctimeMs ||
            finalPathStat.dev !== before.dev ||
            finalPathStat.ino !== before.ino ||
            finalPathStat.size !== before.size ||
            finalPathStat.mtimeMs !== before.mtimeMs ||
            finalPathStat.ctimeMs !== before.ctimeMs ||
            !contents.subarray(0, 22).toString('utf8').startsWith('#!/usr/bin/env python3') ||
            contents.includes(0)
        ) {
            throw new Error(`openat ${name} helper changed while its trusted bytes were being pinned.`);
        }
        const fd = openAnonymousReadOnlySnapshot(contents, `tonswap-openat-${name}`, 0o400, `openat ${name} helper`);
        const pinnedStat = fs.fstatSync(fd);
        return Object.freeze({
            name,
            fd,
            dev: pinnedStat.dev,
            ino: pinnedStat.ino,
            bytes: contents.length,
            sha256: sha256(contents),
        });
    } finally {
        if (sourceFd !== undefined) {
            fs.closeSync(sourceFd);
        }
    }
}

function assertPinnedOpenatHelperCurrent(helper: PinnedOpenatHelper) {
    const current = fs.fstatSync(helper.fd);
    if (
        !current.isFile() ||
        current.nlink !== 0 ||
        current.dev !== helper.dev ||
        current.ino !== helper.ino ||
        current.size !== helper.bytes ||
        sha256(readExactDescriptorBytes(helper.fd, helper.bytes, `openat ${helper.name} helper`)) !== helper.sha256
    ) {
        throw new Error(`openat ${helper.name} helper pinned bytes changed before execution.`);
    }
}

function assertPinnedOpenatHelperArgs(
    helperName: PinnedOpenatHelperName,
    args: readonly string[],
) {
    const allowed =
        args.length === 0 ||
        (
            helperName === 'mkdir' &&
            args.length === 1 &&
            args[0] === '--chmod-existing'
        );
    if (!allowed) {
        throw new Error(`openat ${helperName} helper received unsupported operation arguments.`);
    }
}

export function preparePinnedOpenatHelperExecution(
    helperName: PinnedOpenatHelperName,
    args: readonly string[] = [],
    options: PinnedOpenatHelperExecutionOptions = {},
): PreparedPinnedOpenatHelperExecution {
    assertPinnedOpenatHelperArgs(helperName, args);
    const helper = PINNED_OPENAT_HELPERS[helperName];
    assertPinnedOpenatHelperCurrent(helper);
    const inheritedReadOnlyFds = options.inheritedReadOnlyFds ?? [];
    for (const [index, fd] of inheritedReadOnlyFds.entries()) {
        if (!Number.isSafeInteger(fd) || fd < 0 || !fs.fstatSync(fd).isFile()) {
            throw new Error(`openat ${helperName} helper inherited read-only fd ${index} must be a regular file.`);
        }
    }
    const childEnv: NodeJS.ProcessEnv = Object.create(null);
    for (const key of PINNED_OPENAT_ENV_ALLOWLIST) {
        if (process.env[key] !== undefined) childEnv[key] = process.env[key];
    }
    childEnv[PINNED_OPENAT_HELPER_MARKER_ENV] = helperName;
    childEnv[PINNED_OPENAT_SOURCE_SHA256_ENV] = helper.sha256;
    return Object.freeze({
        command: 'python3',
        args: Object.freeze(['-c', PINNED_OPENAT_HELPER_BOOTSTRAP, ...args]),
        env: Object.freeze(childEnv),
        input: options.input,
        inheritedReadOnlyFds: Object.freeze([helper.fd, ...inheritedReadOnlyFds]),
    });
}

export function executePinnedOpenatHelper(
    helperName: PinnedOpenatHelperName,
    args: readonly string[],
    options: PinnedOpenatHelperExecutionOptions & { encoding: 'utf8' },
): string;
export function executePinnedOpenatHelper(
    helperName: PinnedOpenatHelperName,
    args?: readonly string[],
    options?: PinnedOpenatHelperExecutionOptions,
): Buffer;
export function executePinnedOpenatHelper(
    helperName: PinnedOpenatHelperName,
    args: readonly string[] = [],
    options: PinnedOpenatHelperExecutionOptions = {},
): string | Buffer {
    const prepared = preparePinnedOpenatHelperExecution(helperName, args, options);
    if (prepared.input === undefined) {
        throw new Error(`openat ${helperName} helper synchronous execution requires an explicit request.`);
    }
    const request = Buffer.isBuffer(prepared.input)
        ? Buffer.from(prepared.input)
        : Buffer.from(prepared.input, 'utf8');
    const requestFd = openAnonymousReadOnlySnapshot(
        request,
        `tonswap-openat-${helperName}-request`,
        0o600,
        `openat ${helperName} request`,
    );
    try {
        const execOptions: childProcess.ExecFileSyncOptions = {
            stdio: [requestFd, 'pipe', 'pipe', ...prepared.inheritedReadOnlyFds],
            env: {
                ...prepared.env,
                [PINNED_OPENAT_REQUEST_SHA256_ENV]: sha256(request),
            },
            ...(options.timeout === undefined ? {} : { timeout: options.timeout }),
            ...(options.encoding === undefined ? {} : { encoding: options.encoding }),
        };
        return childProcess.execFileSync(
            prepared.command,
            [...prepared.args],
            execOptions as never,
        );
    } finally {
        fs.closeSync(requestFd);
    }
}

function contentsBase64(contents: string | Buffer) {
    return Buffer.isBuffer(contents)
        ? contents.toString('base64')
        : Buffer.from(contents, 'utf8').toString('base64');
}

function writeOpenatPreparedFiles(
    writes: OpenatPreparedWrite[],
    preconditions: OpenatPreparedPrecondition[] = [],
    rootIdentity: ParentDirectoryIdentity,
) {
    for (const write of writes) {
        if (
            write.mode !== undefined &&
            (!Number.isSafeInteger(write.mode) || write.mode < 0 || write.mode > 0o777)
        ) {
            throw new Error(`${write.label} mode must be an integer between 0000 and 0777.`);
        }
    }
    const request = {
        root: rootIdentity,
        preconditions: preconditions.map((precondition) => ({
            parentPath: path.resolve(path.dirname(precondition.resolved)),
            fileName: path.basename(precondition.resolved),
            label: precondition.label,
            expectedParent: precondition.parentIdentity,
            expectedTarget: precondition.targetIdentity,
            expectedBytes: precondition.expectedBytes,
            expectedSha256: precondition.expectedSha256,
            expectedMode: precondition.expectedMode,
            expectedUid: precondition.expectedUid,
            displayParent: precondition.displayParent,
            displayTarget: precondition.displayTarget,
        })),
        writes: writes.map((write) => ({
            parentPath: path.resolve(write.target.parent),
            fileName: path.basename(write.target.resolved),
            label: write.label,
            append: write.append === true,
            expectedParent: write.parentIdentity,
            expectedTarget: write.targetIdentity,
            displayParent: write.displayParent,
            displayTarget: write.displayTarget,
            contentsBase64: contentsBase64(write.contents),
            ...(write.mode === undefined ? {} : { mode: write.mode }),
        })),
    };
    const requestJson = JSON.stringify(request);
    try {
        executePinnedOpenatHelper('write', [], { input: requestJson });
    } catch (error) {
        if (error && typeof error === 'object' && 'stderr' in error) {
            const stderr = Buffer.from((error as { stderr?: Buffer | string }).stderr ?? '').toString('utf8').trim();
            if (stderr.length > 0) {
                throw new Error(stderr);
            }
        }
        throw error;
    }
}

function writeOpenatPreparedFileFromDescriptor(
    write: Omit<OpenatPreparedWrite, 'contents'>,
    sourceFd: number,
    sourceIdentity: RegularFileIdentity,
    expectedSourceSha256: string,
    rootIdentity: ParentDirectoryIdentity,
) {
    const request = {
        root: rootIdentity,
        preconditions: [],
        writes: [{
            parentPath: path.resolve(write.target.parent),
            fileName: path.basename(write.target.resolved),
            label: write.label,
            append: false,
            expectedParent: write.parentIdentity,
            expectedTarget: write.targetIdentity,
            displayParent: write.displayParent,
            displayTarget: write.displayTarget,
            contentsFd: 4,
            expectedContents: sourceIdentity,
            expectedContentsSha256: expectedSourceSha256,
            ...(write.mode === undefined ? {} : { mode: write.mode }),
        }],
    };
    try {
        executePinnedOpenatHelper('write', [], {
            input: JSON.stringify(request),
            inheritedReadOnlyFds: [sourceFd],
        });
    } catch (error) {
        if (error && typeof error === 'object' && 'stderr' in error) {
            const stderr = Buffer.from((error as { stderr?: Buffer | string }).stderr ?? '').toString('utf8').trim();
            if (stderr.length > 0) {
                throw new Error(stderr);
            }
        }
        throw error;
    }
}

function unlinkOpenatPreparedFiles(unlinks: OpenatPreparedUnlink[], rootIdentity: ParentDirectoryIdentity) {
    const request = {
        root: rootIdentity,
        unlinks: unlinks.map((entry) => ({
            entryType: entry.entryType,
            parentPath: path.resolve(path.dirname(entry.filePath)),
            fileName: path.basename(entry.filePath),
            label: entry.label,
            expectedParent: entry.parentIdentity,
            expectedTarget: entry.targetIdentity,
            displayParent: entry.displayParent,
            displayTarget: entry.displayTarget,
        })),
    };
    try {
        executePinnedOpenatHelper('unlink', [], {
            input: JSON.stringify(request),
        });
    } catch (error) {
        if (error && typeof error === 'object' && 'stderr' in error) {
            const stderr = Buffer.from((error as { stderr?: Buffer | string }).stderr ?? '').toString('utf8').trim();
            if (stderr.length > 0) {
                throw new Error(stderr);
            }
        }
        throw error;
    }
}

export function unlinkPreflightedFileWithoutFollowingTargetSymlink(options: CheckedUnlinkOptions) {
    unlinkOpenatPreparedFiles([
        {
            filePath: options.filePath,
            entryType: 'file',
            label: options.label,
            parentIdentity: options.parentIdentity,
            targetIdentity: options.targetIdentity,
            displayParent: options.displayParent,
            displayTarget: options.displayTarget,
        },
    ], options.rootIdentity);
}

export function rmdirPreflightedDirectoryWithoutFollowingTargetSymlink(options: CheckedRmdirOptions) {
    unlinkOpenatPreparedFiles([
        {
            filePath: options.directoryPath,
            entryType: 'directory',
            label: options.label,
            parentIdentity: options.parentIdentity,
            targetIdentity: options.directoryIdentity,
            displayParent: options.displayParent,
            displayTarget: options.displayTarget,
        },
    ], options.rootIdentity);
}

function createFsError(code: string, message: string): NodeJS.ErrnoException {
    const error = new Error(message) as NodeJS.ErrnoException;
    error.code = code;
    return error;
}

function assertWritableNewFile(context: RepoPathContext, filePath: string, label: string) {
    assertNoSymlinkSegments(context, filePath, label);
    assertPathInsideRoot(context, filePath, label);
    if (!fs.existsSync(filePath)) {
        return;
    }
    const stat = fs.lstatSync(filePath);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, filePath)}`);
    }
    if (stat.isFile()) {
        throw createFsError('EEXIST', `${label} already exists: ${relativeToRoot(context, filePath)}`);
    }
    throw new Error(`${label} must be a regular file: ${relativeToRoot(context, filePath)}`);
}

export function writePreparedNewFileWithoutFollowingTargetSymlink(
    context: RepoPathContext,
    target: PreparedWrite,
    contents: string | Buffer,
    label: string,
    options: {
        mode?: number;
        preconditions?: PreparedFileWritePrecondition[];
    } = {},
) {
    const rootIdentity = captureContextRootIdentity(context);
    ensureDirectoryWithoutSymlinkSegments(context, target.parent, `${label} parent directory`);
    assertWritableParentDirectory(context, target.parent, label);
    assertWritableNewFile(context, target.resolved, label);
    const parentIdentity = captureContextParentDirectoryIdentity(context, target.parent, `${label} parent directory`);
    const preparedWrite = {
        target,
        contents,
        label,
        mode: options.mode,
        parentIdentity,
        targetIdentity: null,
        displayParent: relativeToRoot(context, target.parent),
        displayTarget: relativeToRoot(context, target.resolved),
    };
    const preparedPreconditions = (options.preconditions ?? []).map((precondition) =>
        prepareFileWritePrecondition(context, precondition),
    );
    assertWritePreconditionsDoNotOverlapTargets([preparedWrite], preparedPreconditions);
    writeOpenatPreparedFiles([preparedWrite], preparedPreconditions, rootIdentity);
}

export function writePreparedFileWithoutFollowingTargetSymlink(
    context: RepoPathContext,
    target: PreparedWrite,
    contents: string | Buffer,
    label: string,
) {
    const rootIdentity = captureContextRootIdentity(context);
    ensureDirectoryWithoutSymlinkSegments(context, target.parent, `${label} parent directory`);
    assertWritableParentDirectory(context, target.parent, label);
    const targetIdentity = assertWritableFileIfExists(context, target.resolved, label);
    const parentIdentity = captureContextParentDirectoryIdentity(context, target.parent, `${label} parent directory`);
    writeOpenatPreparedFiles([
        {
            target,
            contents,
            label,
            parentIdentity,
            targetIdentity,
            displayParent: relativeToRoot(context, target.parent),
            displayTarget: relativeToRoot(context, target.resolved),
        },
    ], [], rootIdentity);
}

export function appendPreparedFileWithoutFollowingTargetSymlink(
    context: RepoPathContext,
    target: PreparedWrite,
    contents: string | Buffer,
    label: string,
) {
    const rootIdentity = captureContextRootIdentity(context);
    ensureDirectoryWithoutSymlinkSegments(context, target.parent, `${label} parent directory`);
    assertWritableParentDirectory(context, target.parent, label);
    const targetIdentity = assertWritableFileIfExists(context, target.resolved, label);
    const parentIdentity = captureContextParentDirectoryIdentity(context, target.parent, `${label} parent directory`);
    writeOpenatPreparedFiles([
        {
            target,
            contents,
            label,
            append: true,
            parentIdentity,
            targetIdentity,
            displayParent: relativeToRoot(context, target.parent),
            displayTarget: relativeToRoot(context, target.resolved),
        },
    ], [], rootIdentity);
}

export function appendPreparedFileWithoutFollowingTargetSymlinkDirect(
    mutationRoot: DirectMutationRoot,
    target: PreparedWrite,
    contents: string | Buffer,
    label: string,
) {
    const rootIdentity = validateDirectMutationRoot(mutationRoot, `${label} direct append root`);
    assertPreparedWriteInsideDirectMutationRoot(mutationRoot, target, label);
    ensureDirectoryWithoutSymlinkSegmentsDirect(mutationRoot, target.parent, `${label} parent directory`);
    assertDirectWritableParentDirectory(target.parent, label);
    const targetIdentity = assertDirectWritableFileIfExists(target.resolved, label);
    const parentIdentity = captureParentDirectoryIdentity(target.parent);
    writeOpenatPreparedFiles([
        {
            target,
            contents,
            label,
            append: true,
            parentIdentity,
            targetIdentity,
            displayParent: target.parent,
            displayTarget: target.resolved,
        },
    ], [], rootIdentity);
}

export function writePreparedFilesWithoutFollowingTargetSymlinks(
    context: RepoPathContext,
    writes: PreparedFileWrite[],
    beforeWrite?: (writes: PreparedFileWritePreflight[]) => void,
    preconditions: PreparedFileWritePrecondition[] = [],
) {
    const rootIdentity = captureContextRootIdentity(context);
    for (const entry of writes) {
        ensureDirectoryWithoutSymlinkSegments(context, entry.target.parent, `${entry.label} parent directory`);
        assertWritableParentDirectory(context, entry.target.parent, entry.label);
    }
    const preparedPreconditions = preconditions.map((precondition) =>
        prepareFileWritePrecondition(context, precondition),
    );

    const preparedWrites = writes.map((entry) => {
        const targetIdentity = entry.createOnly
            ? (assertWritableNewFile(context, entry.target.resolved, entry.label), null)
            : assertWritableFileIfExists(context, entry.target.resolved, entry.label);
        return {
            entry,
            target: entry.target,
            label: entry.label,
            append: entry.append,
            mode: entry.mode,
            parentIdentity: captureContextParentDirectoryIdentity(
                context,
                entry.target.parent,
                `${entry.label} parent directory`,
            ),
            targetIdentity,
            displayParent: relativeToRoot(context, entry.target.parent),
            displayTarget: relativeToRoot(context, entry.target.resolved),
        };
    });
    assertPreparedWriteTargetsDoNotOverlap(preparedWrites, 'generated outputs');
    assertWritePreconditionsDoNotOverlapTargets(preparedWrites, preparedPreconditions);

    beforeWrite?.(preparedWrites.map((entry) => ({
        target: entry.target,
        label: entry.label,
        append: entry.append,
        parentIdentity: entry.parentIdentity,
        targetIdentity: entry.targetIdentity,
    })));

    writeOpenatPreparedFiles(preparedWrites.map((entry) => ({
        target: entry.target,
        contents: entry.entry.contents,
        label: entry.label,
        append: entry.append,
        mode: entry.entry.mode,
        parentIdentity: entry.parentIdentity,
        targetIdentity: entry.targetIdentity,
        displayParent: entry.displayParent,
        displayTarget: entry.displayTarget,
    })), preparedPreconditions, rootIdentity);
}

export function writePreparedFilesWithoutFollowingTargetSymlinksDirect(
    mutationRoot: DirectMutationRoot,
    writes: PreparedFileWrite[],
) {
    const rootIdentity = validateDirectMutationRoot(mutationRoot, 'direct generated outputs root');
    if (writes.length === 0) {
        throw new Error('direct generated outputs must include at least one write.');
    }
    for (const entry of writes) {
        assertPreparedWriteInsideDirectMutationRoot(mutationRoot, entry.target, entry.label);
    }
    for (const entry of writes) {
        ensureDirectoryWithoutSymlinkSegmentsDirect(
            mutationRoot,
            entry.target.parent,
            `${entry.label} parent directory`,
        );
        assertDirectWritableParentDirectory(entry.target.parent, entry.label);
    }

    const preparedWrites = writes.map((entry) => {
        if (entry.createOnly && fs.existsSync(entry.target.resolved)) {
            throw createFsError('EEXIST', `${entry.label} already exists: ${entry.target.resolved}`);
        }
        const targetIdentity = entry.createOnly ? null : assertDirectWritableFileIfExists(entry.target.resolved, entry.label);
        return {
            target: entry.target,
            contents: entry.contents,
            label: entry.label,
            append: entry.append,
            mode: entry.mode,
            parentIdentity: captureParentDirectoryIdentity(entry.target.parent),
            targetIdentity,
            displayParent: entry.target.parent,
            displayTarget: entry.target.resolved,
        };
    });
    assertPreparedWriteTargetsDoNotOverlap(preparedWrites, 'generated outputs');
    writeOpenatPreparedFiles(preparedWrites, [], rootIdentity);
}

export function copyPreparedRegularFileToNewFileWithoutFollowingTargetSymlinkDirect(
    sourceContext: RepoPathContext,
    source: PreparedRead,
    mutationRoot: DirectMutationRoot,
    target: PreparedWrite,
    label: string,
    expectedSourceSha256: string,
    mode = 0o600,
) {
    if (!/^[0-9a-f]{64}$/.test(expectedSourceSha256)) {
        throw new Error(`${label} expected source checksum must be lowercase 64-character hex.`);
    }
    if (mode !== 0o600) {
        throw new Error(`${label} mode must be 0600.`);
    }
    if (source.resolved === target.resolved) {
        throw new Error(`${label} source and destination must be distinct files.`);
    }
    const rootIdentity = validateDirectMutationRoot(mutationRoot, `${label} direct copy root`);
    assertPreparedWriteInsideDirectMutationRoot(mutationRoot, target, label);
    ensureDirectoryWithoutSymlinkSegmentsDirect(
        mutationRoot,
        target.parent,
        `${label} parent directory`,
    );
    assertDirectWritableParentDirectory(target.parent, label);
    if (fs.existsSync(target.resolved)) {
        throw createFsError('EEXIST', `${label} already exists: ${target.resolved}`);
    }

    const sourceFd = openPreparedReadDescriptor(sourceContext, source, `${label} source`);
    try {
        const parentIdentity = captureParentDirectoryIdentity(target.parent);
        writeOpenatPreparedFileFromDescriptor(
            {
                target,
                label,
                append: false,
                mode,
                parentIdentity,
                targetIdentity: null,
                displayParent: target.parent,
                displayTarget: target.resolved,
            },
            sourceFd,
            source.fileIdentity,
            expectedSourceSha256,
            rootIdentity,
        );
        assertPreparedReadDescriptorCurrent(sourceContext, source, sourceFd, `${label} source`);
    } finally {
        fs.closeSync(sourceFd);
    }
}

export function removeDirectoryWithoutFollowingSymlinks(
    context: RepoPathContext,
    directory: string,
    label: string,
) {
    const rootIdentity = captureContextRootIdentity(context);
    assertNoSymlinkSegments(context, directory, label);
    assertPathInsideRoot(context, directory, label);
    if (!fs.existsSync(directory)) {
        return;
    }
    const stat = fs.lstatSync(directory);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, directory)}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} must be a directory: ${relativeToRoot(context, directory)}`);
    }
    assertDirectoryTreeContainsOnlyRegularEntries(context, directory, label);
    removeTreeWithoutFollowingSymlinks(context, directory, label, rootIdentity);
}

export function removeFileWithoutFollowingSymlinks(
    context: RepoPathContext,
    filePath: string,
    label: string,
) {
    const rootIdentity = captureContextRootIdentity(context);
    assertNoSymlinkSegments(context, filePath, label);
    assertPathInsideRoot(context, filePath, label);
    let stat: fs.Stats;
    try {
        stat = fs.lstatSync(filePath);
    } catch (error) {
        if (isFsError(error, 'ENOENT')) {
            return;
        }
        throw error;
    }
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, filePath)}`);
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must be a regular file: ${relativeToRoot(context, filePath)}`);
    }
    const parentIdentity = captureContextParentDirectoryIdentity(
        context,
        path.dirname(filePath),
        `${label} parent directory`,
    );
    unlinkPreflightedRegularFile(
        filePath,
        label,
        captureRegularFileIdentity(stat),
        parentIdentity,
        (candidate) => relativeToRoot(context, candidate),
        rootIdentity,
    );
}

export async function removeDirectoryWithoutFollowingSymlinksDirectAsync(
    mutationRoot: DirectMutationRoot,
    directory: string,
    label: string,
) {
    const rootIdentity = validateDirectMutationRoot(mutationRoot, `${label} direct cleanup root`);
    const resolved = path.resolve(directory);
    assertPathInsideDirectMutationRoot(mutationRoot, resolved, label);
    assertDirectDirectoryTreeContainsOnlyRegularEntries(resolved, label);
    await removeTreeWithoutFollowingSymlinksDirectAsync(resolved, label, rootIdentity);
}

function captureRegularFileIdentity(stat: fs.Stats): RegularFileIdentity {
    return {
        dev: stat.dev,
        ino: stat.ino,
        size: stat.size,
        mtimeMs: stat.mtimeMs,
        ctimeMs: stat.ctimeMs,
    };
}

function prepareResolvedRegularFileRead(context: RepoPathContext, resolved: string, label: string): PreparedRead {
    if (!fs.existsSync(resolved)) {
        throw new Error(`${label} not found: ${relativeToRoot(context, resolved)}`);
    }
    const parentIdentity = captureParentDirectoryIdentity(path.dirname(resolved));
    const stat = fs.lstatSync(resolved);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, resolved)}`);
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must be a regular file: ${relativeToRoot(context, resolved)}`);
    }
    if (stat.nlink > 1) {
        throw new Error(`${label} must not have hardlinks: ${relativeToRoot(context, resolved)}`);
    }
    return {
        resolved,
        parentIdentity,
        fileIdentity: captureRegularFileIdentity(stat),
    };
}

function prepareResolvedRegularFileReadDirect(resolved: string, label: string): PreparedRead {
    if (!fs.existsSync(resolved)) {
        throw new Error(`${label} not found: ${resolved}`);
    }
    const parentIdentity = captureParentDirectoryIdentity(path.dirname(resolved));
    const stat = fs.lstatSync(resolved);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${resolved}`);
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must be a regular file: ${resolved}`);
    }
    if (stat.nlink > 1) {
        throw new Error(`${label} must not have hardlinks: ${resolved}`);
    }
    return {
        resolved,
        parentIdentity,
        fileIdentity: captureRegularFileIdentity(stat),
    };
}

function assertRegularFileIdentityUnchanged(
    current: fs.Stats,
    expected: RegularFileIdentity,
    label: string,
    pathLabel: string,
) {
    if (!current.isFile()) {
        throw new Error(`${label} changed before unlink: ${pathLabel}`);
    }
    if (current.nlink > 1) {
        throw new Error(`${label} must not have hardlinks: ${pathLabel}`);
    }
    if (current.nlink < 1) {
        throw new Error(`${label} changed before unlink: ${pathLabel}`);
    }
    if (
        current.dev !== expected.dev ||
        current.ino !== expected.ino ||
        current.size !== expected.size ||
        current.mtimeMs !== expected.mtimeMs ||
        current.ctimeMs !== expected.ctimeMs
    ) {
        throw new Error(`${label} changed before unlink: ${pathLabel}`);
    }
}

function regularFileIdentityMatches(current: fs.Stats, expected: RegularFileIdentity) {
    return (
        current.dev === expected.dev &&
        current.ino === expected.ino &&
        current.size === expected.size &&
        current.mtimeMs === expected.mtimeMs &&
        current.ctimeMs === expected.ctimeMs
    );
}

function regularFileReadIdentityMatches(current: fs.Stats, expected: RegularFileIdentity) {
    return current.isFile() && regularFileIdentityMatches(current, expected);
}

function readPreparedTextFileWithFormatter(
    input: PreparedRead,
    label: string,
    formatPath: (filePath: string) => string,
): string {
    return readPreparedFileWithFormatter(input, label, formatPath).toString('utf8');
}

function readPreparedFileWithFormatter(
    input: PreparedRead,
    label: string,
    formatPath: (filePath: string) => string,
): Buffer {
    let fd: number | undefined;
    try {
        try {
            fd = fs.openSync(input.resolved, fs.constants.O_RDONLY | NO_FOLLOW_FLAG);
        } catch (error) {
            if (isFsError(error, 'ELOOP')) {
                throw new Error(`${label} must not be a symlink: ${formatPath(input.resolved)}`);
            }
            throw error;
        }
        if (!parentIdentityMatches(path.dirname(input.resolved), input.parentIdentity)) {
            throw new Error(`${label} parent directory changed before read: ${formatPath(path.dirname(input.resolved))}`);
        }
        const openedStat = fs.fstatSync(fd);
        if (openedStat.nlink > 1) {
            throw new Error(`${label} must not have hardlinks: ${formatPath(input.resolved)}`);
        }
        if (openedStat.nlink < 1) {
            throw new Error(`${label} changed before read: ${formatPath(input.resolved)}`);
        }
        if (!regularFileReadIdentityMatches(openedStat, input.fileIdentity)) {
            throw new Error(`${label} changed before read: ${formatPath(input.resolved)}`);
        }
        const raw = fs.readFileSync(fd);
        const finalDescriptorStat = fs.fstatSync(fd);
        if (finalDescriptorStat.nlink > 1) {
            throw new Error(`${label} must not have hardlinks: ${formatPath(input.resolved)}`);
        }
        if (finalDescriptorStat.nlink < 1) {
            throw new Error(`${label} changed during read: ${formatPath(input.resolved)}`);
        }
        if (!regularFileReadIdentityMatches(finalDescriptorStat, input.fileIdentity)) {
            throw new Error(`${label} changed during read: ${formatPath(input.resolved)}`);
        }
        let finalPathStat: fs.Stats;
        try {
            finalPathStat = fs.lstatSync(input.resolved);
        } catch (error) {
            if (isFsError(error, 'ENOENT')) {
                throw new Error(`${label} changed during read: ${formatPath(input.resolved)}`);
            }
            throw error;
        }
        if (!regularFileReadIdentityMatches(finalPathStat, input.fileIdentity)) {
            throw new Error(`${label} changed during read: ${formatPath(input.resolved)}`);
        }
        if (finalPathStat.nlink > 1) {
            throw new Error(`${label} must not have hardlinks: ${formatPath(input.resolved)}`);
        }
        if (!parentIdentityMatches(path.dirname(input.resolved), input.parentIdentity)) {
            throw new Error(`${label} parent directory changed during read: ${formatPath(path.dirname(input.resolved))}`);
        }
        return raw;
    } catch (error) {
        if (isFsError(error, 'ENOENT')) {
            throw new Error(`${label} changed before read: ${formatPath(input.resolved)}`);
        }
        throw error;
    } finally {
        if (fd !== undefined) {
            fs.closeSync(fd);
        }
    }
}

function unlinkPreflightedRegularFile(
    filePath: string,
    label: string,
    expectedFileIdentity: RegularFileIdentity,
    expectedParentIdentity: ParentDirectoryIdentity,
    formatPath: (filePath: string) => string,
    rootIdentity: ParentDirectoryIdentity,
) {
    let fd: number | undefined;
    try {
        try {
            fd = fs.openSync(filePath, fs.constants.O_RDONLY | NO_FOLLOW_FLAG);
        } catch (error) {
            if (isFsError(error, 'ELOOP')) {
                throw new Error(`${label} must not be a symlink: ${formatPath(filePath)}`);
            }
            throw error;
        }
        const targetIdentity = captureUnlinkTargetIdentity(filePath, fd, expectedFileIdentity, label, formatPath(filePath));
        if (!parentIdentityMatches(path.dirname(filePath), expectedParentIdentity)) {
            throw new Error(`${label} parent changed before unlink: ${formatPath(filePath)}`);
        }
        unlinkPreflightedFileWithoutFollowingTargetSymlink({
            filePath,
            label,
            parentIdentity: expectedParentIdentity,
            targetIdentity,
            displayParent: formatPath(path.dirname(filePath)),
            displayTarget: formatPath(filePath),
            rootIdentity,
        });
    } finally {
        if (fd !== undefined) {
            fs.closeSync(fd);
        }
    }
}

async function captureParentDirectoryIdentityAsync(directory: string): Promise<ParentDirectoryIdentity> {
    const stat = await fs.promises.lstat(directory);
    if (stat.isSymbolicLink()) {
        throw new Error(`Parent directory must not be a symlink: ${directory}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`Parent directory must be a directory: ${directory}`);
    }
    return {
        realpath: await fs.promises.realpath(directory),
        dev: stat.dev,
        ino: stat.ino,
    };
}

async function parentIdentityMatchesAsync(directory: string, expected: ParentDirectoryIdentity) {
    let current: ParentDirectoryIdentity;
    try {
        current = await captureParentDirectoryIdentityAsync(directory);
    } catch {
        return false;
    }
    return current.realpath === expected.realpath && current.dev === expected.dev && current.ino === expected.ino;
}

async function assertRegularFileIdentityUnchangedAsync(
    current: fs.Stats,
    expected: RegularFileIdentity,
    label: string,
    pathLabel: string,
) {
    if (!current.isFile()) {
        throw new Error(`${label} changed before unlink: ${pathLabel}`);
    }
    if (current.nlink > 1) {
        throw new Error(`${label} must not have hardlinks before unlink: ${pathLabel}`);
    }
    if (current.nlink < 1) {
        throw new Error(`${label} changed before unlink: ${pathLabel}`);
    }
    if (
        current.dev !== expected.dev ||
        current.ino !== expected.ino ||
        current.size !== expected.size ||
        current.mtimeMs !== expected.mtimeMs ||
        current.ctimeMs !== expected.ctimeMs
    ) {
        throw new Error(`${label} changed before unlink: ${pathLabel}`);
    }
}

async function unlinkPreflightedRegularFileAsync(
    filePath: string,
    label: string,
    expectedFileIdentity: RegularFileIdentity,
    expectedParentIdentity: ParentDirectoryIdentity,
    rootIdentity: ParentDirectoryIdentity,
) {
    let handle: Awaited<ReturnType<typeof fs.promises.open>> | undefined;
    try {
        try {
            handle = await fs.promises.open(filePath, fs.constants.O_RDONLY | NO_FOLLOW_FLAG);
        } catch (error) {
            if (isFsError(error, 'ELOOP')) {
                throw new Error(`${label} must not be a symlink: ${filePath}`);
            }
            throw error;
        }
        await assertRegularFileIdentityUnchangedAsync(await handle.stat(), expectedFileIdentity, label, filePath);
        const targetIdentity = captureUnlinkTargetIdentity(filePath, handle.fd, expectedFileIdentity, label, filePath);
        if (!(await parentIdentityMatchesAsync(path.dirname(filePath), expectedParentIdentity))) {
            throw new Error(`${label} parent changed before unlink: ${filePath}`);
        }
        unlinkPreflightedFileWithoutFollowingTargetSymlink({
            filePath,
            label,
            parentIdentity: expectedParentIdentity,
            targetIdentity,
            displayParent: path.dirname(filePath),
            displayTarget: filePath,
            rootIdentity,
        });
    } finally {
        await handle?.close();
    }
}

function assertDirectoryIdentityUnchanged(
    current: fs.Stats,
    expected: Pick<fs.Stats, 'dev' | 'ino'>,
    label: string,
    directory: string,
) {
    if (!current.isDirectory()) {
        throw new Error(`${label} changed before rmdir: ${directory}`);
    }
    if (current.dev !== expected.dev || current.ino !== expected.ino) {
        throw new Error(`${label} changed before rmdir: ${directory}`);
    }
}

async function removeTreeWithoutFollowingSymlinksDirectAsync(
    entryPath: string,
    label: string,
    rootIdentity: ParentDirectoryIdentity,
) {
    let stat: fs.Stats;
    try {
        stat = await fs.promises.lstat(entryPath);
    } catch (error) {
        if (isFsError(error, 'ENOENT')) {
            return;
        }
        throw error;
    }
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not contain symlinks: ${entryPath}`);
    }
    if (stat.isDirectory()) {
        const directoryIdentity = { dev: stat.dev, ino: stat.ino };
        const parentIdentity = await captureParentDirectoryIdentityAsync(path.dirname(entryPath));
        const entries = await fs.promises.readdir(entryPath);
        for (const entry of entries) {
            await removeTreeWithoutFollowingSymlinksDirectAsync(path.join(entryPath, entry), label, rootIdentity);
        }
        assertDirectoryIdentityUnchanged(await fs.promises.lstat(entryPath), directoryIdentity, label, entryPath);
        if (!(await parentIdentityMatchesAsync(path.dirname(entryPath), parentIdentity))) {
            throw new Error(`${label} parent changed before rmdir: ${entryPath}`);
        }
        rmdirPreflightedDirectoryWithoutFollowingTargetSymlink({
            directoryPath: entryPath,
            label,
            parentIdentity,
            directoryIdentity,
            displayParent: path.dirname(entryPath),
            displayTarget: entryPath,
            rootIdentity,
        });
        return;
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must contain only regular files/directories: ${entryPath}`);
    }
    await unlinkPreflightedRegularFileAsync(
        entryPath,
        label,
        captureRegularFileIdentity(stat),
        await captureParentDirectoryIdentityAsync(path.dirname(entryPath)),
        rootIdentity,
    );
}

function isWindowsAbsolutePath(filePath: string) {
    return /^[A-Za-z]:[\\/]/.test(filePath) || /^\\\\/.test(filePath);
}

function isFsError(error: unknown, code: string): error is NodeJS.ErrnoException {
    return Boolean(error && typeof error === 'object' && 'code' in error && (error as NodeJS.ErrnoException).code === code);
}

function removeTreeWithoutFollowingSymlinks(
    context: RepoPathContext,
    entryPath: string,
    label: string,
    rootIdentity: ParentDirectoryIdentity,
) {
    if (!fs.existsSync(entryPath)) {
        return;
    }
    const stat = fs.lstatSync(entryPath);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not contain symlinks: ${relativeToRoot(context, entryPath)}`);
    }
    if (stat.isDirectory()) {
        const directoryIdentity = { dev: stat.dev, ino: stat.ino };
        const parentIdentity = captureContextParentDirectoryIdentity(
            context,
            path.dirname(entryPath),
            `${label} parent directory`,
        );
        for (const entry of fs.readdirSync(entryPath, { withFileTypes: true })) {
            removeTreeWithoutFollowingSymlinks(context, path.join(entryPath, entry.name), label, rootIdentity);
        }
        assertDirectoryIdentityUnchanged(fs.lstatSync(entryPath), directoryIdentity, label, relativeToRoot(context, entryPath));
        if (!parentIdentityMatches(path.dirname(entryPath), parentIdentity)) {
            throw new Error(`${label} parent changed before rmdir: ${relativeToRoot(context, entryPath)}`);
        }
        rmdirPreflightedDirectoryWithoutFollowingTargetSymlink({
            directoryPath: entryPath,
            label,
            parentIdentity,
            directoryIdentity,
            displayParent: relativeToRoot(context, path.dirname(entryPath)),
            displayTarget: relativeToRoot(context, entryPath),
            rootIdentity,
        });
        return;
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must contain only regular files/directories: ${relativeToRoot(context, entryPath)}`);
    }
    unlinkPreflightedRegularFile(
        entryPath,
        label,
        captureRegularFileIdentity(stat),
        captureContextParentDirectoryIdentity(
            context,
            path.dirname(entryPath),
            `${label} parent directory`,
        ),
        (candidate) => relativeToRoot(context, candidate),
        rootIdentity,
    );
}

export function captureParentDirectoryIdentity(directory: string): ParentDirectoryIdentity {
    const stat = fs.lstatSync(directory);
    if (stat.isSymbolicLink()) {
        throw new Error(`Parent directory must not be a symlink: ${directory}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`Parent directory must be a directory: ${directory}`);
    }
    return {
        realpath: fs.realpathSync(directory),
        dev: stat.dev,
        ino: stat.ino,
    };
}

function captureCanonicalRootIdentity(rootPath: string, label: string): ParentDirectoryIdentity {
    const resolvedRoot = path.resolve(rootPath);
    const identity = captureParentDirectoryIdentity(resolvedRoot);
    if (path.resolve(identity.realpath) !== resolvedRoot) {
        throw new Error(`${label} must be a canonical real directory: ${resolvedRoot}`);
    }
    return identity;
}

function assertPreparedRepoPathContextAuthentic(
    context: RepoPathContext | unknown,
    label: string,
): asserts context is RepoPathContext {
    if (
        !context ||
        typeof context !== 'object' ||
        !PREPARED_REPO_PATH_CONTEXTS.has(context) ||
        !Object.isFrozen(context)
    ) {
        throw new Error(`${label} must be created by createRepoPathContext and remain frozen.`);
    }
    const candidate = context as RepoPathContext;
    if (
        !candidate.rootIdentity ||
        !Object.isFrozen(candidate.rootIdentity) ||
        typeof candidate.root !== 'string' ||
        typeof candidate.lexicalRoot !== 'string' ||
        typeof candidate.pathHint !== 'string' ||
        candidate.pathHint.length === 0 ||
        path.resolve(candidate.root) !== candidate.root ||
        path.resolve(candidate.lexicalRoot) !== candidate.lexicalRoot ||
        candidate.root === path.parse(candidate.root).root ||
        candidate.rootIdentity.realpath !== candidate.root ||
        typeof candidate.rootIdentity.dev !== 'number' ||
        !Number.isSafeInteger(candidate.rootIdentity.dev) ||
        candidate.rootIdentity.dev < 0 ||
        typeof candidate.rootIdentity.ino !== 'number' ||
        !Number.isSafeInteger(candidate.rootIdentity.ino) ||
        candidate.rootIdentity.ino < 0
    ) {
        throw new Error(`${label} is not a valid frozen repo path context.`);
    }
}

function captureContextRootIdentity(context: RepoPathContext): ParentDirectoryIdentity {
    assertPreparedRepoPathContextAuthentic(context, 'repo path context');
    let current: ParentDirectoryIdentity;
    try {
        current = captureCanonicalRootIdentity(context.root, 'repo root');
    } catch {
        throw new Error(`repo root changed before guarded filesystem operation; ${context.pathHint}`);
    }
    let currentLexicalRoot: string;
    try {
        currentLexicalRoot = fs.realpathSync(context.lexicalRoot);
    } catch {
        throw new Error(`repo lexical root changed before guarded filesystem operation; ${context.pathHint}`);
    }
    if (
        context.rootIdentity.realpath !== context.root ||
        currentLexicalRoot !== context.root ||
        current.realpath !== context.rootIdentity.realpath ||
        current.dev !== context.rootIdentity.dev ||
        current.ino !== context.rootIdentity.ino
    ) {
        throw new Error(`repo root changed before guarded filesystem operation; ${context.pathHint}`);
    }
    return context.rootIdentity;
}

export function assertRepoPathContextCurrent(
    context: RepoPathContext | unknown,
    label = 'repo path context',
): asserts context is RepoPathContext {
    assertPreparedRepoPathContextAuthentic(context, label);
    captureContextRootIdentity(context);
}

function captureContextParentDirectoryIdentity(
    context: RepoPathContext,
    directory: string,
    label: string,
): ParentDirectoryIdentity {
    const resolvedDirectory = path.resolve(directory);
    assertPathInsideRoot(context, resolvedDirectory, label);
    const identity = captureParentDirectoryIdentity(resolvedDirectory);
    if (path.resolve(identity.realpath) !== resolvedDirectory) {
        throw new Error(`${label} changed outside the repo root before guarded filesystem operation.`);
    }
    assertPathInsideRoot(context, identity.realpath, label);
    return identity;
}

function createRootedDirectory(
    rootIdentity: ParentDirectoryIdentity,
    parentPath: string,
    childName: string,
    mode: number,
    label: string,
    displayPath: string,
): DirectoryIdentity {
    if (!Number.isSafeInteger(mode) || mode < 0 || mode > 0o777) {
        throw new Error(`${label} directory mode must be an integer between 0000 and 0777.`);
    }
    const canonicalParent = path.resolve(parentPath);
    if (
        !childName ||
        childName === '.' ||
        childName === '..' ||
        path.basename(childName) !== childName ||
        childName.includes('/') ||
        childName.includes('\\') ||
        childName.includes('\0')
    ) {
        throw new Error(`${label} child name must be one direct canonical path segment.`);
    }
    const parentIdentity = captureParentDirectoryIdentity(canonicalParent);
    const request = {
        root: rootIdentity,
        parentPath: canonicalParent,
        childName,
        label,
        mode,
        expectedParent: parentIdentity,
        displayPath,
    };
    try {
        const raw = executePinnedOpenatHelper('mkdir', [], {
            input: JSON.stringify(request),
            encoding: 'utf8',
        });
        const parsed: unknown = JSON.parse(raw);
        if (
            !parsed ||
            typeof parsed !== 'object' ||
            Array.isArray(parsed) ||
            Object.keys(parsed).length !== 2 ||
            !Object.prototype.hasOwnProperty.call(parsed, 'dev') ||
            !Object.prototype.hasOwnProperty.call(parsed, 'ino')
        ) {
            throw new Error(`${label} openat mkdir helper returned an invalid directory identity.`);
        }
        const identity = parsed as { dev?: unknown; ino?: unknown };
        if (
            typeof identity.dev !== 'number' ||
            !Number.isSafeInteger(identity.dev) ||
            identity.dev < 0 ||
            typeof identity.ino !== 'number' ||
            !Number.isSafeInteger(identity.ino) ||
            identity.ino < 0
        ) {
            throw new Error(`${label} openat mkdir helper returned an invalid directory identity.`);
        }
        return { dev: identity.dev, ino: identity.ino };
    } catch (error) {
        if (error && typeof error === 'object' && 'stderr' in error) {
            const stderr = Buffer.from((error as { stderr?: Buffer | string }).stderr ?? '').toString('utf8').trim();
            if (stderr) {
                throw new Error(stderr);
            }
        }
        throw error;
    }
}

export function prepareDirectMutationRoot(rootPath: string, label: string): DirectMutationRoot {
    if (typeof rootPath !== 'string' || rootPath.trim().length === 0) {
        throw new Error(`${label} must be a non-empty path.`);
    }
    const root = path.resolve(rootPath);
    if (root === path.parse(root).root) {
        throw new Error(`${label} must not be the filesystem root.`);
    }
    const identity = captureCanonicalRootIdentity(root, label);
    return Object.freeze({
        kind: DIRECT_MUTATION_ROOT_KIND,
        root,
        identity: Object.freeze({ ...identity }),
    });
}

export function prepareDirectMutationRootForTargets(targetPaths: readonly string[], label: string): DirectMutationRoot {
    if (targetPaths.length === 0) {
        throw new Error(`${label} requires at least one target path.`);
    }
    const targets = targetPaths.map((target) => path.resolve(target));
    const filesystemRoots = uniquePaths(targets.map((target) => path.parse(target).root));
    if (filesystemRoots.length !== 1) {
        throw new Error(`${label} targets must stay on one filesystem root.`);
    }
    const filesystemRoot = filesystemRoots[0];
    let candidate = path.dirname(targets[0]);
    while (!targets.every((target) => {
        const relative = path.relative(candidate, target);
        return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative));
    })) {
        const parent = path.dirname(candidate);
        if (parent === candidate) {
            break;
        }
        candidate = parent;
    }
    while (candidate !== filesystemRoot) {
        try {
            const stat = fs.lstatSync(candidate);
            if (stat.isSymbolicLink()) {
                throw new Error(`${label} must not be a symlink: ${candidate}`);
            }
            if (stat.isDirectory()) {
                return prepareDirectMutationRoot(candidate, label);
            }
        } catch (error) {
            if (!isFsError(error, 'ENOENT')) {
                throw error;
            }
        }
        candidate = path.dirname(candidate);
    }
    throw new Error(`${label} has no meaningful existing mutation root above its targets.`);
}

function validateDirectMutationRoot(mutationRoot: DirectMutationRoot, label: string): ParentDirectoryIdentity {
    if (
        !mutationRoot ||
        mutationRoot.kind !== DIRECT_MUTATION_ROOT_KIND ||
        typeof mutationRoot.root !== 'string' ||
        !mutationRoot.identity ||
        !Object.isFrozen(mutationRoot) ||
        !Object.isFrozen(mutationRoot.identity)
    ) {
        throw new Error(`${label} must be prepared with prepareDirectMutationRoot.`);
    }
    const root = path.resolve(mutationRoot.root);
    if (root !== mutationRoot.root || root === path.parse(root).root || mutationRoot.identity.realpath !== root) {
        throw new Error(`${label} is not bound to a meaningful canonical root.`);
    }
    const current = captureCanonicalRootIdentity(root, label);
    if (
        current.realpath !== mutationRoot.identity.realpath ||
        current.dev !== mutationRoot.identity.dev ||
        current.ino !== mutationRoot.identity.ino
    ) {
        throw new Error(`${label} changed before guarded filesystem operation.`);
    }
    return mutationRoot.identity;
}

export function assertDirectMutationRootCurrent(mutationRoot: DirectMutationRoot, label: string) {
    validateDirectMutationRoot(mutationRoot, label);
}

function assertPathInsideDirectMutationRoot(mutationRoot: DirectMutationRoot, candidate: string, label: string) {
    const resolved = path.resolve(candidate);
    const relative = path.relative(mutationRoot.root, resolved);
    if (relative.startsWith('..') || path.isAbsolute(relative)) {
        throw new Error(`${label} must stay within direct mutation root ${mutationRoot.root}.`);
    }
}

function assertPreparedWriteInsideDirectMutationRoot(
    mutationRoot: DirectMutationRoot,
    target: PreparedWrite,
    label: string,
) {
    const resolvedTarget = path.resolve(target.resolved);
    const resolvedParent = path.resolve(target.parent);
    if (path.dirname(resolvedTarget) !== resolvedParent) {
        throw new Error(`${label} target parent does not match its resolved path.`);
    }
    assertPathInsideDirectMutationRoot(mutationRoot, resolvedParent, `${label} parent directory`);
    assertPathInsideDirectMutationRoot(mutationRoot, resolvedTarget, label);
}

function parentIdentityMatches(directory: string, expected: ParentDirectoryIdentity) {
    let current: ParentDirectoryIdentity;
    try {
        current = captureParentDirectoryIdentity(directory);
    } catch {
        return false;
    }
    return current.realpath === expected.realpath && current.dev === expected.dev && current.ino === expected.ino;
}

export function assertParentIdentityUnchanged(
    context: RepoPathContext,
    directory: string,
    expected: ParentDirectoryIdentity,
    label: string,
) {
    if (!parentIdentityMatches(directory, expected)) {
        throw new Error(`${label} parent directory changed before write: ${relativeToRoot(context, directory)}`);
    }
}

function assertWritableParentDirectory(context: RepoPathContext, directory: string, label: string) {
    assertNoSymlinkSegments(context, directory, `${label} parent directory`);
    assertPathInsideRoot(context, directory, `${label} parent directory`);
    const stat = fs.lstatSync(directory);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} parent directory must not be a symlink: ${relativeToRoot(context, directory)}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} parent directory must be a directory: ${relativeToRoot(context, directory)}`);
    }
}

// On macOS, the first writable open of a copied/provenance-tagged file can
// change ctime without a write. Establish mutation-target identity through the
// same access mode the openat writer will use, then keep the exact timestamp
// comparison at the later mutation boundary. Read-only identities are unchanged.
function captureWritableTargetIdentity(filePath: string, initial: fs.Stats, label: string, displayPath: string): RegularFileIdentity {
    let fd: number | undefined;
    try {
        try {
            fd = fs.openSync(filePath, fs.constants.O_RDWR | NO_FOLLOW_FLAG);
        } catch (error) {
            if (isFsError(error, 'ELOOP')) throw new Error(`${label} must not be a symlink: ${displayPath}`);
            throw error;
        }
        const opened = fs.fstatSync(fd);
        if (!opened.isFile() || opened.nlink !== 1 || opened.dev !== initial.dev || opened.ino !== initial.ino ||
            opened.size !== initial.size || opened.mtimeMs !== initial.mtimeMs || opened.mode !== initial.mode ||
            opened.uid !== initial.uid || opened.gid !== initial.gid) {
            throw new Error(`${label} changed during writable target capture: ${displayPath}`);
        }
        const identity = captureRegularFileIdentity(opened);
        const linked = fs.lstatSync(filePath);
        if (linked.isSymbolicLink() || linked.nlink !== 1 || !regularFileReadIdentityMatches(linked, identity)) {
            throw new Error(`${label} changed during writable target capture: ${displayPath}`);
        }
        return identity;
    } finally {
        if (fd !== undefined) fs.closeSync(fd);
    }
}

function hashDescriptor(fd: number, size: number): string {
    const hash = createHash('sha256');
    const buffer = Buffer.allocUnsafe(64 * 1024);
    for (let offset = 0; offset < size;) {
        const count = fs.readSync(fd, buffer, 0, Math.min(buffer.length, size - offset), offset);
        if (count === 0) break;
        hash.update(buffer.subarray(0, count));
        offset += count;
    }
    return hash.digest('hex');
}

// The unlink helper needs a writable descriptor to scrub a raced hardlink. Prime the same
// macOS ctime transition as a write, while proving that the preflighted bytes did not change.
function captureUnlinkTargetIdentity(
    filePath: string,
    fd: number,
    expected: RegularFileIdentity,
    label: string,
    displayPath: string,
): RegularFileIdentity {
    const initial = fs.fstatSync(fd);
    assertRegularFileIdentityUnchanged(initial, expected, label, displayPath);
    const before = hashDescriptor(fd, initial.size);
    assertRegularFileIdentityUnchanged(fs.fstatSync(fd), expected, label, displayPath);
    let captured: RegularFileIdentity;
    try {
        captured = captureWritableTargetIdentity(filePath, initial, label, displayPath);
    } catch (error) {
        // The helper has a separately verified mode-restoration path for read-only files.
        if (!isFsError(error, 'EACCES') && !isFsError(error, 'EPERM')) throw error;
        captured = expected;
    }
    if (hashDescriptor(fd, initial.size) !== before) {
        throw new Error(`${label} changed during unlink target capture: ${displayPath}`);
    }
    assertRegularFileIdentityUnchanged(fs.fstatSync(fd), captured, label, displayPath);
    assertRegularFileIdentityUnchanged(fs.lstatSync(filePath), captured, label, displayPath);
    return captured;
}

function assertWritableFileIfExists(context: RepoPathContext, filePath: string, label: string) {
    assertNoSymlinkSegments(context, filePath, label);
    assertPathInsideRoot(context, filePath, label);
    if (!fs.existsSync(filePath)) {
        return null;
    }
    const stat = fs.lstatSync(filePath);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, filePath)}`);
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must be a regular file: ${relativeToRoot(context, filePath)}`);
    }
    if (stat.nlink > 1) {
        throw new Error(`${label} must not have hardlinks: ${relativeToRoot(context, filePath)}`);
    }
    return captureWritableTargetIdentity(filePath, stat, label, relativeToRoot(context, filePath));
}

function prepareFileWritePrecondition(
    context: RepoPathContext,
    precondition: PreparedFileWritePrecondition,
): OpenatPreparedPrecondition {
    assertNoSymlinkSegments(context, precondition.resolved, precondition.label);
    assertPathInsideRoot(context, precondition.resolved, precondition.label);
    if (
        precondition.bytes !== undefined &&
        (!Number.isSafeInteger(precondition.bytes) || precondition.bytes < 0)
    ) {
        throw new Error(`${precondition.label} byte precondition must be a non-negative safe integer.`);
    }
    if (
        precondition.sha256 !== undefined &&
        (typeof precondition.sha256 !== 'string' || !/^[0-9a-f]{64}$/.test(precondition.sha256))
    ) {
        throw new Error(`${precondition.label} sha256 precondition must be a lowercase 64-character hex string.`);
    }
    if (
        precondition.expectedMode !== undefined &&
        (!Number.isSafeInteger(precondition.expectedMode) || precondition.expectedMode < 0 || precondition.expectedMode > 0o777)
    ) {
        throw new Error(`${precondition.label} expected mode must be an integer between 0000 and 0777.`);
    }
    if (
        precondition.expectedUid !== undefined &&
        (!Number.isSafeInteger(precondition.expectedUid) || precondition.expectedUid < 0)
    ) {
        throw new Error(`${precondition.label} expected UID must be a non-negative safe integer.`);
    }
    if (!fs.existsSync(precondition.resolved)) {
        throw new Error(`${precondition.label} not found: ${relativeToRoot(context, precondition.resolved)}`);
    }
    const stat = fs.lstatSync(precondition.resolved);
    if (stat.isSymbolicLink()) {
        throw new Error(`${precondition.label} must not be a symlink: ${relativeToRoot(context, precondition.resolved)}`);
    }
    if (!stat.isFile()) {
        throw new Error(`${precondition.label} must be a regular file: ${relativeToRoot(context, precondition.resolved)}`);
    }
    if (stat.nlink > 1) {
        throw new Error(`${precondition.label} must not have hardlinks: ${relativeToRoot(context, precondition.resolved)}`);
    }
    if (
        precondition.expectedMode !== undefined &&
        (stat.mode & 0o777) !== precondition.expectedMode
    ) {
        throw new Error(
            `${precondition.label} mode must be ${precondition.expectedMode.toString(8).padStart(4, '0')}: ${relativeToRoot(context, precondition.resolved)}`,
        );
    }
    if (precondition.expectedUid !== undefined && stat.uid !== precondition.expectedUid) {
        throw new Error(
            `${precondition.label} owner UID must be ${precondition.expectedUid}: ${relativeToRoot(context, precondition.resolved)}`,
        );
    }
    const parent = path.dirname(precondition.resolved);
    const parentIdentity = captureContextParentDirectoryIdentity(
        context,
        parent,
        `${precondition.label} parent directory`,
    );
    return {
        resolved: precondition.resolved,
        label: precondition.label,
        parentIdentity,
        targetIdentity: captureRegularFileIdentity(stat),
        expectedBytes: precondition.bytes,
        expectedSha256: precondition.sha256,
        expectedMode: precondition.expectedMode,
        expectedUid: precondition.expectedUid,
        displayParent: relativeToRoot(context, parent),
        displayTarget: relativeToRoot(context, precondition.resolved),
    };
}

function assertWritePreconditionsDoNotOverlapTargets(
    preparedWrites: Array<{ label: string; target: PreparedWrite; targetIdentity: RegularFileIdentity | null }>,
    preconditions: OpenatPreparedPrecondition[],
) {
    const writePaths = new Map<string, string>();
    const writeIdentities = new Map<string, string>();
    for (const write of preparedWrites) {
        writePaths.set(write.target.resolved, write.label);
        if (write.targetIdentity !== null) {
            writeIdentities.set(`${write.targetIdentity.dev}:${write.targetIdentity.ino}`, write.label);
        }
    }
    for (const precondition of preconditions) {
        const pathCollision = writePaths.get(precondition.resolved);
        if (pathCollision) {
            throw new Error(`${precondition.label} precondition must not target output ${pathCollision}.`);
        }
        const identityCollision = writeIdentities.get(`${precondition.targetIdentity.dev}:${precondition.targetIdentity.ino}`);
        if (identityCollision) {
            throw new Error(`${precondition.label} precondition must not target output ${identityCollision}.`);
        }
    }
}

function assertDirectorySegment(context: RepoPathContext, directory: string, label: string) {
    const stat = fs.lstatSync(directory);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not contain symlink path segments; ${context.pathHint}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} parent path segment must be a directory: ${relativeToRoot(context, directory)}`);
    }
}

export function ensureDirectoryWithoutSymlinkSegments(context: RepoPathContext, directory: string, label: string) {
    const rootIdentity = captureContextRootIdentity(context);
    const resolvedDirectory = path.resolve(directory);
    assertPathInsideRoot(context, resolvedDirectory, label);
    const relativePath = path.relative(context.root, resolvedDirectory);
    if (relativePath === '') {
        assertDirectorySegment(context, context.root, label);
        return;
    }
    if (relativePath.startsWith('..') || path.isAbsolute(relativePath)) {
        throw new Error(`${label} must stay within the repo root; ${context.pathHint}`);
    }

    let current = context.root;
    for (const segment of relativePath.split(path.sep)) {
        current = path.join(current, segment);
        try {
            assertDirectorySegment(context, current, label);
            continue;
        } catch (error) {
            if (!isFsError(error, 'ENOENT')) {
                throw error;
            }
        }

        try {
            createRootedDirectory(
                rootIdentity,
                path.dirname(current),
                path.basename(current),
                0o755,
                label,
                relativeToRoot(context, current),
            );
        } catch (error) {
            if (!(error instanceof Error) || !error.message.includes('is create-once and already exists:')) {
                throw error;
            }
        }
        assertDirectorySegment(context, current, label);
    }
    captureContextRootIdentity(context);
}

function assertDirectWritableParentDirectory(directory: string, label: string) {
    const stat = fs.lstatSync(directory);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} parent directory must not be a symlink: ${directory}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} parent directory must be a directory: ${directory}`);
    }
}

function assertDirectDirectorySegment(directory: string, label: string) {
    const stat = fs.lstatSync(directory);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not contain symlink path segments: ${directory}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} parent path segment must be a directory: ${directory}`);
    }
}

export function ensureDirectoryWithoutSymlinkSegmentsDirect(
    mutationRoot: DirectMutationRoot,
    directory: string,
    label: string,
    mode = 0o755,
) {
    if (!Number.isSafeInteger(mode) || mode < 0 || mode > 0o777) {
        throw new Error(`${label} mode must be an integer between 0000 and 0777.`);
    }
    const rootIdentity = validateDirectMutationRoot(mutationRoot, `${label} direct mkdir root`);
    const resolvedDirectory = path.resolve(directory);
    assertPathInsideDirectMutationRoot(mutationRoot, resolvedDirectory, label);
    const relativePath = path.relative(mutationRoot.root, resolvedDirectory);
    let current = mutationRoot.root;
    if (relativePath === '') {
        assertDirectDirectorySegment(current, label);
        return;
    }

    for (const segment of relativePath.split(path.sep)) {
        current = path.join(current, segment);
        try {
            assertDirectDirectorySegment(current, label);
            continue;
        } catch (error) {
            if (!isFsError(error, 'ENOENT')) {
                throw error;
            }
        }

        try {
            createRootedDirectory(
                rootIdentity,
                path.dirname(current),
                path.basename(current),
                mode,
                label,
                current,
            );
        } catch (error) {
            if (!(error instanceof Error) || !error.message.includes('is create-once and already exists:')) {
                throw error;
            }
        }
        assertDirectDirectorySegment(current, label);
    }
    validateDirectMutationRoot(mutationRoot, `${label} direct mkdir root`);
}

export function createDirectoryWithoutFollowingSymlinksDirect(
    mutationRoot: DirectMutationRoot,
    directory: string,
    mode: number,
    label: string,
) {
    if (!Number.isSafeInteger(mode) || mode < 0 || mode > 0o777) {
        throw new Error(`${label} mode must be an integer between 0000 and 0777.`);
    }
    const rootIdentity = validateDirectMutationRoot(mutationRoot, `${label} direct mkdir root`);
    const resolved = path.resolve(directory);
    assertPathInsideDirectMutationRoot(mutationRoot, resolved, label);
    const parent = path.dirname(resolved);
    assertPathInsideDirectMutationRoot(mutationRoot, parent, `${label} parent`);
    assertDirectWritableParentDirectory(parent, label);
    if (fs.existsSync(resolved)) {
        throw createFsError('EEXIST', `${label} is create-once and already exists: ${resolved}`);
    }
    const createdIdentity = createRootedDirectory(
        rootIdentity,
        parent,
        path.basename(resolved),
        mode,
        label,
        resolved,
    );
    const created = fs.lstatSync(resolved);
    if (
        created.isSymbolicLink() ||
        !created.isDirectory() ||
        created.dev !== createdIdentity.dev ||
        created.ino !== createdIdentity.ino ||
        (created.mode & 0o777) !== mode
    ) {
        throw new Error(`${label} changed after guarded creation: ${resolved}`);
    }
    validateDirectMutationRoot(mutationRoot, `${label} direct mkdir root`);
    return Object.freeze({ ...createdIdentity });
}

export function setDirectoryModeWithoutFollowingSymlinksDirect(
    mutationRoot: DirectMutationRoot,
    directory: string,
    mode: number,
    label: string,
    expectedTargetIdentity?: Readonly<DirectoryIdentity>,
    expectedParentIdentity?: Readonly<ParentDirectoryIdentity>,
    expectedCurrentMode?: number,
) {
    if (!Number.isSafeInteger(mode) || mode < 0 || mode > 0o777) {
        throw new Error(`${label} mode must be an integer between 0000 and 0777.`);
    }
    if (
        expectedCurrentMode !== undefined &&
        (!Number.isSafeInteger(expectedCurrentMode) ||
            expectedCurrentMode < 0 ||
            expectedCurrentMode > 0o777)
    ) {
        throw new Error(`${label} expected current mode must be an integer between 0000 and 0777.`);
    }
    const rootIdentity = validateDirectMutationRoot(mutationRoot, `${label} direct chmod root`);
    const resolved = path.resolve(directory);
    assertPathInsideDirectMutationRoot(mutationRoot, resolved, label);
    const stat = fs.lstatSync(resolved);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${resolved}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} must be a directory: ${resolved}`);
    }
    const targetIdentity = expectedTargetIdentity ?? { dev: stat.dev, ino: stat.ino };
    if (stat.dev !== targetIdentity.dev || stat.ino !== targetIdentity.ino) {
        throw new Error(`${label} directory identity changed before guarded mode update: ${resolved}`);
    }
    if (
        expectedCurrentMode !== undefined &&
        (stat.mode & 0o7777) !== expectedCurrentMode
    ) {
        throw new Error(`${label} current mode changed before guarded mode update: ${resolved}`);
    }
    const parent = path.dirname(resolved);
    const currentParentIdentity = captureParentDirectoryIdentity(parent);
    const parentIdentity = expectedParentIdentity ?? currentParentIdentity;
    if (
        currentParentIdentity.realpath !== parentIdentity.realpath ||
        currentParentIdentity.dev !== parentIdentity.dev ||
        currentParentIdentity.ino !== parentIdentity.ino
    ) {
        throw new Error(`${label} parent directory identity changed before guarded mode update: ${parent}`);
    }
    const request = {
        root: rootIdentity,
        parentPath: parent,
        childName: path.basename(resolved),
        label,
        mode,
        expectedParent: parentIdentity,
        expectedTarget: targetIdentity,
        ...(expectedCurrentMode === undefined ? {} : { expectedCurrentMode }),
        displayPath: resolved,
    };
    try {
        const raw = executePinnedOpenatHelper('mkdir', ['--chmod-existing'], {
            input: JSON.stringify(request),
            encoding: 'utf8',
        });
        const parsed: unknown = JSON.parse(raw);
        if (
            !parsed ||
            typeof parsed !== 'object' ||
            Array.isArray(parsed) ||
            Object.keys(parsed).length !== 2 ||
            !Object.prototype.hasOwnProperty.call(parsed, 'dev') ||
            !Object.prototype.hasOwnProperty.call(parsed, 'ino')
        ) {
            throw new Error(`${label} openat chmod helper returned an invalid directory identity.`);
        }
        const identity = parsed as { dev?: unknown; ino?: unknown };
        if (identity.dev !== targetIdentity.dev || identity.ino !== targetIdentity.ino) {
            throw new Error(`${label} openat chmod helper returned a changed directory identity.`);
        }
    } catch (error) {
        if (error && typeof error === 'object' && 'stderr' in error) {
            const stderr = Buffer.from((error as { stderr?: Buffer | string }).stderr ?? '').toString('utf8').trim();
            if (stderr.length > 0) {
                throw new Error(stderr);
            }
        }
        throw error;
    }
    const finalStat = fs.lstatSync(resolved);
    if (
        finalStat.isSymbolicLink() ||
        !finalStat.isDirectory() ||
        finalStat.dev !== targetIdentity.dev ||
        finalStat.ino !== targetIdentity.ino ||
        (finalStat.mode & 0o7777) !== mode
    ) {
        throw new Error(`${label} changed after guarded mode restoration: ${resolved}`);
    }
    validateDirectMutationRoot(mutationRoot, `${label} direct chmod root`);
}

export function removeEmptyDirectoryWithoutFollowingSymlinks(
    context: RepoPathContext,
    directory: string,
    label: string,
) {
    const rootIdentity = captureContextRootIdentity(context);
    const resolved = resolveRepoPath(context, directory, label);
    let stat: fs.Stats;
    try {
        stat = fs.lstatSync(resolved);
    } catch (error) {
        if (isFsError(error, 'ENOENT')) {
            return;
        }
        throw error;
    }
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${relativeToRoot(context, resolved)}`);
    }
    if (!stat.isDirectory()) {
        throw new Error(`${label} must be a directory: ${relativeToRoot(context, resolved)}`);
    }
    if (fs.readdirSync(resolved).length !== 0) {
        throw new Error(`${label} must be empty before restoration: ${relativeToRoot(context, resolved)}`);
    }
    const directoryIdentity = { dev: stat.dev, ino: stat.ino };
    const parentIdentity = captureContextParentDirectoryIdentity(
        context,
        path.dirname(resolved),
        `${label} parent directory`,
    );
    assertDirectoryIdentityUnchanged(
        fs.lstatSync(resolved),
        directoryIdentity,
        label,
        relativeToRoot(context, resolved),
    );
    if (!parentIdentityMatches(path.dirname(resolved), parentIdentity)) {
        throw new Error(`${label} parent changed before rmdir: ${relativeToRoot(context, resolved)}`);
    }
    rmdirPreflightedDirectoryWithoutFollowingTargetSymlink({
        directoryPath: resolved,
        label,
        parentIdentity,
        directoryIdentity,
        displayParent: relativeToRoot(context, path.dirname(resolved)),
        displayTarget: relativeToRoot(context, resolved),
        rootIdentity,
    });
}

export function createTemporaryDirectoryWithoutFollowingSymlinksDirect(
    mutationRoot: DirectMutationRoot,
    parentDirectory: string,
    prefix: string,
    label: string,
) {
    const rootIdentity = validateDirectMutationRoot(mutationRoot, `${label} direct temporary-directory root`);
    const parent = path.resolve(parentDirectory);
    assertPathInsideDirectMutationRoot(mutationRoot, parent, `${label} parent directory`);
    if (
        typeof prefix !== 'string' ||
        prefix.length === 0 ||
        prefix === '.' ||
        prefix === '..' ||
        prefix.includes('/') ||
        prefix.includes('\\') ||
        prefix.includes('\0')
    ) {
        throw new Error(`${label} prefix must be a non-empty direct path segment prefix.`);
    }
    ensureDirectoryWithoutSymlinkSegmentsDirect(mutationRoot, parent, `${label} parent directory`);
    assertDirectWritableParentDirectory(parent, label);

    for (let attempt = 0; attempt < 32; attempt += 1) {
        const childName = `${prefix}${randomBytes(16).toString('hex')}`;
        const tempDirectory = path.join(parent, childName);
        try {
            createRootedDirectory(rootIdentity, parent, childName, 0o700, label, tempDirectory);
            validateDirectMutationRoot(mutationRoot, `${label} direct temporary-directory root`);
            return tempDirectory;
        } catch (error) {
            if (error instanceof Error && error.message.includes('is create-once and already exists:')) {
                continue;
            }
            throw error;
        }
    }
    throw new Error(`${label} could not allocate a unique rooted temporary directory.`);
}

function assertDirectWritableFileIfExists(filePath: string, label: string) {
    if (!fs.existsSync(filePath)) {
        return null;
    }
    const stat = fs.lstatSync(filePath);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not be a symlink: ${filePath}`);
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must be a regular file: ${filePath}`);
    }
    if (stat.nlink > 1) {
        throw new Error(`${label} must not have hardlinks: ${filePath}`);
    }
    return captureWritableTargetIdentity(filePath, stat, label, filePath);
}

function assertDirectoryTreeContainsOnlyRegularEntries(
    context: RepoPathContext,
    entryPath: string,
    label: string,
) {
    const stat = fs.lstatSync(entryPath);
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not contain symlinks: ${relativeToRoot(context, entryPath)}`);
    }
    if (stat.isDirectory()) {
        for (const entry of fs.readdirSync(entryPath, { withFileTypes: true })) {
            assertDirectoryTreeContainsOnlyRegularEntries(context, path.join(entryPath, entry.name), label);
        }
        return;
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must contain only regular files and directories: ${relativeToRoot(context, entryPath)}`);
    }
    if (stat.nlink > 1) {
        throw new Error(`${label} must not contain hardlinks: ${relativeToRoot(context, entryPath)}`);
    }
}

function assertDirectDirectoryTreeContainsOnlyRegularEntries(entryPath: string, label: string) {
    let stat: fs.Stats;
    try {
        stat = fs.lstatSync(entryPath);
    } catch (error) {
        if (isFsError(error, 'ENOENT')) {
            return;
        }
        throw error;
    }
    if (stat.isSymbolicLink()) {
        throw new Error(`${label} must not contain symlinks: ${entryPath}`);
    }
    if (stat.isDirectory()) {
        for (const entry of fs.readdirSync(entryPath, { withFileTypes: true })) {
            assertDirectDirectoryTreeContainsOnlyRegularEntries(path.join(entryPath, entry.name), label);
        }
        return;
    }
    if (!stat.isFile()) {
        throw new Error(`${label} must contain only regular files and directories: ${entryPath}`);
    }
    if (stat.nlink > 1) {
        throw new Error(`${label} must not contain hardlinks: ${entryPath}`);
    }
}

function uniquePaths(paths: string[]) {
    return Array.from(new Set(paths));
}

function assertPathInsideRoot(context: RepoPathContext, candidate: string, label: string) {
    const relativePath = path.relative(context.root, candidate);
    if (relativePath.startsWith('..') || path.isAbsolute(relativePath)) {
        throw new Error(`${label} must stay within the repo root; ${context.pathHint}`);
    }
}

function assertNoSymlinkSegments(context: RepoPathContext, candidate: string, label: string) {
    for (const root of uniquePaths([context.lexicalRoot, context.root])) {
        const relativePath = path.relative(root, candidate);
        if (!relativePath || relativePath.startsWith('..') || path.isAbsolute(relativePath)) {
            continue;
        }
        let current = root;
        const segments = relativePath.split(path.sep);
        for (let index = 0; index < segments.length; index += 1) {
            const segment = segments[index];
            current = path.join(current, segment);
            try {
                const stat = fs.lstatSync(current);
                if (stat.isSymbolicLink()) {
                    throw new Error(`${label} must not contain symlink path segments; ${context.pathHint}`);
                }
                if (index < segments.length - 1 && !stat.isDirectory()) {
                    throw new Error(
                        `${label} parent path segment must be a directory: ${relativeToRoot(context, current)}`,
                    );
                }
            } catch (error) {
                if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT') {
                    continue;
                }
                if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOTDIR') {
                    throw new Error(`${label} parent path segment must be a directory; ${context.pathHint}`);
                }
                throw error;
            }
        }
        return;
    }
    if (fs.existsSync(candidate) && fs.lstatSync(candidate).isSymbolicLink()) {
        throw new Error(`${label} must not contain symlink path segments; ${context.pathHint}`);
    }
}

function resolveThroughExistingParent(candidate: string) {
    const suffix: string[] = [];
    let current = candidate;
    while (!fs.existsSync(current)) {
        const parent = path.dirname(current);
        if (parent === current) {
            return candidate;
        }
        suffix.unshift(path.basename(current));
        current = parent;
    }
    return path.join(fs.realpathSync(current), ...suffix);
}
