import fs from 'fs';
import path from 'path';
import {
    createRepoPathContext,
    prepareRegularFileRead,
    prepareWritableFile,
    readPreparedTextFile,
    relativeToRoot,
    removeFileWithoutFollowingSymlinks,
    resolveRepoPath,
    writePreparedFilesWithoutFollowingTargetSymlinks,
    type RepoPathContext,
} from '../utils/repoPathGuards';
import { assertNoDuplicateJsonObjectKeys } from '../utils/jsonEvidence';
import compiler from '../build/compiler.json';

export const ORIGINS = ['tep74', 'tep89', 'jetton-v2.1', 'stablecoin'] as const;

export type OpEntry = {
    tag: string; // 0x and 8 lowercase hex digits
    group?: string; // rendered into @gen/op/<group> unless `allow` is present
    ascii?: string; // the four bytes of a house tag
    struct?: string; // the one Tolk struct that may carry the tag as its prefix
    allow?: string[]; // non-empty: rendered alone into @gen/op/restricted_<name>; empty: TypeScript only
    origin?: (typeof ORIGINS)[number]; // an external tag; house tags have none
    legacy?: true; // the same message, layout unchanged, as a tag of the old system
};

export type Registry = {
    reserved: string[]; // literals that may appear anywhere and can never be tags
    constants: Record<string, string>; // the same, with what the value means
    ops: Record<string, OpEntry>;
    held: Record<string, OpEntry>; // allocated to a named row that no build registers yet
    legacy: Record<string, Record<string, string>>; // module path -> OP_NAME -> value, until the module moves to `ops`
    retired: Record<string, string>; // 32-bit value of the old system -> its name, or the file that wrote it bare; never a tag again
};

const ROOT = path.resolve(__dirname, '../..');
const PATH_HINT = 'keep opcode generator inputs and generated outputs inside the checkout with no symlinked path segments.';
const ENTRY_FIELDS = ['tag', 'group', 'ascii', 'struct', 'allow', 'origin', 'legacy'];
const TAG = /^0x[0-9a-f]{8}$/;
const NAME = /^[a-z][a-z0-9_]*$/;
// No underscore, so a group include can never be taken for a restricted_<name> include.
const GROUP = /^[a-z][a-z0-9]*$/;
const STRUCT = /^[A-Z][A-Za-z0-9]*$/;
// A path becomes an output location: no empty, dot or traversal segment.
const SOURCE = /^contracts(?:\/[A-Za-z0-9_][A-Za-z0-9_.-]*)+\.tolk$/;
const LEGACY_NAME = /^OP_[A-Z0-9_]+$/;
const LEGACY_VALUE = /^(?:0x[0-9a-fA-F]+|\d+)$/;

function fail(message: string): never {
    throw new Error(`[generate:opcodes] ${message}`);
}

function matches(value: unknown, pattern: RegExp): value is string {
    return typeof value === 'string' && pattern.test(value);
}

function record(value: unknown, label: string): Record<string, unknown> {
    if (!value || typeof value !== 'object' || Array.isArray(value)) fail(`${label} must be a JSON object`);
    return value as Record<string, unknown>;
}

function parseFile(raw: string, file: string, schema: string, keys: string[]): Record<string, unknown> {
    // JSON.parse keeps the last of two equal keys, which would hide a second definition of a name.
    assertNoDuplicateJsonObjectKeys(raw, file);
    const json = record(JSON.parse(raw), file);
    if (json.schema !== schema) fail(`${file} must declare the schema ${schema}`);
    if (Object.keys(json).sort().join() !== ['schema', ...keys].sort().join()) fail(`${file} must hold exactly the keys schema, ${keys.join(', ')}`);
    for (const key of keys) if (key !== 'reserved') record(json[key], `${file} ${key}`);
    return json;
}

/** Parses both registry files and refuses a registry that breaks a rule of the tag space. */
export function parseRegistry(raw: string, rawRetired: string): Registry {
    const json = parseFile(raw, 'config/opcodes.json', 'tonswap-opcodes-v2', ['reserved', 'constants', 'ops', 'held', 'legacy']);
    const retired = parseFile(rawRetired, 'config/opcodes.retired.json', 'tonswap-opcodes-retired-v1', ['retired']).retired;
    if (!Array.isArray(json.reserved)) fail('config/opcodes.json reserved must be an array');
    const { schema: _schema, ...sections } = json;
    const registry = { ...sections, retired } as unknown as Registry;

    // Every value that is spoken for, with its owner: a tag has one name and one meaning.
    const taken = new Map<bigint, string>();
    const claim = (tag: unknown, owner: string) => {
        if (!matches(tag, TAG)) fail(`${owner}: a tag is 0x and 8 lowercase hex digits, got ${String(tag)}`);
        const other = taken.get(BigInt(tag));
        if (other !== undefined) fail(`${owner}: ${tag} is already ${other}`);
        taken.set(BigInt(tag), owner);
    };
    for (const tag of registry.reserved) claim(tag, 'a reserved value');
    for (const [tag, meaning] of Object.entries(registry.constants)) claim(tag, `the constant "${String(meaning)}"`);
    for (const [tag, name] of Object.entries(registry.retired)) claim(tag, `the retired tag ${String(name)}`);

    const retiredValues = new Set(Object.keys(registry.retired).map(BigInt));
    const legacyNames = new Map<bigint, string>();
    for (const [module, opcodes] of Object.entries(registry.legacy)) {
        if (!SOURCE.test(module)) fail(`a legacy module path must be a clean contracts/**/*.tolk path: ${module}`);
        for (const [name, value] of Object.entries(record(opcodes, `legacy ${module}`))) {
            if (!LEGACY_NAME.test(name)) fail(`invalid opcode name in ${module}: ${name}`);
            if (!matches(value, LEGACY_VALUE)) fail(`invalid opcode value for ${module}.${name}: ${String(value)}`);
            // A retired tag has no user left; a legacy section is a user.
            if (retiredValues.has(BigInt(value))) fail(`${module}.${name}: ${value} is retired`);
            legacyNames.set(BigInt(value), name);
        }
    }

    const names = new Set<string>();
    const structs = new Set<string>();
    // Held rows first, so a registered entry that takes a held value is the one reported.
    for (const section of ['held', 'ops'] as const) {
        for (const [name, value] of Object.entries(registry[section])) {
            const at = `${section}.${name}`;
            const entry = record(value, at) as OpEntry;
            if (!NAME.test(name)) fail(`${at}: a name is lower snake case`);
            if (names.has(name)) fail(`${at}: the name is defined twice`);
            names.add(name);
            const unknown = Object.keys(entry).filter((field) => !ENTRY_FIELDS.includes(field));
            if (unknown.length > 0) fail(`${at}: unknown field ${unknown.join(', ')}`);
            claim(entry.tag, at);
            const legacyName = legacyNames.get(BigInt(entry.tag));
            if (entry.legacy !== undefined && entry.legacy !== true) fail(`${at}: legacy is true or absent`);
            if (legacyName !== undefined && !(section === 'ops' && entry.legacy)) {
                fail(`${at}: ${entry.tag} is the legacy tag ${legacyName}; only the same message with an unchanged layout keeps it ("legacy": true)`);
            }
            if (entry.origin !== undefined && !ORIGINS.includes(entry.origin)) fail(`${at}: unknown origin ${String(entry.origin)}`);
            if (entry.origin === undefined && entry.ascii === undefined) fail(`${at}: a house tag spells four ASCII bytes`);
            if (entry.ascii !== undefined && entry.ascii !== Buffer.from(entry.tag.slice(2), 'hex').toString('latin1')) {
                fail(`${at}: ascii ${String(entry.ascii)} is not the four bytes of ${entry.tag}`);
            }
            if (entry.group !== undefined && !matches(entry.group, GROUP)) fail(`${at}: invalid group ${String(entry.group)}`);
            if (entry.struct !== undefined) {
                if (!matches(entry.struct, STRUCT)) fail(`${at}: invalid struct name ${String(entry.struct)}`);
                if (structs.has(entry.struct)) fail(`${at}: the struct ${entry.struct} already carries another tag`);
                structs.add(entry.struct);
            }
            if (entry.allow !== undefined) {
                const allow: unknown[] = Array.isArray(entry.allow) ? entry.allow : fail(`${at}: allow must be an array`);
                if (new Set(allow).size !== allow.length || !allow.every((file) => matches(file, SOURCE))) {
                    fail(`${at}: allow lists distinct clean contracts/**/*.tolk paths`);
                }
            } else if (entry.group === undefined) {
                fail(`${at}: an entry needs a group or an allow list`);
            }
        }
    }
    return registry;
}

function readInput(context: RepoPathContext, file: string): string {
    const label = `opcode registry input ${file}`;
    return readPreparedTextFile(context, prepareRegularFileRead(context, file, label), label);
}

function readRegistry(context: RepoPathContext): Registry {
    return parseRegistry(readInput(context, 'config/opcodes.json'), readInput(context, 'config/opcodes.retired.json'));
}

export function loadRegistry(root: string = ROOT): Registry {
    return readRegistry(createRepoPathContext({ rootPath: root, pathHint: PATH_HINT }));
}

function uppercaseHex(value: string): string {
    return value.startsWith('0x') ? `0x${value.slice(2).toUpperCase()}` : value.toUpperCase();
}

function renderInclude(constants: string[], tolkVersion: string): string {
    return `${[`tolk ${tolkVersion}`, '', '// Auto-generated. Do not edit manually.', ...constants, ''].join('\n')}\n`;
}

/**
 * Every generated Tolk include by repo-relative path: one per legacy module at the path its importers
 * use today, one per group, and one per restricted entry.
 */
export function renderIncludes(registry: Registry, tolkVersion: string = compiler.version): Record<string, string> {
    const sources: Record<string, string> = {};
    for (const [module, opcodes] of Object.entries(registry.legacy)) {
        const { dir, name } = path.posix.parse(module.slice('contracts/'.length));
        const constants = Object.keys(opcodes).sort().map((opcode) => `const ${opcode}: int = ${uppercaseHex(opcodes[opcode])};`);
        sources[path.posix.join('contracts/generated/opcodes', dir, `${name}_opcodes.tolk`)] = renderInclude(constants, tolkVersion);
    }
    const groups = new Map<string, string[]>();
    for (const [name, entry] of Object.entries(registry.ops)) {
        const constant = `const OP_${name.toUpperCase()}: int = ${entry.tag};`;
        if (entry.allow === undefined) {
            groups.set(entry.group!, [...(groups.get(entry.group!) ?? []), constant]);
        } else if (entry.allow.length > 0) {
            // Tolk rejects a constant reached through a transitive import, so the import line is the gate.
            sources[`contracts/generated/op/restricted_${name}.tolk`] = renderInclude([constant], tolkVersion);
        }
    }
    for (const [group, constants] of groups) sources[`contracts/generated/op/${group}.tolk`] = renderInclude(constants.sort(), tolkVersion);
    return sources;
}

/** The includes of the registry under `root`. The build serves this map in memory and never reads the generated files. */
export function opcodeSources(root: string, tolkVersion: string): Record<string, string> {
    return renderIncludes(loadRegistry(root), tolkVersion);
}

/** `OP.<NAME>` for every registry entry, after the legacy exports that unmigrated wrappers still import. */
export function renderTypescript(registry: Registry): string {
    // One symbol cannot carry two values: a legacy name that differs between modules exists in its Tolk includes only.
    const values = new Map<string, Set<string>>();
    for (const opcodes of Object.values(registry.legacy)) {
        for (const [name, value] of Object.entries(opcodes)) values.set(name, (values.get(name) ?? new Set<string>()).add(uppercaseHex(value)));
    }
    const legacy = [...values].filter(([, seen]) => seen.size === 1).map(([name, seen]) => [name, [...seen][0]]);
    legacy.sort(([a], [b]) => a.localeCompare(b));
    const ops = Object.entries(registry.ops).map(([name, entry]) => `    ${name.toUpperCase()}: ${entry.tag},`);
    return `${[
        '// Auto-generated by scripts/codegen/generate_opcodes.ts. Do not edit manually.',
        '',
        'export const OPCODES = {',
        ...legacy.map(([name, value]) => `    ${name}: ${value},`),
        '} as const;',
        '',
        'export type OpcodeName = keyof typeof OPCODES;',
        '',
        'export const {',
        ...legacy.map(([name], index) => `    ${name}${index === legacy.length - 1 ? '' : ','}`),
        '} = OPCODES;',
        '',
        'export const OP = {',
        ...ops.sort(),
        '} as const;',
        '',
        'export type OpName = keyof typeof OP;',
    ].join('\n')}\n`;
}

// Regular files under a generated root that this run does not write. A symlink stops the run before anything is removed.
function staleFiles(context: RepoPathContext, directory: string, expected: Set<string>): string[] {
    if (!fs.existsSync(directory)) return [];
    return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
        const file = path.join(directory, entry.name);
        if (entry.isDirectory()) return staleFiles(context, file, expected);
        if (!entry.isFile()) fail(`a generated opcode root holds only regular files and directories: ${relativeToRoot(context, file)}`);
        return expected.has(file) ? [] : [file];
    });
}

export function generateOpcodes(root: string = ROOT): void {
    const context = createRepoPathContext({ rootPath: root, pathHint: PATH_HINT });
    const registry = readRegistry(context);
    const outputs = { ...renderIncludes(registry), 'wrappers/generated/opcodes.ts': renderTypescript(registry) };
    // Every output is resolved before the first write, so a refused path leaves the tree as it was.
    const writes = Object.entries(outputs).map(([file, contents]) => {
        const label = `generated opcode output ${file}`;
        return { target: prepareWritableFile(context, file, label), contents, label };
    });
    const expected = new Set(writes.map((write) => write.target.resolved));
    const stale = ['contracts/generated/opcodes', 'contracts/generated/op'].flatMap((directory) =>
        staleFiles(context, resolveRepoPath(context, directory, 'generated opcode include root'), expected));
    for (const file of stale) removeFileWithoutFollowingSymlinks(context, file, 'stale generated opcode include');
    writePreparedFilesWithoutFollowingTargetSymlinks(context, writes);
}

if (require.main === module) generateOpcodes();
