export class DuplicateJsonObjectKeyError extends Error {}

export function assertNoDuplicateJsonObjectKeys(raw: string, label: string) {
    let index = 0;

    const syntaxError = (message: string): never => {
        throw new SyntaxError(`${message} at offset ${index}`);
    };
    const skipWhitespace = () => {
        while (index < raw.length && /[\t\n\r ]/.test(raw[index])) {
            index += 1;
        }
    };
    const expectChar = (expected: string) => {
        if (raw[index] !== expected) {
            syntaxError(`expected ${expected}`);
        }
        index += 1;
    };
    const readHexCodeUnit = () => {
        if (index + 4 > raw.length) {
            syntaxError('truncated unicode escape');
        }
        const encoded = raw.slice(index, index + 4);
        if (!/^[0-9a-fA-F]{4}$/.test(encoded)) {
            syntaxError('invalid unicode escape');
        }
        index += 4;
        return String.fromCharCode(Number.parseInt(encoded, 16));
    };
    const parseString = (): string => {
        expectChar('"');
        let value = '';
        while (index < raw.length) {
            const character = raw[index];
            const code = raw.charCodeAt(index);
            index += 1;
            if (character === '"') {
                return value;
            }
            if (code < 0x20) {
                syntaxError('unescaped control character in string');
            }
            if (character !== '\\') {
                value += character;
                continue;
            }
            if (index >= raw.length) {
                syntaxError('unterminated escape sequence');
            }
            const escape = raw[index];
            index += 1;
            switch (escape) {
                case '"':
                case '\\':
                case '/':
                    value += escape;
                    break;
                case 'b':
                    value += '\b';
                    break;
                case 'f':
                    value += '\f';
                    break;
                case 'n':
                    value += '\n';
                    break;
                case 'r':
                    value += '\r';
                    break;
                case 't':
                    value += '\t';
                    break;
                case 'u':
                    value += readHexCodeUnit();
                    break;
                default:
                    syntaxError('invalid escape sequence');
            }
        }
        return syntaxError('unterminated string');
    };
    const parseNumber = () => {
        if (raw[index] === '-') {
            index += 1;
        }
        if (raw[index] === '0') {
            index += 1;
        } else if (/[1-9]/.test(raw[index] ?? '')) {
            while (/[0-9]/.test(raw[index] ?? '')) {
                index += 1;
            }
        } else {
            syntaxError('invalid number');
        }
        if (raw[index] === '.') {
            index += 1;
            if (!/[0-9]/.test(raw[index] ?? '')) {
                syntaxError('invalid number fraction');
            }
            while (/[0-9]/.test(raw[index] ?? '')) {
                index += 1;
            }
        }
        if (raw[index] === 'e' || raw[index] === 'E') {
            index += 1;
            if (raw[index] === '+' || raw[index] === '-') {
                index += 1;
            }
            if (!/[0-9]/.test(raw[index] ?? '')) {
                syntaxError('invalid number exponent');
            }
            while (/[0-9]/.test(raw[index] ?? '')) {
                index += 1;
            }
        }
    };
    const parseLiteral = (literal: string) => {
        if (raw.slice(index, index + literal.length) !== literal) {
            syntaxError(`expected ${literal}`);
        }
        index += literal.length;
    };
    const parseArray = () => {
        expectChar('[');
        skipWhitespace();
        if (raw[index] === ']') {
            index += 1;
            return;
        }
        for (;;) {
            parseValue();
            skipWhitespace();
            if (raw[index] === ']') {
                index += 1;
                return;
            }
            expectChar(',');
            skipWhitespace();
        }
    };
    const parseObject = () => {
        expectChar('{');
        const keys = new Set<string>();
        skipWhitespace();
        if (raw[index] === '}') {
            index += 1;
            return;
        }
        for (;;) {
            skipWhitespace();
            if (raw[index] !== '"') {
                syntaxError('expected object key');
            }
            const key = parseString();
            if (keys.has(key)) {
                throw new DuplicateJsonObjectKeyError(`${label} contains duplicate JSON object key ${JSON.stringify(key)}.`);
            }
            keys.add(key);
            skipWhitespace();
            expectChar(':');
            parseValue();
            skipWhitespace();
            if (raw[index] === '}') {
                index += 1;
                return;
            }
            expectChar(',');
            skipWhitespace();
        }
    };
    const parseValue = () => {
        skipWhitespace();
        const character = raw[index];
        if (character === '{') {
            parseObject();
        } else if (character === '[') {
            parseArray();
        } else if (character === '"') {
            parseString();
        } else if (character === '-' || /[0-9]/.test(character ?? '')) {
            parseNumber();
        } else if (character === 't') {
            parseLiteral('true');
        } else if (character === 'f') {
            parseLiteral('false');
        } else if (character === 'n') {
            parseLiteral('null');
        } else {
            syntaxError('expected JSON value');
        }
    };

    parseValue();
    skipWhitespace();
    if (index !== raw.length) {
        syntaxError('unexpected trailing data');
    }
}
